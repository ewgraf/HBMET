﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nn4
{
    class Predict_Bottom
    {
        /**C# deployment code of Neural Networks Model**/

        public static string[] MLP_114_16_2(string[] CatInputs)
        {
            int Cat_idx = 0;

            string Var4 = CatInputs[Cat_idx++]; //Input Variable

            string Var6 = CatInputs[Cat_idx++]; //Input Variable

            string Var7 = CatInputs[Cat_idx++]; //Input Variable

            string Var8 = CatInputs[Cat_idx++]; //Input Variable

            string Var9 = CatInputs[Cat_idx++]; //Input Variable

            string Var10 = CatInputs[Cat_idx++]; //Input Variable

            string Var11 = CatInputs[Cat_idx++]; //Input Variable

            string Var12 = CatInputs[Cat_idx++]; //Input Variable

            string Var13 = CatInputs[Cat_idx++]; //Input Variable

            string Var14 = CatInputs[Cat_idx++]; //Input Variable

            string Var15 = CatInputs[Cat_idx++]; //Input Variable

            string Var16 = CatInputs[Cat_idx++]; //Input Variable

            string Var17 = CatInputs[Cat_idx++]; //Input Variable

            string Var19 = CatInputs[Cat_idx++]; //Input Variable

            string Var20 = CatInputs[Cat_idx++]; //Input Variable

            string Var21 = CatInputs[Cat_idx++]; //Input Variable

            string Var22 = CatInputs[Cat_idx++]; //Input Variable

            string Var23 = CatInputs[Cat_idx++]; //Input Variable

            string Var24 = CatInputs[Cat_idx++]; //Input Variable

            string Var25 = CatInputs[Cat_idx++]; //Input Variable

            string Var26 = CatInputs[Cat_idx++]; //Input Variable

            string Var27 = CatInputs[Cat_idx++]; //Input Variable

            string Var28 = CatInputs[Cat_idx++]; //Input Variable

            string Var29 = CatInputs[Cat_idx++]; //Input Variable

            string Var30 = CatInputs[Cat_idx++]; //Input Variable

            string __statist_PredCat = "";

            string[] __statist_DCats = new string[2];

            __statist_DCats[0] = "0";

            __statist_DCats[1] = "3";



            double __statist_ConfLevel = 3.0E-300;







            double[,] __statist_i_h_wts = new double[16, 114];



            __statist_i_h_wts[0, 0] = 9.35066299855685e-003;

            __statist_i_h_wts[0, 1] = -5.74696657776578e-002;

            __statist_i_h_wts[0, 2] = -4.62050388675673e-002;

            __statist_i_h_wts[0, 3] = -6.38539227231294e-002;

            __statist_i_h_wts[0, 4] = 2.90422971277792e-002;

            __statist_i_h_wts[0, 5] = 1.94730505730442e-002;

            __statist_i_h_wts[0, 6] = 6.76580097694717e-002;

            __statist_i_h_wts[0, 7] = 6.76874164037973e-002;

            __statist_i_h_wts[0, 8] = -3.47806632058264e-002;

            __statist_i_h_wts[0, 9] = 5.93054019311311e-002;

            __statist_i_h_wts[0, 10] = 3.95081793325182e-003;

            __statist_i_h_wts[0, 11] = 8.97782418412582e-002;

            __statist_i_h_wts[0, 12] = 5.33737335804322e-002;

            __statist_i_h_wts[0, 13] = 6.08303334599358e-002;

            __statist_i_h_wts[0, 14] = 4.68012110000154e-002;

            __statist_i_h_wts[0, 15] = 1.65718546362331e-003;

            __statist_i_h_wts[0, 16] = 2.47132342102055e-002;

            __statist_i_h_wts[0, 17] = -5.73971948441027e-002;

            __statist_i_h_wts[0, 18] = -9.98553353365297e-003;

            __statist_i_h_wts[0, 19] = -7.03810085006858e-002;

            __statist_i_h_wts[0, 20] = -9.53194235277845e-003;

            __statist_i_h_wts[0, 21] = -4.60077689226459e-002;

            __statist_i_h_wts[0, 22] = -8.31631021424893e-003;

            __statist_i_h_wts[0, 23] = -1.34809449854506e-002;

            __statist_i_h_wts[0, 24] = 2.71757046958883e-002;

            __statist_i_h_wts[0, 25] = -3.93591459796456e-002;

            __statist_i_h_wts[0, 26] = 5.87028613517249e-003;

            __statist_i_h_wts[0, 27] = 3.26811290044785e-003;

            __statist_i_h_wts[0, 28] = 4.14780826790504e-002;

            __statist_i_h_wts[0, 29] = -3.99493586924959e-002;

            __statist_i_h_wts[0, 30] = -3.02364227413575e-002;

            __statist_i_h_wts[0, 31] = 4.47364327999724e-002;

            __statist_i_h_wts[0, 32] = -5.05627965773917e-002;

            __statist_i_h_wts[0, 33] = 9.07197448481095e-003;

            __statist_i_h_wts[0, 34] = -6.22824814540821e-002;

            __statist_i_h_wts[0, 35] = 2.05363292267733e-002;

            __statist_i_h_wts[0, 36] = 1.08809076944714e-003;

            __statist_i_h_wts[0, 37] = 1.77524448578280e-002;

            __statist_i_h_wts[0, 38] = -3.32373620712968e-002;

            __statist_i_h_wts[0, 39] = -1.20787593511812e-002;

            __statist_i_h_wts[0, 40] = -4.71947653407222e-002;

            __statist_i_h_wts[0, 41] = -4.29488262736647e-003;

            __statist_i_h_wts[0, 42] = -1.65261207774962e-001;

            __statist_i_h_wts[0, 43] = 1.07624660920991e-001;

            __statist_i_h_wts[0, 44] = 7.51361142228607e-002;

            __statist_i_h_wts[0, 45] = -2.13482777770091e-001;

            __statist_i_h_wts[0, 46] = 1.12630000017636e-001;

            __statist_i_h_wts[0, 47] = 1.61892274355332e-001;

            __statist_i_h_wts[0, 48] = 1.07988460041002e+000;

            __statist_i_h_wts[0, 49] = -1.34288082106020e+000;

            __statist_i_h_wts[0, 50] = 3.10906037619816e-001;

            __statist_i_h_wts[0, 51] = -2.69276951808311e-001;

            __statist_i_h_wts[0, 52] = 1.88186718104437e-001;

            __statist_i_h_wts[0, 53] = 1.14317236776129e-001;

            __statist_i_h_wts[0, 54] = -1.00458156214818e-001;

            __statist_i_h_wts[0, 55] = 4.38369099925557e-002;

            __statist_i_h_wts[0, 56] = 9.20025634255889e-002;

            __statist_i_h_wts[0, 57] = -6.40930873512374e-002;

            __statist_i_h_wts[0, 58] = 3.30777803378300e-002;

            __statist_i_h_wts[0, 59] = 4.85779461429954e-002;

            __statist_i_h_wts[0, 60] = -2.43537200678229e-001;

            __statist_i_h_wts[0, 61] = 1.44344339602922e-001;

            __statist_i_h_wts[0, 62] = 1.37086503977717e-001;

            __statist_i_h_wts[0, 63] = 1.35970783340352e+000;

            __statist_i_h_wts[0, 64] = -1.80620937278656e+000;

            __statist_i_h_wts[0, 65] = 4.81674460558159e-001;

            __statist_i_h_wts[0, 66] = -2.02613100013798e-001;

            __statist_i_h_wts[0, 67] = 1.00863834419761e-001;

            __statist_i_h_wts[0, 68] = 1.52622444994930e-001;

            __statist_i_h_wts[0, 69] = -1.34038084367602e-001;

            __statist_i_h_wts[0, 70] = 4.37409551543089e-002;

            __statist_i_h_wts[0, 71] = 1.35307170227976e-001;

            __statist_i_h_wts[0, 72] = -1.41604405059833e+000;

            __statist_i_h_wts[0, 73] = 1.34939759870222e+000;

            __statist_i_h_wts[0, 74] = 1.20464033716562e-001;

            __statist_i_h_wts[0, 75] = -1.81950158908288e+000;

            __statist_i_h_wts[0, 76] = 1.53841991391115e+000;

            __statist_i_h_wts[0, 77] = 3.41249165132626e-001;

            __statist_i_h_wts[0, 78] = -1.61319144226493e+000;

            __statist_i_h_wts[0, 79] = 1.38000445341354e+000;

            __statist_i_h_wts[0, 80] = 2.58947344374608e-001;

            __statist_i_h_wts[0, 81] = -1.15892817935898e+000;

            __statist_i_h_wts[0, 82] = 9.77469173095956e-001;

            __statist_i_h_wts[0, 83] = 2.47524635359677e-001;

            __statist_i_h_wts[0, 84] = 3.44125091629906e-001;

            __statist_i_h_wts[0, 85] = -1.65116053503114e-001;

            __statist_i_h_wts[0, 86] = -1.44830815334103e-001;

            __statist_i_h_wts[0, 87] = 5.12838268763493e-002;

            __statist_i_h_wts[0, 88] = 2.70595065337545e-001;

            __statist_i_h_wts[0, 89] = -2.72804355093323e-001;

            __statist_i_h_wts[0, 90] = 2.29115091693233e+000;

            __statist_i_h_wts[0, 91] = -1.08445151529946e+000;

            __statist_i_h_wts[0, 92] = -1.18397113190717e+000;

            __statist_i_h_wts[0, 93] = 1.67342656990018e-001;

            __statist_i_h_wts[0, 94] = 9.10408758952506e-002;

            __statist_i_h_wts[0, 95] = -2.18898429935274e-001;

            __statist_i_h_wts[0, 96] = 3.21427973315442e-001;

            __statist_i_h_wts[0, 97] = -2.26051821211289e-001;

            __statist_i_h_wts[0, 98] = -7.58930250539614e-002;

            __statist_i_h_wts[0, 99] = 1.34996193860932e-001;

            __statist_i_h_wts[0, 100] = 9.59317751452269e-002;

            __statist_i_h_wts[0, 101] = -2.16492529889042e-001;

            __statist_i_h_wts[0, 102] = -9.57372040169147e-002;

            __statist_i_h_wts[0, 103] = 3.20217161716156e-001;

            __statist_i_h_wts[0, 104] = -1.79278998615074e-001;

            __statist_i_h_wts[0, 105] = 2.06322332432143e+000;

            __statist_i_h_wts[0, 106] = -1.13334228882285e+000;

            __statist_i_h_wts[0, 107] = -8.76435452821935e-001;

            __statist_i_h_wts[0, 108] = 1.39071181419701e-001;

            __statist_i_h_wts[0, 109] = 1.41426130181082e-002;

            __statist_i_h_wts[0, 110] = -1.08968902064044e-001;

            __statist_i_h_wts[0, 111] = 2.25432966268948e-001;

            __statist_i_h_wts[0, 112] = -1.40030849116074e-001;

            __statist_i_h_wts[0, 113] = -5.42867228332849e-002;



            __statist_i_h_wts[1, 0] = -8.15571569559170e-002;

            __statist_i_h_wts[1, 1] = -6.05029874400266e-002;

            __statist_i_h_wts[1, 2] = 2.43087291505967e-002;

            __statist_i_h_wts[1, 3] = 8.01188396863686e-002;

            __statist_i_h_wts[1, 4] = 4.95951924582797e-002;

            __statist_i_h_wts[1, 5] = -2.13680783763146e-002;

            __statist_i_h_wts[1, 6] = 1.33763333443588e-001;

            __statist_i_h_wts[1, 7] = 1.92421906493401e-002;

            __statist_i_h_wts[1, 8] = -3.20328012702472e-002;

            __statist_i_h_wts[1, 9] = -4.55217696991074e-002;

            __statist_i_h_wts[1, 10] = 1.23432515634930e-002;

            __statist_i_h_wts[1, 11] = 9.41152693425647e-002;

            __statist_i_h_wts[1, 12] = -6.34357070807082e-002;

            __statist_i_h_wts[1, 13] = -6.53945188601929e-002;

            __statist_i_h_wts[1, 14] = -6.03448001242569e-002;

            __statist_i_h_wts[1, 15] = 1.50720048315229e-001;

            __statist_i_h_wts[1, 16] = -1.39734020957558e-001;

            __statist_i_h_wts[1, 17] = -1.27784073534982e-001;

            __statist_i_h_wts[1, 18] = -7.96436148721631e-002;

            __statist_i_h_wts[1, 19] = -4.86193658774772e-003;

            __statist_i_h_wts[1, 20] = -1.57552935061837e-001;

            __statist_i_h_wts[1, 21] = -1.17324950365114e-001;

            __statist_i_h_wts[1, 22] = -7.19526528290113e-002;

            __statist_i_h_wts[1, 23] = 7.56602091599657e-002;

            __statist_i_h_wts[1, 24] = 1.00153805582368e-001;

            __statist_i_h_wts[1, 25] = -1.28799223155537e-001;

            __statist_i_h_wts[1, 26] = 3.37388000358584e-002;

            __statist_i_h_wts[1, 27] = 1.35064692535477e-002;

            __statist_i_h_wts[1, 28] = 2.20011319680175e-002;

            __statist_i_h_wts[1, 29] = -1.49470769631325e-002;

            __statist_i_h_wts[1, 30] = -4.35717550638974e-002;

            __statist_i_h_wts[1, 31] = -4.79278178824688e-002;

            __statist_i_h_wts[1, 32] = 2.95944994141769e-002;

            __statist_i_h_wts[1, 33] = -3.25979605024691e-002;

            __statist_i_h_wts[1, 34] = 1.21513934005182e-001;

            __statist_i_h_wts[1, 35] = 1.59337925951679e-002;

            __statist_i_h_wts[1, 36] = -1.37477209718073e-002;

            __statist_i_h_wts[1, 37] = -1.90969803160790e-002;

            __statist_i_h_wts[1, 38] = 1.94440113677540e-003;

            __statist_i_h_wts[1, 39] = 8.42381303068896e-002;

            __statist_i_h_wts[1, 40] = -6.64731185075281e-002;

            __statist_i_h_wts[1, 41] = 4.90078200423227e-002;

            __statist_i_h_wts[1, 42] = -8.18949699196455e-001;

            __statist_i_h_wts[1, 43] = 2.23600670467457e-001;

            __statist_i_h_wts[1, 44] = 2.49551969768130e-001;

            __statist_i_h_wts[1, 45] = -1.06256443645410e+000;

            __statist_i_h_wts[1, 46] = 4.44581966729628e-001;

            __statist_i_h_wts[1, 47] = 2.67433576747437e-001;

            __statist_i_h_wts[1, 48] = -7.36106093575304e-001;

            __statist_i_h_wts[1, 49] = -3.96912832199545e-001;

            __statist_i_h_wts[1, 50] = 7.97044571406012e-001;

            __statist_i_h_wts[1, 51] = -7.12827484443604e-001;

            __statist_i_h_wts[1, 52] = 4.91554298101795e-002;

            __statist_i_h_wts[1, 53] = 3.19179823599350e-001;

            __statist_i_h_wts[1, 54] = -7.00992724373434e-001;

            __statist_i_h_wts[1, 55] = 1.21965930343134e-001;

            __statist_i_h_wts[1, 56] = 2.44399350117252e-001;

            __statist_i_h_wts[1, 57] = -5.59160556571393e-001;

            __statist_i_h_wts[1, 58] = 9.12010576884951e-002;

            __statist_i_h_wts[1, 59] = 1.23855093753947e-001;

            __statist_i_h_wts[1, 60] = -6.09938091319017e-001;

            __statist_i_h_wts[1, 61] = -9.15028812061195e-002;

            __statist_i_h_wts[1, 62] = 3.48218025843122e-001;

            __statist_i_h_wts[1, 63] = -2.52682899884456e-001;

            __statist_i_h_wts[1, 64] = -1.62236190027919e+000;

            __statist_i_h_wts[1, 65] = 1.55163758369422e+000;

            __statist_i_h_wts[1, 66] = -4.99705296403751e-001;

            __statist_i_h_wts[1, 67] = -2.13439700632593e-001;

            __statist_i_h_wts[1, 68] = 3.68293410139327e-001;

            __statist_i_h_wts[1, 69] = -4.74670147368345e-001;

            __statist_i_h_wts[1, 70] = -9.77311888528757e-002;

            __statist_i_h_wts[1, 71] = 2.25703963477026e-001;

            __statist_i_h_wts[1, 72] = -1.06385680158998e+000;

            __statist_i_h_wts[1, 73] = 1.00186386285417e-001;

            __statist_i_h_wts[1, 74] = 6.32706151253889e-001;

            __statist_i_h_wts[1, 75] = -1.73658606710295e+000;

            __statist_i_h_wts[1, 76] = 2.50129240596160e-001;

            __statist_i_h_wts[1, 77] = 1.13252986036209e+000;

            __statist_i_h_wts[1, 78] = -1.96402755865147e+000;

            __statist_i_h_wts[1, 79] = 6.36299665759047e-001;

            __statist_i_h_wts[1, 80] = 9.96146437428899e-001;

            __statist_i_h_wts[1, 81] = -1.01634924717753e+000;

            __statist_i_h_wts[1, 82] = 1.17683823284454e-001;

            __statist_i_h_wts[1, 83] = 5.68733565999628e-001;

            __statist_i_h_wts[1, 84] = 4.91043430859361e-001;

            __statist_i_h_wts[1, 85] = -6.01128879315248e-001;

            __statist_i_h_wts[1, 86] = -2.29003604150491e-001;

            __statist_i_h_wts[1, 87] = 1.95968893113744e-001;

            __statist_i_h_wts[1, 88] = 1.56401621985360e-002;

            __statist_i_h_wts[1, 89] = -5.61279134600537e-001;

            __statist_i_h_wts[1, 90] = 3.73717775582446e+000;

            __statist_i_h_wts[1, 91] = -6.20528551030927e-001;

            __statist_i_h_wts[1, 92] = -3.47096687754559e+000;

            __statist_i_h_wts[1, 93] = 3.02346270230023e-001;

            __statist_i_h_wts[1, 94] = -2.99203526161655e-001;

            __statist_i_h_wts[1, 95] = -3.75043454187496e-001;

            __statist_i_h_wts[1, 96] = 4.05784820883065e-001;

            __statist_i_h_wts[1, 97] = -5.62901896000393e-001;

            __statist_i_h_wts[1, 98] = -1.80394836058792e-001;

            __statist_i_h_wts[1, 99] = 8.52167928289581e-002;

            __statist_i_h_wts[1, 100] = -1.67738700665767e-001;

            __statist_i_h_wts[1, 101] = -2.68789037895468e-001;

            __statist_i_h_wts[1, 102] = -2.46889070696166e-001;

            __statist_i_h_wts[1, 103] = 2.69688400072913e-001;

            __statist_i_h_wts[1, 104] = -3.37290020213493e-001;

            __statist_i_h_wts[1, 105] = 2.47226720946969e+000;

            __statist_i_h_wts[1, 106] = -5.71135357534863e-001;

            __statist_i_h_wts[1, 107] = -2.22931737013763e+000;

            __statist_i_h_wts[1, 108] = -7.82148966350410e-002;

            __statist_i_h_wts[1, 109] = 1.04408273176677e-001;

            __statist_i_h_wts[1, 110] = -3.50889230576746e-001;

            __statist_i_h_wts[1, 111] = -4.26587299420578e-002;

            __statist_i_h_wts[1, 112] = -1.96824428967890e-001;

            __statist_i_h_wts[1, 113] = -9.81153392812069e-002;



            __statist_i_h_wts[2, 0] = 1.99125667380093e-002;

            __statist_i_h_wts[2, 1] = -8.84175566829372e-002;

            __statist_i_h_wts[2, 2] = 2.14774962123570e-002;

            __statist_i_h_wts[2, 3] = -6.47187988970984e-002;

            __statist_i_h_wts[2, 4] = -4.30978437241280e-002;

            __statist_i_h_wts[2, 5] = -5.92941521916228e-002;

            __statist_i_h_wts[2, 6] = -9.50263691647489e-002;

            __statist_i_h_wts[2, 7] = -4.14977806719750e-002;

            __statist_i_h_wts[2, 8] = -2.02858837943134e-003;

            __statist_i_h_wts[2, 9] = 5.68373743883944e-002;

            __statist_i_h_wts[2, 10] = -4.74365343169789e-002;

            __statist_i_h_wts[2, 11] = -5.07611415485862e-002;

            __statist_i_h_wts[2, 12] = 1.65554225272876e-002;

            __statist_i_h_wts[2, 13] = 2.87104149162663e-002;

            __statist_i_h_wts[2, 14] = 8.35182905079216e-003;

            __statist_i_h_wts[2, 15] = -1.59780583070892e-001;

            __statist_i_h_wts[2, 16] = 3.27696830740738e-002;

            __statist_i_h_wts[2, 17] = 2.50448422622148e-002;

            __statist_i_h_wts[2, 18] = 1.62469643395944e-002;

            __statist_i_h_wts[2, 19] = -5.42050098307425e-002;

            __statist_i_h_wts[2, 20] = 4.46046394661932e-002;

            __statist_i_h_wts[2, 21] = 3.29848567769069e-002;

            __statist_i_h_wts[2, 22] = -6.66548959959382e-003;

            __statist_i_h_wts[2, 23] = -1.19911024375612e-001;

            __statist_i_h_wts[2, 24] = -7.77138979389052e-002;

            __statist_i_h_wts[2, 25] = 4.46764555888344e-002;

            __statist_i_h_wts[2, 26] = -2.65146776533669e-002;

            __statist_i_h_wts[2, 27] = -2.30578690935361e-002;

            __statist_i_h_wts[2, 28] = -1.25746324797268e-002;

            __statist_i_h_wts[2, 29] = -1.87539547246410e-002;

            __statist_i_h_wts[2, 30] = -8.73488074596184e-002;

            __statist_i_h_wts[2, 31] = -3.30864491258268e-002;

            __statist_i_h_wts[2, 32] = -9.65032324651222e-002;

            __statist_i_h_wts[2, 33] = 5.38930916554408e-002;

            __statist_i_h_wts[2, 34] = -1.44807646183579e-001;

            __statist_i_h_wts[2, 35] = -9.63274299109132e-002;

            __statist_i_h_wts[2, 36] = -8.07750964917029e-003;

            __statist_i_h_wts[2, 37] = -1.81482664081912e-002;

            __statist_i_h_wts[2, 38] = -1.38714992801958e-002;

            __statist_i_h_wts[2, 39] = -8.90650029673792e-002;

            __statist_i_h_wts[2, 40] = -2.30436139031001e-002;

            __statist_i_h_wts[2, 41] = -3.90934171674161e-002;

            __statist_i_h_wts[2, 42] = -6.50231001387843e-001;

            __statist_i_h_wts[2, 43] = -2.77100873252535e-001;

            __statist_i_h_wts[2, 44] = -2.32511332492447e-001;

            __statist_i_h_wts[2, 45] = -5.29630042671705e-001;

            __statist_i_h_wts[2, 46] = -3.48396848901564e-001;

            __statist_i_h_wts[2, 47] = -2.41464374588102e-001;

            __statist_i_h_wts[2, 48] = 2.27165819048761e+000;

            __statist_i_h_wts[2, 49] = -2.49470807383417e+000;

            __statist_i_h_wts[2, 50] = -9.48723166321084e-001;

            __statist_i_h_wts[2, 51] = -7.00557231352753e-001;

            __statist_i_h_wts[2, 52] = -2.34565099959656e-001;

            __statist_i_h_wts[2, 53] = -2.47607095519244e-001;

            __statist_i_h_wts[2, 54] = -7.88776815015986e-001;

            __statist_i_h_wts[2, 55] = -1.62573553157092e-001;

            __statist_i_h_wts[2, 56] = -2.14574105194026e-001;

            __statist_i_h_wts[2, 57] = -7.00371938445679e-001;

            __statist_i_h_wts[2, 58] = -3.12411891566337e-001;

            __statist_i_h_wts[2, 59] = -1.57541192982514e-001;

            __statist_i_h_wts[2, 60] = -7.10720870477589e-001;

            __statist_i_h_wts[2, 61] = -1.39093288648900e-001;

            __statist_i_h_wts[2, 62] = -3.21484102383707e-001;

            __statist_i_h_wts[2, 63] = 2.42696307425670e+000;

            __statist_i_h_wts[2, 64] = -2.01240488842800e+000;

            __statist_i_h_wts[2, 65] = -1.62450007975217e+000;

            __statist_i_h_wts[2, 66] = -7.31773764654412e-001;

            __statist_i_h_wts[2, 67] = -8.60170061494984e-002;

            __statist_i_h_wts[2, 68] = -3.64003180182039e-001;

            __statist_i_h_wts[2, 69] = -8.68974204114018e-001;

            __statist_i_h_wts[2, 70] = -7.13866393338511e-002;

            __statist_i_h_wts[2, 71] = -2.41775548470115e-001;

            __statist_i_h_wts[2, 72] = -2.05892373502039e+000;

            __statist_i_h_wts[2, 73] = 1.32045116868929e+000;

            __statist_i_h_wts[2, 74] = -4.42896670009113e-001;

            __statist_i_h_wts[2, 75] = -1.83680572109889e+000;

            __statist_i_h_wts[2, 76] = 1.44481600298177e+000;

            __statist_i_h_wts[2, 77] = -7.90715766692796e-001;

            __statist_i_h_wts[2, 78] = -1.61635813163127e+000;

            __statist_i_h_wts[2, 79] = 1.23047512428650e+000;

            __statist_i_h_wts[2, 80] = -8.06720135959123e-001;

            __statist_i_h_wts[2, 81] = -2.16904122856961e+000;

            __statist_i_h_wts[2, 82] = 1.41044235969879e+000;

            __statist_i_h_wts[2, 83] = -4.10259884571394e-001;

            __statist_i_h_wts[2, 84] = -9.05637967898996e-001;

            __statist_i_h_wts[2, 85] = -3.97278910366172e-001;

            __statist_i_h_wts[2, 86] = 1.52722412523527e-001;

            __statist_i_h_wts[2, 87] = -8.20607693621622e-001;

            __statist_i_h_wts[2, 88] = -6.71879713325842e-001;

            __statist_i_h_wts[2, 89] = 3.20084912776774e-001;

            __statist_i_h_wts[2, 90] = 6.35706097760600e-001;

            __statist_i_h_wts[2, 91] = -4.09288133838593e+000;

            __statist_i_h_wts[2, 92] = 2.28261834401252e+000;

            __statist_i_h_wts[2, 93] = -7.98094004500987e-001;

            __statist_i_h_wts[2, 94] = -5.76877578776074e-001;

            __statist_i_h_wts[2, 95] = 1.97680531978310e-001;

            __statist_i_h_wts[2, 96] = -9.17144770016207e-001;

            __statist_i_h_wts[2, 97] = -3.17327657898436e-001;

            __statist_i_h_wts[2, 98] = 5.66984932697310e-002;

            __statist_i_h_wts[2, 99] = -9.41071523648705e-001;

            __statist_i_h_wts[2, 100] = -4.28121799667360e-001;

            __statist_i_h_wts[2, 101] = 1.74779363171676e-001;

            __statist_i_h_wts[2, 102] = -7.54407714238134e-001;

            __statist_i_h_wts[2, 103] = -6.31451432040408e-001;

            __statist_i_h_wts[2, 104] = 2.28544779668132e-001;

            __statist_i_h_wts[2, 105] = 8.79400051384007e-001;

            __statist_i_h_wts[2, 106] = -3.44855607716437e+000;

            __statist_i_h_wts[2, 107] = 1.37180740565915e+000;

            __statist_i_h_wts[2, 108] = -7.30118449812940e-001;

            __statist_i_h_wts[2, 109] = -6.92329708022418e-001;

            __statist_i_h_wts[2, 110] = 2.33249158311418e-001;

            __statist_i_h_wts[2, 111] = -8.46171824109998e-001;

            __statist_i_h_wts[2, 112] = -3.97080842598293e-001;

            __statist_i_h_wts[2, 113] = 5.87286810207992e-002;



            __statist_i_h_wts[3, 0] = -1.07044300625920e-001;

            __statist_i_h_wts[3, 1] = -1.17508894685741e-001;

            __statist_i_h_wts[3, 2] = 2.13566668423211e-002;

            __statist_i_h_wts[3, 3] = 7.89112620448790e-002;

            __statist_i_h_wts[3, 4] = 2.29198417403723e-002;

            __statist_i_h_wts[3, 5] = -3.03159347064825e-002;

            __statist_i_h_wts[3, 6] = 5.96535906735266e-002;

            __statist_i_h_wts[3, 7] = -1.03633211964527e-002;

            __statist_i_h_wts[3, 8] = -2.22172765134173e-002;

            __statist_i_h_wts[3, 9] = 3.35353633893751e-002;

            __statist_i_h_wts[3, 10] = -5.78317679256714e-002;

            __statist_i_h_wts[3, 11] = 2.34925758811743e-003;

            __statist_i_h_wts[3, 12] = 7.02186343091956e-002;

            __statist_i_h_wts[3, 13] = -2.59193288958197e-002;

            __statist_i_h_wts[3, 14] = -6.00238424890751e-003;

            __statist_i_h_wts[3, 15] = 7.59650516689897e-002;

            __statist_i_h_wts[3, 16] = -5.39082338472258e-002;

            __statist_i_h_wts[3, 17] = -3.56896683247498e-003;

            __statist_i_h_wts[3, 18] = -3.82224477043224e-002;

            __statist_i_h_wts[3, 19] = -1.57961720495489e-002;

            __statist_i_h_wts[3, 20] = -2.14273540389671e-002;

            __statist_i_h_wts[3, 21] = -5.08679516084275e-002;

            __statist_i_h_wts[3, 22] = -6.75658397572444e-002;

            __statist_i_h_wts[3, 23] = -6.98351611013473e-002;

            __statist_i_h_wts[3, 24] = 1.32944042887345e-001;

            __statist_i_h_wts[3, 25] = 5.26972633615414e-002;

            __statist_i_h_wts[3, 26] = 9.32337271527923e-002;

            __statist_i_h_wts[3, 27] = 2.93864324958038e-004;

            __statist_i_h_wts[3, 28] = 4.98514677076036e-002;

            __statist_i_h_wts[3, 29] = 4.38959487232316e-002;

            __statist_i_h_wts[3, 30] = -8.94645194188742e-002;

            __statist_i_h_wts[3, 31] = -6.32038069807941e-002;

            __statist_i_h_wts[3, 32] = -4.18147043802258e-002;

            __statist_i_h_wts[3, 33] = 7.28852630343867e-003;

            __statist_i_h_wts[3, 34] = 3.64475920766910e-002;

            __statist_i_h_wts[3, 35] = -7.84326814368148e-003;

            __statist_i_h_wts[3, 36] = -2.33249649830849e-002;

            __statist_i_h_wts[3, 37] = -5.54873539077980e-002;

            __statist_i_h_wts[3, 38] = 6.50262350075019e-002;

            __statist_i_h_wts[3, 39] = -1.37296077024289e-002;

            __statist_i_h_wts[3, 40] = -1.08654596137423e-001;

            __statist_i_h_wts[3, 41] = -1.91128051021561e-002;

            __statist_i_h_wts[3, 42] = -2.43946140933882e-001;

            __statist_i_h_wts[3, 43] = -6.60913770798205e-002;

            __statist_i_h_wts[3, 44] = 1.03096595583209e-002;

            __statist_i_h_wts[3, 45] = -1.80514244689629e-001;

            __statist_i_h_wts[3, 46] = -1.22760277104917e-001;

            __statist_i_h_wts[3, 47] = 2.27023202457365e-002;

            __statist_i_h_wts[3, 48] = 1.16387846106305e+000;

            __statist_i_h_wts[3, 49] = -1.37857146647818e+000;

            __statist_i_h_wts[3, 50] = -5.04161953298812e-002;

            __statist_i_h_wts[3, 51] = -2.38141625707081e-001;

            __statist_i_h_wts[3, 52] = 6.45561910945248e-002;

            __statist_i_h_wts[3, 53] = -1.19089567713360e-001;

            __statist_i_h_wts[3, 54] = -1.71357299343484e-001;

            __statist_i_h_wts[3, 55] = -1.40829464809092e-001;

            __statist_i_h_wts[3, 56] = 1.53642010454923e-002;

            __statist_i_h_wts[3, 57] = -1.38066608614892e-001;

            __statist_i_h_wts[3, 58] = -1.24130400153738e-001;

            __statist_i_h_wts[3, 59] = -2.03006957991613e-002;

            __statist_i_h_wts[3, 60] = -1.54496127284667e-001;

            __statist_i_h_wts[3, 61] = -1.81965057704189e-001;

            __statist_i_h_wts[3, 62] = 5.88043257180171e-002;

            __statist_i_h_wts[3, 63] = 1.46448091998844e+000;

            __statist_i_h_wts[3, 64] = -1.71848562188332e+000;

            __statist_i_h_wts[3, 65] = -1.58914538441431e-002;

            __statist_i_h_wts[3, 66] = -1.50112913338270e-001;

            __statist_i_h_wts[3, 67] = -1.17158752945947e-001;

            __statist_i_h_wts[3, 68] = 1.73291058290056e-002;

            __statist_i_h_wts[3, 69] = 6.96608651783190e-002;

            __statist_i_h_wts[3, 70] = -1.78574371948580e-001;

            __statist_i_h_wts[3, 71] = -1.72077219902645e-001;

            __statist_i_h_wts[3, 72] = -1.24878124921748e+000;

            __statist_i_h_wts[3, 73] = 8.41814492990496e-001;

            __statist_i_h_wts[3, 74] = 1.24598429158449e-001;

            __statist_i_h_wts[3, 75] = -1.69067394356840e+000;

            __statist_i_h_wts[3, 76] = 1.29855253588639e+000;

            __statist_i_h_wts[3, 77] = 1.25745963149599e-001;

            __statist_i_h_wts[3, 78] = -1.74254238147863e+000;

            __statist_i_h_wts[3, 79] = 1.26138988329942e+000;

            __statist_i_h_wts[3, 80] = 2.10592189413686e-001;

            __statist_i_h_wts[3, 81] = -1.23049082455429e+000;

            __statist_i_h_wts[3, 82] = 7.25177143047518e-001;

            __statist_i_h_wts[3, 83] = 2.13633060426958e-001;

            __statist_i_h_wts[3, 84] = -1.10741750428210e-002;

            __statist_i_h_wts[3, 85] = -2.62725472305618e-001;

            __statist_i_h_wts[3, 86] = -2.00822516182304e-002;

            __statist_i_h_wts[3, 87] = -2.18679293521392e-001;

            __statist_i_h_wts[3, 88] = 1.40560276695375e-002;

            __statist_i_h_wts[3, 89] = -7.03655534871099e-002;

            __statist_i_h_wts[3, 90] = 1.82007879942125e+000;

            __statist_i_h_wts[3, 91] = -1.48334477023369e+000;

            __statist_i_h_wts[3, 92] = -6.00500106509125e-001;

            __statist_i_h_wts[3, 93] = -3.56049596917553e-001;

            __statist_i_h_wts[3, 94] = 2.01315576879462e-001;

            __statist_i_h_wts[3, 95] = -1.15477831386742e-001;

            __statist_i_h_wts[3, 96] = -3.30985418952195e-002;

            __statist_i_h_wts[3, 97] = -1.74458340332289e-001;

            __statist_i_h_wts[3, 98] = -4.35123303586375e-002;

            __statist_i_h_wts[3, 99] = -2.15203592597580e-001;

            __statist_i_h_wts[3, 100] = -1.10817344962814e-001;

            __statist_i_h_wts[3, 101] = 6.48717102332740e-002;

            __statist_i_h_wts[3, 102] = -2.54119038151344e-001;

            __statist_i_h_wts[3, 103] = 5.68221621904470e-002;

            __statist_i_h_wts[3, 104] = -9.25601994854245e-002;

            __statist_i_h_wts[3, 105] = 1.30576235143774e+000;

            __statist_i_h_wts[3, 106] = -1.17477275251469e+000;

            __statist_i_h_wts[3, 107] = -3.97185343932192e-001;

            __statist_i_h_wts[3, 108] = -3.99189423561903e-001;

            __statist_i_h_wts[3, 109] = 1.93381710306928e-001;

            __statist_i_h_wts[3, 110] = -6.54687237611477e-002;

            __statist_i_h_wts[3, 111] = -1.62784604990794e-002;

            __statist_i_h_wts[3, 112] = -2.48061301756424e-001;

            __statist_i_h_wts[3, 113] = -1.84787653008167e-002;



            __statist_i_h_wts[4, 0] = -1.54887645378111e-001;

            __statist_i_h_wts[4, 1] = -5.26536551300626e-002;

            __statist_i_h_wts[4, 2] = -1.71844336995852e-002;

            __statist_i_h_wts[4, 3] = 3.29672964046411e-002;

            __statist_i_h_wts[4, 4] = -1.79410842542236e-002;

            __statist_i_h_wts[4, 5] = -1.15206031464234e-001;

            __statist_i_h_wts[4, 6] = 4.58546188939373e-002;

            __statist_i_h_wts[4, 7] = 2.27185215861242e-001;

            __statist_i_h_wts[4, 8] = -1.25128217016512e-001;

            __statist_i_h_wts[4, 9] = 5.29553414066973e-002;

            __statist_i_h_wts[4, 10] = -1.06498654933062e-001;

            __statist_i_h_wts[4, 11] = 2.80377354197955e-002;

            __statist_i_h_wts[4, 12] = 3.18933026034353e-002;

            __statist_i_h_wts[4, 13] = 7.34599811299881e-002;

            __statist_i_h_wts[4, 14] = 6.27604196360621e-002;

            __statist_i_h_wts[4, 15] = 1.55322437483569e-001;

            __statist_i_h_wts[4, 16] = -1.44913763452075e-001;

            __statist_i_h_wts[4, 17] = -2.53872195149617e-002;

            __statist_i_h_wts[4, 18] = -9.99535244045373e-002;

            __statist_i_h_wts[4, 19] = -9.07773901507563e-003;

            __statist_i_h_wts[4, 20] = 5.62535165521421e-002;

            __statist_i_h_wts[4, 21] = -1.56544334556683e-001;

            __statist_i_h_wts[4, 22] = -7.19666634325606e-002;

            __statist_i_h_wts[4, 23] = 1.61034422382477e-002;

            __statist_i_h_wts[4, 24] = 1.15647106474995e-001;

            __statist_i_h_wts[4, 25] = -7.81833926713556e-002;

            __statist_i_h_wts[4, 26] = 4.01312270601178e-002;

            __statist_i_h_wts[4, 27] = -1.54382079205705e-001;

            __statist_i_h_wts[4, 28] = 1.17992436013054e-001;

            __statist_i_h_wts[4, 29] = 2.28958677034862e-002;

            __statist_i_h_wts[4, 30] = -3.87060517147063e-002;

            __statist_i_h_wts[4, 31] = -1.05680277117933e-001;

            __statist_i_h_wts[4, 32] = -9.88172364889830e-002;

            __statist_i_h_wts[4, 33] = -2.03970671756117e-002;

            __statist_i_h_wts[4, 34] = 5.24077327823475e-002;

            __statist_i_h_wts[4, 35] = 9.83554399326843e-002;

            __statist_i_h_wts[4, 36] = -7.92056793845612e-003;

            __statist_i_h_wts[4, 37] = -1.87742200302162e-002;

            __statist_i_h_wts[4, 38] = 3.13922081135383e-002;

            __statist_i_h_wts[4, 39] = -2.92183961632002e-003;

            __statist_i_h_wts[4, 40] = -1.23049770621482e-001;

            __statist_i_h_wts[4, 41] = 6.46276107793865e-002;

            __statist_i_h_wts[4, 42] = -1.60946071450460e-001;

            __statist_i_h_wts[4, 43] = -2.82655119218300e-001;

            __statist_i_h_wts[4, 44] = 2.44883230639318e-002;

            __statist_i_h_wts[4, 45] = 6.17951258247604e-003;

            __statist_i_h_wts[4, 46] = -3.90227705878323e-001;

            __statist_i_h_wts[4, 47] = 1.57005771961908e-002;

            __statist_i_h_wts[4, 48] = 7.45114098401743e-001;

            __statist_i_h_wts[4, 49] = -1.45015998259964e+000;

            __statist_i_h_wts[4, 50] = 2.90179933342708e-001;

            __statist_i_h_wts[4, 51] = -1.73860151562414e-001;

            __statist_i_h_wts[4, 52] = -2.47843657647391e-001;

            __statist_i_h_wts[4, 53] = 4.16115944567044e-002;

            __statist_i_h_wts[4, 54] = -9.18222360081684e-002;

            __statist_i_h_wts[4, 55] = -3.85688767024735e-001;

            __statist_i_h_wts[4, 56] = 9.39461582233895e-002;

            __statist_i_h_wts[4, 57] = -2.18676887113018e-001;

            __statist_i_h_wts[4, 58] = -2.05541922305284e-001;

            __statist_i_h_wts[4, 59] = 5.12084209789880e-002;

            __statist_i_h_wts[4, 60] = -4.85797753600863e-002;

            __statist_i_h_wts[4, 61] = -3.73555314857262e-001;

            __statist_i_h_wts[4, 62] = 4.96637291526659e-002;

            __statist_i_h_wts[4, 63] = 9.89534654730199e-001;

            __statist_i_h_wts[4, 64] = -1.97831790612546e+000;

            __statist_i_h_wts[4, 65] = 6.29304795419046e-001;

            __statist_i_h_wts[4, 66] = -3.10547489801285e-001;

            __statist_i_h_wts[4, 67] = -1.96022123262412e-001;

            __statist_i_h_wts[4, 68] = 1.26070516206749e-001;

            __statist_i_h_wts[4, 69] = -4.23635359408254e-002;

            __statist_i_h_wts[4, 70] = -3.51572640508096e-001;

            __statist_i_h_wts[4, 71] = -4.67039187405050e-003;

            __statist_i_h_wts[4, 72] = -8.18662797516432e-001;

            __statist_i_h_wts[4, 73] = 1.05449066695907e-001;

            __statist_i_h_wts[4, 74] = 3.07406318453107e-001;

            __statist_i_h_wts[4, 75] = -1.23873423756422e+000;

            __statist_i_h_wts[4, 76] = 4.82313031665145e-001;

            __statist_i_h_wts[4, 77] = 3.51882082183671e-001;

            __statist_i_h_wts[4, 78] = -1.47869950888623e+000;

            __statist_i_h_wts[4, 79] = 5.17898115167488e-001;

            __statist_i_h_wts[4, 80] = 5.72460061434927e-001;

            __statist_i_h_wts[4, 81] = -9.63281754780683e-001;

            __statist_i_h_wts[4, 82] = 1.85399036140936e-001;

            __statist_i_h_wts[4, 83] = 3.92343986309330e-001;

            __statist_i_h_wts[4, 84] = -7.15835489612050e-002;

            __statist_i_h_wts[4, 85] = -1.18387632039430e-001;

            __statist_i_h_wts[4, 86] = -1.71860162517163e-001;

            __statist_i_h_wts[4, 87] = -3.19732656878942e-001;

            __statist_i_h_wts[4, 88] = 3.73584698832584e-001;

            __statist_i_h_wts[4, 89] = -4.48110343824505e-001;

            __statist_i_h_wts[4, 90] = 1.97250431944577e+000;

            __statist_i_h_wts[4, 91] = -8.04721455877623e-001;

            __statist_i_h_wts[4, 92] = -1.56153439925541e+000;

            __statist_i_h_wts[4, 93] = -5.61576032880683e-001;

            __statist_i_h_wts[4, 94] = 1.88445811898710e-001;

            __statist_i_h_wts[4, 95] = -1.23601555712531e-002;

            __statist_i_h_wts[4, 96] = -2.51974215454716e-001;

            __statist_i_h_wts[4, 97] = -1.02659969980620e-001;

            __statist_i_h_wts[4, 98] = -3.79993508287443e-002;

            __statist_i_h_wts[4, 99] = 1.01429291206285e-002;

            __statist_i_h_wts[4, 100] = -3.20158597841730e-001;

            __statist_i_h_wts[4, 101] = -9.43720020204832e-002;

            __statist_i_h_wts[4, 102] = -4.42429151807288e-001;

            __statist_i_h_wts[4, 103] = 3.45160494371516e-001;

            __statist_i_h_wts[4, 104] = -2.96198924834033e-001;

            __statist_i_h_wts[4, 105] = 1.11733361244267e+000;

            __statist_i_h_wts[4, 106] = -8.92244949287976e-001;

            __statist_i_h_wts[4, 107] = -6.33316052317133e-001;

            __statist_i_h_wts[4, 108] = -5.92389318550549e-001;

            __statist_i_h_wts[4, 109] = 3.05227835599160e-001;

            __statist_i_h_wts[4, 110] = -1.14030765666150e-001;

            __statist_i_h_wts[4, 111] = -3.48819752574165e-001;

            __statist_i_h_wts[4, 112] = 6.25838253255375e-002;

            __statist_i_h_wts[4, 113] = -9.75379245381552e-002;



            __statist_i_h_wts[5, 0] = -1.12065932242761e-001;

            __statist_i_h_wts[5, 1] = -1.78154602335710e-001;

            __statist_i_h_wts[5, 2] = 3.87129232567353e-002;

            __statist_i_h_wts[5, 3] = 1.23693513253756e-001;

            __statist_i_h_wts[5, 4] = 8.07536476899709e-002;

            __statist_i_h_wts[5, 5] = -5.36637048269725e-002;

            __statist_i_h_wts[5, 6] = 1.59254510338688e-001;

            __statist_i_h_wts[5, 7] = -3.99946642186299e-002;

            __statist_i_h_wts[5, 8] = -9.46489460911081e-002;

            __statist_i_h_wts[5, 9] = -2.67126143649731e-002;

            __statist_i_h_wts[5, 10] = -2.71274899672157e-002;

            __statist_i_h_wts[5, 11] = 1.26413901454463e-001;

            __statist_i_h_wts[5, 12] = -7.42171343277710e-002;

            __statist_i_h_wts[5, 13] = -1.38723211296518e-001;

            __statist_i_h_wts[5, 14] = -7.45174736916074e-002;

            __statist_i_h_wts[5, 15] = 1.89020515673647e-001;

            __statist_i_h_wts[5, 16] = -1.67189002972211e-001;

            __statist_i_h_wts[5, 17] = -1.47200981808266e-001;

            __statist_i_h_wts[5, 18] = -9.59848328434238e-002;

            __statist_i_h_wts[5, 19] = -5.40270892780388e-003;

            __statist_i_h_wts[5, 20] = -2.30112260806258e-001;

            __statist_i_h_wts[5, 21] = -1.93915721478993e-001;

            __statist_i_h_wts[5, 22] = -9.06938282836173e-002;

            __statist_i_h_wts[5, 23] = 8.75552436765002e-002;

            __statist_i_h_wts[5, 24] = 1.01443656747381e-001;

            __statist_i_h_wts[5, 25] = -1.67555519612938e-001;

            __statist_i_h_wts[5, 26] = 4.87902616186784e-002;

            __statist_i_h_wts[5, 27] = -2.01792401021572e-002;

            __statist_i_h_wts[5, 28] = 1.71505465015931e-002;

            __statist_i_h_wts[5, 29] = -3.64590843749593e-002;

            __statist_i_h_wts[5, 30] = -1.38367568857980e-001;

            __statist_i_h_wts[5, 31] = -4.86629113609627e-002;

            __statist_i_h_wts[5, 32] = 4.85176066361074e-002;

            __statist_i_h_wts[5, 33] = -8.71539941782668e-002;

            __statist_i_h_wts[5, 34] = 1.15861721639664e-001;

            __statist_i_h_wts[5, 35] = 3.46672788004866e-002;

            __statist_i_h_wts[5, 36] = -8.15067367870523e-003;

            __statist_i_h_wts[5, 37] = -2.40525625373324e-002;

            __statist_i_h_wts[5, 38] = 2.81961089081426e-002;

            __statist_i_h_wts[5, 39] = 9.81968692349276e-002;

            __statist_i_h_wts[5, 40] = -1.99608083804505e-001;

            __statist_i_h_wts[5, 41] = 4.06740739435666e-002;

            __statist_i_h_wts[5, 42] = -1.57813838641739e+000;

            __statist_i_h_wts[5, 43] = 1.65230149414630e-001;

            __statist_i_h_wts[5, 44] = 2.97823748260909e-001;

            __statist_i_h_wts[5, 45] = -1.83431489247877e+000;

            __statist_i_h_wts[5, 46] = 4.10487537032253e-001;

            __statist_i_h_wts[5, 47] = 3.01480057236149e-001;

            __statist_i_h_wts[5, 48] = -2.24769800728053e+000;

            __statist_i_h_wts[5, 49] = 1.96852841335807e-001;

            __statist_i_h_wts[5, 50] = 9.12088931673538e-001;

            __statist_i_h_wts[5, 51] = -1.50897162252909e+000;

            __statist_i_h_wts[5, 52] = 9.47188997325800e-002;

            __statist_i_h_wts[5, 53] = 2.96285441053508e-001;

            __statist_i_h_wts[5, 54] = -1.60631682428657e+000;

            __statist_i_h_wts[5, 55] = 1.90170727566088e-001;

            __statist_i_h_wts[5, 56] = 3.16503107053538e-001;

            __statist_i_h_wts[5, 57] = -1.50896458922901e+000;

            __statist_i_h_wts[5, 58] = 2.35909998270417e-001;

            __statist_i_h_wts[5, 59] = 1.71850628532029e-001;

            __statist_i_h_wts[5, 60] = -1.56244775587386e+000;

            __statist_i_h_wts[5, 61] = 5.97341980450160e-002;

            __statist_i_h_wts[5, 62] = 3.93727921556857e-001;

            __statist_i_h_wts[5, 63] = -1.92389520978436e+000;

            __statist_i_h_wts[5, 64] = -1.00187510700360e+000;

            __statist_i_h_wts[5, 65] = 1.79403533417147e+000;

            __statist_i_h_wts[5, 66] = -1.46025396737044e+000;

            __statist_i_h_wts[5, 67] = -1.03313377686503e-001;

            __statist_i_h_wts[5, 68] = 4.42056130829821e-001;

            __statist_i_h_wts[5, 69] = -1.46981576844024e+000;

            __statist_i_h_wts[5, 70] = 1.49069811222307e-001;

            __statist_i_h_wts[5, 71] = 2.20045885551940e-001;

            __statist_i_h_wts[5, 72] = -4.79089853621099e-001;

            __statist_i_h_wts[5, 73] = -1.40566243836529e+000;

            __statist_i_h_wts[5, 74] = 7.69573191911390e-001;

            __statist_i_h_wts[5, 75] = -1.36377739304206e+000;

            __statist_i_h_wts[5, 76] = -1.15996837812774e+000;

            __statist_i_h_wts[5, 77] = 1.41864507411743e+000;

            __statist_i_h_wts[5, 78] = -1.59134745929531e+000;

            __statist_i_h_wts[5, 79] = -7.63769211549418e-001;

            __statist_i_h_wts[5, 80] = 1.23200952255665e+000;

            __statist_i_h_wts[5, 81] = -5.69480403607440e-001;

            __statist_i_h_wts[5, 82] = -1.27679701101894e+000;

            __statist_i_h_wts[5, 83] = 7.36469777862171e-001;

            __statist_i_h_wts[5, 84] = 5.25458037197571e-001;

            __statist_i_h_wts[5, 85] = -1.35710892416259e+000;

            __statist_i_h_wts[5, 86] = -2.90245133601320e-001;

            __statist_i_h_wts[5, 87] = 8.69787701844333e-004;

            __statist_i_h_wts[5, 88] = -2.66767090464827e-001;

            __statist_i_h_wts[5, 89] = -8.36723720546354e-001;

            __statist_i_h_wts[5, 90] = 4.76487637900036e+000;

            __statist_i_h_wts[5, 91] = -1.07346628597124e+000;

            __statist_i_h_wts[5, 92] = -4.81988167285524e+000;

            __statist_i_h_wts[5, 93] = 1.38592266671473e-001;

            __statist_i_h_wts[5, 94] = -7.51296086950812e-001;

            __statist_i_h_wts[5, 95] = -5.08335988930178e-001;

            __statist_i_h_wts[5, 96] = 1.88316078603154e-001;

            __statist_i_h_wts[5, 97] = -9.93472798624162e-001;

            __statist_i_h_wts[5, 98] = -2.84771691594908e-001;

            __statist_i_h_wts[5, 99] = -1.72772534000693e-001;

            __statist_i_h_wts[5, 100] = -5.90280991707982e-001;

            __statist_i_h_wts[5, 101] = -3.46498379126825e-001;

            __statist_i_h_wts[5, 102] = -7.66560109506480e-001;

            __statist_i_h_wts[5, 103] = 1.62150413005165e-001;

            __statist_i_h_wts[5, 104] = -4.80083452204992e-001;

            __statist_i_h_wts[5, 105] = 2.71911187193638e+000;

            __statist_i_h_wts[5, 106] = -7.56342674062414e-001;

            __statist_i_h_wts[5, 107] = -3.05177912753999e+000;

            __statist_i_h_wts[5, 108] = -4.82430098910323e-001;

            __statist_i_h_wts[5, 109] = -1.54981419905987e-001;

            __statist_i_h_wts[5, 110] = -4.97224688381398e-001;

            __statist_i_h_wts[5, 111] = -4.50889964692940e-001;

            __statist_i_h_wts[5, 112] = -5.53524291315783e-001;

            __statist_i_h_wts[5, 113] = -9.53425746842174e-002;



            __statist_i_h_wts[6, 0] = -1.01777912555453e-001;

            __statist_i_h_wts[6, 1] = 3.17236640678056e-002;

            __statist_i_h_wts[6, 2] = 4.34906448640869e-002;

            __statist_i_h_wts[6, 3] = 1.31545042783964e-001;

            __statist_i_h_wts[6, 4] = 9.18776187627726e-002;

            __statist_i_h_wts[6, 5] = -7.58888142702708e-002;

            __statist_i_h_wts[6, 6] = 1.11616801575687e-001;

            __statist_i_h_wts[6, 7] = 1.32039082990654e-001;

            __statist_i_h_wts[6, 8] = -6.69997901589898e-002;

            __statist_i_h_wts[6, 9] = -4.32077590816892e-002;

            __statist_i_h_wts[6, 10] = -3.26169055850799e-002;

            __statist_i_h_wts[6, 11] = 7.27680801835703e-002;

            __statist_i_h_wts[6, 12] = -2.62295105824652e-002;

            __statist_i_h_wts[6, 13] = -8.19683565040425e-002;

            __statist_i_h_wts[6, 14] = -2.46998758907656e-002;

            __statist_i_h_wts[6, 15] = 1.29849940768884e-001;

            __statist_i_h_wts[6, 16] = -1.44424886209046e-001;

            __statist_i_h_wts[6, 17] = -4.36164094040806e-002;

            __statist_i_h_wts[6, 18] = -6.24461813936478e-002;

            __statist_i_h_wts[6, 19] = -2.29869748186368e-002;

            __statist_i_h_wts[6, 20] = -3.76785636618254e-002;

            __statist_i_h_wts[6, 21] = -1.93369681767516e-001;

            __statist_i_h_wts[6, 22] = -7.82759491288055e-002;

            __statist_i_h_wts[6, 23] = 4.72845209052141e-002;

            __statist_i_h_wts[6, 24] = 1.41042918869731e-001;

            __statist_i_h_wts[6, 25] = -7.02353722985475e-002;

            __statist_i_h_wts[6, 26] = 1.78366381250740e-002;

            __statist_i_h_wts[6, 27] = -1.92470439024485e-002;

            __statist_i_h_wts[6, 28] = 4.44132667646468e-002;

            __statist_i_h_wts[6, 29] = 2.58528148755438e-002;

            __statist_i_h_wts[6, 30] = -1.27767424451547e-001;

            __statist_i_h_wts[6, 31] = -8.83485945338656e-002;

            __statist_i_h_wts[6, 32] = 3.50854640775416e-002;

            __statist_i_h_wts[6, 33] = -1.44900320486353e-002;

            __statist_i_h_wts[6, 34] = 1.69773825161419e-001;

            __statist_i_h_wts[6, 35] = 6.00274764565631e-002;

            __statist_i_h_wts[6, 36] = 5.35269154741327e-004;

            __statist_i_h_wts[6, 37] = -3.13916853112343e-002;

            __statist_i_h_wts[6, 38] = 1.06614152197050e-001;

            __statist_i_h_wts[6, 39] = 5.80957079624940e-002;

            __statist_i_h_wts[6, 40] = -1.39340444477395e-001;

            __statist_i_h_wts[6, 41] = 2.86269677200913e-002;

            __statist_i_h_wts[6, 42] = -3.91287336438270e-001;

            __statist_i_h_wts[6, 43] = 1.91850060384199e-001;

            __statist_i_h_wts[6, 44] = 2.05711164813520e-001;

            __statist_i_h_wts[6, 45] = -5.00479044151894e-001;

            __statist_i_h_wts[6, 46] = 3.47986710421994e-001;

            __statist_i_h_wts[6, 47] = 1.46976588992307e-001;

            __statist_i_h_wts[6, 48] = -4.08699876234731e-002;

            __statist_i_h_wts[6, 49] = -5.72186014418287e-001;

            __statist_i_h_wts[6, 50] = 6.19768833848919e-001;

            __statist_i_h_wts[6, 51] = -1.95359527616735e-001;

            __statist_i_h_wts[6, 52] = -1.26158487937679e-003;

            __statist_i_h_wts[6, 53] = 2.05020535919950e-001;

            __statist_i_h_wts[6, 54] = -3.50443700724386e-001;

            __statist_i_h_wts[6, 55] = 1.16572414468947e-001;

            __statist_i_h_wts[6, 56] = 2.30720123670137e-001;

            __statist_i_h_wts[6, 57] = -3.27626428777185e-001;

            __statist_i_h_wts[6, 58] = 2.06206279105981e-001;

            __statist_i_h_wts[6, 59] = 1.24179485043385e-001;

            __statist_i_h_wts[6, 60] = -2.34264580977457e-001;

            __statist_i_h_wts[6, 61] = -3.43500129969503e-002;

            __statist_i_h_wts[6, 62] = 2.70520630991915e-001;

            __statist_i_h_wts[6, 63] = 1.66789417028112e-001;

            __statist_i_h_wts[6, 64] = -1.41881092798880e+000;

            __statist_i_h_wts[6, 65] = 1.28343294255974e+000;

            __statist_i_h_wts[6, 66] = -1.52883388916967e-001;

            __statist_i_h_wts[6, 67] = -1.93115802172412e-001;

            __statist_i_h_wts[6, 68] = 3.29047732931779e-001;

            __statist_i_h_wts[6, 69] = 2.08200415337928e-002;

            __statist_i_h_wts[6, 70] = -1.01146736296985e-001;

            __statist_i_h_wts[6, 71] = 8.16695509739382e-002;

            __statist_i_h_wts[6, 72] = -8.31862275730255e-001;

            __statist_i_h_wts[6, 73] = 2.56923549149668e-001;

            __statist_i_h_wts[6, 74] = 5.94880721079766e-001;

            __statist_i_h_wts[6, 75] = -1.55157871548062e+000;

            __statist_i_h_wts[6, 76] = 6.13260911416774e-001;

            __statist_i_h_wts[6, 77] = 9.64849706424429e-001;

            __statist_i_h_wts[6, 78] = -1.79573102906900e+000;

            __statist_i_h_wts[6, 79] = 8.66024164482497e-001;

            __statist_i_h_wts[6, 80] = 9.23745432045229e-001;

            __statist_i_h_wts[6, 81] = -9.38153440621715e-001;

            __statist_i_h_wts[6, 82] = 3.88706668646271e-001;

            __statist_i_h_wts[6, 83] = 5.47285108590480e-001;

            __statist_i_h_wts[6, 84] = 3.31691783011401e-001;

            __statist_i_h_wts[6, 85] = -1.72649725908750e-001;

            __statist_i_h_wts[6, 86] = -1.45571329716610e-001;

            __statist_i_h_wts[6, 87] = 1.07869412941025e-001;

            __statist_i_h_wts[6, 88] = 2.93839977230246e-001;

            __statist_i_h_wts[6, 89] = -3.62891479829319e-001;

            __statist_i_h_wts[6, 90] = 3.12688449283855e+000;

            __statist_i_h_wts[6, 91] = -3.72850255627624e-001;

            __statist_i_h_wts[6, 92] = -2.72633561384620e+000;

            __statist_i_h_wts[6, 93] = 1.36736864188968e-001;

            __statist_i_h_wts[6, 94] = 3.75838516203331e-002;

            __statist_i_h_wts[6, 95] = -1.35943714873671e-001;

            __statist_i_h_wts[6, 96] = 3.07819876757733e-001;

            __statist_i_h_wts[6, 97] = -1.09481854229995e-001;

            __statist_i_h_wts[6, 98] = -1.80749790598995e-001;

            __statist_i_h_wts[6, 99] = 1.39800747362153e-001;

            __statist_i_h_wts[6, 100] = -5.22410587696069e-002;

            __statist_i_h_wts[6, 101] = -8.89110778433040e-002;

            __statist_i_h_wts[6, 102] = -6.57058698754998e-002;

            __statist_i_h_wts[6, 103] = 2.87776516262386e-001;

            __statist_i_h_wts[6, 104] = -2.32590696490155e-001;

            __statist_i_h_wts[6, 105] = 1.84967650119142e+000;

            __statist_i_h_wts[6, 106] = -2.43895718019820e-001;

            __statist_i_h_wts[6, 107] = -1.60469383143191e+000;

            __statist_i_h_wts[6, 108] = -5.42161744417769e-002;

            __statist_i_h_wts[6, 109] = 3.44926325474207e-001;

            __statist_i_h_wts[6, 110] = -3.06393665327089e-001;

            __statist_i_h_wts[6, 111] = 1.29504947540772e-001;

            __statist_i_h_wts[6, 112] = -1.02057783690096e-001;

            __statist_i_h_wts[6, 113] = -2.47169941334391e-002;



            __statist_i_h_wts[7, 0] = -1.15574400420349e-001;

            __statist_i_h_wts[7, 1] = -1.06437634837509e-001;

            __statist_i_h_wts[7, 2] = 3.38910103879971e-002;

            __statist_i_h_wts[7, 3] = 1.02765602736038e-001;

            __statist_i_h_wts[7, 4] = 8.31476824348807e-002;

            __statist_i_h_wts[7, 5] = -5.65679864088995e-002;

            __statist_i_h_wts[7, 6] = 1.44335601930210e-001;

            __statist_i_h_wts[7, 7] = -1.15251366661542e-002;

            __statist_i_h_wts[7, 8] = -7.93955054739000e-002;

            __statist_i_h_wts[7, 9] = -3.80521307315006e-002;

            __statist_i_h_wts[7, 10] = 2.82696451115075e-003;

            __statist_i_h_wts[7, 11] = 1.14571939037951e-001;

            __statist_i_h_wts[7, 12] = -4.67750157693896e-002;

            __statist_i_h_wts[7, 13] = -9.82315579729642e-002;

            __statist_i_h_wts[7, 14] = -5.85559080171658e-002;

            __statist_i_h_wts[7, 15] = 1.69676802428634e-001;

            __statist_i_h_wts[7, 16] = -1.59588205521776e-001;

            __statist_i_h_wts[7, 17] = -1.23024743977392e-001;

            __statist_i_h_wts[7, 18] = -9.35070022007974e-002;

            __statist_i_h_wts[7, 19] = -5.64476701935905e-003;

            __statist_i_h_wts[7, 20] = -2.05662991071243e-001;

            __statist_i_h_wts[7, 21] = -1.63018625696075e-001;

            __statist_i_h_wts[7, 22] = -6.97189875474201e-002;

            __statist_i_h_wts[7, 23] = 9.11968209596977e-002;

            __statist_i_h_wts[7, 24] = 1.22350023992492e-001;

            __statist_i_h_wts[7, 25] = -1.56255719924786e-001;

            __statist_i_h_wts[7, 26] = 5.46987540943795e-002;

            __statist_i_h_wts[7, 27] = 9.32486159007869e-003;

            __statist_i_h_wts[7, 28] = 2.20272822368373e-002;

            __statist_i_h_wts[7, 29] = -3.23111288516255e-002;

            __statist_i_h_wts[7, 30] = -8.79035097862151e-002;

            __statist_i_h_wts[7, 31] = -5.34703854897986e-002;

            __statist_i_h_wts[7, 32] = 4.37009468317122e-002;

            __statist_i_h_wts[7, 33] = -9.09163893855257e-002;

            __statist_i_h_wts[7, 34] = 1.29384168709352e-001;

            __statist_i_h_wts[7, 35] = 3.06492377727937e-002;

            __statist_i_h_wts[7, 36] = 2.18116733155809e-003;

            __statist_i_h_wts[7, 37] = -1.75441029995642e-002;

            __statist_i_h_wts[7, 38] = 2.64521111802527e-002;

            __statist_i_h_wts[7, 39] = 1.06998437047386e-001;

            __statist_i_h_wts[7, 40] = -1.64559950935590e-001;

            __statist_i_h_wts[7, 41] = 5.56462926575797e-002;

            __statist_i_h_wts[7, 42] = -1.09262437351743e+000;

            __statist_i_h_wts[7, 43] = 2.02519636016232e-001;

            __statist_i_h_wts[7, 44] = 2.74986401713595e-001;

            __statist_i_h_wts[7, 45] = -1.31250224289726e+000;

            __statist_i_h_wts[7, 46] = 3.98954569552515e-001;

            __statist_i_h_wts[7, 47] = 2.92947039322163e-001;

            __statist_i_h_wts[7, 48] = -1.46820787745483e+000;

            __statist_i_h_wts[7, 49] = -2.64668338031117e-002;

            __statist_i_h_wts[7, 50] = 8.96588143967288e-001;

            __statist_i_h_wts[7, 51] = -1.01993192480021e+000;

            __statist_i_h_wts[7, 52] = 8.54700128551333e-002;

            __statist_i_h_wts[7, 53] = 2.88863717421611e-001;

            __statist_i_h_wts[7, 54] = -1.07571975150343e+000;

            __statist_i_h_wts[7, 55] = 1.71904181737252e-001;

            __statist_i_h_wts[7, 56] = 2.81885801030392e-001;

            __statist_i_h_wts[7, 57] = -9.64434915506901e-001;

            __statist_i_h_wts[7, 58] = 2.07299757052354e-001;

            __statist_i_h_wts[7, 59] = 1.64252318506752e-001;

            __statist_i_h_wts[7, 60] = -1.00108872919131e+000;

            __statist_i_h_wts[7, 61] = 1.23125174840783e-002;

            __statist_i_h_wts[7, 62] = 3.83883224117192e-001;

            __statist_i_h_wts[7, 63] = -1.09049440746959e+000;

            __statist_i_h_wts[7, 64] = -1.20187124796651e+000;

            __statist_i_h_wts[7, 65] = 1.65786455737643e+000;

            __statist_i_h_wts[7, 66] = -8.92157287657714e-001;

            __statist_i_h_wts[7, 67] = -1.48708454072663e-001;

            __statist_i_h_wts[7, 68] = 4.34821377147228e-001;

            __statist_i_h_wts[7, 69] = -8.90923223081552e-001;

            __statist_i_h_wts[7, 70] = 6.62548402767716e-002;

            __statist_i_h_wts[7, 71] = 2.12516167710231e-001;

            __statist_i_h_wts[7, 72] = -7.00217087856479e-001;

            __statist_i_h_wts[7, 73] = -6.27705008247282e-001;

            __statist_i_h_wts[7, 74] = 7.32143314308589e-001;

            __statist_i_h_wts[7, 75] = -1.54633084093867e+000;

            __statist_i_h_wts[7, 76] = -4.28078082775668e-001;

            __statist_i_h_wts[7, 77] = 1.36286800939999e+000;

            __statist_i_h_wts[7, 78] = -1.75122435554519e+000;

            __statist_i_h_wts[7, 79] = -2.40107877747284e-002;

            __statist_i_h_wts[7, 80] = 1.15456437069142e+000;

            __statist_i_h_wts[7, 81] = -7.48107080338675e-001;

            __statist_i_h_wts[7, 82] = -5.43795544201875e-001;

            __statist_i_h_wts[7, 83] = 6.79998175702185e-001;

            __statist_i_h_wts[7, 84] = 6.22382080897464e-001;

            __statist_i_h_wts[7, 85] = -9.83162021235308e-001;

            __statist_i_h_wts[7, 86] = -2.41904369790549e-001;

            __statist_i_h_wts[7, 87] = 2.20190520820647e-001;

            __statist_i_h_wts[7, 88] = -8.64140453123909e-002;

            __statist_i_h_wts[7, 89] = -7.22695083514647e-001;

            __statist_i_h_wts[7, 90] = 4.50443195703528e+000;

            __statist_i_h_wts[7, 91] = -8.16604956499843e-001;

            __statist_i_h_wts[7, 92] = -4.30471724040280e+000;

            __statist_i_h_wts[7, 93] = 3.60447979057463e-001;

            __statist_i_h_wts[7, 94] = -5.08242604344325e-001;

            __statist_i_h_wts[7, 95] = -4.67289411494737e-001;

            __statist_i_h_wts[7, 96] = 4.09742855795262e-001;

            __statist_i_h_wts[7, 97] = -7.62507702793324e-001;

            __statist_i_h_wts[7, 98] = -2.53079408677538e-001;

            __statist_i_h_wts[7, 99] = 2.37903661351367e-002;

            __statist_i_h_wts[7, 100] = -3.24717561292101e-001;

            __statist_i_h_wts[7, 101] = -2.97250515432449e-001;

            __statist_i_h_wts[7, 102] = -4.37895769714399e-001;

            __statist_i_h_wts[7, 103] = 2.53856180040691e-001;

            __statist_i_h_wts[7, 104] = -4.35970729880177e-001;

            __statist_i_h_wts[7, 105] = 2.72109888684811e+000;

            __statist_i_h_wts[7, 106] = -5.82760804547257e-001;

            __statist_i_h_wts[7, 107] = -2.74544445112537e+000;

            __statist_i_h_wts[7, 108] = -2.09704106200539e-001;

            __statist_i_h_wts[7, 109] = 5.15221331398191e-002;

            __statist_i_h_wts[7, 110] = -4.41635968538586e-001;

            __statist_i_h_wts[7, 111] = -2.02327108223073e-001;

            __statist_i_h_wts[7, 112] = -3.03873566454525e-001;

            __statist_i_h_wts[7, 113] = -1.06540670922883e-001;



            __statist_i_h_wts[8, 0] = -1.17961879079004e-001;

            __statist_i_h_wts[8, 1] = -1.04414506165576e-001;

            __statist_i_h_wts[8, 2] = 5.80511200328655e-002;

            __statist_i_h_wts[8, 3] = 1.04411934809913e-001;

            __statist_i_h_wts[8, 4] = 9.73614109826611e-002;

            __statist_i_h_wts[8, 5] = -2.93757953676976e-002;

            __statist_i_h_wts[8, 6] = 1.54464775103778e-001;

            __statist_i_h_wts[8, 7] = -1.01697474732590e-002;

            __statist_i_h_wts[8, 8] = -6.59992102962134e-002;

            __statist_i_h_wts[8, 9] = -3.91675011553016e-002;

            __statist_i_h_wts[8, 10] = 1.66845294011243e-002;

            __statist_i_h_wts[8, 11] = 1.15712800139747e-001;

            __statist_i_h_wts[8, 12] = -4.38140849628869e-002;

            __statist_i_h_wts[8, 13] = -1.03244097148468e-001;

            __statist_i_h_wts[8, 14] = -5.53708781237355e-002;

            __statist_i_h_wts[8, 15] = 1.66532582931939e-001;

            __statist_i_h_wts[8, 16] = -1.55276702169093e-001;

            __statist_i_h_wts[8, 17] = -1.11299787308748e-001;

            __statist_i_h_wts[8, 18] = -6.36846757739346e-002;

            __statist_i_h_wts[8, 19] = 2.34487165824833e-003;

            __statist_i_h_wts[8, 20] = -1.78814306449091e-001;

            __statist_i_h_wts[8, 21] = -1.44554937076951e-001;

            __statist_i_h_wts[8, 22] = -4.71787718903587e-002;

            __statist_i_h_wts[8, 23] = 1.13354942714372e-001;

            __statist_i_h_wts[8, 24] = 1.03800145787456e-001;

            __statist_i_h_wts[8, 25] = -1.20296009798336e-001;

            __statist_i_h_wts[8, 26] = 5.45488979063335e-002;

            __statist_i_h_wts[8, 27] = 2.25797242928331e-002;

            __statist_i_h_wts[8, 28] = 8.23190906498978e-003;

            __statist_i_h_wts[8, 29] = -2.28228840053047e-002;

            __statist_i_h_wts[8, 30] = -7.62463559976808e-002;

            __statist_i_h_wts[8, 31] = -4.80174580932868e-002;

            __statist_i_h_wts[8, 32] = 3.71186497703819e-002;

            __statist_i_h_wts[8, 33] = -7.20924400559198e-002;

            __statist_i_h_wts[8, 34] = 1.49499169732723e-001;

            __statist_i_h_wts[8, 35] = 4.12505121295697e-002;

            __statist_i_h_wts[8, 36] = 7.29232386163249e-004;

            __statist_i_h_wts[8, 37] = -1.80179401561162e-002;

            __statist_i_h_wts[8, 38] = 2.97995759862822e-002;

            __statist_i_h_wts[8, 39] = 9.04329861526902e-002;

            __statist_i_h_wts[8, 40] = -1.50116884069169e-001;

            __statist_i_h_wts[8, 41] = 2.39127328119190e-002;

            __statist_i_h_wts[8, 42] = -9.56544069914464e-001;

            __statist_i_h_wts[8, 43] = 1.90258452693113e-001;

            __statist_i_h_wts[8, 44] = 2.69107479901142e-001;

            __statist_i_h_wts[8, 45] = -1.16660349686146e+000;

            __statist_i_h_wts[8, 46] = 3.91189467549627e-001;

            __statist_i_h_wts[8, 47] = 2.72833759450551e-001;

            __statist_i_h_wts[8, 48] = -1.17709067104651e+000;

            __statist_i_h_wts[8, 49] = -1.60239457880206e-001;

            __statist_i_h_wts[8, 50] = 8.47744300573280e-001;

            __statist_i_h_wts[8, 51] = -8.37145548534104e-001;

            __statist_i_h_wts[8, 52] = 5.77747604796777e-002;

            __statist_i_h_wts[8, 53] = 2.90839048379568e-001;

            __statist_i_h_wts[8, 54] = -9.06698656093205e-001;

            __statist_i_h_wts[8, 55] = 1.30200660454033e-001;

            __statist_i_h_wts[8, 56] = 2.64674768445309e-001;

            __statist_i_h_wts[8, 57] = -8.03143343237323e-001;

            __statist_i_h_wts[8, 58] = 1.76739673458082e-001;

            __statist_i_h_wts[8, 59] = 1.44121167930214e-001;

            __statist_i_h_wts[8, 60] = -8.02748433146783e-001;

            __statist_i_h_wts[8, 61] = -9.22709331530209e-003;

            __statist_i_h_wts[8, 62] = 3.78727724886135e-001;

            __statist_i_h_wts[8, 63] = -7.83334247637306e-001;

            __statist_i_h_wts[8, 64] = -1.34439842011924e+000;

            __statist_i_h_wts[8, 65] = 1.64343864519077e+000;

            __statist_i_h_wts[8, 66] = -7.30555820832097e-001;

            __statist_i_h_wts[8, 67] = -1.80764535210101e-001;

            __statist_i_h_wts[8, 68] = 4.04719135339761e-001;

            __statist_i_h_wts[8, 69] = -7.02078497211273e-001;

            __statist_i_h_wts[8, 70] = 2.17211842492316e-002;

            __statist_i_h_wts[8, 71] = 2.13670796330611e-001;

            __statist_i_h_wts[8, 72] = -8.40318055982995e-001;

            __statist_i_h_wts[8, 73] = -3.78359579852743e-001;

            __statist_i_h_wts[8, 74] = 7.11367267459753e-001;

            __statist_i_h_wts[8, 75] = -1.61077467202468e+000;

            __statist_i_h_wts[8, 76] = -1.54093404005056e-001;

            __statist_i_h_wts[8, 77] = 1.30209295412529e+000;

            __statist_i_h_wts[8, 78] = -1.84721870482112e+000;

            __statist_i_h_wts[8, 79] = 2.08690799484797e-001;

            __statist_i_h_wts[8, 80] = 1.11637376900203e+000;

            __statist_i_h_wts[8, 81] = -8.51364045688589e-001;

            __statist_i_h_wts[8, 82] = -3.06123056012658e-001;

            __statist_i_h_wts[8, 83] = 6.71549094346382e-001;

            __statist_i_h_wts[8, 84] = 5.71225675937675e-001;

            __statist_i_h_wts[8, 85] = -8.36533728542649e-001;

            __statist_i_h_wts[8, 86] = -2.49691277763201e-001;

            __statist_i_h_wts[8, 87] = 2.21850249424332e-001;

            __statist_i_h_wts[8, 88] = -3.30693165676776e-002;

            __statist_i_h_wts[8, 89] = -6.90057356048921e-001;

            __statist_i_h_wts[8, 90] = 4.31890182462456e+000;

            __statist_i_h_wts[8, 91] = -7.11216678104962e-001;

            __statist_i_h_wts[8, 92] = -4.10474975689563e+000;

            __statist_i_h_wts[8, 93] = 3.72324092622848e-001;

            __statist_i_h_wts[8, 94] = -4.07607357991237e-001;

            __statist_i_h_wts[8, 95] = -4.55915398230489e-001;

            __statist_i_h_wts[8, 96] = 4.06457255350841e-001;

            __statist_i_h_wts[8, 97] = -6.84288189284924e-001;

            __statist_i_h_wts[8, 98] = -2.32676831938320e-001;

            __statist_i_h_wts[8, 99] = 4.31140501999263e-002;

            __statist_i_h_wts[8, 100] = -2.49757770368815e-001;

            __statist_i_h_wts[8, 101] = -2.65270909111930e-001;

            __statist_i_h_wts[8, 102] = -3.59947800671876e-001;

            __statist_i_h_wts[8, 103] = 2.70528932245438e-001;

            __statist_i_h_wts[8, 104] = -4.15438633633415e-001;

            __statist_i_h_wts[8, 105] = 2.62127140838618e+000;

            __statist_i_h_wts[8, 106] = -5.17096501096261e-001;

            __statist_i_h_wts[8, 107] = -2.61856798802802e+000;

            __statist_i_h_wts[8, 108] = -1.81201993155355e-001;

            __statist_i_h_wts[8, 109] = 7.48276273791762e-002;

            __statist_i_h_wts[8, 110] = -4.17489437271214e-001;

            __statist_i_h_wts[8, 111] = -1.44343432823441e-001;

            __statist_i_h_wts[8, 112] = -2.60390400526022e-001;

            __statist_i_h_wts[8, 113] = -9.65471340963061e-002;



            __statist_i_h_wts[9, 0] = -4.49315903991686e-002;

            __statist_i_h_wts[9, 1] = -9.81878148056761e-003;

            __statist_i_h_wts[9, 2] = -1.31215314290896e-002;

            __statist_i_h_wts[9, 3] = 5.56285489584634e-003;

            __statist_i_h_wts[9, 4] = 2.99290646368376e-002;

            __statist_i_h_wts[9, 5] = 1.28441497949552e-002;

            __statist_i_h_wts[9, 6] = 4.22816957282249e-002;

            __statist_i_h_wts[9, 7] = 2.34124710778939e-002;

            __statist_i_h_wts[9, 8] = -7.96722610360735e-004;

            __statist_i_h_wts[9, 9] = -1.23040602713938e-002;

            __statist_i_h_wts[9, 10] = 3.73291621198538e-002;

            __statist_i_h_wts[9, 11] = 3.44833366066586e-002;

            __statist_i_h_wts[9, 12] = -5.72880956758727e-003;

            __statist_i_h_wts[9, 13] = -2.14466143141380e-003;

            __statist_i_h_wts[9, 14] = -1.45185925982996e-002;

            __statist_i_h_wts[9, 15] = 4.69355354428126e-002;

            __statist_i_h_wts[9, 16] = -4.70964403477124e-002;

            __statist_i_h_wts[9, 17] = -4.23283451807354e-002;

            __statist_i_h_wts[9, 18] = -2.73472848390908e-002;

            __statist_i_h_wts[9, 19] = -6.64033249217577e-003;

            __statist_i_h_wts[9, 20] = -6.26606246993884e-002;

            __statist_i_h_wts[9, 21] = -7.68037251856718e-002;

            __statist_i_h_wts[9, 22] = -3.10350433086781e-002;

            __statist_i_h_wts[9, 23] = 2.22350023009433e-002;

            __statist_i_h_wts[9, 24] = 4.68051920232423e-002;

            __statist_i_h_wts[9, 25] = -5.26005955289031e-002;

            __statist_i_h_wts[9, 26] = 1.64849987160805e-002;

            __statist_i_h_wts[9, 27] = 1.30357900164276e-002;

            __statist_i_h_wts[9, 28] = 1.27171110620660e-002;

            __statist_i_h_wts[9, 29] = -3.75865870271943e-002;

            __statist_i_h_wts[9, 30] = -6.09938660085548e-003;

            __statist_i_h_wts[9, 31] = 6.64613901420731e-003;

            __statist_i_h_wts[9, 32] = 4.91782539368794e-003;

            __statist_i_h_wts[9, 33] = -2.53153970301107e-002;

            __statist_i_h_wts[9, 34] = 3.52605831743373e-002;

            __statist_i_h_wts[9, 35] = 2.94583281691874e-002;

            __statist_i_h_wts[9, 36] = -5.46777578897223e-003;

            __statist_i_h_wts[9, 37] = 3.75540150975343e-004;

            __statist_i_h_wts[9, 38] = -1.38302572644332e-003;

            __statist_i_h_wts[9, 39] = 2.07342657073313e-002;

            __statist_i_h_wts[9, 40] = -3.00737287822559e-002;

            __statist_i_h_wts[9, 41] = 8.74076818751562e-003;

            __statist_i_h_wts[9, 42] = -2.69242999152606e-001;

            __statist_i_h_wts[9, 43] = 7.91943754627319e-002;

            __statist_i_h_wts[9, 44] = 1.18467501550104e-001;

            __statist_i_h_wts[9, 45] = -3.70466292436465e-001;

            __statist_i_h_wts[9, 46] = 1.44607135534062e-001;

            __statist_i_h_wts[9, 47] = 1.53892070266305e-001;

            __statist_i_h_wts[9, 48] = 5.35552301436423e-001;

            __statist_i_h_wts[9, 49] = -1.02053158771368e+000;

            __statist_i_h_wts[9, 50] = 3.99850808073992e-001;

            __statist_i_h_wts[9, 51] = -2.96208968736685e-001;

            __statist_i_h_wts[9, 52] = 7.20893426534511e-002;

            __statist_i_h_wts[9, 53] = 1.74797011829929e-001;

            __statist_i_h_wts[9, 54] = -2.05592519026409e-001;

            __statist_i_h_wts[9, 55] = -2.24763042295187e-003;

            __statist_i_h_wts[9, 56] = 1.27256221471494e-001;

            __statist_i_h_wts[9, 57] = -1.38541977615670e-001;

            __statist_i_h_wts[9, 58] = 1.75576286263497e-002;

            __statist_i_h_wts[9, 59] = 7.73897644546701e-002;

            __statist_i_h_wts[9, 60] = -2.18367049614663e-001;

            __statist_i_h_wts[9, 61] = -3.58118953709623e-002;

            __statist_i_h_wts[9, 62] = 1.80288629981662e-001;

            __statist_i_h_wts[9, 63] = 9.39643908554237e-001;

            __statist_i_h_wts[9, 64] = -1.70997584069203e+000;

            __statist_i_h_wts[9, 65] = 7.04697873440372e-001;

            __statist_i_h_wts[9, 66] = -1.87240408645053e-001;

            __statist_i_h_wts[9, 67] = -8.50180299139040e-002;

            __statist_i_h_wts[9, 68] = 2.08642920061972e-001;

            __statist_i_h_wts[9, 69] = -8.30779921684887e-002;

            __statist_i_h_wts[9, 70] = -8.76037004867251e-002;

            __statist_i_h_wts[9, 71] = 1.18888965917097e-001;

            __statist_i_h_wts[9, 72] = -1.26124616626820e+000;

            __statist_i_h_wts[9, 73] = 8.94210311942021e-001;

            __statist_i_h_wts[9, 74] = 2.92446069178787e-001;

            __statist_i_h_wts[9, 75] = -1.65522045341322e+000;

            __statist_i_h_wts[9, 76] = 1.05537559889912e+000;

            __statist_i_h_wts[9, 77] = 5.25686329024081e-001;

            __statist_i_h_wts[9, 78] = -1.71930152837848e+000;

            __statist_i_h_wts[9, 79] = 1.18012717474536e+000;

            __statist_i_h_wts[9, 80] = 4.52598053347808e-001;

            __statist_i_h_wts[9, 81] = -1.16130357274215e+000;

            __statist_i_h_wts[9, 82] = 8.41984112155260e-001;

            __statist_i_h_wts[9, 83] = 2.82148042077022e-001;

            __statist_i_h_wts[9, 84] = 3.10147098667909e-001;

            __statist_i_h_wts[9, 85] = -2.35426106183926e-001;

            __statist_i_h_wts[9, 86] = -1.24028700086149e-001;

            __statist_i_h_wts[9, 87] = 1.35064843226282e-001;

            __statist_i_h_wts[9, 88] = 6.54358723760177e-002;

            __statist_i_h_wts[9, 89] = -2.71262615841289e-001;

            __statist_i_h_wts[9, 90] = 2.39179366985549e+000;

            __statist_i_h_wts[9, 91] = -8.68063666107118e-001;

            __statist_i_h_wts[9, 92] = -1.56862703528639e+000;

            __statist_i_h_wts[9, 93] = 2.00802965829198e-001;

            __statist_i_h_wts[9, 94] = -8.50192460869068e-002;

            __statist_i_h_wts[9, 95] = -1.75037218466950e-001;

            __statist_i_h_wts[9, 96] = 3.31112534607730e-001;

            __statist_i_h_wts[9, 97] = -3.27360518023717e-001;

            __statist_i_h_wts[9, 98] = -7.53580888652056e-002;

            __statist_i_h_wts[9, 99] = 1.18190699999698e-001;

            __statist_i_h_wts[9, 100] = -7.29765582858842e-002;

            __statist_i_h_wts[9, 101] = -1.21563469175364e-001;

            __statist_i_h_wts[9, 102] = -9.45055890989136e-002;

            __statist_i_h_wts[9, 103] = 1.68898535356128e-001;

            __statist_i_h_wts[9, 104] = -1.34699666318836e-001;

            __statist_i_h_wts[9, 105] = 1.78286537922219e+000;

            __statist_i_h_wts[9, 106] = -8.14707931324296e-001;

            __statist_i_h_wts[9, 107] = -1.04416721583471e+000;

            __statist_i_h_wts[9, 108] = 6.47526052690183e-003;

            __statist_i_h_wts[9, 109] = 6.52048180847472e-002;

            __statist_i_h_wts[9, 110] = -1.46848117004379e-001;

            __statist_i_h_wts[9, 111] = 1.18637597240469e-001;

            __statist_i_h_wts[9, 112] = -1.50314425186209e-001;

            __statist_i_h_wts[9, 113] = -7.46588249080190e-002;



            __statist_i_h_wts[10, 0] = -1.19598315904972e-002;

            __statist_i_h_wts[10, 1] = -1.40112327426917e-001;

            __statist_i_h_wts[10, 2] = 9.88755887640991e-003;

            __statist_i_h_wts[10, 3] = 5.09604898032390e-002;

            __statist_i_h_wts[10, 4] = -3.94398191741841e-003;

            __statist_i_h_wts[10, 5] = -8.44725929575275e-002;

            __statist_i_h_wts[10, 6] = 5.95019557943893e-003;

            __statist_i_h_wts[10, 7] = 3.35078106623775e-002;

            __statist_i_h_wts[10, 8] = -4.83697063345979e-002;

            __statist_i_h_wts[10, 9] = 4.75360986530728e-002;

            __statist_i_h_wts[10, 10] = -1.15443700097991e-001;

            __statist_i_h_wts[10, 11] = 2.87955774808660e-002;

            __statist_i_h_wts[10, 12] = 1.10356195118120e-001;

            __statist_i_h_wts[10, 13] = 1.09744087208062e-002;

            __statist_i_h_wts[10, 14] = 1.90232577754555e-002;

            __statist_i_h_wts[10, 15] = 3.62853639094792e-002;

            __statist_i_h_wts[10, 16] = -3.62149524802924e-002;

            __statist_i_h_wts[10, 17] = 6.74588424391746e-002;

            __statist_i_h_wts[10, 18] = -3.84579558238758e-002;

            __statist_i_h_wts[10, 19] = -5.58054007928629e-002;

            __statist_i_h_wts[10, 20] = 2.08033087751034e-002;

            __statist_i_h_wts[10, 21] = -5.45331142833495e-002;

            __statist_i_h_wts[10, 22] = -4.53116502430422e-002;

            __statist_i_h_wts[10, 23] = -8.64649682791673e-002;

            __statist_i_h_wts[10, 24] = 9.02923900623957e-002;

            __statist_i_h_wts[10, 25] = 4.31156241450818e-002;

            __statist_i_h_wts[10, 26] = 9.37361887339780e-002;

            __statist_i_h_wts[10, 27] = 2.39789368562489e-002;

            __statist_i_h_wts[10, 28] = 4.57266080640549e-002;

            __statist_i_h_wts[10, 29] = 1.56471371538891e-002;

            __statist_i_h_wts[10, 30] = -1.34351231687631e-001;

            __statist_i_h_wts[10, 31] = -7.39829684134962e-002;

            __statist_i_h_wts[10, 32] = -1.20216217778720e-001;

            __statist_i_h_wts[10, 33] = 4.98278102298071e-002;

            __statist_i_h_wts[10, 34] = -6.86352671891148e-002;

            __statist_i_h_wts[10, 35] = -1.84317962106447e-002;

            __statist_i_h_wts[10, 36] = 3.09387494321882e-003;

            __statist_i_h_wts[10, 37] = -1.91861499246524e-002;

            __statist_i_h_wts[10, 38] = 8.88511876746925e-002;

            __statist_i_h_wts[10, 39] = -4.90923387390615e-002;

            __statist_i_h_wts[10, 40] = -1.28091615725998e-001;

            __statist_i_h_wts[10, 41] = -2.30591649203766e-002;

            __statist_i_h_wts[10, 42] = -1.50058500453314e-001;

            __statist_i_h_wts[10, 43] = -1.01016420023026e-001;

            __statist_i_h_wts[10, 44] = -1.17702247574813e-001;

            __statist_i_h_wts[10, 45] = -9.83341475524577e-002;

            __statist_i_h_wts[10, 46] = -1.81558557709662e-001;

            __statist_i_h_wts[10, 47] = -1.00861477090303e-001;

            __statist_i_h_wts[10, 48] = 1.80829815302644e+000;

            __statist_i_h_wts[10, 49] = -1.68814068017464e+000;

            __statist_i_h_wts[10, 50] = -4.97085636170293e-001;

            __statist_i_h_wts[10, 51] = -2.25359227981953e-001;

            __statist_i_h_wts[10, 52] = 8.00997013114565e-002;

            __statist_i_h_wts[10, 53] = -2.20356650734815e-001;

            __statist_i_h_wts[10, 54] = -1.30802679596679e-001;

            __statist_i_h_wts[10, 55] = -1.44825909625051e-001;

            __statist_i_h_wts[10, 56] = -1.15384061224669e-001;

            __statist_i_h_wts[10, 57] = -6.93376812363672e-002;

            __statist_i_h_wts[10, 58] = -1.89550647930194e-001;

            __statist_i_h_wts[10, 59] = -1.03548499281825e-001;

            __statist_i_h_wts[10, 60] = -8.06299070781067e-002;

            __statist_i_h_wts[10, 61] = -1.13596931909146e-001;

            __statist_i_h_wts[10, 62] = -1.43527328272574e-001;

            __statist_i_h_wts[10, 63] = 2.12863997060638e+000;

            __statist_i_h_wts[10, 64] = -1.77437007954783e+000;

            __statist_i_h_wts[10, 65] = -7.59133365147778e-001;

            __statist_i_h_wts[10, 66] = -1.17474491257365e-001;

            __statist_i_h_wts[10, 67] = -4.41347964810761e-002;

            __statist_i_h_wts[10, 68] = -2.25850939225881e-001;

            __statist_i_h_wts[10, 69] = -5.57078553132324e-002;

            __statist_i_h_wts[10, 70] = -9.35581055722832e-002;

            __statist_i_h_wts[10, 71] = -2.55771470965027e-001;

            __statist_i_h_wts[10, 72] = -1.45974624407471e+000;

            __statist_i_h_wts[10, 73] = 1.21888487450257e+000;

            __statist_i_h_wts[10, 74] = -1.59423369930607e-001;

            __statist_i_h_wts[10, 75] = -1.78114215283660e+000;

            __statist_i_h_wts[10, 76] = 1.70303939142647e+000;

            __statist_i_h_wts[10, 77] = -2.99586168618621e-001;

            __statist_i_h_wts[10, 78] = -1.67290431497738e+000;

            __statist_i_h_wts[10, 79] = 1.47447953270136e+000;

            __statist_i_h_wts[10, 80] = -1.77717854986607e-001;

            __statist_i_h_wts[10, 81] = -1.56744370049491e+000;

            __statist_i_h_wts[10, 82] = 1.11582499905883e+000;

            __statist_i_h_wts[10, 83] = 3.92910662190247e-002;

            __statist_i_h_wts[10, 84] = -1.45745221994078e-001;

            __statist_i_h_wts[10, 85] = -3.69264866426220e-001;

            __statist_i_h_wts[10, 86] = 1.09472195492793e-001;

            __statist_i_h_wts[10, 87] = -4.90549617446909e-001;

            __statist_i_h_wts[10, 88] = -4.75976945007082e-002;

            __statist_i_h_wts[10, 89] = 1.59383407577897e-001;

            __statist_i_h_wts[10, 90] = 1.36861326547706e+000;

            __statist_i_h_wts[10, 91] = -2.44649335850361e+000;

            __statist_i_h_wts[10, 92] = 7.06629086839852e-001;

            __statist_i_h_wts[10, 93] = -5.81245365240931e-001;

            __statist_i_h_wts[10, 94] = 1.67727244899108e-001;

            __statist_i_h_wts[10, 95] = 4.11923862899448e-002;

            __statist_i_h_wts[10, 96] = -3.42697048525165e-001;

            __statist_i_h_wts[10, 97] = -4.32722369471445e-002;

            __statist_i_h_wts[10, 98] = 2.65361175660946e-002;

            __statist_i_h_wts[10, 99] = -3.30489452306554e-001;

            __statist_i_h_wts[10, 100] = -1.77549264302725e-001;

            __statist_i_h_wts[10, 101] = 1.26659555948378e-001;

            __statist_i_h_wts[10, 102] = -3.23462355803661e-001;

            __statist_i_h_wts[10, 103] = -2.59234252484259e-002;

            __statist_i_h_wts[10, 104] = -3.30973209604647e-002;

            __statist_i_h_wts[10, 105] = 1.21830026919244e+000;

            __statist_i_h_wts[10, 106] = -1.95630912401460e+000;

            __statist_i_h_wts[10, 107] = 3.54220650515069e-001;

            __statist_i_h_wts[10, 108] = -4.22406751767122e-001;

            __statist_i_h_wts[10, 109] = -5.67255398478849e-002;

            __statist_i_h_wts[10, 110] = 7.34855725712458e-002;

            __statist_i_h_wts[10, 111] = -1.79043863089201e-001;

            __statist_i_h_wts[10, 112] = -2.49928890722513e-001;

            __statist_i_h_wts[10, 113] = 4.29273124188145e-002;



            __statist_i_h_wts[11, 0] = -2.38352084331826e-001;

            __statist_i_h_wts[11, 1] = 1.24370334188111e-001;

            __statist_i_h_wts[11, 2] = 9.86395318397701e-002;

            __statist_i_h_wts[11, 3] = 1.89434934369296e-001;

            __statist_i_h_wts[11, 4] = 1.70904917758693e-001;

            __statist_i_h_wts[11, 5] = -1.15858992760151e-001;

            __statist_i_h_wts[11, 6] = 1.68714308316609e-001;

            __statist_i_h_wts[11, 7] = 7.34349141301607e-002;

            __statist_i_h_wts[11, 8] = -6.58705587876186e-002;

            __statist_i_h_wts[11, 9] = -1.77118916077918e-001;

            __statist_i_h_wts[11, 10] = -4.44196373126898e-002;

            __statist_i_h_wts[11, 11] = 9.42996831310099e-002;

            __statist_i_h_wts[11, 12] = -9.36634972275376e-003;

            __statist_i_h_wts[11, 13] = -2.04265423170229e-001;

            __statist_i_h_wts[11, 14] = -2.36468108542232e-003;

            __statist_i_h_wts[11, 15] = 2.14620753179080e-001;

            __statist_i_h_wts[11, 16] = -1.80835841190048e-001;

            __statist_i_h_wts[11, 17] = -1.87275512938613e-002;

            __statist_i_h_wts[11, 18] = -2.56193181564135e-003;

            __statist_i_h_wts[11, 19] = -2.54428819760772e-003;

            __statist_i_h_wts[11, 20] = -1.40192810197051e-001;

            __statist_i_h_wts[11, 21] = -2.90222684539048e-001;

            __statist_i_h_wts[11, 22] = -1.34748922459881e-001;

            __statist_i_h_wts[11, 23] = 4.63295753137702e-002;

            __statist_i_h_wts[11, 24] = 1.38969306139182e-001;

            __statist_i_h_wts[11, 25] = 4.26662324433521e-002;

            __statist_i_h_wts[11, 26] = -1.78189511216693e-002;

            __statist_i_h_wts[11, 27] = -1.90669406104484e-002;

            __statist_i_h_wts[11, 28] = 4.80094585503716e-002;

            __statist_i_h_wts[11, 29] = 5.50444463347405e-002;

            __statist_i_h_wts[11, 30] = -1.83781779337549e-001;

            __statist_i_h_wts[11, 31] = -1.88992242672256e-001;

            __statist_i_h_wts[11, 32] = 8.24121652554682e-002;

            __statist_i_h_wts[11, 33] = -5.77112762570783e-002;

            __statist_i_h_wts[11, 34] = 3.00446468193212e-001;

            __statist_i_h_wts[11, 35] = 4.68206591161723e-002;

            __statist_i_h_wts[11, 36] = -1.09998254983341e-004;

            __statist_i_h_wts[11, 37] = -8.72923354908353e-002;

            __statist_i_h_wts[11, 38] = 2.48756706502665e-001;

            __statist_i_h_wts[11, 39] = 6.50833496351013e-002;

            __statist_i_h_wts[11, 40] = -1.82914204795245e-001;

            __statist_i_h_wts[11, 41] = 1.29701800646515e-001;

            __statist_i_h_wts[11, 42] = -1.55430361367165e-001;

            __statist_i_h_wts[11, 43] = -2.52841409745438e-002;

            __statist_i_h_wts[11, 44] = 2.15045047795445e-001;

            __statist_i_h_wts[11, 45] = -3.27169815687985e-001;

            __statist_i_h_wts[11, 46] = 1.98789204748411e-001;

            __statist_i_h_wts[11, 47] = 1.35782037366554e-001;

            __statist_i_h_wts[11, 48] = -1.85244333620972e-001;

            __statist_i_h_wts[11, 49] = -4.51565605098491e-001;

            __statist_i_h_wts[11, 50] = 6.73982605614381e-001;

            __statist_i_h_wts[11, 51] = -4.27514659967359e-003;

            __statist_i_h_wts[11, 52] = -1.39381958345370e-001;

            __statist_i_h_wts[11, 53] = 1.90173017553985e-001;

            __statist_i_h_wts[11, 54] = -2.73391993607175e-001;

            __statist_i_h_wts[11, 55] = -5.71215769993498e-002;

            __statist_i_h_wts[11, 56] = 3.45025579594239e-001;

            __statist_i_h_wts[11, 57] = -4.83984869747910e-001;

            __statist_i_h_wts[11, 58] = 2.97277297451000e-001;

            __statist_i_h_wts[11, 59] = 2.04186135942842e-001;

            __statist_i_h_wts[11, 60] = -1.75993835459000e-001;

            __statist_i_h_wts[11, 61] = -1.13495578496617e-001;

            __statist_i_h_wts[11, 62] = 3.24694310930239e-001;

            __statist_i_h_wts[11, 63] = -1.14839949019174e-001;

            __statist_i_h_wts[11, 64] = -1.40408604511060e+000;

            __statist_i_h_wts[11, 65] = 1.54660031150775e+000;

            __statist_i_h_wts[11, 66] = -1.49447561297551e-001;

            __statist_i_h_wts[11, 67] = -2.30042498179973e-001;

            __statist_i_h_wts[11, 68] = 4.06639055504645e-001;

            __statist_i_h_wts[11, 69] = 1.16525525935255e-001;

            __statist_i_h_wts[11, 70] = -7.72906611688076e-002;

            __statist_i_h_wts[11, 71] = -2.09404416487268e-003;

            __statist_i_h_wts[11, 72] = -5.76041307394230e-001;

            __statist_i_h_wts[11, 73] = -2.80201067646226e-001;

            __statist_i_h_wts[11, 74] = 9.06145534862399e-001;

            __statist_i_h_wts[11, 75] = -1.47389126415559e+000;

            __statist_i_h_wts[11, 76] = 1.73238785404072e-001;

            __statist_i_h_wts[11, 77] = 1.31328152433276e+000;

            __statist_i_h_wts[11, 78] = -1.59193334319313e+000;

            __statist_i_h_wts[11, 79] = 4.80388028944258e-001;

            __statist_i_h_wts[11, 80] = 1.15939179465756e+000;

            __statist_i_h_wts[11, 81] = -7.40528067419955e-001;

            __statist_i_h_wts[11, 82] = 1.06176586722273e-001;

            __statist_i_h_wts[11, 83] = 6.68573487185988e-001;

            __statist_i_h_wts[11, 84] = 3.49986204259997e-001;

            __statist_i_h_wts[11, 85] = -1.01226214807961e-001;

            __statist_i_h_wts[11, 86] = -2.12405243979899e-001;

            __statist_i_h_wts[11, 87] = 1.81676957737756e-001;

            __statist_i_h_wts[11, 88] = 4.96802324210887e-001;

            __statist_i_h_wts[11, 89] = -6.63692561177505e-001;

            __statist_i_h_wts[11, 90] = 3.93022543203644e+000;

            __statist_i_h_wts[11, 91] = -3.28545567201036e-001;

            __statist_i_h_wts[11, 92] = -3.58134218322946e+000;

            __statist_i_h_wts[11, 93] = 3.50903641677957e-001;

            __statist_i_h_wts[11, 94] = -2.37546009520343e-001;

            __statist_i_h_wts[11, 95] = -1.05393458087309e-001;

            __statist_i_h_wts[11, 96] = 5.65214668864368e-001;

            __statist_i_h_wts[11, 97] = -1.63499250600239e-001;

            __statist_i_h_wts[11, 98] = -3.77970632520278e-001;

            __statist_i_h_wts[11, 99] = 1.53194658292545e-001;

            __statist_i_h_wts[11, 100] = -1.34119996888526e-001;

            __statist_i_h_wts[11, 101] = 2.46334422737304e-002;

            __statist_i_h_wts[11, 102] = -1.25726302783100e-001;

            __statist_i_h_wts[11, 103] = 2.97258467886940e-001;

            __statist_i_h_wts[11, 104] = -1.67006959299073e-001;

            __statist_i_h_wts[11, 105] = 1.98788580419225e+000;

            __statist_i_h_wts[11, 106] = -1.48267814245586e-001;

            __statist_i_h_wts[11, 107] = -1.83067906674784e+000;

            __statist_i_h_wts[11, 108] = 3.10492619226726e-002;

            __statist_i_h_wts[11, 109] = 2.74920410662611e-001;

            __statist_i_h_wts[11, 110] = -2.91133175986059e-001;

            __statist_i_h_wts[11, 111] = 2.57631667493826e-001;

            __statist_i_h_wts[11, 112] = -1.74779722632299e-001;

            __statist_i_h_wts[11, 113] = -8.84409259618704e-002;



            __statist_i_h_wts[12, 0] = -5.51683430181308e-002;

            __statist_i_h_wts[12, 1] = -1.22483259975608e-002;

            __statist_i_h_wts[12, 2] = 1.63372918834248e-002;

            __statist_i_h_wts[12, 3] = 7.64673614877428e-002;

            __statist_i_h_wts[12, 4] = 5.43601839986584e-002;

            __statist_i_h_wts[12, 5] = -4.19742322263725e-002;

            __statist_i_h_wts[12, 6] = 6.37473675021440e-002;

            __statist_i_h_wts[12, 7] = 5.94682824658819e-002;

            __statist_i_h_wts[12, 8] = -3.69495138330811e-002;

            __statist_i_h_wts[12, 9] = -2.28998981184549e-002;

            __statist_i_h_wts[12, 10] = 3.19914825942565e-002;

            __statist_i_h_wts[12, 11] = 6.86485442935162e-002;

            __statist_i_h_wts[12, 12] = -2.09028953110456e-002;

            __statist_i_h_wts[12, 13] = -5.12764917729484e-002;

            __statist_i_h_wts[12, 14] = -2.32549477979662e-002;

            __statist_i_h_wts[12, 15] = 1.06854829569201e-001;

            __statist_i_h_wts[12, 16] = -1.04949670201326e-001;

            __statist_i_h_wts[12, 17] = -6.05598659871675e-002;

            __statist_i_h_wts[12, 18] = -3.79279810408118e-002;

            __statist_i_h_wts[12, 19] = -1.05591750387472e-002;

            __statist_i_h_wts[12, 20] = -7.13284142915365e-002;

            __statist_i_h_wts[12, 21] = -1.15324984049279e-001;

            __statist_i_h_wts[12, 22] = -6.20220542163231e-002;

            __statist_i_h_wts[12, 23] = 5.80719671717627e-002;

            __statist_i_h_wts[12, 24] = 8.78690035058804e-002;

            __statist_i_h_wts[12, 25] = -7.99489615127619e-002;

            __statist_i_h_wts[12, 26] = 2.27607895304072e-002;

            __statist_i_h_wts[12, 27] = 6.16655531621636e-003;

            __statist_i_h_wts[12, 28] = 3.51057249962065e-002;

            __statist_i_h_wts[12, 29] = 3.39949659716065e-003;

            __statist_i_h_wts[12, 30] = -4.90707345616760e-002;

            __statist_i_h_wts[12, 31] = -4.24827878557428e-002;

            __statist_i_h_wts[12, 32] = 2.93584721706870e-002;

            __statist_i_h_wts[12, 33] = -3.89864736491491e-002;

            __statist_i_h_wts[12, 34] = 9.86548348015339e-002;

            __statist_i_h_wts[12, 35] = 2.29108197125632e-002;

            __statist_i_h_wts[12, 36] = -6.41609963697840e-003;

            __statist_i_h_wts[12, 37] = -1.67543103061221e-002;

            __statist_i_h_wts[12, 38] = 3.75618501776720e-002;

            __statist_i_h_wts[12, 39] = 6.25932745357688e-002;

            __statist_i_h_wts[12, 40] = -2.97853045192929e-002;

            __statist_i_h_wts[12, 41] = 2.63343987794400e-002;

            __statist_i_h_wts[12, 42] = -3.72995062858931e-001;

            __statist_i_h_wts[12, 43] = 2.21575621322348e-001;

            __statist_i_h_wts[12, 44] = 1.90795861210414e-001;

            __statist_i_h_wts[12, 45] = -5.35470373020656e-001;

            __statist_i_h_wts[12, 46] = 3.61261757899787e-001;

            __statist_i_h_wts[12, 47] = 1.81422143245972e-001;

            __statist_i_h_wts[12, 48] = 4.55699425205321e-002;

            __statist_i_h_wts[12, 49] = -6.01380164081343e-001;

            __statist_i_h_wts[12, 50] = 6.19595355482703e-001;

            __statist_i_h_wts[12, 51] = -2.86060045387525e-001;

            __statist_i_h_wts[12, 52] = 8.45377859259397e-002;

            __statist_i_h_wts[12, 53] = 2.24978564479263e-001;

            __statist_i_h_wts[12, 54] = -2.65997808328552e-001;

            __statist_i_h_wts[12, 55] = 1.22594414183283e-001;

            __statist_i_h_wts[12, 56] = 1.81747728038570e-001;

            __statist_i_h_wts[12, 57] = -2.25016225099729e-001;

            __statist_i_h_wts[12, 58] = 1.22210755005800e-001;

            __statist_i_h_wts[12, 59] = 9.79885518300012e-002;

            __statist_i_h_wts[12, 60] = -2.06026739587572e-001;

            __statist_i_h_wts[12, 61] = -1.59239529195649e-002;

            __statist_i_h_wts[12, 62] = 2.54730647405590e-001;

            __statist_i_h_wts[12, 63] = 3.80307820206697e-001;

            __statist_i_h_wts[12, 64] = -1.49071960790582e+000;

            __statist_i_h_wts[12, 65] = 1.13525908252899e+000;

            __statist_i_h_wts[12, 66] = -1.35714073207314e-001;

            __statist_i_h_wts[12, 67] = -1.48082217242260e-001;

            __statist_i_h_wts[12, 68] = 3.22106907792927e-001;

            __statist_i_h_wts[12, 69] = -3.29525582215185e-002;

            __statist_i_h_wts[12, 70] = -6.57036855677763e-002;

            __statist_i_h_wts[12, 71] = 1.45926927043453e-001;

            __statist_i_h_wts[12, 72] = -1.02527143168054e+000;

            __statist_i_h_wts[12, 73] = 5.52882267646683e-001;

            __statist_i_h_wts[12, 74] = 4.80832462812482e-001;

            __statist_i_h_wts[12, 75] = -1.59521104479538e+000;

            __statist_i_h_wts[12, 76] = 7.88303382825461e-001;

            __statist_i_h_wts[12, 77] = 8.34333696586097e-001;

            __statist_i_h_wts[12, 78] = -1.75209471709166e+000;

            __statist_i_h_wts[12, 79] = 1.02165377366580e+000;

            __statist_i_h_wts[12, 80] = 7.72770297416960e-001;

            __statist_i_h_wts[12, 81] = -9.73521084147996e-001;

            __statist_i_h_wts[12, 82] = 5.75008162641747e-001;

            __statist_i_h_wts[12, 83] = 4.35917400365976e-001;

            __statist_i_h_wts[12, 84] = 4.09659371913586e-001;

            __statist_i_h_wts[12, 85] = -2.23024510983094e-001;

            __statist_i_h_wts[12, 86] = -1.46968049437090e-001;

            __statist_i_h_wts[12, 87] = 1.41217133316537e-001;

            __statist_i_h_wts[12, 88] = 2.24704573056424e-001;

            __statist_i_h_wts[12, 89] = -3.56605766866927e-001;

            __statist_i_h_wts[12, 90] = 2.90306552945810e+000;

            __statist_i_h_wts[12, 91] = -4.33436622652312e-001;

            __statist_i_h_wts[12, 92] = -2.43054229478256e+000;

            __statist_i_h_wts[12, 93] = 2.29129797149072e-001;

            __statist_i_h_wts[12, 94] = 2.67963080205298e-002;

            __statist_i_h_wts[12, 95] = -2.25959042415308e-001;

            __statist_i_h_wts[12, 96] = 3.47220904397568e-001;

            __statist_i_h_wts[12, 97] = -2.06881439824843e-001;

            __statist_i_h_wts[12, 98] = -1.25786540986554e-001;

            __statist_i_h_wts[12, 99] = 1.94624366471193e-001;

            __statist_i_h_wts[12, 100] = -4.16666486279953e-002;

            __statist_i_h_wts[12, 101] = -1.37776639289439e-001;

            __statist_i_h_wts[12, 102] = -4.84463397243762e-002;

            __statist_i_h_wts[12, 103] = 3.07749797917055e-001;

            __statist_i_h_wts[12, 104] = -2.29506643044330e-001;

            __statist_i_h_wts[12, 105] = 1.93197683401863e+000;

            __statist_i_h_wts[12, 106] = -4.21666278252064e-001;

            __statist_i_h_wts[12, 107] = -1.49748448651416e+000;

            __statist_i_h_wts[12, 108] = 2.68017989992586e-002;

            __statist_i_h_wts[12, 109] = 2.57299895533359e-001;

            __statist_i_h_wts[12, 110] = -2.73396183239515e-001;

            __statist_i_h_wts[12, 111] = 1.67027863898227e-001;

            __statist_i_h_wts[12, 112] = -8.64904469214323e-002;

            __statist_i_h_wts[12, 113] = -5.81147374981094e-002;



            __statist_i_h_wts[13, 0] = 1.53998508909768e-002;

            __statist_i_h_wts[13, 1] = -3.86457818683628e-003;

            __statist_i_h_wts[13, 2] = -2.83078204267921e-002;

            __statist_i_h_wts[13, 3] = -7.22031434311093e-002;

            __statist_i_h_wts[13, 4] = -6.86842612805850e-004;

            __statist_i_h_wts[13, 5] = 7.88285596283935e-002;

            __statist_i_h_wts[13, 6] = -9.78035791517985e-002;

            __statist_i_h_wts[13, 7] = -7.36891416654295e-004;

            __statist_i_h_wts[13, 8] = 5.73858387189582e-002;

            __statist_i_h_wts[13, 9] = 2.17417954465724e-002;

            __statist_i_h_wts[13, 10] = 6.60159860996531e-002;

            __statist_i_h_wts[13, 11] = -6.47342776885320e-002;

            __statist_i_h_wts[13, 12] = -6.33843416285625e-002;

            __statist_i_h_wts[13, 13] = -3.96137740319906e-002;

            __statist_i_h_wts[13, 14] = -3.22053130736450e-002;

            __statist_i_h_wts[13, 15] = -1.06151551749122e-001;

            __statist_i_h_wts[13, 16] = 5.73546855360518e-002;

            __statist_i_h_wts[13, 17] = -7.81624751951132e-002;

            __statist_i_h_wts[13, 18] = -1.67692202007564e-002;

            __statist_i_h_wts[13, 19] = -2.86792148357187e-002;

            __statist_i_h_wts[13, 20] = -4.77163048872429e-002;

            __statist_i_h_wts[13, 21] = 7.41450390029248e-002;

            __statist_i_h_wts[13, 22] = -1.78983754043085e-003;

            __statist_i_h_wts[13, 23] = -3.25541901955134e-002;

            __statist_i_h_wts[13, 24] = -9.60910570688000e-002;

            __statist_i_h_wts[13, 25] = 4.55599765599196e-002;

            __statist_i_h_wts[13, 26] = -4.29960250177520e-002;

            __statist_i_h_wts[13, 27] = 1.59608008545425e-002;

            __statist_i_h_wts[13, 28] = -6.54414588879773e-002;

            __statist_i_h_wts[13, 29] = -3.86008137849098e-002;

            __statist_i_h_wts[13, 30] = 4.77078556681368e-002;

            __statist_i_h_wts[13, 31] = 1.31418827116866e-002;

            __statist_i_h_wts[13, 32] = 5.00786020426993e-002;

            __statist_i_h_wts[13, 33] = 3.15347905108894e-002;

            __statist_i_h_wts[13, 34] = -5.06484593544861e-002;

            __statist_i_h_wts[13, 35] = -4.82956368442431e-002;

            __statist_i_h_wts[13, 36] = 2.26196364124113e-003;

            __statist_i_h_wts[13, 37] = -3.34215631011382e-003;

            __statist_i_h_wts[13, 38] = -4.44725173785516e-002;

            __statist_i_h_wts[13, 39] = -1.65686077309355e-002;

            __statist_i_h_wts[13, 40] = 1.11248982465666e-001;

            __statist_i_h_wts[13, 41] = -7.18319279517680e-002;

            __statist_i_h_wts[13, 42] = -4.00946694218499e-001;

            __statist_i_h_wts[13, 43] = -6.65955172724233e-002;

            __statist_i_h_wts[13, 44] = -2.17450539146579e-002;

            __statist_i_h_wts[13, 45] = -5.74208428555410e-001;

            __statist_i_h_wts[13, 46] = 1.12680932761083e-001;

            __statist_i_h_wts[13, 47] = 2.55114870169916e-002;

            __statist_i_h_wts[13, 48] = 1.62043332764171e+000;

            __statist_i_h_wts[13, 49] = -2.00555268663392e+000;

            __statist_i_h_wts[13, 50] = -8.18388316070875e-002;

            __statist_i_h_wts[13, 51] = -5.42599661737503e-001;

            __statist_i_h_wts[13, 52] = -3.67498037146436e-002;

            __statist_i_h_wts[13, 53] = 1.10909282179329e-001;

            __statist_i_h_wts[13, 54] = -3.52328181669767e-001;

            __statist_i_h_wts[13, 55] = -8.26940651102172e-002;

            __statist_i_h_wts[13, 56] = -2.45419755063363e-002;

            __statist_i_h_wts[13, 57] = -2.86632847529025e-001;

            __statist_i_h_wts[13, 58] = -1.57510891218955e-001;

            __statist_i_h_wts[13, 59] = -4.09477945860690e-002;

            __statist_i_h_wts[13, 60] = -5.17577390187752e-001;

            __statist_i_h_wts[13, 61] = -1.01791514012817e-002;

            __statist_i_h_wts[13, 62] = 5.17844387431019e-002;

            __statist_i_h_wts[13, 63] = 2.02335867404340e+000;

            __statist_i_h_wts[13, 64] = -2.20747136043746e+000;

            __statist_i_h_wts[13, 65] = -2.80285441122549e-001;

            __statist_i_h_wts[13, 66] = -4.03988460313341e-001;

            __statist_i_h_wts[13, 67] = -9.54106212994013e-002;

            __statist_i_h_wts[13, 68] = 3.81906445410955e-002;

            __statist_i_h_wts[13, 69] = -3.27995468094497e-001;

            __statist_i_h_wts[13, 70] = -2.12746968384088e-001;

            __statist_i_h_wts[13, 71] = 9.20053029767188e-002;

            __statist_i_h_wts[13, 72] = -2.08002694451045e+000;

            __statist_i_h_wts[13, 73] = 1.65017611304862e+000;

            __statist_i_h_wts[13, 74] = -5.20351727211810e-002;

            __statist_i_h_wts[13, 75] = -2.12826584901277e+000;

            __statist_i_h_wts[13, 76] = 1.74657352880513e+000;

            __statist_i_h_wts[13, 77] = -9.00771283688890e-002;

            __statist_i_h_wts[13, 78] = -1.90730495574544e+000;

            __statist_i_h_wts[13, 79] = 1.63285659421406e+000;

            __statist_i_h_wts[13, 80] = -1.79441316471219e-001;

            __statist_i_h_wts[13, 81] = -1.80655514185720e+000;

            __statist_i_h_wts[13, 82] = 1.50182146905806e+000;

            __statist_i_h_wts[13, 83] = -1.56929419355064e-001;

            __statist_i_h_wts[13, 84] = -1.84540657958677e-001;

            __statist_i_h_wts[13, 85] = -2.46667321094701e-001;

            __statist_i_h_wts[13, 86] = 5.10270507849894e-003;

            __statist_i_h_wts[13, 87] = -6.79619933933022e-002;

            __statist_i_h_wts[13, 88] = -4.39468666421094e-001;

            __statist_i_h_wts[13, 89] = 4.27087246679372e-002;

            __statist_i_h_wts[13, 90] = 1.58128342768562e+000;

            __statist_i_h_wts[13, 91] = -2.39556649651017e+000;

            __statist_i_h_wts[13, 92] = 3.59392854939318e-001;

            __statist_i_h_wts[13, 93] = -7.79069395049931e-003;

            __statist_i_h_wts[13, 94] = -3.97093063503551e-001;

            __statist_i_h_wts[13, 95] = -2.46370023817897e-002;

            __statist_i_h_wts[13, 96] = -4.45714632377847e-002;

            __statist_i_h_wts[13, 97] = -3.94321151897353e-001;

            __statist_i_h_wts[13, 98] = -9.73648998254238e-003;

            __statist_i_h_wts[13, 99] = -3.00699343687590e-001;

            __statist_i_h_wts[13, 100] = -1.42472319947274e-001;

            __statist_i_h_wts[13, 101] = -1.31463705527121e-002;

            __statist_i_h_wts[13, 102] = -2.98384979829398e-001;

            __statist_i_h_wts[13, 103] = -3.16089269239568e-001;

            __statist_i_h_wts[13, 104] = 1.49078980402376e-001;

            __statist_i_h_wts[13, 105] = 1.32532199973115e+000;

            __statist_i_h_wts[13, 106] = -2.02883463527723e+000;

            __statist_i_h_wts[13, 107] = 2.45351421425884e-001;

            __statist_i_h_wts[13, 108] = -1.48017469544121e-001;

            __statist_i_h_wts[13, 109] = -3.24644467013432e-001;

            __statist_i_h_wts[13, 110] = 4.15354839196304e-002;

            __statist_i_h_wts[13, 111] = -1.57124667998398e-001;

            __statist_i_h_wts[13, 112] = -2.98980544639862e-001;

            __statist_i_h_wts[13, 113] = -6.92151715012563e-003;



            __statist_i_h_wts[14, 0] = -4.40193189983551e-002;

            __statist_i_h_wts[14, 1] = -2.49847992841486e-002;

            __statist_i_h_wts[14, 2] = -6.50618731750375e-002;

            __statist_i_h_wts[14, 3] = 8.50373072105015e-002;

            __statist_i_h_wts[14, 4] = -2.79551065872023e-002;

            __statist_i_h_wts[14, 5] = -2.69678345808648e-002;

            __statist_i_h_wts[14, 6] = -5.39046671490915e-002;

            __statist_i_h_wts[14, 7] = 4.88564622423181e-002;

            __statist_i_h_wts[14, 8] = 1.97152573966034e-001;

            __statist_i_h_wts[14, 9] = -5.79252476921864e-002;

            __statist_i_h_wts[14, 10] = 4.57024473697236e-002;

            __statist_i_h_wts[14, 11] = 9.26176411858034e-002;

            __statist_i_h_wts[14, 12] = -2.47679673426685e-002;

            __statist_i_h_wts[14, 13] = -7.35867203437937e-003;

            __statist_i_h_wts[14, 14] = -8.32276289296102e-002;

            __statist_i_h_wts[14, 15] = 1.60151079003421e-001;

            __statist_i_h_wts[14, 16] = -6.01909810671837e-002;

            __statist_i_h_wts[14, 17] = -1.68442918222179e-001;

            __statist_i_h_wts[14, 18] = -1.28398545662829e-001;

            __statist_i_h_wts[14, 19] = 2.35948165984067e-002;

            __statist_i_h_wts[14, 20] = 1.32695599732234e-002;

            __statist_i_h_wts[14, 21] = -6.32871294597164e-002;

            __statist_i_h_wts[14, 22] = -5.35402193876497e-002;

            __statist_i_h_wts[14, 23] = 2.89737734452114e-002;

            __statist_i_h_wts[14, 24] = -1.41691058974400e-001;

            __statist_i_h_wts[14, 25] = -3.65661829716838e-002;

            __statist_i_h_wts[14, 26] = 7.86300901035845e-002;

            __statist_i_h_wts[14, 27] = 6.22065878728428e-002;

            __statist_i_h_wts[14, 28] = -1.51124022894587e-002;

            __statist_i_h_wts[14, 29] = -3.23486164702909e-002;

            __statist_i_h_wts[14, 30] = -1.92373406299290e-002;

            __statist_i_h_wts[14, 31] = 2.99113629873227e-002;

            __statist_i_h_wts[14, 32] = 6.66330263220534e-002;

            __statist_i_h_wts[14, 33] = 4.82719235131537e-002;

            __statist_i_h_wts[14, 34] = 9.32606568006196e-002;

            __statist_i_h_wts[14, 35] = 1.74199773657846e-001;

            __statist_i_h_wts[14, 36] = -1.75698950128187e-003;

            __statist_i_h_wts[14, 37] = 1.04150053866429e-001;

            __statist_i_h_wts[14, 38] = -1.82140989382726e-002;

            __statist_i_h_wts[14, 39] = 2.77479613615025e-001;

            __statist_i_h_wts[14, 40] = 2.02481815756480e-001;

            __statist_i_h_wts[14, 41] = -7.19154728878790e-002;

            __statist_i_h_wts[14, 42] = 5.08924096985335e-002;

            __statist_i_h_wts[14, 43] = 5.38404654372007e-003;

            __statist_i_h_wts[14, 44] = 5.47007637824728e-001;

            __statist_i_h_wts[14, 45] = -3.12191358191124e-001;

            __statist_i_h_wts[14, 46] = -3.73584029096141e-001;

            __statist_i_h_wts[14, 47] = 1.24660716320975e+000;

            __statist_i_h_wts[14, 48] = -4.19036262953446e-001;

            __statist_i_h_wts[14, 49] = -3.30004428344655e-001;

            __statist_i_h_wts[14, 50] = 1.29278667794210e+000;

            __statist_i_h_wts[14, 51] = -2.35495218323296e-001;

            __statist_i_h_wts[14, 52] = -2.77752091732658e-001;

            __statist_i_h_wts[14, 53] = 1.07723824236759e+000;

            __statist_i_h_wts[14, 54] = 5.95650328472888e-002;

            __statist_i_h_wts[14, 55] = 5.33377520885569e-003;

            __statist_i_h_wts[14, 56] = 5.00289314512314e-001;

            __statist_i_h_wts[14, 57] = 1.03501128996861e-001;

            __statist_i_h_wts[14, 58] = 9.88397635941878e-002;

            __statist_i_h_wts[14, 59] = 3.49613907607766e-001;

            __statist_i_h_wts[14, 60] = -6.49636810389822e-001;

            __statist_i_h_wts[14, 61] = -6.02819426834471e-001;

            __statist_i_h_wts[14, 62] = 1.80372677526395e+000;

            __statist_i_h_wts[14, 63] = -1.30711898492245e+000;

            __statist_i_h_wts[14, 64] = -1.02225436093349e+000;

            __statist_i_h_wts[14, 65] = 2.91953146286532e+000;

            __statist_i_h_wts[14, 66] = -4.48659381516341e-001;

            __statist_i_h_wts[14, 67] = -4.43740073547074e-001;

            __statist_i_h_wts[14, 68] = 1.46216631978942e+000;

            __statist_i_h_wts[14, 69] = -2.95871571233731e-002;

            __statist_i_h_wts[14, 70] = 3.23918687579707e-002;

            __statist_i_h_wts[14, 71] = 5.75715329641468e-001;

            __statist_i_h_wts[14, 72] = -7.11199674847970e-002;

            __statist_i_h_wts[14, 73] = 4.86787657133299e-002;

            __statist_i_h_wts[14, 74] = 5.72582767438927e-001;

            __statist_i_h_wts[14, 75] = -1.09790661353308e+000;

            __statist_i_h_wts[14, 76] = -7.69289485082040e-001;

            __statist_i_h_wts[14, 77] = 2.42210127694115e+000;

            __statist_i_h_wts[14, 78] = -1.35670400898445e+000;

            __statist_i_h_wts[14, 79] = -9.54587467083401e-001;

            __statist_i_h_wts[14, 80] = 2.87510641955815e+000;

            __statist_i_h_wts[14, 81] = 2.93668574702053e-002;

            __statist_i_h_wts[14, 82] = 3.92102976505281e-002;

            __statist_i_h_wts[14, 83] = 5.18926068523520e-001;

            __statist_i_h_wts[14, 84] = 2.54850874871344e-001;

            __statist_i_h_wts[14, 85] = 3.42200089963418e-001;

            __statist_i_h_wts[14, 86] = -4.86257265080309e-002;

            __statist_i_h_wts[14, 87] = 5.70741839657952e-001;

            __statist_i_h_wts[14, 88] = 4.26108593279256e-001;

            __statist_i_h_wts[14, 89] = -4.36962429228957e-001;

            __statist_i_h_wts[14, 90] = 4.18364291391081e+000;

            __statist_i_h_wts[14, 91] = 6.22530579165432e-002;

            __statist_i_h_wts[14, 92] = -3.68139132896132e+000;

            __statist_i_h_wts[14, 93] = 5.70774685999694e-001;

            __statist_i_h_wts[14, 94] = 4.38195559544311e-001;

            __statist_i_h_wts[14, 95] = -3.98995110597014e-001;

            __statist_i_h_wts[14, 96] = 2.15833337453031e-001;

            __statist_i_h_wts[14, 97] = 2.71226158477040e-001;

            __statist_i_h_wts[14, 98] = 5.72745456126408e-002;

            __statist_i_h_wts[14, 99] = 3.82151908701729e-001;

            __statist_i_h_wts[14, 100] = 3.94756623415118e-001;

            __statist_i_h_wts[14, 101] = -2.04441672647584e-001;

            __statist_i_h_wts[14, 102] = 5.66248027768038e-001;

            __statist_i_h_wts[14, 103] = 4.89531195168443e-001;

            __statist_i_h_wts[14, 104] = -4.97628011832663e-001;

            __statist_i_h_wts[14, 105] = 8.02787439703296e-001;

            __statist_i_h_wts[14, 106] = 8.40045087328036e-001;

            __statist_i_h_wts[14, 107] = -1.07245889137479e+000;

            __statist_i_h_wts[14, 108] = 5.95773774008371e-001;

            __statist_i_h_wts[14, 109] = 3.74694450286471e-001;

            __statist_i_h_wts[14, 110] = -4.29312774466019e-001;

            __statist_i_h_wts[14, 111] = 2.66399232650648e-001;

            __statist_i_h_wts[14, 112] = 3.28780791838724e-001;

            __statist_i_h_wts[14, 113] = -4.09769396527152e-002;



            __statist_i_h_wts[15, 0] = 7.90890554132888e-002;

            __statist_i_h_wts[15, 1] = 1.10240698725933e-001;

            __statist_i_h_wts[15, 2] = -8.51670741396801e-002;

            __statist_i_h_wts[15, 3] = -9.71422465052083e-002;

            __statist_i_h_wts[15, 4] = -4.15649871217629e-002;

            __statist_i_h_wts[15, 5] = 4.31687947329416e-002;

            __statist_i_h_wts[15, 6] = -8.68135997777654e-002;

            __statist_i_h_wts[15, 7] = -5.48564605300083e-002;

            __statist_i_h_wts[15, 8] = 5.63762546532146e-002;

            __statist_i_h_wts[15, 9] = 6.65315510502214e-003;

            __statist_i_h_wts[15, 10] = 1.40120477225450e-001;

            __statist_i_h_wts[15, 11] = 3.84812653598632e-002;

            __statist_i_h_wts[15, 12] = -2.16089833159766e-002;

            __statist_i_h_wts[15, 13] = 8.03092421220838e-002;

            __statist_i_h_wts[15, 14] = -2.94197540045590e-002;

            __statist_i_h_wts[15, 15] = -8.23589298319343e-002;

            __statist_i_h_wts[15, 16] = 3.03839746465898e-002;

            __statist_i_h_wts[15, 17] = -9.64724670416180e-002;

            __statist_i_h_wts[15, 18] = -4.92413837649577e-002;

            __statist_i_h_wts[15, 19] = 5.92550678846480e-002;

            __statist_i_h_wts[15, 20] = -2.76925162212508e-002;

            __statist_i_h_wts[15, 21] = 3.92823153060046e-002;

            __statist_i_h_wts[15, 22] = 1.26570367449957e-001;

            __statist_i_h_wts[15, 23] = -4.44116264679100e-003;

            __statist_i_h_wts[15, 24] = -1.44235207993042e-001;

            __statist_i_h_wts[15, 25] = -1.59563674642502e-001;

            __statist_i_h_wts[15, 26] = -1.43194440774508e-001;

            __statist_i_h_wts[15, 27] = -1.14897875526746e-002;

            __statist_i_h_wts[15, 28] = 2.76309653117703e-002;

            __statist_i_h_wts[15, 29] = -9.30617667577943e-002;

            __statist_i_h_wts[15, 30] = 9.44281544240667e-002;

            __statist_i_h_wts[15, 31] = 7.59962700250421e-002;

            __statist_i_h_wts[15, 32] = -4.30530332251123e-002;

            __statist_i_h_wts[15, 33] = 3.82833623237626e-002;

            __statist_i_h_wts[15, 34] = -1.40849796836822e-001;

            __statist_i_h_wts[15, 35] = -4.35530557163966e-002;

            __statist_i_h_wts[15, 36] = -8.29153565848900e-003;

            __statist_i_h_wts[15, 37] = 9.21183728171857e-002;

            __statist_i_h_wts[15, 38] = -1.59419818879636e-001;

            __statist_i_h_wts[15, 39] = -1.76976713103278e-002;

            __statist_i_h_wts[15, 40] = 1.56885225744961e-001;

            __statist_i_h_wts[15, 41] = 7.64296737790682e-002;

            __statist_i_h_wts[15, 42] = -1.45054549556529e-001;

            __statist_i_h_wts[15, 43] = -1.01442215190530e-001;

            __statist_i_h_wts[15, 44] = 4.50777930887886e-002;

            __statist_i_h_wts[15, 45] = -2.82308287529491e-001;

            __statist_i_h_wts[15, 46] = 4.73823965754804e-002;

            __statist_i_h_wts[15, 47] = 3.56622603458810e-002;

            __statist_i_h_wts[15, 48] = 1.78423615753608e+000;

            __statist_i_h_wts[15, 49] = -2.13416972995654e+000;

            __statist_i_h_wts[15, 50] = 1.60023238461703e-001;

            __statist_i_h_wts[15, 51] = -2.77793256331678e-001;

            __statist_i_h_wts[15, 52] = -1.02507033203496e-001;

            __statist_i_h_wts[15, 53] = 1.80375760398430e-001;

            __statist_i_h_wts[15, 54] = -1.76581012181533e-001;

            __statist_i_h_wts[15, 55] = -9.41986751175140e-002;

            __statist_i_h_wts[15, 56] = 5.85985096903395e-002;

            __statist_i_h_wts[15, 57] = -1.96723619311357e-001;

            __statist_i_h_wts[15, 58] = -7.05096879084229e-002;

            __statist_i_h_wts[15, 59] = 6.06235541200849e-002;

            __statist_i_h_wts[15, 60] = -3.94612670965407e-001;

            __statist_i_h_wts[15, 61] = 1.67347469545644e-001;

            __statist_i_h_wts[15, 62] = 2.26245834605046e-002;

            __statist_i_h_wts[15, 63] = 2.23266552598750e+000;

            __statist_i_h_wts[15, 64] = -2.54433319929421e+000;

            __statist_i_h_wts[15, 65] = 1.12310757941341e-001;

            __statist_i_h_wts[15, 66] = -4.68269974620666e-001;

            __statist_i_h_wts[15, 67] = 1.04433196929806e-001;

            __statist_i_h_wts[15, 68] = 1.60841820210615e-001;

            __statist_i_h_wts[15, 69] = -4.59128995022672e-001;

            __statist_i_h_wts[15, 70] = -3.59784494333051e-002;

            __statist_i_h_wts[15, 71] = 2.95538034476859e-001;

            __statist_i_h_wts[15, 72] = -2.20844489167166e+000;

            __statist_i_h_wts[15, 73] = 1.90272633405206e+000;

            __statist_i_h_wts[15, 74] = 7.71122386413248e-002;

            __statist_i_h_wts[15, 75] = -2.20338687722625e+000;

            __statist_i_h_wts[15, 76] = 1.82028060554026e+000;

            __statist_i_h_wts[15, 77] = 1.65549276854222e-001;

            __statist_i_h_wts[15, 78] = -2.08431283066175e+000;

            __statist_i_h_wts[15, 79] = 1.87090273717371e+000;

            __statist_i_h_wts[15, 80] = -4.26808127568092e-004;

            __statist_i_h_wts[15, 81] = -2.10295732137215e+000;

            __statist_i_h_wts[15, 82] = 1.92854685297730e+000;

            __statist_i_h_wts[15, 83] = -4.01578283527848e-002;

            __statist_i_h_wts[15, 84] = 6.61683274189923e-002;

            __statist_i_h_wts[15, 85] = -1.65843921505374e-001;

            __statist_i_h_wts[15, 86] = -1.26021177712288e-001;

            __statist_i_h_wts[15, 87] = 6.48221019228430e-002;

            __statist_i_h_wts[15, 88] = -8.15745023945854e-002;

            __statist_i_h_wts[15, 89] = -1.70751786256137e-001;

            __statist_i_h_wts[15, 90] = 2.15689729658936e+000;

            __statist_i_h_wts[15, 91] = -2.27423588532580e+000;

            __statist_i_h_wts[15, 92] = -1.22825531169588e-001;

            __statist_i_h_wts[15, 93] = 3.23788810050734e-001;

            __statist_i_h_wts[15, 94] = -5.46759275303760e-001;

            __statist_i_h_wts[15, 95] = 3.94561485951746e-002;

            __statist_i_h_wts[15, 96] = 3.22000418212229e-001;

            __statist_i_h_wts[15, 97] = -5.25508307370587e-001;

            __statist_i_h_wts[15, 98] = 9.87906934832131e-003;

            __statist_i_h_wts[15, 99] = 1.07518037534259e-001;

            __statist_i_h_wts[15, 100] = -1.30611297953673e-001;

            __statist_i_h_wts[15, 101] = -1.55995795984220e-001;

            __statist_i_h_wts[15, 102] = -9.24741298355682e-002;

            __statist_i_h_wts[15, 103] = -1.43975619375289e-001;

            __statist_i_h_wts[15, 104] = 2.85303416133287e-002;

            __statist_i_h_wts[15, 105] = 2.00692788983397e+000;

            __statist_i_h_wts[15, 106] = -2.09309389353335e+000;

            __statist_i_h_wts[15, 107] = -9.26330554753642e-002;

            __statist_i_h_wts[15, 108] = 2.41369224781505e-001;

            __statist_i_h_wts[15, 109] = -4.73710519741006e-001;

            __statist_i_h_wts[15, 110] = 1.52102006952991e-002;

            __statist_i_h_wts[15, 111] = 1.57184263968512e-002;

            __statist_i_h_wts[15, 112] = -1.53158738471235e-001;

            __statist_i_h_wts[15, 113] = -5.16959906168230e-002;



            double[,] __statist_h_o_wts = new double[2, 16];



            __statist_h_o_wts[0, 0] = -5.33954517561313e-001;

            __statist_h_o_wts[0, 1] = -3.69234729872479e-001;

            __statist_h_o_wts[0, 2] = -2.19717543572979e-001;

            __statist_h_o_wts[0, 3] = 7.69981314845468e-001;

            __statist_h_o_wts[0, 4] = 9.12663375062387e-001;

            __statist_h_o_wts[0, 5] = 4.92326476684128e-001;

            __statist_h_o_wts[0, 6] = 4.79625947966516e-001;

            __statist_h_o_wts[0, 7] = 2.69599663157166e-001;

            __statist_h_o_wts[0, 8] = 2.73252028678628e-001;

            __statist_h_o_wts[0, 9] = -2.58597176036664e-003;

            __statist_h_o_wts[0, 10] = 1.22360667124932e+000;

            __statist_h_o_wts[0, 11] = 1.45773591723954e+000;

            __statist_h_o_wts[0, 12] = -2.95766024532470e-002;

            __statist_h_o_wts[0, 13] = -8.21309826625640e-001;

            __statist_h_o_wts[0, 14] = 3.60165040124865e+000;

            __statist_h_o_wts[0, 15] = -1.07884671809243e+000;



            __statist_h_o_wts[1, 0] = 5.21292503316732e-001;

            __statist_h_o_wts[1, 1] = 3.45913252340672e-001;

            __statist_h_o_wts[1, 2] = 2.40346384943320e-001;

            __statist_h_o_wts[1, 3] = -7.83664759562212e-001;

            __statist_h_o_wts[1, 4] = -9.31487195227281e-001;

            __statist_h_o_wts[1, 5] = -5.16000230181046e-001;

            __statist_h_o_wts[1, 6] = -4.59991139420253e-001;

            __statist_h_o_wts[1, 7] = -2.40064886213459e-001;

            __statist_h_o_wts[1, 8] = -2.67840036279625e-001;

            __statist_h_o_wts[1, 9] = 2.25095736417001e-002;

            __statist_h_o_wts[1, 10] = -1.26950836112101e+000;

            __statist_h_o_wts[1, 11] = -1.47709157695050e+000;

            __statist_h_o_wts[1, 12] = 4.41088656383393e-003;

            __statist_h_o_wts[1, 13] = 7.61074009747817e-001;

            __statist_h_o_wts[1, 14] = -3.56158523356645e+000;

            __statist_h_o_wts[1, 15] = 1.10716766357388e+000;



            double[] __statist_hidden_bias = new double[16];

            __statist_hidden_bias[0] = 5.56718587630358e-002;

            __statist_hidden_bias[1] = -3.52107749072068e-001;

            __statist_hidden_bias[2] = -1.16585265079923e+000;

            __statist_hidden_bias[3] = -2.80490625477647e-001;

            __statist_hidden_bias[4] = -3.72612963015289e-001;

            __statist_hidden_bias[5] = -1.11808964027977e+000;

            __statist_hidden_bias[6] = 7.54148114933624e-003;

            __statist_hidden_bias[7] = -6.32587609389938e-001;

            __statist_hidden_bias[8] = -4.84236978610927e-001;

            __statist_hidden_bias[9] = -6.70786140646222e-002;

            __statist_hidden_bias[10] = -3.93756640212533e-001;

            __statist_hidden_bias[11] = 3.20255352976255e-002;

            __statist_hidden_bias[12] = 4.00152650621683e-002;

            __statist_hidden_bias[13] = -4.68158334880193e-001;

            __statist_hidden_bias[14] = 5.70232346903371e-001;

            __statist_hidden_bias[15] = -1.94219001689082e-001;



            double[] __statist_output_bias = new double[2];

            __statist_output_bias[0] = -1.49556796021487e+000;

            __statist_output_bias[1] = 1.51553438172505e+000;



            double[] __statist_inputs = new double[114];



            double[] __statist_hidden = new double[16];



            double[] __statist_outputs = new double[2];

            __statist_outputs[0] = -1.0e+307;

            __statist_outputs[1] = -1.0e+307;





            if (Var4 == "0")
            {

                __statist_inputs[0] = 1;

            }

            else
            {

                __statist_inputs[0] = 0;

            }



            if (Var4 == "1")
            {

                __statist_inputs[1] = 1;

            }

            else
            {

                __statist_inputs[1] = 0;

            }



            if (Var4 == "10")
            {

                __statist_inputs[2] = 1;

            }

            else
            {

                __statist_inputs[2] = 0;

            }



            if (Var4 == "11")
            {

                __statist_inputs[3] = 1;

            }

            else
            {

                __statist_inputs[3] = 0;

            }



            if (Var4 == "12")
            {

                __statist_inputs[4] = 1;

            }

            else
            {

                __statist_inputs[4] = 0;

            }



            if (Var4 == "13")
            {

                __statist_inputs[5] = 1;

            }

            else
            {

                __statist_inputs[5] = 0;

            }



            if (Var4 == "14")
            {

                __statist_inputs[6] = 1;

            }

            else
            {

                __statist_inputs[6] = 0;

            }



            if (Var4 == "15")
            {

                __statist_inputs[7] = 1;

            }

            else
            {

                __statist_inputs[7] = 0;

            }



            if (Var4 == "16")
            {

                __statist_inputs[8] = 1;

            }

            else
            {

                __statist_inputs[8] = 0;

            }



            if (Var4 == "17")
            {

                __statist_inputs[9] = 1;

            }

            else
            {

                __statist_inputs[9] = 0;

            }



            if (Var4 == "18")
            {

                __statist_inputs[10] = 1;

            }

            else
            {

                __statist_inputs[10] = 0;

            }



            if (Var4 == "19")
            {

                __statist_inputs[11] = 1;

            }

            else
            {

                __statist_inputs[11] = 0;

            }



            if (Var4 == "2")
            {

                __statist_inputs[12] = 1;

            }

            else
            {

                __statist_inputs[12] = 0;

            }



            if (Var4 == "20")
            {

                __statist_inputs[13] = 1;

            }

            else
            {

                __statist_inputs[13] = 0;

            }



            if (Var4 == "21")
            {

                __statist_inputs[14] = 1;

            }

            else
            {

                __statist_inputs[14] = 0;

            }



            if (Var4 == "22")
            {

                __statist_inputs[15] = 1;

            }

            else
            {

                __statist_inputs[15] = 0;

            }



            if (Var4 == "23")
            {

                __statist_inputs[16] = 1;

            }

            else
            {

                __statist_inputs[16] = 0;

            }



            if (Var4 == "24")
            {

                __statist_inputs[17] = 1;

            }

            else
            {

                __statist_inputs[17] = 0;

            }



            if (Var4 == "25")
            {

                __statist_inputs[18] = 1;

            }

            else
            {

                __statist_inputs[18] = 0;

            }



            if (Var4 == "26")
            {

                __statist_inputs[19] = 1;

            }

            else
            {

                __statist_inputs[19] = 0;

            }



            if (Var4 == "27")
            {

                __statist_inputs[20] = 1;

            }

            else
            {

                __statist_inputs[20] = 0;

            }



            if (Var4 == "28")
            {

                __statist_inputs[21] = 1;

            }

            else
            {

                __statist_inputs[21] = 0;

            }



            if (Var4 == "29")
            {

                __statist_inputs[22] = 1;

            }

            else
            {

                __statist_inputs[22] = 0;

            }



            if (Var4 == "3")
            {

                __statist_inputs[23] = 1;

            }

            else
            {

                __statist_inputs[23] = 0;

            }



            if (Var4 == "30")
            {

                __statist_inputs[24] = 1;

            }

            else
            {

                __statist_inputs[24] = 0;

            }



            if (Var4 == "31")
            {

                __statist_inputs[25] = 1;

            }

            else
            {

                __statist_inputs[25] = 0;

            }



            if (Var4 == "32")
            {

                __statist_inputs[26] = 1;

            }

            else
            {

                __statist_inputs[26] = 0;

            }



            if (Var4 == "33")
            {

                __statist_inputs[27] = 1;

            }

            else
            {

                __statist_inputs[27] = 0;

            }



            if (Var4 == "34")
            {

                __statist_inputs[28] = 1;

            }

            else
            {

                __statist_inputs[28] = 0;

            }



            if (Var4 == "35")
            {

                __statist_inputs[29] = 1;

            }

            else
            {

                __statist_inputs[29] = 0;

            }



            if (Var4 == "36")
            {

                __statist_inputs[30] = 1;

            }

            else
            {

                __statist_inputs[30] = 0;

            }



            if (Var4 == "37")
            {

                __statist_inputs[31] = 1;

            }

            else
            {

                __statist_inputs[31] = 0;

            }



            if (Var4 == "38")
            {

                __statist_inputs[32] = 1;

            }

            else
            {

                __statist_inputs[32] = 0;

            }



            if (Var4 == "39")
            {

                __statist_inputs[33] = 1;

            }

            else
            {

                __statist_inputs[33] = 0;

            }



            if (Var4 == "4")
            {

                __statist_inputs[34] = 1;

            }

            else
            {

                __statist_inputs[34] = 0;

            }



            if (Var4 == "40")
            {

                __statist_inputs[35] = 1;

            }

            else
            {

                __statist_inputs[35] = 0;

            }



            if (Var4 == "41")
            {

                __statist_inputs[36] = 1;

            }

            else
            {

                __statist_inputs[36] = 0;

            }



            if (Var4 == "5")
            {

                __statist_inputs[37] = 1;

            }

            else
            {

                __statist_inputs[37] = 0;

            }



            if (Var4 == "6")
            {

                __statist_inputs[38] = 1;

            }

            else
            {

                __statist_inputs[38] = 0;

            }



            if (Var4 == "7")
            {

                __statist_inputs[39] = 1;

            }

            else
            {

                __statist_inputs[39] = 0;

            }



            if (Var4 == "8")
            {

                __statist_inputs[40] = 1;

            }

            else
            {

                __statist_inputs[40] = 0;

            }



            if (Var4 == "9")
            {

                __statist_inputs[41] = 1;

            }

            else
            {

                __statist_inputs[41] = 0;

            }



            if (Var6 == "0")
            {

                __statist_inputs[42] = 1;

            }

            else
            {

                __statist_inputs[42] = 0;

            }



            if (Var6 == "1")
            {

                __statist_inputs[43] = 1;

            }

            else
            {

                __statist_inputs[43] = 0;

            }



            if (Var6 == "2")
            {

                __statist_inputs[44] = 1;

            }

            else
            {

                __statist_inputs[44] = 0;

            }



            if (Var7 == "0")
            {

                __statist_inputs[45] = 1;

            }

            else
            {

                __statist_inputs[45] = 0;

            }



            if (Var7 == "1")
            {

                __statist_inputs[46] = 1;

            }

            else
            {

                __statist_inputs[46] = 0;

            }



            if (Var7 == "2")
            {

                __statist_inputs[47] = 1;

            }

            else
            {

                __statist_inputs[47] = 0;

            }



            if (Var8 == "0")
            {

                __statist_inputs[48] = 1;

            }

            else
            {

                __statist_inputs[48] = 0;

            }



            if (Var8 == "1")
            {

                __statist_inputs[49] = 1;

            }

            else
            {

                __statist_inputs[49] = 0;

            }



            if (Var8 == "2")
            {

                __statist_inputs[50] = 1;

            }

            else
            {

                __statist_inputs[50] = 0;

            }



            if (Var9 == "0")
            {

                __statist_inputs[51] = 1;

            }

            else
            {

                __statist_inputs[51] = 0;

            }



            if (Var9 == "1")
            {

                __statist_inputs[52] = 1;

            }

            else
            {

                __statist_inputs[52] = 0;

            }



            if (Var9 == "2")
            {

                __statist_inputs[53] = 1;

            }

            else
            {

                __statist_inputs[53] = 0;

            }



            if (Var10 == "0")
            {

                __statist_inputs[54] = 1;

            }

            else
            {

                __statist_inputs[54] = 0;

            }



            if (Var10 == "1")
            {

                __statist_inputs[55] = 1;

            }

            else
            {

                __statist_inputs[55] = 0;

            }



            if (Var10 == "2")
            {

                __statist_inputs[56] = 1;

            }

            else
            {

                __statist_inputs[56] = 0;

            }



            if (Var11 == "0")
            {

                __statist_inputs[57] = 1;

            }

            else
            {

                __statist_inputs[57] = 0;

            }



            if (Var11 == "1")
            {

                __statist_inputs[58] = 1;

            }

            else
            {

                __statist_inputs[58] = 0;

            }



            if (Var11 == "2")
            {

                __statist_inputs[59] = 1;

            }

            else
            {

                __statist_inputs[59] = 0;

            }



            if (Var12 == "0")
            {

                __statist_inputs[60] = 1;

            }

            else
            {

                __statist_inputs[60] = 0;

            }



            if (Var12 == "1")
            {

                __statist_inputs[61] = 1;

            }

            else
            {

                __statist_inputs[61] = 0;

            }



            if (Var12 == "2")
            {

                __statist_inputs[62] = 1;

            }

            else
            {

                __statist_inputs[62] = 0;

            }



            if (Var13 == "0")
            {

                __statist_inputs[63] = 1;

            }

            else
            {

                __statist_inputs[63] = 0;

            }



            if (Var13 == "1")
            {

                __statist_inputs[64] = 1;

            }

            else
            {

                __statist_inputs[64] = 0;

            }



            if (Var13 == "2")
            {

                __statist_inputs[65] = 1;

            }

            else
            {

                __statist_inputs[65] = 0;

            }



            if (Var14 == "0")
            {

                __statist_inputs[66] = 1;

            }

            else
            {

                __statist_inputs[66] = 0;

            }



            if (Var14 == "1")
            {

                __statist_inputs[67] = 1;

            }

            else
            {

                __statist_inputs[67] = 0;

            }



            if (Var14 == "2")
            {

                __statist_inputs[68] = 1;

            }

            else
            {

                __statist_inputs[68] = 0;

            }



            if (Var15 == "0")
            {

                __statist_inputs[69] = 1;

            }

            else
            {

                __statist_inputs[69] = 0;

            }



            if (Var15 == "1")
            {

                __statist_inputs[70] = 1;

            }

            else
            {

                __statist_inputs[70] = 0;

            }



            if (Var15 == "2")
            {

                __statist_inputs[71] = 1;

            }

            else
            {

                __statist_inputs[71] = 0;

            }



            if (Var16 == "0")
            {

                __statist_inputs[72] = 1;

            }

            else
            {

                __statist_inputs[72] = 0;

            }



            if (Var16 == "1")
            {

                __statist_inputs[73] = 1;

            }

            else
            {

                __statist_inputs[73] = 0;

            }



            if (Var16 == "2")
            {

                __statist_inputs[74] = 1;

            }

            else
            {

                __statist_inputs[74] = 0;

            }



            if (Var17 == "0")
            {

                __statist_inputs[75] = 1;

            }

            else
            {

                __statist_inputs[75] = 0;

            }



            if (Var17 == "1")
            {

                __statist_inputs[76] = 1;

            }

            else
            {

                __statist_inputs[76] = 0;

            }



            if (Var17 == "2")
            {

                __statist_inputs[77] = 1;

            }

            else
            {

                __statist_inputs[77] = 0;

            }



            if (Var19 == "0")
            {

                __statist_inputs[78] = 1;

            }

            else
            {

                __statist_inputs[78] = 0;

            }



            if (Var19 == "1")
            {

                __statist_inputs[79] = 1;

            }

            else
            {

                __statist_inputs[79] = 0;

            }



            if (Var19 == "2")
            {

                __statist_inputs[80] = 1;

            }

            else
            {

                __statist_inputs[80] = 0;

            }



            if (Var20 == "0")
            {

                __statist_inputs[81] = 1;

            }

            else
            {

                __statist_inputs[81] = 0;

            }



            if (Var20 == "1")
            {

                __statist_inputs[82] = 1;

            }

            else
            {

                __statist_inputs[82] = 0;

            }



            if (Var20 == "2")
            {

                __statist_inputs[83] = 1;

            }

            else
            {

                __statist_inputs[83] = 0;

            }



            if (Var21 == "0")
            {

                __statist_inputs[84] = 1;

            }

            else
            {

                __statist_inputs[84] = 0;

            }



            if (Var21 == "1")
            {

                __statist_inputs[85] = 1;

            }

            else
            {

                __statist_inputs[85] = 0;

            }



            if (Var21 == "2")
            {

                __statist_inputs[86] = 1;

            }

            else
            {

                __statist_inputs[86] = 0;

            }



            if (Var22 == "0")
            {

                __statist_inputs[87] = 1;

            }

            else
            {

                __statist_inputs[87] = 0;

            }



            if (Var22 == "1")
            {

                __statist_inputs[88] = 1;

            }

            else
            {

                __statist_inputs[88] = 0;

            }



            if (Var22 == "2")
            {

                __statist_inputs[89] = 1;

            }

            else
            {

                __statist_inputs[89] = 0;

            }



            if (Var23 == "0")
            {

                __statist_inputs[90] = 1;

            }

            else
            {

                __statist_inputs[90] = 0;

            }



            if (Var23 == "1")
            {

                __statist_inputs[91] = 1;

            }

            else
            {

                __statist_inputs[91] = 0;

            }



            if (Var23 == "2")
            {

                __statist_inputs[92] = 1;

            }

            else
            {

                __statist_inputs[92] = 0;

            }



            if (Var24 == "0")
            {

                __statist_inputs[93] = 1;

            }

            else
            {

                __statist_inputs[93] = 0;

            }



            if (Var24 == "1")
            {

                __statist_inputs[94] = 1;

            }

            else
            {

                __statist_inputs[94] = 0;

            }



            if (Var24 == "2")
            {

                __statist_inputs[95] = 1;

            }

            else
            {

                __statist_inputs[95] = 0;

            }



            if (Var25 == "0")
            {

                __statist_inputs[96] = 1;

            }

            else
            {

                __statist_inputs[96] = 0;

            }



            if (Var25 == "1")
            {

                __statist_inputs[97] = 1;

            }

            else
            {

                __statist_inputs[97] = 0;

            }



            if (Var25 == "2")
            {

                __statist_inputs[98] = 1;

            }

            else
            {

                __statist_inputs[98] = 0;

            }



            if (Var26 == "0")
            {

                __statist_inputs[99] = 1;

            }

            else
            {

                __statist_inputs[99] = 0;

            }



            if (Var26 == "1")
            {

                __statist_inputs[100] = 1;

            }

            else
            {

                __statist_inputs[100] = 0;

            }



            if (Var26 == "2")
            {

                __statist_inputs[101] = 1;

            }

            else
            {

                __statist_inputs[101] = 0;

            }



            if (Var27 == "0")
            {

                __statist_inputs[102] = 1;

            }

            else
            {

                __statist_inputs[102] = 0;

            }



            if (Var27 == "1")
            {

                __statist_inputs[103] = 1;

            }

            else
            {

                __statist_inputs[103] = 0;

            }



            if (Var27 == "2")
            {

                __statist_inputs[104] = 1;

            }

            else
            {

                __statist_inputs[104] = 0;

            }



            if (Var28 == "0")
            {

                __statist_inputs[105] = 1;

            }

            else
            {

                __statist_inputs[105] = 0;

            }



            if (Var28 == "1")
            {

                __statist_inputs[106] = 1;

            }

            else
            {

                __statist_inputs[106] = 0;

            }



            if (Var28 == "2")
            {

                __statist_inputs[107] = 1;

            }

            else
            {

                __statist_inputs[107] = 0;

            }



            if (Var29 == "0")
            {

                __statist_inputs[108] = 1;

            }

            else
            {

                __statist_inputs[108] = 0;

            }



            if (Var29 == "1")
            {

                __statist_inputs[109] = 1;

            }

            else
            {

                __statist_inputs[109] = 0;

            }



            if (Var29 == "2")
            {

                __statist_inputs[110] = 1;

            }

            else
            {

                __statist_inputs[110] = 0;

            }



            if (Var30 == "0")
            {

                __statist_inputs[111] = 1;

            }

            else
            {

                __statist_inputs[111] = 0;

            }



            if (Var30 == "1")
            {

                __statist_inputs[112] = 1;

            }

            else
            {

                __statist_inputs[112] = 0;

            }



            if (Var30 == "2")
            {

                __statist_inputs[113] = 1;

            }

            else
            {

                __statist_inputs[113] = 0;

            }



            double __statist_delta = 0;

            double __statist_maximum = 1;

            double __statist_minimum = 0;

            int __statist_ninputs = 114;

            int __statist_nhidden = 16;



            /*Compute feed forward signals from Input layer to hidden layer*/

            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                __statist_hidden[__statist_row] = 0.0;

                for (int __statist_col = 0; __statist_col < __statist_ninputs; __statist_col++)
                {

                    __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + (__statist_i_h_wts[__statist_row, __statist_col] * __statist_inputs[__statist_col]);

                }

                __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + __statist_hidden_bias[__statist_row];

            }



            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                if (__statist_hidden[__statist_row] > 100.0)
                {

                    __statist_hidden[__statist_row] = 1.0;

                }

                else
                {

                    if (__statist_hidden[__statist_row] < -100.0)
                    {

                        __statist_hidden[__statist_row] = 0.0;

                    }

                    else
                    {

                        __statist_hidden[__statist_row] = 1.0 / (1.0 + Math.Exp(-__statist_hidden[__statist_row]));

                    }

                }

            }



            int __statist_noutputs = 2;



            /*Compute feed forward signals from hidden layer to output layer*/

            for (int __statist_row2 = 0; __statist_row2 < __statist_noutputs; __statist_row2++)
            {

                __statist_outputs[__statist_row2] = 0.0;

                for (int __statist_col2 = 0; __statist_col2 < __statist_nhidden; __statist_col2++)
                {

                    __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + (__statist_h_o_wts[__statist_row2, __statist_col2] * __statist_hidden[__statist_col2]);

                }

                __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + __statist_output_bias[__statist_row2];

            }





            double __statist_sum = 0.0;

            double __statist_maxIndex = 0;

            for (int __statist_jj = 0; __statist_jj < __statist_noutputs; __statist_jj++)
            {

                if (__statist_outputs[__statist_jj] > 200)
                {

                    double __statist_max = __statist_outputs[1];

                    __statist_maxIndex = 0;

                    for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
                    {

                        if (__statist_outputs[__statist_ii] > __statist_max)
                        {

                            __statist_max = __statist_outputs[__statist_ii];

                            __statist_maxIndex = __statist_ii;

                        }

                    }



                    for (int __statist_kk = 0; __statist_kk < __statist_noutputs; __statist_kk++)
                    {

                        if (__statist_kk == __statist_maxIndex)
                        {

                            __statist_outputs[__statist_jj] = 1.0;

                        }

                        else
                        {

                            __statist_outputs[__statist_kk] = 0.0;

                        }

                    }

                }

                else
                {

                    __statist_outputs[__statist_jj] = Math.Exp(__statist_outputs[__statist_jj]);

                    __statist_sum = __statist_sum + __statist_outputs[__statist_jj];

                }

            }

            for (int __statist_ll = 0; __statist_ll < __statist_noutputs; __statist_ll++)
            {

                if (__statist_sum != 0)
                {

                    __statist_outputs[__statist_ll] = __statist_outputs[__statist_ll] / __statist_sum;

                }

            }



            int __statist_PredIndex = 1;

            for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
            {

                if (__statist_ConfLevel < __statist_outputs[__statist_ii])
                {

                    __statist_ConfLevel = __statist_outputs[__statist_ii];

                    __statist_PredIndex = __statist_ii;

                }

            }



            __statist_PredCat = __statist_DCats[__statist_PredIndex];

            string[] prediction = new string[2] { __statist_PredCat, __statist_ConfLevel.ToString() };
            
            return prediction;
        }



       public static string[] Main (string[] args) 
       {

         int argID = 0;

         string[] CatInputs = new string[25];

         int catID = 0;



         if (args.Length >= 25)

         {

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

             CatInputs[catID++] = args[argID++];

         }

         else

         {

             string Comment = "";

             string Comment1 = "**************************************************************************\n";

             Comment += Comment1;

             string Comment2 = "Please enter at least NaN command line parameters in the following order for \nthe program to Predict.\n";

             Comment += Comment2;

             Comment += Comment1;

             string Comment3 = "Var4  Type - String (categories are { \"0\"  \"1\"  \"10\"  \"11\"  \"12\"  \"13\"  \"14\"  \"15\"  \"16\"  \"17\"  \"18\"  \"19\"  \"2\"  \"20\"  \"21\"  \"22\"  \"23\"  \"24\"  \"25\"  \"26\"  \"27\"  \"28\"  \"29\"  \"3\"  \"30\"  \"31\"  \"32\"  \"33\"  \"34\"  \"35\"  \"36\"  \"37\"  \"38\"  \"39\"  \"4\"  \"40\"  \"41\"  \"5\"  \"6\"  \"7\"  \"8\"  \"9\" } )\n";

             Comment += Comment3;

             string Comment4 = "Var6  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment4;

             string Comment5 = "Var7  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment5;

             string Comment6 = "Var8  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment6;

             string Comment7 = "Var9  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment7;

             string Comment8 = "Var10  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment8;

             string Comment9 = "Var11  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment9;

             string Comment10 = "Var12  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment10;

             string Comment11 = "Var13  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment11;

             string Comment12 = "Var14  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment12;

             string Comment13 = "Var15  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment13;

             string Comment14 = "Var16  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment14;

             string Comment15 = "Var17  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment15;

             string Comment16 = "Var19  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment16;

             string Comment17 = "Var20  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment17;

             string Comment18 = "Var21  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment18;

             string Comment19 = "Var22  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment19;

             string Comment20 = "Var23  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment20;

             string Comment21 = "Var24  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment21;

             string Comment22 = "Var25  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment22;

             string Comment23 = "Var26  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment23;

             string Comment24 = "Var27  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment24;

             string Comment25 = "Var28  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment25;

             string Comment26 = "Var29  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment26;

             string Comment27 = "Var30  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

             Comment += Comment27;

             Comment += Comment1;

           return new string[] { Comment };
         }

         return MLP_114_16_2(CatInputs);
       }
        
    }
}
