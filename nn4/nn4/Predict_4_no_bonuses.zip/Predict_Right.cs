﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nn4
{
    class Predict_Right
    {
        /**C# deployment code of Neural Networks Model**/

        /**==========================================================================
        Before running the C# deployment code please read the following.

         STATISTICA variable names will be exported as-is into the C# deployment script;
        please verify the resulting script to ensure that the variable names follow the C#
        naming conventions and modify the names if necessary.

        ==========================================================================**/

        public static string[] MLP_114_17_2(string[] CatInputs)
        {
            int Cat_idx = 0;

            string Var4 = CatInputs[Cat_idx++]; //Input Variable

            string Var6 = CatInputs[Cat_idx++]; //Input Variable

            string Var7 = CatInputs[Cat_idx++]; //Input Variable

            string Var8 = CatInputs[Cat_idx++]; //Input Variable

            string Var9 = CatInputs[Cat_idx++]; //Input Variable

            string Var10 = CatInputs[Cat_idx++]; //Input Variable

            string Var11 = CatInputs[Cat_idx++]; //Input Variable

            string Var12 = CatInputs[Cat_idx++]; //Input Variable

            string Var13 = CatInputs[Cat_idx++]; //Input Variable

            string Var14 = CatInputs[Cat_idx++]; //Input Variable

            string Var15 = CatInputs[Cat_idx++]; //Input Variable

            string Var16 = CatInputs[Cat_idx++]; //Input Variable

            string Var17 = CatInputs[Cat_idx++]; //Input Variable

            string Var20 = CatInputs[Cat_idx++]; //Input Variable

            string Var21 = CatInputs[Cat_idx++]; //Input Variable

            string Var22 = CatInputs[Cat_idx++]; //Input Variable

            string Var23 = CatInputs[Cat_idx++]; //Input Variable

            string Var24 = CatInputs[Cat_idx++]; //Input Variable

            string Var25 = CatInputs[Cat_idx++]; //Input Variable

            string Var26 = CatInputs[Cat_idx++]; //Input Variable

            string Var27 = CatInputs[Cat_idx++]; //Input Variable

            string Var28 = CatInputs[Cat_idx++]; //Input Variable

            string Var29 = CatInputs[Cat_idx++]; //Input Variable

            string Var30 = CatInputs[Cat_idx++]; //Input Variable

            string Var19 = CatInputs[Cat_idx++]; //Input Variable

            string __statist_PredCat = "";

            string[] __statist_DCats = new string[2];

            __statist_DCats[0] = "0";

            __statist_DCats[1] = "2";



            double __statist_ConfLevel = 3.0E-300;







            double[,] __statist_i_h_wts = new double[17, 114];



            __statist_i_h_wts[0, 0] = 4.09950600201985e-003;

            __statist_i_h_wts[0, 1] = -3.74357598335655e-002;

            __statist_i_h_wts[0, 2] = 3.56464509117030e-002;

            __statist_i_h_wts[0, 3] = 5.24609287121345e-002;

            __statist_i_h_wts[0, 4] = 1.14315854927198e-002;

            __statist_i_h_wts[0, 5] = 2.42842754287591e-002;

            __statist_i_h_wts[0, 6] = 2.84403705331980e-002;

            __statist_i_h_wts[0, 7] = 4.75349984148506e-002;

            __statist_i_h_wts[0, 8] = 6.34153043127174e-002;

            __statist_i_h_wts[0, 9] = 1.75247618031648e-002;

            __statist_i_h_wts[0, 10] = 3.78687646800003e-002;

            __statist_i_h_wts[0, 11] = 6.08544604061618e-002;

            __statist_i_h_wts[0, 12] = -6.02604726056474e-003;

            __statist_i_h_wts[0, 13] = 1.11716121871738e-002;

            __statist_i_h_wts[0, 14] = -3.36235774670381e-002;

            __statist_i_h_wts[0, 15] = 3.60416540819128e-002;

            __statist_i_h_wts[0, 16] = 2.53278493423855e-003;

            __statist_i_h_wts[0, 17] = -3.76178373080008e-002;

            __statist_i_h_wts[0, 18] = -3.27794500867656e-002;

            __statist_i_h_wts[0, 19] = -6.07336315086756e-002;

            __statist_i_h_wts[0, 20] = -4.32757022040974e-002;

            __statist_i_h_wts[0, 21] = -5.30637729167015e-002;

            __statist_i_h_wts[0, 22] = -3.79905655901845e-003;

            __statist_i_h_wts[0, 23] = -1.58456003463239e-002;

            __statist_i_h_wts[0, 24] = 1.53252331679452e-003;

            __statist_i_h_wts[0, 25] = 2.29607805219496e-002;

            __statist_i_h_wts[0, 26] = 3.15168796961054e-002;

            __statist_i_h_wts[0, 27] = 3.89601488737393e-002;

            __statist_i_h_wts[0, 28] = 3.43239244975929e-002;

            __statist_i_h_wts[0, 29] = 2.13660323440170e-003;

            __statist_i_h_wts[0, 30] = -4.63950723850725e-003;

            __statist_i_h_wts[0, 31] = -8.93110447887191e-003;

            __statist_i_h_wts[0, 32] = 4.54361899439267e-003;

            __statist_i_h_wts[0, 33] = 2.41811190948561e-002;

            __statist_i_h_wts[0, 34] = 5.39354324435192e-002;

            __statist_i_h_wts[0, 35] = 4.65997971890206e-002;

            __statist_i_h_wts[0, 36] = 1.30502999086478e-002;

            __statist_i_h_wts[0, 37] = -2.36455976706907e-003;

            __statist_i_h_wts[0, 38] = -1.44286383908403e-002;

            __statist_i_h_wts[0, 39] = 4.08936828992555e-002;

            __statist_i_h_wts[0, 40] = -1.52040890805380e-002;

            __statist_i_h_wts[0, 41] = 1.86563390558748e-002;

            __statist_i_h_wts[0, 42] = 1.92163683686697e-001;

            __statist_i_h_wts[0, 43] = 3.45922199316420e-001;

            __statist_i_h_wts[0, 44] = -7.91060701919285e-002;

            __statist_i_h_wts[0, 45] = 7.52156627312354e-003;

            __statist_i_h_wts[0, 46] = 5.16764698716245e-001;

            __statist_i_h_wts[0, 47] = -7.17673914180958e-002;

            __statist_i_h_wts[0, 48] = 6.62108067471695e-001;

            __statist_i_h_wts[0, 49] = -2.25193878217279e-002;

            __statist_i_h_wts[0, 50] = -1.89051692073989e-001;

            __statist_i_h_wts[0, 51] = -4.45582588135618e-001;

            __statist_i_h_wts[0, 52] = 7.50329820220383e-001;

            __statist_i_h_wts[0, 53] = 1.37252581039557e-001;

            __statist_i_h_wts[0, 54] = 1.74930518468869e-002;

            __statist_i_h_wts[0, 55] = 2.67506085881234e-001;

            __statist_i_h_wts[0, 56] = 1.56368535285633e-001;

            __statist_i_h_wts[0, 57] = 3.89318268003442e-001;

            __statist_i_h_wts[0, 58] = 2.02211617197425e-001;

            __statist_i_h_wts[0, 59] = -1.53014267647983e-001;

            __statist_i_h_wts[0, 60] = 1.45391608711375e-001;

            __statist_i_h_wts[0, 61] = 4.81356269246619e-001;

            __statist_i_h_wts[0, 62] = -1.37035302943563e-001;

            __statist_i_h_wts[0, 63] = 9.51703695965002e-001;

            __statist_i_h_wts[0, 64] = -1.70993701352012e-001;

            __statist_i_h_wts[0, 65] = -3.24592045955952e-001;

            __statist_i_h_wts[0, 66] = -3.25290194433101e-001;

            __statist_i_h_wts[0, 67] = 4.86376369469377e-001;

            __statist_i_h_wts[0, 68] = 2.93012617883732e-001;

            __statist_i_h_wts[0, 69] = 1.60151002826115e-001;

            __statist_i_h_wts[0, 70] = 5.85411310674159e-002;

            __statist_i_h_wts[0, 71] = 2.17809198658961e-001;

            __statist_i_h_wts[0, 72] = -3.76727394133663e-001;

            __statist_i_h_wts[0, 73] = 1.17323014218664e+000;

            __statist_i_h_wts[0, 74] = -3.72724959358671e-001;

            __statist_i_h_wts[0, 75] = -8.28283624366365e-001;

            __statist_i_h_wts[0, 76] = 1.72440022569248e+000;

            __statist_i_h_wts[0, 77] = -4.72133922036344e-001;

            __statist_i_h_wts[0, 78] = -1.23875023698965e+000;

            __statist_i_h_wts[0, 79] = 9.35334439850806e-001;

            __statist_i_h_wts[0, 80] = 7.57809615297169e-001;

            __statist_i_h_wts[0, 81] = 2.73146032535497e-001;

            __statist_i_h_wts[0, 82] = 2.97995430378555e-001;

            __statist_i_h_wts[0, 83] = -1.28883274542712e-001;

            __statist_i_h_wts[0, 84] = 6.69907381249431e-002;

            __statist_i_h_wts[0, 85] = 5.05564008255297e-001;

            __statist_i_h_wts[0, 86] = -1.38212491277140e-001;

            __statist_i_h_wts[0, 87] = 8.70862203856149e-001;

            __statist_i_h_wts[0, 88] = -1.05060056032349e-001;

            __statist_i_h_wts[0, 89] = -3.08691524544583e-001;

            __statist_i_h_wts[0, 90] = -3.51853839968580e-001;

            __statist_i_h_wts[0, 91] = 5.35492353602049e-001;

            __statist_i_h_wts[0, 92] = 2.66844511399938e-001;

            __statist_i_h_wts[0, 93] = 6.91164132605713e-002;

            __statist_i_h_wts[0, 94] = 1.56136629513776e-001;

            __statist_i_h_wts[0, 95] = 2.14738322007401e-001;

            __statist_i_h_wts[0, 96] = 2.57538955357876e-001;

            __statist_i_h_wts[0, 97] = 3.03359193732439e-001;

            __statist_i_h_wts[0, 98] = -1.18126432380776e-001;

            __statist_i_h_wts[0, 99] = 8.33006434029667e-002;

            __statist_i_h_wts[0, 100] = 4.97213644682105e-001;

            __statist_i_h_wts[0, 101] = -9.77719927514444e-002;

            __statist_i_h_wts[0, 102] = 6.87305338033318e-001;

            __statist_i_h_wts[0, 103] = -4.49742460720697e-002;

            __statist_i_h_wts[0, 104] = -1.92824282284751e-001;

            __statist_i_h_wts[0, 105] = -3.74299309818600e-001;

            __statist_i_h_wts[0, 106] = 7.11938320291754e-001;

            __statist_i_h_wts[0, 107] = 1.12914982986610e-001;

            __statist_i_h_wts[0, 108] = -5.49679151846375e-002;

            __statist_i_h_wts[0, 109] = 3.67559249274442e-001;

            __statist_i_h_wts[0, 110] = 1.54050466464557e-001;

            __statist_i_h_wts[0, 111] = -2.05323628245515e+000;

            __statist_i_h_wts[0, 112] = 1.32564610060617e+000;

            __statist_i_h_wts[0, 113] = 1.15624082004697e+000;



            __statist_i_h_wts[1, 0] = -5.30044211947276e-002;

            __statist_i_h_wts[1, 1] = 1.42924760891313e-002;

            __statist_i_h_wts[1, 2] = -6.59175223880446e-002;

            __statist_i_h_wts[1, 3] = -1.72344407507020e-002;

            __statist_i_h_wts[1, 4] = 8.64274820711401e-002;

            __statist_i_h_wts[1, 5] = 8.38205459531640e-003;

            __statist_i_h_wts[1, 6] = 1.44382834104618e-002;

            __statist_i_h_wts[1, 7] = -5.57692865790163e-003;

            __statist_i_h_wts[1, 8] = -6.15581741301871e-002;

            __statist_i_h_wts[1, 9] = -3.78962508681380e-002;

            __statist_i_h_wts[1, 10] = -2.04787933662613e-002;

            __statist_i_h_wts[1, 11] = -7.57293222456749e-002;

            __statist_i_h_wts[1, 12] = -5.53393753684659e-002;

            __statist_i_h_wts[1, 13] = 2.26940591106815e-002;

            __statist_i_h_wts[1, 14] = 3.66335000536212e-002;

            __statist_i_h_wts[1, 15] = 1.99632732119034e-002;

            __statist_i_h_wts[1, 16] = -1.23552234418689e-002;

            __statist_i_h_wts[1, 17] = 9.04611262104070e-002;

            __statist_i_h_wts[1, 18] = 1.13531313912610e-001;

            __statist_i_h_wts[1, 19] = 7.63131849766278e-003;

            __statist_i_h_wts[1, 20] = 4.19217548157929e-002;

            __statist_i_h_wts[1, 21] = 4.84530501656413e-003;

            __statist_i_h_wts[1, 22] = 7.44451045738852e-002;

            __statist_i_h_wts[1, 23] = 3.67913923348409e-003;

            __statist_i_h_wts[1, 24] = 2.59033862859538e-002;

            __statist_i_h_wts[1, 25] = -3.38139261846149e-002;

            __statist_i_h_wts[1, 26] = -4.48114099936913e-002;

            __statist_i_h_wts[1, 27] = 9.66010487279300e-003;

            __statist_i_h_wts[1, 28] = -3.38189772692292e-002;

            __statist_i_h_wts[1, 29] = 2.90034171095760e-002;

            __statist_i_h_wts[1, 30] = 2.11476552070416e-002;

            __statist_i_h_wts[1, 31] = 5.10225413129426e-002;

            __statist_i_h_wts[1, 32] = -1.81051796441500e-002;

            __statist_i_h_wts[1, 33] = 7.36789434288321e-003;

            __statist_i_h_wts[1, 34] = 2.22586540808055e-003;

            __statist_i_h_wts[1, 35] = -6.48982420016395e-002;

            __statist_i_h_wts[1, 36] = -1.89365270522505e-003;

            __statist_i_h_wts[1, 37] = 7.84237706320845e-003;

            __statist_i_h_wts[1, 38] = 4.06671356154706e-002;

            __statist_i_h_wts[1, 39] = -1.15028748943915e-002;

            __statist_i_h_wts[1, 40] = 6.58434520544139e-003;

            __statist_i_h_wts[1, 41] = 5.03781309207937e-003;

            __statist_i_h_wts[1, 42] = 3.25918918575005e-002;

            __statist_i_h_wts[1, 43] = -9.22119327286775e-002;

            __statist_i_h_wts[1, 44] = 5.83708971105379e-002;

            __statist_i_h_wts[1, 45] = 5.58380798224837e-002;

            __statist_i_h_wts[1, 46] = -7.97637229480292e-002;

            __statist_i_h_wts[1, 47] = 5.00506818579516e-002;

            __statist_i_h_wts[1, 48] = -1.35187784493115e-001;

            __statist_i_h_wts[1, 49] = -3.38141942840157e-002;

            __statist_i_h_wts[1, 50] = 1.92126497828044e-001;

            __statist_i_h_wts[1, 51] = 1.82996471625859e-001;

            __statist_i_h_wts[1, 52] = -1.67610018715539e-001;

            __statist_i_h_wts[1, 53] = -6.06637592729368e-003;

            __statist_i_h_wts[1, 54] = 6.43987146724773e-002;

            __statist_i_h_wts[1, 55] = 6.42441261355687e-002;

            __statist_i_h_wts[1, 56] = -8.13072805743300e-002;

            __statist_i_h_wts[1, 57] = -1.62319751484529e-002;

            __statist_i_h_wts[1, 58] = -7.50497852706913e-002;

            __statist_i_h_wts[1, 59] = 7.49882337172196e-002;

            __statist_i_h_wts[1, 60] = -2.94972646393949e-002;

            __statist_i_h_wts[1, 61] = -1.22573140581123e-001;

            __statist_i_h_wts[1, 62] = 1.47729188641326e-001;

            __statist_i_h_wts[1, 63] = -3.83076576962135e-001;

            __statist_i_h_wts[1, 64] = 7.71820786594477e-002;

            __statist_i_h_wts[1, 65] = 3.08413255226112e-001;

            __statist_i_h_wts[1, 66] = 5.40135719384656e-002;

            __statist_i_h_wts[1, 67] = 7.24846600893134e-002;

            __statist_i_h_wts[1, 68] = -1.35225712516086e-001;

            __statist_i_h_wts[1, 69] = -2.56293216752358e-002;

            __statist_i_h_wts[1, 70] = 1.12715517560052e-001;

            __statist_i_h_wts[1, 71] = -9.57442657235027e-002;

            __statist_i_h_wts[1, 72] = 2.12214087482109e-003;

            __statist_i_h_wts[1, 73] = -2.09692194711844e-001;

            __statist_i_h_wts[1, 74] = 2.24532193527299e-001;

            __statist_i_h_wts[1, 75] = 4.29978354564221e-002;

            __statist_i_h_wts[1, 76] = -3.91286914524832e-001;

            __statist_i_h_wts[1, 77] = 3.66651580457497e-001;

            __statist_i_h_wts[1, 78] = 4.39391978452911e-001;

            __statist_i_h_wts[1, 79] = -3.43438193483695e-002;

            __statist_i_h_wts[1, 80] = -3.88597279801239e-001;

            __statist_i_h_wts[1, 81] = 4.83028877037435e-002;

            __statist_i_h_wts[1, 82] = -1.10047658318284e-001;

            __statist_i_h_wts[1, 83] = 9.28037081953294e-002;

            __statist_i_h_wts[1, 84] = -4.69017450956134e-002;

            __statist_i_h_wts[1, 85] = -6.58797019000649e-002;

            __statist_i_h_wts[1, 86] = 1.24677907622622e-001;

            __statist_i_h_wts[1, 87] = -4.59930195680893e-001;

            __statist_i_h_wts[1, 88] = 1.71579908327451e-001;

            __statist_i_h_wts[1, 89] = 3.19956868415416e-001;

            __statist_i_h_wts[1, 90] = 4.65796054023823e-002;

            __statist_i_h_wts[1, 91] = 1.00960966207430e-001;

            __statist_i_h_wts[1, 92] = -1.03397372402846e-001;

            __statist_i_h_wts[1, 93] = 9.84130680629084e-002;

            __statist_i_h_wts[1, 94] = 7.99355091446696e-002;

            __statist_i_h_wts[1, 95] = -1.81172897327406e-001;

            __statist_i_h_wts[1, 96] = -2.41068216702201e-002;

            __statist_i_h_wts[1, 97] = -3.59559862821033e-002;

            __statist_i_h_wts[1, 98] = 5.72919154489251e-002;

            __statist_i_h_wts[1, 99] = 2.18045967772074e-002;

            __statist_i_h_wts[1, 100] = -9.59264856271927e-002;

            __statist_i_h_wts[1, 101] = 8.49500100818422e-002;

            __statist_i_h_wts[1, 102] = -1.92868710849472e-001;

            __statist_i_h_wts[1, 103] = 4.49502687740060e-002;

            __statist_i_h_wts[1, 104] = 1.68677076281894e-001;

            __statist_i_h_wts[1, 105] = 1.28785190260993e-001;

            __statist_i_h_wts[1, 106] = -6.95569210064555e-002;

            __statist_i_h_wts[1, 107] = -5.36336085506989e-002;

            __statist_i_h_wts[1, 108] = 1.67400333426868e-001;

            __statist_i_h_wts[1, 109] = -5.39834275441792e-002;

            __statist_i_h_wts[1, 110] = -6.19986212141766e-002;

            __statist_i_h_wts[1, 111] = 1.06422842560065e+000;

            __statist_i_h_wts[1, 112] = -2.69742506208021e-001;

            __statist_i_h_wts[1, 113] = -7.95786234610017e-001;



            __statist_i_h_wts[2, 0] = -5.44974630577502e-002;

            __statist_i_h_wts[2, 1] = -8.76158075526890e-002;

            __statist_i_h_wts[2, 2] = -6.26860831469183e-002;

            __statist_i_h_wts[2, 3] = -2.82343320528866e-002;

            __statist_i_h_wts[2, 4] = 2.07864646412946e-001;

            __statist_i_h_wts[2, 5] = 5.85043124270805e-002;

            __statist_i_h_wts[2, 6] = 4.87067399339000e-002;

            __statist_i_h_wts[2, 7] = 4.28548177698805e-002;

            __statist_i_h_wts[2, 8] = -7.28400236677972e-002;

            __statist_i_h_wts[2, 9] = -1.16456709832846e-001;

            __statist_i_h_wts[2, 10] = -5.41532959363363e-002;

            __statist_i_h_wts[2, 11] = -8.68145097049225e-002;

            __statist_i_h_wts[2, 12] = -4.42758384482026e-002;

            __statist_i_h_wts[2, 13] = 5.71895640832394e-003;

            __statist_i_h_wts[2, 14] = 1.10129567540642e-001;

            __statist_i_h_wts[2, 15] = 4.85401776280668e-002;

            __statist_i_h_wts[2, 16] = -5.97234955316983e-002;

            __statist_i_h_wts[2, 17] = 1.69479266644773e-001;

            __statist_i_h_wts[2, 18] = 1.50964569076370e-001;

            __statist_i_h_wts[2, 19] = -1.40233520765378e-001;

            __statist_i_h_wts[2, 20] = -7.14937790593730e-002;

            __statist_i_h_wts[2, 21] = 1.45591680465312e-002;

            __statist_i_h_wts[2, 22] = 1.02739323218766e-001;

            __statist_i_h_wts[2, 23] = 4.10657383609312e-002;

            __statist_i_h_wts[2, 24] = 2.47358995780851e-003;

            __statist_i_h_wts[2, 25] = -1.11614598497245e-002;

            __statist_i_h_wts[2, 26] = -5.48913925305068e-002;

            __statist_i_h_wts[2, 27] = 2.75558096755499e-002;

            __statist_i_h_wts[2, 28] = -1.08082822623334e-002;

            __statist_i_h_wts[2, 29] = 1.40215365443562e-001;

            __statist_i_h_wts[2, 30] = 1.35879053176546e-001;

            __statist_i_h_wts[2, 31] = -1.28538521506878e-001;

            __statist_i_h_wts[2, 32] = -5.92940258979117e-002;

            __statist_i_h_wts[2, 33] = 1.75382229034207e-001;

            __statist_i_h_wts[2, 34] = -1.42228708664260e-002;

            __statist_i_h_wts[2, 35] = -1.58598161423595e-001;

            __statist_i_h_wts[2, 36] = 5.10975401856788e-003;

            __statist_i_h_wts[2, 37] = 8.49326440395077e-002;

            __statist_i_h_wts[2, 38] = 9.65161741334685e-002;

            __statist_i_h_wts[2, 39] = -1.16804678006738e-001;

            __statist_i_h_wts[2, 40] = -1.73434213191326e-001;

            __statist_i_h_wts[2, 41] = 8.87310784466564e-002;

            __statist_i_h_wts[2, 42] = 2.03857499060068e-001;

            __statist_i_h_wts[2, 43] = -2.45672185858150e-002;

            __statist_i_h_wts[2, 44] = 1.73951311827557e-002;

            __statist_i_h_wts[2, 45] = 2.36086261671222e-002;

            __statist_i_h_wts[2, 46] = 2.41063258924951e-001;

            __statist_i_h_wts[2, 47] = -7.53221921708491e-002;

            __statist_i_h_wts[2, 48] = 4.10182718962410e-001;

            __statist_i_h_wts[2, 49] = -2.29284188373545e-001;

            __statist_i_h_wts[2, 50] = 1.71971809651996e-004;

            __statist_i_h_wts[2, 51] = -1.99191133984646e-001;

            __statist_i_h_wts[2, 52] = 1.92302954531826e-001;

            __statist_i_h_wts[2, 53] = 1.64615228772533e-001;

            __statist_i_h_wts[2, 54] = 1.43905215006409e-001;

            __statist_i_h_wts[2, 55] = -1.00048104637011e-001;

            __statist_i_h_wts[2, 56] = 1.34825518416880e-001;

            __statist_i_h_wts[2, 57] = 2.46656903770767e-001;

            __statist_i_h_wts[2, 58] = 6.82358835204490e-002;

            __statist_i_h_wts[2, 59] = -1.19101011001292e-001;

            __statist_i_h_wts[2, 60] = -3.78627327011493e-002;

            __statist_i_h_wts[2, 61] = 2.51638609285129e-001;

            __statist_i_h_wts[2, 62] = -5.60516204144698e-002;

            __statist_i_h_wts[2, 63] = 5.15460354268927e-001;

            __statist_i_h_wts[2, 64] = -5.23096758997304e-001;

            __statist_i_h_wts[2, 65] = 2.04102790406812e-001;

            __statist_i_h_wts[2, 66] = -1.33836834045971e-001;

            __statist_i_h_wts[2, 67] = 1.94964241911386e-001;

            __statist_i_h_wts[2, 68] = 1.01739173980121e-001;

            __statist_i_h_wts[2, 69] = 8.55998897133177e-002;

            __statist_i_h_wts[2, 70] = 3.91998061563286e-002;

            __statist_i_h_wts[2, 71] = 6.92223141546986e-002;

            __statist_i_h_wts[2, 72] = -3.80079727046519e-001;

            __statist_i_h_wts[2, 73] = 6.01907111136812e-001;

            __statist_i_h_wts[2, 74] = -5.36479249776841e-003;

            __statist_i_h_wts[2, 75] = -7.35793737313210e-001;

            __statist_i_h_wts[2, 76] = 9.13576925117067e-001;

            __statist_i_h_wts[2, 77] = 1.93136206529800e-002;

            __statist_i_h_wts[2, 78] = -5.73478646675250e-001;

            __statist_i_h_wts[2, 79] = 5.67273418448770e-001;

            __statist_i_h_wts[2, 80] = 1.67960511090105e-001;

            __statist_i_h_wts[2, 81] = 1.42529832721625e-001;

            __statist_i_h_wts[2, 82] = 6.28196089306908e-002;

            __statist_i_h_wts[2, 83] = -3.33233515448066e-002;

            __statist_i_h_wts[2, 84] = -7.54155223534241e-002;

            __statist_i_h_wts[2, 85] = 2.90828639317719e-001;

            __statist_i_h_wts[2, 86] = -4.60260036959681e-002;

            __statist_i_h_wts[2, 87] = 4.17842893374058e-001;

            __statist_i_h_wts[2, 88] = -4.17181790923541e-001;

            __statist_i_h_wts[2, 89] = 1.76370043675660e-001;

            __statist_i_h_wts[2, 90] = -1.57177803055646e-001;

            __statist_i_h_wts[2, 91] = 1.03531806520727e-001;

            __statist_i_h_wts[2, 92] = 2.39610591963728e-001;

            __statist_i_h_wts[2, 93] = 2.01830720241517e-001;

            __statist_i_h_wts[2, 94] = 4.74937064108197e-002;

            __statist_i_h_wts[2, 95] = -5.38989760882019e-002;

            __statist_i_h_wts[2, 96] = 4.61138782090063e-002;

            __statist_i_h_wts[2, 97] = 1.14383362251347e-001;

            __statist_i_h_wts[2, 98] = 2.04150445376284e-002;

            __statist_i_h_wts[2, 99] = -9.15506249431312e-002;

            __statist_i_h_wts[2, 100] = 2.12893992970135e-001;

            __statist_i_h_wts[2, 101] = 6.81615430150689e-002;

            __statist_i_h_wts[2, 102] = 6.29911166417013e-001;

            __statist_i_h_wts[2, 103] = -4.00323121086719e-001;

            __statist_i_h_wts[2, 104] = -2.88516196787382e-002;

            __statist_i_h_wts[2, 105] = -3.10454020914204e-002;

            __statist_i_h_wts[2, 106] = 2.85696354862264e-001;

            __statist_i_h_wts[2, 107] = -7.82957694134054e-002;

            __statist_i_h_wts[2, 108] = 7.02082213595817e-002;

            __statist_i_h_wts[2, 109] = 2.08778221106849e-001;

            __statist_i_h_wts[2, 110] = -1.00013220135038e-001;

            __statist_i_h_wts[2, 111] = -1.25673908929350e-001;

            __statist_i_h_wts[2, 112] = 8.16358103372353e-001;

            __statist_i_h_wts[2, 113] = -4.98077263199869e-001;



            __statist_i_h_wts[3, 0] = 5.06252447618304e-003;

            __statist_i_h_wts[3, 1] = 2.95795082849336e-002;

            __statist_i_h_wts[3, 2] = -5.07983282892558e-002;

            __statist_i_h_wts[3, 3] = -1.04789929708883e-002;

            __statist_i_h_wts[3, 4] = 4.89266215041724e-002;

            __statist_i_h_wts[3, 5] = 1.95600503926271e-002;

            __statist_i_h_wts[3, 6] = -1.32107211505767e-002;

            __statist_i_h_wts[3, 7] = -2.77153368258349e-002;

            __statist_i_h_wts[3, 8] = -9.71610884770054e-002;

            __statist_i_h_wts[3, 9] = -2.83455768188080e-002;

            __statist_i_h_wts[3, 10] = -3.78617119763679e-002;

            __statist_i_h_wts[3, 11] = -6.48807189452080e-002;

            __statist_i_h_wts[3, 12] = -5.18036189262826e-002;

            __statist_i_h_wts[3, 13] = 1.09586269420242e-002;

            __statist_i_h_wts[3, 14] = 6.61930457713878e-002;

            __statist_i_h_wts[3, 15] = -1.56787091017145e-002;

            __statist_i_h_wts[3, 16] = 1.65439704628897e-002;

            __statist_i_h_wts[3, 17] = 8.18143493702801e-002;

            __statist_i_h_wts[3, 18] = 6.31755226929848e-002;

            __statist_i_h_wts[3, 19] = 6.73194084339977e-002;

            __statist_i_h_wts[3, 20] = 5.39869398140382e-003;

            __statist_i_h_wts[3, 21] = 2.64923713392663e-002;

            __statist_i_h_wts[3, 22] = 1.56481751066303e-002;

            __statist_i_h_wts[3, 23] = 4.74685803139126e-002;

            __statist_i_h_wts[3, 24] = -1.11241062855457e-002;

            __statist_i_h_wts[3, 25] = 3.44811438672149e-003;

            __statist_i_h_wts[3, 26] = -3.56431307312418e-002;

            __statist_i_h_wts[3, 27] = -2.74005170824376e-002;

            __statist_i_h_wts[3, 28] = -6.48568581019167e-002;

            __statist_i_h_wts[3, 29] = 2.35668641117487e-002;

            __statist_i_h_wts[3, 30] = 3.13987011321892e-002;

            __statist_i_h_wts[3, 31] = 1.01727883551853e-002;

            __statist_i_h_wts[3, 32] = -2.40503725766005e-002;

            __statist_i_h_wts[3, 33] = 2.02130597172362e-002;

            __statist_i_h_wts[3, 34] = -3.54469704221698e-002;

            __statist_i_h_wts[3, 35] = -5.55687164441819e-002;

            __statist_i_h_wts[3, 36] = -9.45572291979264e-003;

            __statist_i_h_wts[3, 37] = 1.51971767039222e-002;

            __statist_i_h_wts[3, 38] = 1.12015322884248e-002;

            __statist_i_h_wts[3, 39] = -3.22646963124418e-002;

            __statist_i_h_wts[3, 40] = 5.19733307908094e-003;

            __statist_i_h_wts[3, 41] = -3.07183803541793e-003;

            __statist_i_h_wts[3, 42] = -5.81274928353450e-002;

            __statist_i_h_wts[3, 43] = -1.33742148124568e-001;

            __statist_i_h_wts[3, 44] = 8.65514575562215e-002;

            __statist_i_h_wts[3, 45] = 2.03923742579087e-002;

            __statist_i_h_wts[3, 46] = -1.87681067745259e-001;

            __statist_i_h_wts[3, 47] = 7.26554671673029e-002;

            __statist_i_h_wts[3, 48] = -4.17119707703512e-001;

            __statist_i_h_wts[3, 49] = 1.23647233580756e-001;

            __statist_i_h_wts[3, 50] = 1.47971036941189e-001;

            __statist_i_h_wts[3, 51] = 2.08248057102628e-001;

            __statist_i_h_wts[3, 52] = -2.64037369862946e-001;

            __statist_i_h_wts[3, 53] = -6.89531954148217e-002;

            __statist_i_h_wts[3, 54] = 4.59141835658449e-002;

            __statist_i_h_wts[3, 55] = -5.27127242454023e-002;

            __statist_i_h_wts[3, 56] = -8.76863431774565e-002;

            __statist_i_h_wts[3, 57] = -1.13089263867556e-001;

            __statist_i_h_wts[3, 58] = -1.15467064260083e-001;

            __statist_i_h_wts[3, 59] = 9.58157755508279e-002;

            __statist_i_h_wts[3, 60] = -4.28602991492210e-002;

            __statist_i_h_wts[3, 61] = -1.89175812916870e-001;

            __statist_i_h_wts[3, 62] = 1.20769424083371e-001;

            __statist_i_h_wts[3, 63] = -5.71955567877894e-001;

            __statist_i_h_wts[3, 64] = 1.10271709138989e-001;

            __statist_i_h_wts[3, 65] = 3.08607802318515e-001;

            __statist_i_h_wts[3, 66] = 1.95507796204316e-001;

            __statist_i_h_wts[3, 67] = -4.67801490165099e-002;

            __statist_i_h_wts[3, 68] = -2.27969935344509e-001;

            __statist_i_h_wts[3, 69] = 1.88848876334074e-003;

            __statist_i_h_wts[3, 70] = 1.66963828197606e-002;

            __statist_i_h_wts[3, 71] = -1.30886645153685e-001;

            __statist_i_h_wts[3, 72] = 1.99277990502230e-001;

            __statist_i_h_wts[3, 73] = -6.48284594383542e-001;

            __statist_i_h_wts[3, 74] = 3.09522310509958e-001;

            __statist_i_h_wts[3, 75] = 4.52164973798939e-001;

            __statist_i_h_wts[3, 76] = -9.84368313193650e-001;

            __statist_i_h_wts[3, 77] = 4.01289239016766e-001;

            __statist_i_h_wts[3, 78] = 9.31827690356006e-001;

            __statist_i_h_wts[3, 79] = -4.60100481538826e-001;

            __statist_i_h_wts[3, 80] = -6.17321485060510e-001;

            __statist_i_h_wts[3, 81] = -3.37463772386230e-002;

            __statist_i_h_wts[3, 82] = -2.08101016287524e-001;

            __statist_i_h_wts[3, 83] = 9.55981864837646e-002;

            __statist_i_h_wts[3, 84] = 5.81231304632477e-003;

            __statist_i_h_wts[3, 85] = -2.42859168596215e-001;

            __statist_i_h_wts[3, 86] = 1.48246632494331e-001;

            __statist_i_h_wts[3, 87] = -5.24085317227025e-001;

            __statist_i_h_wts[3, 88] = 9.89368498399782e-002;

            __statist_i_h_wts[3, 89] = 2.94056394470794e-001;

            __statist_i_h_wts[3, 90] = 2.78036329916977e-001;

            __statist_i_h_wts[3, 91] = -2.51489377777810e-001;

            __statist_i_h_wts[3, 92] = -1.49121245447606e-001;

            __statist_i_h_wts[3, 93] = 1.58236200526383e-001;

            __statist_i_h_wts[3, 94] = -1.19006238036234e-001;

            __statist_i_h_wts[3, 95] = -1.89498138900762e-001;

            __statist_i_h_wts[3, 96] = -6.79954579955756e-002;

            __statist_i_h_wts[3, 97] = -1.61198353640407e-001;

            __statist_i_h_wts[3, 98] = 1.14623758198976e-001;

            __statist_i_h_wts[3, 99] = 1.71028756491670e-002;

            __statist_i_h_wts[3, 100] = -2.56293338206631e-001;

            __statist_i_h_wts[3, 101] = 1.07161860569745e-001;

            __statist_i_h_wts[3, 102] = -4.01241232265762e-001;

            __statist_i_h_wts[3, 103] = 4.75651197303075e-002;

            __statist_i_h_wts[3, 104] = 2.03338889412385e-001;

            __statist_i_h_wts[3, 105] = 2.49197998353374e-001;

            __statist_i_h_wts[3, 106] = -3.24345775610197e-001;

            __statist_i_h_wts[3, 107] = -7.59549618709589e-002;

            __statist_i_h_wts[3, 108] = 1.48569627560154e-001;

            __statist_i_h_wts[3, 109] = -1.67040537060295e-001;

            __statist_i_h_wts[3, 110] = -1.18602270655855e-001;

            __statist_i_h_wts[3, 111] = 1.63267017406228e+000;

            __statist_i_h_wts[3, 112] = -6.92014258835857e-001;

            __statist_i_h_wts[3, 113] = -1.04679972411380e+000;



            __statist_i_h_wts[4, 0] = -5.33155993146362e-002;

            __statist_i_h_wts[4, 1] = -6.71826087981312e-003;

            __statist_i_h_wts[4, 2] = -2.44827045886423e-002;

            __statist_i_h_wts[4, 3] = -7.14964680000115e-003;

            __statist_i_h_wts[4, 4] = -2.92474249647234e-002;

            __statist_i_h_wts[4, 5] = -2.38434130535733e-002;

            __statist_i_h_wts[4, 6] = -1.83794441751522e-001;

            __statist_i_h_wts[4, 7] = -1.41504137216638e-002;

            __statist_i_h_wts[4, 8] = 1.78089873818891e-002;

            __statist_i_h_wts[4, 9] = -2.81538347405058e-002;

            __statist_i_h_wts[4, 10] = -5.03642776319218e-002;

            __statist_i_h_wts[4, 11] = -2.31803776241767e-002;

            __statist_i_h_wts[4, 12] = 5.87274413025160e-002;

            __statist_i_h_wts[4, 13] = -8.59282507010615e-002;

            __statist_i_h_wts[4, 14] = 9.42404159956200e-003;

            __statist_i_h_wts[4, 15] = 6.74518534807886e-002;

            __statist_i_h_wts[4, 16] = 8.36766404454768e-002;

            __statist_i_h_wts[4, 17] = 9.68869424612334e-002;

            __statist_i_h_wts[4, 18] = 6.06422910886561e-002;

            __statist_i_h_wts[4, 19] = 1.99778700681380e-002;

            __statist_i_h_wts[4, 20] = -4.56567851114174e-003;

            __statist_i_h_wts[4, 21] = -6.86346165597893e-002;

            __statist_i_h_wts[4, 22] = 4.02068624486722e-002;

            __statist_i_h_wts[4, 23] = -4.14179860242078e-002;

            __statist_i_h_wts[4, 24] = 4.09337279532203e-003;

            __statist_i_h_wts[4, 25] = 4.19514298780733e-002;

            __statist_i_h_wts[4, 26] = 2.25897991572246e-002;

            __statist_i_h_wts[4, 27] = -1.75448935259926e-002;

            __statist_i_h_wts[4, 28] = -3.04949144808247e-002;

            __statist_i_h_wts[4, 29] = 4.15943792829766e-002;

            __statist_i_h_wts[4, 30] = 2.63721046290802e-002;

            __statist_i_h_wts[4, 31] = 1.88431783206380e-002;

            __statist_i_h_wts[4, 32] = -1.32403942938689e-002;

            __statist_i_h_wts[4, 33] = -1.06321395422606e-003;

            __statist_i_h_wts[4, 34] = 7.10172897296076e-002;

            __statist_i_h_wts[4, 35] = -1.62533276123120e-002;

            __statist_i_h_wts[4, 36] = -9.95839047323453e-004;

            __statist_i_h_wts[4, 37] = -2.77412885215173e-002;

            __statist_i_h_wts[4, 38] = 1.48376632663426e-002;

            __statist_i_h_wts[4, 39] = -2.12271199374573e-002;

            __statist_i_h_wts[4, 40] = 5.42762830620451e-002;

            __statist_i_h_wts[4, 41] = -2.15382902673844e-002;

            __statist_i_h_wts[4, 42] = -9.50403909397037e-002;

            __statist_i_h_wts[4, 43] = -1.63725826264730e-001;

            __statist_i_h_wts[4, 44] = 1.46787439046920e-001;

            __statist_i_h_wts[4, 45] = -1.57391287892025e-001;

            __statist_i_h_wts[4, 46] = -1.08098227340013e-001;

            __statist_i_h_wts[4, 47] = 1.75891365530623e-001;

            __statist_i_h_wts[4, 48] = 1.15428872907827e-001;

            __statist_i_h_wts[4, 49] = -4.03664498307772e-001;

            __statist_i_h_wts[4, 50] = 1.67424397840925e-001;

            __statist_i_h_wts[4, 51] = -7.17318630559130e-002;

            __statist_i_h_wts[4, 52] = -2.25012321146079e-002;

            __statist_i_h_wts[4, 53] = -2.61577810781116e-002;

            __statist_i_h_wts[4, 54] = 9.56631226903005e-002;

            __statist_i_h_wts[4, 55] = -2.46768365424060e-001;

            __statist_i_h_wts[4, 56] = 2.06614397746718e-002;

            __statist_i_h_wts[4, 57] = -2.98972605459954e-001;

            __statist_i_h_wts[4, 58] = -1.25441517585843e-001;

            __statist_i_h_wts[4, 59] = 3.25233479294380e-001;

            __statist_i_h_wts[4, 60] = -3.58638051910190e-001;

            __statist_i_h_wts[4, 61] = -1.64358758101071e-001;

            __statist_i_h_wts[4, 62] = 4.15953887550411e-001;

            __statist_i_h_wts[4, 63] = -1.18941523917226e-001;

            __statist_i_h_wts[4, 64] = -5.42523747039969e-001;

            __statist_i_h_wts[4, 65] = 5.63874934579028e-001;

            __statist_i_h_wts[4, 66] = 1.44866675211198e-001;

            __statist_i_h_wts[4, 67] = -2.73444042879644e-002;

            __statist_i_h_wts[4, 68] = -2.27254589459777e-001;

            __statist_i_h_wts[4, 69] = 1.37930742372896e-001;

            __statist_i_h_wts[4, 70] = -3.63155547973898e-002;

            __statist_i_h_wts[4, 71] = -1.71937562363336e-001;

            __statist_i_h_wts[4, 72] = -5.78462422116398e-001;

            __statist_i_h_wts[4, 73] = 1.06677423046705e-001;

            __statist_i_h_wts[4, 74] = 3.73578274627418e-001;

            __statist_i_h_wts[4, 75] = -9.82442920276259e-001;

            __statist_i_h_wts[4, 76] = 4.08941501277312e-001;

            __statist_i_h_wts[4, 77] = 4.65012743301372e-001;

            __statist_i_h_wts[4, 78] = -5.81525352338361e-001;

            __statist_i_h_wts[4, 79] = 6.07065707811956e-001;

            __statist_i_h_wts[4, 80] = -1.37220102347213e-001;

            __statist_i_h_wts[4, 81] = -1.97835291079970e-001;

            __statist_i_h_wts[4, 82] = -4.98480335847589e-002;

            __statist_i_h_wts[4, 83] = 1.38016299419102e-001;

            __statist_i_h_wts[4, 84] = -2.81681838156780e-001;

            __statist_i_h_wts[4, 85] = -2.42018727857757e-001;

            __statist_i_h_wts[4, 86] = 4.25597854471810e-001;

            __statist_i_h_wts[4, 87] = -1.66381919275196e-002;

            __statist_i_h_wts[4, 88] = -5.79887610515863e-001;

            __statist_i_h_wts[4, 89] = 5.05668451559781e-001;

            __statist_i_h_wts[4, 90] = 4.08129541019493e-002;

            __statist_i_h_wts[4, 91] = 2.21046181412657e-001;

            __statist_i_h_wts[4, 92] = -3.72538295682597e-001;

            __statist_i_h_wts[4, 93] = 3.33274527480907e-002;

            __statist_i_h_wts[4, 94] = -1.25851419068016e-001;

            __statist_i_h_wts[4, 95] = -2.77688538053514e-002;

            __statist_i_h_wts[4, 96] = -7.35373756163380e-002;

            __statist_i_h_wts[4, 97] = -3.46035276815303e-003;

            __statist_i_h_wts[4, 98] = -5.52737151558553e-002;

            __statist_i_h_wts[4, 99] = -7.58293930962089e-002;

            __statist_i_h_wts[4, 100] = -1.32793844558980e-001;

            __statist_i_h_wts[4, 101] = 9.12304952971615e-002;

            __statist_i_h_wts[4, 102] = 1.58863547352128e-001;

            __statist_i_h_wts[4, 103] = -2.74594644028203e-001;

            __statist_i_h_wts[4, 104] = 2.91845292336587e-002;

            __statist_i_h_wts[4, 105] = -1.55203126448360e-001;

            __statist_i_h_wts[4, 106] = -3.80729537977622e-002;

            __statist_i_h_wts[4, 107] = 5.85792054044236e-002;

            __statist_i_h_wts[4, 108] = -6.17870747829356e-002;

            __statist_i_h_wts[4, 109] = -1.47261331747150e-001;

            __statist_i_h_wts[4, 110] = 6.48829188657721e-002;

            __statist_i_h_wts[4, 111] = -4.26962164507617e-001;

            __statist_i_h_wts[4, 112] = 5.17542643653399e-001;

            __statist_i_h_wts[4, 113] = -1.66028672145731e-001;



            __statist_i_h_wts[5, 0] = 7.16292279246671e-002;

            __statist_i_h_wts[5, 1] = -6.17165503884098e-003;

            __statist_i_h_wts[5, 2] = 3.16973799130027e-002;

            __statist_i_h_wts[5, 3] = -1.56907799424230e-002;

            __statist_i_h_wts[5, 4] = -8.51149041504820e-003;

            __statist_i_h_wts[5, 5] = 2.26217155922463e-003;

            __statist_i_h_wts[5, 6] = -2.12543633368724e-002;

            __statist_i_h_wts[5, 7] = -3.40373238543842e-002;

            __statist_i_h_wts[5, 8] = -1.98667345385971e-002;

            __statist_i_h_wts[5, 9] = -7.40683698366388e-004;

            __statist_i_h_wts[5, 10] = 1.79330218481014e-002;

            __statist_i_h_wts[5, 11] = 2.75601574276929e-003;

            __statist_i_h_wts[5, 12] = -2.40061329850682e-002;

            __statist_i_h_wts[5, 13] = -5.25768066509118e-002;

            __statist_i_h_wts[5, 14] = 3.13013487206076e-002;

            __statist_i_h_wts[5, 15] = 3.02928775682319e-003;

            __statist_i_h_wts[5, 16] = 6.07760791350015e-003;

            __statist_i_h_wts[5, 17] = 4.02901905734241e-002;

            __statist_i_h_wts[5, 18] = -1.25553412033003e-002;

            __statist_i_h_wts[5, 19] = 4.95653258148340e-002;

            __statist_i_h_wts[5, 20] = -5.62046804965279e-002;

            __statist_i_h_wts[5, 21] = 5.28572581823118e-002;

            __statist_i_h_wts[5, 22] = -7.73524631048146e-003;

            __statist_i_h_wts[5, 23] = 3.81203603806215e-002;

            __statist_i_h_wts[5, 24] = -1.96329468339095e-002;

            __statist_i_h_wts[5, 25] = 3.19159522984564e-002;

            __statist_i_h_wts[5, 26] = -9.22187951080872e-003;

            __statist_i_h_wts[5, 27] = -3.25684122210909e-002;

            __statist_i_h_wts[5, 28] = -5.04702630275701e-002;

            __statist_i_h_wts[5, 29] = -1.36290771472904e-002;

            __statist_i_h_wts[5, 30] = 1.17091398126989e-002;

            __statist_i_h_wts[5, 31] = -5.68370840321891e-002;

            __statist_i_h_wts[5, 32] = 5.99506535223936e-003;

            __statist_i_h_wts[5, 33] = 3.49468329360570e-002;

            __statist_i_h_wts[5, 34] = 1.52773507789553e-002;

            __statist_i_h_wts[5, 35] = 4.90272169284522e-002;

            __statist_i_h_wts[5, 36] = 2.16617882835584e-002;

            __statist_i_h_wts[5, 37] = -8.37798033952907e-003;

            __statist_i_h_wts[5, 38] = 1.09327343147028e-002;

            __statist_i_h_wts[5, 39] = -2.73025945758005e-002;

            __statist_i_h_wts[5, 40] = -2.72874159889548e-002;

            __statist_i_h_wts[5, 41] = 1.34704053290596e-002;

            __statist_i_h_wts[5, 42] = -4.89983491417816e-002;

            __statist_i_h_wts[5, 43] = 2.37505955879961e-002;

            __statist_i_h_wts[5, 44] = 3.63832478782955e-002;

            __statist_i_h_wts[5, 45] = 5.18539651490535e-002;

            __statist_i_h_wts[5, 46] = -4.46686429314022e-002;

            __statist_i_h_wts[5, 47] = -6.05139836215918e-005;

            __statist_i_h_wts[5, 48] = -3.18424833403676e-001;

            __statist_i_h_wts[5, 49] = 3.60255925195855e-001;

            __statist_i_h_wts[5, 50] = -4.66452872766676e-002;

            __statist_i_h_wts[5, 51] = 1.66451463920973e-001;

            __statist_i_h_wts[5, 52] = -7.91273800375991e-002;

            __statist_i_h_wts[5, 53] = -8.46958844139058e-002;

            __statist_i_h_wts[5, 54] = 9.33215679306367e-002;

            __statist_i_h_wts[5, 55] = -2.41855036421687e-002;

            __statist_i_h_wts[5, 56] = -3.63474780515526e-002;

            __statist_i_h_wts[5, 57] = -7.37464345190698e-002;

            __statist_i_h_wts[5, 58] = 7.00219478766320e-002;

            __statist_i_h_wts[5, 59] = 1.57438322019438e-002;

            __statist_i_h_wts[5, 60] = 1.21109371189844e-002;

            __statist_i_h_wts[5, 61] = -1.95173615757190e-002;

            __statist_i_h_wts[5, 62] = 1.09029367300295e-002;

            __statist_i_h_wts[5, 63] = -3.21982227230690e-001;

            __statist_i_h_wts[5, 64] = 3.10972201017346e-001;

            __statist_i_h_wts[5, 65] = 6.50293820339286e-002;

            __statist_i_h_wts[5, 66] = 1.89142301771021e-001;

            __statist_i_h_wts[5, 67] = -7.74647835736010e-002;

            __statist_i_h_wts[5, 68] = -8.80333631612691e-002;

            __statist_i_h_wts[5, 69] = 2.01257474812503e-002;

            __statist_i_h_wts[5, 70] = 6.23466243625543e-002;

            __statist_i_h_wts[5, 71] = -5.57306428363783e-002;

            __statist_i_h_wts[5, 72] = 4.31943606977151e-001;

            __statist_i_h_wts[5, 73] = -4.82618517393357e-001;

            __statist_i_h_wts[5, 74] = 9.15614002086089e-002;

            __statist_i_h_wts[5, 75] = 7.51833031676405e-001;

            __statist_i_h_wts[5, 76] = -8.32487652515833e-001;

            __statist_i_h_wts[5, 77] = 1.10391413155764e-001;

            __statist_i_h_wts[5, 78] = 6.99160129458657e-001;

            __statist_i_h_wts[5, 79] = -3.61298586992398e-001;

            __statist_i_h_wts[5, 80] = -3.08617908759402e-001;

            __statist_i_h_wts[5, 81] = -5.90613676606062e-002;

            __statist_i_h_wts[5, 82] = 5.51775284986561e-002;

            __statist_i_h_wts[5, 83] = 1.88528576518707e-002;

            __statist_i_h_wts[5, 84] = 9.73149194754688e-002;

            __statist_i_h_wts[5, 85] = -9.84431200531736e-002;

            __statist_i_h_wts[5, 86] = 2.21889784269066e-002;

            __statist_i_h_wts[5, 87] = -2.22280541842368e-001;

            __statist_i_h_wts[5, 88] = 2.36176540198875e-001;

            __statist_i_h_wts[5, 89] = -5.51246645271394e-004;

            __statist_i_h_wts[5, 90] = 2.93450289828964e-001;

            __statist_i_h_wts[5, 91] = -2.13269583752354e-001;

            __statist_i_h_wts[5, 92] = -5.13424476433632e-002;

            __statist_i_h_wts[5, 93] = 1.06297808902056e-001;

            __statist_i_h_wts[5, 94] = -5.48784385027786e-002;

            __statist_i_h_wts[5, 95] = -3.36908417644939e-002;

            __statist_i_h_wts[5, 96] = -6.37585285068564e-002;

            __statist_i_h_wts[5, 97] = 3.27024131068190e-002;

            __statist_i_h_wts[5, 98] = 5.52087396902924e-002;

            __statist_i_h_wts[5, 99] = 4.92281200351012e-002;

            __statist_i_h_wts[5, 100] = -8.40756542101747e-002;

            __statist_i_h_wts[5, 101] = 2.15098670874652e-002;

            __statist_i_h_wts[5, 102] = -2.64851090858724e-001;

            __statist_i_h_wts[5, 103] = 2.23261036832986e-001;

            __statist_i_h_wts[5, 104] = 3.83139495259667e-002;

            __statist_i_h_wts[5, 105] = 2.25253623375939e-001;

            __statist_i_h_wts[5, 106] = -1.66056443787571e-001;

            __statist_i_h_wts[5, 107] = -6.46702884663007e-002;

            __statist_i_h_wts[5, 108] = 2.36481862524693e-002;

            __statist_i_h_wts[5, 109] = 3.85746167888138e-002;

            __statist_i_h_wts[5, 110] = -1.24041750427886e-002;

            __statist_i_h_wts[5, 111] = 8.41468748411231e-001;

            __statist_i_h_wts[5, 112] = -4.71722548532683e-001;

            __statist_i_h_wts[5, 113] = -3.63648032125941e-001;



            __statist_i_h_wts[6, 0] = -4.35719758215893e-002;

            __statist_i_h_wts[6, 1] = 2.58438389629927e-002;

            __statist_i_h_wts[6, 2] = -5.49577836969938e-002;

            __statist_i_h_wts[6, 3] = -1.92143631867326e-002;

            __statist_i_h_wts[6, 4] = 2.87819653685109e-002;

            __statist_i_h_wts[6, 5] = 2.08789805693377e-003;

            __statist_i_h_wts[6, 6] = 5.15542668820842e-003;

            __statist_i_h_wts[6, 7] = -1.36819275942672e-002;

            __statist_i_h_wts[6, 8] = -3.91166812961682e-002;

            __statist_i_h_wts[6, 9] = -9.18079509893741e-003;

            __statist_i_h_wts[6, 10] = -1.92993526137063e-002;

            __statist_i_h_wts[6, 11] = -3.07037542031097e-002;

            __statist_i_h_wts[6, 12] = -7.47683725941767e-002;

            __statist_i_h_wts[6, 13] = 1.15521240981622e-002;

            __statist_i_h_wts[6, 14] = 4.76269565378016e-002;

            __statist_i_h_wts[6, 15] = 2.87154454830088e-002;

            __statist_i_h_wts[6, 16] = 7.95632178102826e-003;

            __statist_i_h_wts[6, 17] = 6.16014450953997e-002;

            __statist_i_h_wts[6, 18] = 5.02446628236191e-002;

            __statist_i_h_wts[6, 19] = 2.49155711379226e-002;

            __statist_i_h_wts[6, 20] = 4.21676894614043e-004;

            __statist_i_h_wts[6, 21] = -5.47317810310744e-003;

            __statist_i_h_wts[6, 22] = 2.42113960408718e-002;

            __statist_i_h_wts[6, 23] = 3.15281013911375e-002;

            __statist_i_h_wts[6, 24] = 1.36278148342749e-003;

            __statist_i_h_wts[6, 25] = -8.50898840878605e-003;

            __statist_i_h_wts[6, 26] = -4.77633816819244e-002;

            __statist_i_h_wts[6, 27] = -1.87755528878189e-002;

            __statist_i_h_wts[6, 28] = -2.78940708079854e-002;

            __statist_i_h_wts[6, 29] = -2.04109980241286e-003;

            __statist_i_h_wts[6, 30] = 1.30487513410044e-002;

            __statist_i_h_wts[6, 31] = 1.22804442893768e-002;

            __statist_i_h_wts[6, 32] = -4.87246883829391e-003;

            __statist_i_h_wts[6, 33] = 3.76306452864332e-003;

            __statist_i_h_wts[6, 34] = 6.02152662890583e-003;

            __statist_i_h_wts[6, 35] = -5.45941129026943e-002;

            __statist_i_h_wts[6, 36] = -9.09940298390091e-003;

            __statist_i_h_wts[6, 37] = 2.84652456122681e-002;

            __statist_i_h_wts[6, 38] = 3.28290411730304e-002;

            __statist_i_h_wts[6, 39] = -1.62869244646589e-002;

            __statist_i_h_wts[6, 40] = 2.36345567479352e-002;

            __statist_i_h_wts[6, 41] = 2.13746067973190e-004;

            __statist_i_h_wts[6, 42] = -4.56917328977764e-002;

            __statist_i_h_wts[6, 43] = -5.31795232194196e-002;

            __statist_i_h_wts[6, 44] = 4.80867181667088e-002;

            __statist_i_h_wts[6, 45] = -8.12813124916263e-002;

            __statist_i_h_wts[6, 46] = -4.86939153552299e-002;

            __statist_i_h_wts[6, 47] = 5.44220647853208e-002;

            __statist_i_h_wts[6, 48] = -8.32804174912699e-002;

            __statist_i_h_wts[6, 49] = -1.01092586545600e-001;

            __statist_i_h_wts[6, 50] = 1.20783789634402e-001;

            __statist_i_h_wts[6, 51] = 7.83199581480825e-002;

            __statist_i_h_wts[6, 52] = -1.08131810225853e-001;

            __statist_i_h_wts[6, 53] = -4.83853707519142e-002;

            __statist_i_h_wts[6, 54] = 7.44113741779887e-004;

            __statist_i_h_wts[6, 55] = 1.29182826703733e-002;

            __statist_i_h_wts[6, 56] = -5.68675256094609e-002;

            __statist_i_h_wts[6, 57] = -1.00963732317821e-001;

            __statist_i_h_wts[6, 58] = -6.36121785447638e-002;

            __statist_i_h_wts[6, 59] = 6.92271799737310e-002;

            __statist_i_h_wts[6, 60] = -1.60017589718452e-001;

            __statist_i_h_wts[6, 61] = -1.85359040092421e-002;

            __statist_i_h_wts[6, 62] = 9.60856892659158e-002;

            __statist_i_h_wts[6, 63] = -2.01218014245633e-001;

            __statist_i_h_wts[6, 64] = -1.01034108416348e-001;

            __statist_i_h_wts[6, 65] = 2.47404091459574e-001;

            __statist_i_h_wts[6, 66] = 2.06560455894259e-002;

            __statist_i_h_wts[6, 67] = 4.96826023715336e-002;

            __statist_i_h_wts[6, 68] = -1.52240995590273e-001;

            __statist_i_h_wts[6, 69] = -4.03259409054808e-002;

            __statist_i_h_wts[6, 70] = 3.94926024431267e-002;

            __statist_i_h_wts[6, 71] = -7.35440132474220e-002;

            __statist_i_h_wts[6, 72] = -3.08732481073312e-002;

            __statist_i_h_wts[6, 73] = -2.07395578663006e-001;

            __statist_i_h_wts[6, 74] = 2.02372287894554e-001;

            __statist_i_h_wts[6, 75] = -5.58863976497495e-002;

            __statist_i_h_wts[6, 76] = -2.95927560487049e-001;

            __statist_i_h_wts[6, 77] = 2.72172942681626e-001;

            __statist_i_h_wts[6, 78] = 2.50729071439133e-001;

            __statist_i_h_wts[6, 79] = -4.23168537628450e-002;

            __statist_i_h_wts[6, 80] = -2.91170657770280e-001;

            __statist_i_h_wts[6, 81] = -5.93038927196290e-002;

            __statist_i_h_wts[6, 82] = -8.74685019756724e-002;

            __statist_i_h_wts[6, 83] = 7.22626648979811e-002;

            __statist_i_h_wts[6, 84] = -1.86135088276738e-001;

            __statist_i_h_wts[6, 85] = 7.75835287027685e-003;

            __statist_i_h_wts[6, 86] = 1.06421192954365e-001;

            __statist_i_h_wts[6, 87] = -2.21375363540848e-001;

            __statist_i_h_wts[6, 88] = -4.68748363823161e-002;

            __statist_i_h_wts[6, 89] = 2.04431893681990e-001;

            __statist_i_h_wts[6, 90] = 3.91368437719199e-002;

            __statist_i_h_wts[6, 91] = 2.25273341285746e-002;

            __statist_i_h_wts[6, 92] = -1.13883954395665e-001;

            __statist_i_h_wts[6, 93] = -5.38152347628860e-003;

            __statist_i_h_wts[6, 94] = 9.43549913667069e-003;

            __statist_i_h_wts[6, 95] = -1.00920452094092e-001;

            __statist_i_h_wts[6, 96] = -5.31753086830336e-002;

            __statist_i_h_wts[6, 97] = -6.72332878083838e-002;

            __statist_i_h_wts[6, 98] = 6.12814682186107e-002;

            __statist_i_h_wts[6, 99] = -1.01182384337890e-001;

            __statist_i_h_wts[6, 100] = -4.67582122911561e-002;

            __statist_i_h_wts[6, 101] = 9.31802511150174e-002;

            __statist_i_h_wts[6, 102] = -1.11153879470167e-001;

            __statist_i_h_wts[6, 103] = -7.06697676738874e-002;

            __statist_i_h_wts[6, 104] = 1.06500237253360e-001;

            __statist_i_h_wts[6, 105] = 4.72266970152708e-002;

            __statist_i_h_wts[6, 106] = -1.03492256644156e-001;

            __statist_i_h_wts[6, 107] = -8.65704699340534e-003;

            __statist_i_h_wts[6, 108] = 2.25197507769455e-002;

            __statist_i_h_wts[6, 109] = -3.96834314992306e-002;

            __statist_i_h_wts[6, 110] = -6.34542263448225e-002;

            __statist_i_h_wts[6, 111] = 7.24502577733910e-001;

            __statist_i_h_wts[6, 112] = -2.25700122698173e-001;

            __statist_i_h_wts[6, 113] = -5.82821395568852e-001;



            __statist_i_h_wts[7, 0] = -1.71002408592918e-001;

            __statist_i_h_wts[7, 1] = 5.94785212979649e-002;

            __statist_i_h_wts[7, 2] = -1.11635857953997e-001;

            __statist_i_h_wts[7, 3] = -4.47366341579675e-002;

            __statist_i_h_wts[7, 4] = 4.09958282102701e-002;

            __statist_i_h_wts[7, 5] = 1.92115476661132e-002;

            __statist_i_h_wts[7, 6] = -7.41150018828283e-002;

            __statist_i_h_wts[7, 7] = -1.62028238823559e-002;

            __statist_i_h_wts[7, 8] = -7.86413685885154e-002;

            __statist_i_h_wts[7, 9] = 1.54265105911765e-003;

            __statist_i_h_wts[7, 10] = -6.09589868365000e-002;

            __statist_i_h_wts[7, 11] = -1.42403791592179e-002;

            __statist_i_h_wts[7, 12] = -7.40446649881050e-002;

            __statist_i_h_wts[7, 13] = 3.44699705158767e-002;

            __statist_i_h_wts[7, 14] = 5.88143209893426e-002;

            __statist_i_h_wts[7, 15] = 1.10278059054330e-002;

            __statist_i_h_wts[7, 16] = 2.75749405254325e-002;

            __statist_i_h_wts[7, 17] = 7.91415075765919e-002;

            __statist_i_h_wts[7, 18] = 1.15898242676968e-001;

            __statist_i_h_wts[7, 19] = -3.46482237807746e-002;

            __statist_i_h_wts[7, 20] = 3.64266277412050e-002;

            __statist_i_h_wts[7, 21] = 2.45509731016628e-002;

            __statist_i_h_wts[7, 22] = 8.17685704772599e-003;

            __statist_i_h_wts[7, 23] = 7.66508371676464e-002;

            __statist_i_h_wts[7, 24] = -9.96112292759046e-003;

            __statist_i_h_wts[7, 25] = -1.07107869950249e-001;

            __statist_i_h_wts[7, 26] = -5.72720754562077e-002;

            __statist_i_h_wts[7, 27] = -3.97673144285005e-003;

            __statist_i_h_wts[7, 28] = -4.90323747291380e-002;

            __statist_i_h_wts[7, 29] = -1.43179352164418e-002;

            __statist_i_h_wts[7, 30] = 3.06423129778597e-002;

            __statist_i_h_wts[7, 31] = 8.40068254421921e-002;

            __statist_i_h_wts[7, 32] = 1.44451599799205e-003;

            __statist_i_h_wts[7, 33] = 3.68538264533722e-002;

            __statist_i_h_wts[7, 34] = -4.74331572924264e-002;

            __statist_i_h_wts[7, 35] = -2.78392111685986e-002;

            __statist_i_h_wts[7, 36] = -7.17782027820264e-003;

            __statist_i_h_wts[7, 37] = 1.30671172751967e-001;

            __statist_i_h_wts[7, 38] = 1.11162537982969e-001;

            __statist_i_h_wts[7, 39] = 2.82867439861374e-002;

            __statist_i_h_wts[7, 40] = 3.74558665936785e-004;

            __statist_i_h_wts[7, 41] = -3.51217863289725e-002;

            __statist_i_h_wts[7, 42] = -3.13778049900831e-002;

            __statist_i_h_wts[7, 43] = -1.23793854394937e-001;

            __statist_i_h_wts[7, 44] = 1.27648521226354e-001;

            __statist_i_h_wts[7, 45] = -1.51941477206058e-002;

            __statist_i_h_wts[7, 46] = -1.35639360206809e-001;

            __statist_i_h_wts[7, 47] = 1.10507667667953e-001;

            __statist_i_h_wts[7, 48] = -4.80557648255983e-002;

            __statist_i_h_wts[7, 49] = -2.78712961058732e-001;

            __statist_i_h_wts[7, 50] = 2.69622085017908e-001;

            __statist_i_h_wts[7, 51] = 1.85854597861291e-001;

            __statist_i_h_wts[7, 52] = -1.65221216143960e-001;

            __statist_i_h_wts[7, 53] = -4.19636766323979e-002;

            __statist_i_h_wts[7, 54] = -2.04206333132376e-002;

            __statist_i_h_wts[7, 55] = 1.41515352460344e-001;

            __statist_i_h_wts[7, 56] = -1.30054434711270e-001;

            __statist_i_h_wts[7, 57] = -1.02325920266539e-001;

            __statist_i_h_wts[7, 58] = -1.70878301589864e-001;

            __statist_i_h_wts[7, 59] = 2.19461071998098e-001;

            __statist_i_h_wts[7, 60] = -2.16111821108504e-001;

            __statist_i_h_wts[7, 61] = -8.15701718416616e-002;

            __statist_i_h_wts[7, 62] = 2.91978651044451e-001;

            __statist_i_h_wts[7, 63] = -9.21661451367480e-002;

            __statist_i_h_wts[7, 64] = -3.77545570835677e-001;

            __statist_i_h_wts[7, 65] = 4.65380483436584e-001;

            __statist_i_h_wts[7, 66] = 2.33305141832146e-001;

            __statist_i_h_wts[7, 67] = 5.68653251036917e-002;

            __statist_i_h_wts[7, 68] = -3.36535580814722e-001;

            __statist_i_h_wts[7, 69] = 9.40856850982697e-002;

            __statist_i_h_wts[7, 70] = 1.35988628589167e-001;

            __statist_i_h_wts[7, 71] = -2.42992772370784e-001;

            __statist_i_h_wts[7, 72] = -4.39903085604234e-001;

            __statist_i_h_wts[7, 73] = -1.76837681495837e-001;

            __statist_i_h_wts[7, 74] = 5.83159877780914e-001;

            __statist_i_h_wts[7, 75] = -3.94898127076687e-001;

            __statist_i_h_wts[7, 76] = -5.43217729126989e-001;

            __statist_i_h_wts[7, 77] = 9.31665365517078e-001;

            __statist_i_h_wts[7, 78] = 6.10665624548010e-001;

            __statist_i_h_wts[7, 79] = 2.72509789645431e-002;

            __statist_i_h_wts[7, 80] = -6.80752478713491e-001;

            __statist_i_h_wts[7, 81] = -6.53301785999538e-002;

            __statist_i_h_wts[7, 82] = -1.82346939704240e-001;

            __statist_i_h_wts[7, 83] = 2.12243670577249e-001;

            __statist_i_h_wts[7, 84] = -2.79513807363931e-001;

            __statist_i_h_wts[7, 85] = 3.11872058629644e-003;

            __statist_i_h_wts[7, 86] = 2.51998403539953e-001;

            __statist_i_h_wts[7, 87] = -9.17243119919248e-002;

            __statist_i_h_wts[7, 88] = -3.82964332617560e-001;

            __statist_i_h_wts[7, 89] = 4.43607712848647e-001;

            __statist_i_h_wts[7, 90] = 2.82975555104912e-001;

            __statist_i_h_wts[7, 91] = 2.63610452593935e-004;

            __statist_i_h_wts[7, 92] = -3.09509876106329e-001;

            __statist_i_h_wts[7, 93] = 1.18500529015864e-001;

            __statist_i_h_wts[7, 94] = 3.13961150076894e-002;

            __statist_i_h_wts[7, 95] = -1.91986860751839e-001;

            __statist_i_h_wts[7, 96] = -8.34890077661130e-002;

            __statist_i_h_wts[7, 97] = -9.05933966972138e-002;

            __statist_i_h_wts[7, 98] = 1.43187650854966e-001;

            __statist_i_h_wts[7, 99] = -1.68404028271958e-001;

            __statist_i_h_wts[7, 100] = -5.86876117639620e-002;

            __statist_i_h_wts[7, 101] = 1.98363325077380e-001;

            __statist_i_h_wts[7, 102] = 1.69181851979324e-002;

            __statist_i_h_wts[7, 103] = -3.07627332399387e-001;

            __statist_i_h_wts[7, 104] = 2.47162037899470e-001;

            __statist_i_h_wts[7, 105] = 2.15207191102474e-001;

            __statist_i_h_wts[7, 106] = -1.28831326765300e-001;

            __statist_i_h_wts[7, 107] = -9.73783743972971e-002;

            __statist_i_h_wts[7, 108] = 1.33402763891264e-001;

            __statist_i_h_wts[7, 109] = 1.05406825318349e-002;

            __statist_i_h_wts[7, 110] = -1.86166203522472e-001;

            __statist_i_h_wts[7, 111] = 1.68117945921897e+000;

            __statist_i_h_wts[7, 112] = -4.11592102958554e-001;

            __statist_i_h_wts[7, 113] = -1.30838496131878e+000;



            __statist_i_h_wts[8, 0] = -1.20649356241489e-001;

            __statist_i_h_wts[8, 1] = -4.33043764954100e-002;

            __statist_i_h_wts[8, 2] = 7.56518895800942e-002;

            __statist_i_h_wts[8, 3] = 3.08414646828786e-002;

            __statist_i_h_wts[8, 4] = 8.23011876668663e-002;

            __statist_i_h_wts[8, 5] = 1.89085852976704e-002;

            __statist_i_h_wts[8, 6] = -5.17461192309651e-002;

            __statist_i_h_wts[8, 7] = 7.47199047680970e-002;

            __statist_i_h_wts[8, 8] = -4.85142545330758e-002;

            __statist_i_h_wts[8, 9] = 8.97409430208350e-002;

            __statist_i_h_wts[8, 10] = 1.90913933327470e-003;

            __statist_i_h_wts[8, 11] = 1.52684358153995e-001;

            __statist_i_h_wts[8, 12] = -6.84603373483569e-002;

            __statist_i_h_wts[8, 13] = 1.95962902012679e-002;

            __statist_i_h_wts[8, 14] = -9.43510270911246e-002;

            __statist_i_h_wts[8, 15] = 4.03646146793469e-002;

            __statist_i_h_wts[8, 16] = -7.43516396397332e-002;

            __statist_i_h_wts[8, 17] = -1.86365854582105e-001;

            __statist_i_h_wts[8, 18] = -2.61117516032813e-002;

            __statist_i_h_wts[8, 19] = -1.89248299102871e-001;

            __statist_i_h_wts[8, 20] = -9.29442204707623e-002;

            __statist_i_h_wts[8, 21] = -5.96901078837565e-002;

            __statist_i_h_wts[8, 22] = -3.92406687214081e-002;

            __statist_i_h_wts[8, 23] = -7.67600736863792e-002;

            __statist_i_h_wts[8, 24] = -3.99372094438668e-002;

            __statist_i_h_wts[8, 25] = -9.04625130294031e-002;

            __statist_i_h_wts[8, 26] = 4.61779516486044e-002;

            __statist_i_h_wts[8, 27] = 1.07712492975404e-002;

            __statist_i_h_wts[8, 28] = 1.12338126830447e-002;

            __statist_i_h_wts[8, 29] = 8.72071770132049e-003;

            __statist_i_h_wts[8, 30] = -9.54435784600123e-002;

            __statist_i_h_wts[8, 31] = -4.98188576150582e-003;

            __statist_i_h_wts[8, 32] = -9.97785520305007e-002;

            __statist_i_h_wts[8, 33] = 6.93982637748302e-002;

            __statist_i_h_wts[8, 34] = -2.63678378170327e-002;

            __statist_i_h_wts[8, 35] = -1.20122000486917e-002;

            __statist_i_h_wts[8, 36] = 4.72145817273983e-003;

            __statist_i_h_wts[8, 37] = -6.09471904639238e-002;

            __statist_i_h_wts[8, 38] = 7.70034220364218e-002;

            __statist_i_h_wts[8, 39] = 2.69493560748863e-003;

            __statist_i_h_wts[8, 40] = 1.09274542150183e-001;

            __statist_i_h_wts[8, 41] = 1.79869317144457e-001;

            __statist_i_h_wts[8, 42] = 1.97668965813109e-002;

            __statist_i_h_wts[8, 43] = -2.07581706248445e-002;

            __statist_i_h_wts[8, 44] = -4.39658519776943e-001;

            __statist_i_h_wts[8, 45] = -3.86533803237833e-002;

            __statist_i_h_wts[8, 46] = -5.16681963457602e-002;

            __statist_i_h_wts[8, 47] = -3.53059675688189e-001;

            __statist_i_h_wts[8, 48] = 3.30304015406033e-001;

            __statist_i_h_wts[8, 49] = -3.03718647350085e-001;

            __statist_i_h_wts[8, 50] = -4.98945266357775e-001;

            __statist_i_h_wts[8, 51] = -2.26774442870726e-001;

            __statist_i_h_wts[8, 52] = -2.43449461305400e-001;

            __statist_i_h_wts[8, 53] = 1.14520041068615e-002;

            __statist_i_h_wts[8, 54] = -2.02783479657900e-001;

            __statist_i_h_wts[8, 55] = -3.96589089800685e-001;

            __statist_i_h_wts[8, 56] = 1.48319852365899e-001;

            __statist_i_h_wts[8, 57] = -8.98534826716854e-002;

            __statist_i_h_wts[8, 58] = 1.18881990309184e-001;

            __statist_i_h_wts[8, 59] = -4.99615982293754e-001;

            __statist_i_h_wts[8, 60] = -8.74746825299943e-002;

            __statist_i_h_wts[8, 61] = 2.41721083190223e-001;

            __statist_i_h_wts[8, 62] = -6.23551886329342e-001;

            __statist_i_h_wts[8, 63] = 5.99007966291313e-001;

            __statist_i_h_wts[8, 64] = 9.87465033489462e-002;

            __statist_i_h_wts[8, 65] = -1.17643789335656e+000;

            __statist_i_h_wts[8, 66] = -3.28142347514173e-001;

            __statist_i_h_wts[8, 67] = -4.91355327538764e-001;

            __statist_i_h_wts[8, 68] = 3.52519991744274e-001;

            __statist_i_h_wts[8, 69] = -3.41551451098802e-001;

            __statist_i_h_wts[8, 70] = -4.92620742892307e-001;

            __statist_i_h_wts[8, 71] = 3.92249012099551e-001;

            __statist_i_h_wts[8, 72] = -1.62576698915681e-001;

            __statist_i_h_wts[8, 73] = 5.45708633717317e-001;

            __statist_i_h_wts[8, 74] = -8.71140507918361e-001;

            __statist_i_h_wts[8, 75] = -1.68078033865199e-001;

            __statist_i_h_wts[8, 76] = 7.07575332686849e-001;

            __statist_i_h_wts[8, 77] = -9.85806327162998e-001;

            __statist_i_h_wts[8, 78] = -1.02359409439692e+000;

            __statist_i_h_wts[8, 79] = -9.75388230517965e-002;

            __statist_i_h_wts[8, 80] = 6.70856831524486e-001;

            __statist_i_h_wts[8, 81] = -3.81272070412882e-002;

            __statist_i_h_wts[8, 82] = 6.13697172430556e-002;

            __statist_i_h_wts[8, 83] = -4.84729448851453e-001;

            __statist_i_h_wts[8, 84] = 5.41205099758698e-002;

            __statist_i_h_wts[8, 85] = 1.79727453903483e-001;

            __statist_i_h_wts[8, 86] = -6.89229279762480e-001;

            __statist_i_h_wts[8, 87] = 5.29485147839317e-001;

            __statist_i_h_wts[8, 88] = -2.22866138946050e-002;

            __statist_i_h_wts[8, 89] = -9.78662621030129e-001;

            __statist_i_h_wts[8, 90] = -4.09860372927469e-001;

            __statist_i_h_wts[8, 91] = -1.47165927310863e-001;

            __statist_i_h_wts[8, 92] = 9.13499380937762e-002;

            __statist_i_h_wts[8, 93] = -1.64323292750379e-001;

            __statist_i_h_wts[8, 94] = -3.82745810212934e-001;

            __statist_i_h_wts[8, 95] = 7.72974707870364e-002;

            __statist_i_h_wts[8, 96] = -1.22431202652118e-001;

            __statist_i_h_wts[8, 97] = -7.78977969706488e-002;

            __statist_i_h_wts[8, 98] = -2.42834474549427e-001;

            __statist_i_h_wts[8, 99] = -7.20799508467587e-002;

            __statist_i_h_wts[8, 100] = -5.40903058628126e-002;

            __statist_i_h_wts[8, 101] = -3.51241694332667e-001;

            __statist_i_h_wts[8, 102] = 2.21965670335794e-001;

            __statist_i_h_wts[8, 103] = -2.97256259896123e-001;

            __statist_i_h_wts[8, 104] = -3.55019814846139e-001;

            __statist_i_h_wts[8, 105] = -2.36698134236739e-001;

            __statist_i_h_wts[8, 106] = -2.11890449520058e-001;

            __statist_i_h_wts[8, 107] = 9.07662295626576e-003;

            __statist_i_h_wts[8, 108] = -2.58308176172447e-001;

            __statist_i_h_wts[8, 109] = -3.62103913716119e-001;

            __statist_i_h_wts[8, 110] = 1.65657602433819e-001;

            __statist_i_h_wts[8, 111] = -2.01814300351244e+000;

            __statist_i_h_wts[8, 112] = 3.77509171320509e-001;

            __statist_i_h_wts[8, 113] = 1.17213720987328e+000;



            __statist_i_h_wts[9, 0] = 8.56589299921575e-003;

            __statist_i_h_wts[9, 1] = 3.82107369460070e-002;

            __statist_i_h_wts[9, 2] = -6.77376040644066e-002;

            __statist_i_h_wts[9, 3] = -3.97800165930591e-002;

            __statist_i_h_wts[9, 4] = -7.07584793255019e-003;

            __statist_i_h_wts[9, 5] = -1.28915089251381e-002;

            __statist_i_h_wts[9, 6] = -1.02019570364832e-004;

            __statist_i_h_wts[9, 7] = -2.42908202168018e-002;

            __statist_i_h_wts[9, 8] = -9.99296772595732e-002;

            __statist_i_h_wts[9, 9] = -1.37952105583888e-002;

            __statist_i_h_wts[9, 10] = -4.41384367676234e-002;

            __statist_i_h_wts[9, 11] = -5.10460743106790e-002;

            __statist_i_h_wts[9, 12] = -5.07708921278589e-002;

            __statist_i_h_wts[9, 13] = -8.45081912120905e-003;

            __statist_i_h_wts[9, 14] = 4.29632933009385e-002;

            __statist_i_h_wts[9, 15] = -2.07547841006704e-002;

            __statist_i_h_wts[9, 16] = -1.49658540722440e-004;

            __statist_i_h_wts[9, 17] = 5.68520671064725e-002;

            __statist_i_h_wts[9, 18] = 3.65084900038239e-002;

            __statist_i_h_wts[9, 19] = 5.34387114309707e-002;

            __statist_i_h_wts[9, 20] = 1.45455709382146e-002;

            __statist_i_h_wts[9, 21] = 2.59722166836490e-002;

            __statist_i_h_wts[9, 22] = -3.53583310065438e-003;

            __statist_i_h_wts[9, 23] = 2.45993498152067e-002;

            __statist_i_h_wts[9, 24] = 5.91580824884360e-003;

            __statist_i_h_wts[9, 25] = 1.13562192233132e-002;

            __statist_i_h_wts[9, 26] = -4.57386489536783e-002;

            __statist_i_h_wts[9, 27] = -4.10828532875447e-002;

            __statist_i_h_wts[9, 28] = -4.55326069909254e-002;

            __statist_i_h_wts[9, 29] = -2.33090122865068e-003;

            __statist_i_h_wts[9, 30] = 2.77535890120436e-002;

            __statist_i_h_wts[9, 31] = -1.44192290831825e-002;

            __statist_i_h_wts[9, 32] = -1.46800912371562e-002;

            __statist_i_h_wts[9, 33] = 5.83432857350611e-003;

            __statist_i_h_wts[9, 34] = -2.83423283128271e-002;

            __statist_i_h_wts[9, 35] = -3.67698211927722e-002;

            __statist_i_h_wts[9, 36] = -4.03440636829660e-003;

            __statist_i_h_wts[9, 37] = 5.56459497719883e-003;

            __statist_i_h_wts[9, 38] = 8.75631535005916e-003;

            __statist_i_h_wts[9, 39] = -2.69513401260246e-002;

            __statist_i_h_wts[9, 40] = 6.04418524287970e-003;

            __statist_i_h_wts[9, 41] = -8.88904792892869e-003;

            __statist_i_h_wts[9, 42] = -7.51127267950231e-002;

            __statist_i_h_wts[9, 43] = -2.76946318599129e-001;

            __statist_i_h_wts[9, 44] = 6.65083823334402e-002;

            __statist_i_h_wts[9, 45] = 9.93853863139102e-002;

            __statist_i_h_wts[9, 46] = -4.49942857341652e-001;

            __statist_i_h_wts[9, 47] = 6.42564826426975e-002;

            __statist_i_h_wts[9, 48] = -3.25301566651077e-001;

            __statist_i_h_wts[9, 49] = -9.26237545806688e-002;

            __statist_i_h_wts[9, 50] = 1.64488324399939e-001;

            __statist_i_h_wts[9, 51] = 3.42820011166503e-001;

            __statist_i_h_wts[9, 52] = -5.10321571666642e-001;

            __statist_i_h_wts[9, 53] = -1.00391386760739e-001;

            __statist_i_h_wts[9, 54] = 7.42010135627270e-002;

            __statist_i_h_wts[9, 55] = -2.15010738904724e-001;

            __statist_i_h_wts[9, 56] = -1.44352284661906e-001;

            __statist_i_h_wts[9, 57] = -2.08873629251456e-001;

            __statist_i_h_wts[9, 58] = -1.83188538796978e-001;

            __statist_i_h_wts[9, 59] = 1.26840222170899e-001;

            __statist_i_h_wts[9, 60] = -1.41737557001692e-002;

            __statist_i_h_wts[9, 61] = -3.95312981719548e-001;

            __statist_i_h_wts[9, 62] = 1.48501533393288e-001;

            __statist_i_h_wts[9, 63] = -5.13661414084764e-001;

            __statist_i_h_wts[9, 64] = -8.44844663620933e-002;

            __statist_i_h_wts[9, 65] = 3.10096212181840e-001;

            __statist_i_h_wts[9, 66] = 2.58143943944163e-001;

            __statist_i_h_wts[9, 67] = -3.01348956000925e-001;

            __statist_i_h_wts[9, 68] = -2.50704899267733e-001;

            __statist_i_h_wts[9, 69] = -3.44157451034322e-002;

            __statist_i_h_wts[9, 70] = -8.00180934471528e-002;

            __statist_i_h_wts[9, 71] = -1.83274110883318e-001;

            __statist_i_h_wts[9, 72] = 2.12865305550610e-001;

            __statist_i_h_wts[9, 73] = -8.37297467298985e-001;

            __statist_i_h_wts[9, 74] = 3.40717951933695e-001;

            __statist_i_h_wts[9, 75] = 5.93519712734515e-001;

            __statist_i_h_wts[9, 76] = -1.31139577804074e+000;

            __statist_i_h_wts[9, 77] = 4.35038039933060e-001;

            __statist_i_h_wts[9, 78] = 1.04873767594353e+000;

            __statist_i_h_wts[9, 79] = -6.64344624477827e-001;

            __statist_i_h_wts[9, 80] = -6.62875169603067e-001;

            __statist_i_h_wts[9, 81] = -1.00103291973483e-001;

            __statist_i_h_wts[9, 82] = -3.18159644261324e-001;

            __statist_i_h_wts[9, 83] = 1.15741960528110e-001;

            __statist_i_h_wts[9, 84] = 3.25236658109399e-002;

            __statist_i_h_wts[9, 85] = -4.44093841769940e-001;

            __statist_i_h_wts[9, 86] = 1.06868984934540e-001;

            __statist_i_h_wts[9, 87] = -4.69363425830205e-001;

            __statist_i_h_wts[9, 88] = -1.19620810820573e-001;

            __statist_i_h_wts[9, 89] = 2.93497199236783e-001;

            __statist_i_h_wts[9, 90] = 3.71750341052648e-001;

            __statist_i_h_wts[9, 91] = -4.37606808781891e-001;

            __statist_i_h_wts[9, 92] = -2.20405047392778e-001;

            __statist_i_h_wts[9, 93] = 1.10837177858660e-001;

            __statist_i_h_wts[9, 94] = -2.10496709686443e-001;

            __statist_i_h_wts[9, 95] = -1.84086406030155e-001;

            __statist_i_h_wts[9, 96] = -1.39686588495805e-001;

            __statist_i_h_wts[9, 97] = -2.56142639031729e-001;

            __statist_i_h_wts[9, 98] = 1.23875609353707e-001;

            __statist_i_h_wts[9, 99] = 2.89021225063985e-002;

            __statist_i_h_wts[9, 100] = -4.13263539862273e-001;

            __statist_i_h_wts[9, 101] = 9.68938381852508e-002;

            __statist_i_h_wts[9, 102] = -3.71650508021797e-001;

            __statist_i_h_wts[9, 103] = -8.01474167234688e-002;

            __statist_i_h_wts[9, 104] = 1.63171509210709e-001;

            __statist_i_h_wts[9, 105] = 3.02223178524227e-001;

            __statist_i_h_wts[9, 106] = -4.99266779060031e-001;

            __statist_i_h_wts[9, 107] = -8.91935437982155e-002;

            __statist_i_h_wts[9, 108] = 1.55367938583639e-001;

            __statist_i_h_wts[9, 109] = -2.77870310442605e-001;

            __statist_i_h_wts[9, 110] = -1.37623877033606e-001;

            __statist_i_h_wts[9, 111] = 1.77503503918031e+000;

            __statist_i_h_wts[9, 112] = -9.43846550979603e-001;

            __statist_i_h_wts[9, 113] = -1.12180002485686e+000;



            __statist_i_h_wts[10, 0] = -5.41934786541193e-003;

            __statist_i_h_wts[10, 1] = 2.65976682444714e-002;

            __statist_i_h_wts[10, 2] = 7.10322132305571e-003;

            __statist_i_h_wts[10, 3] = -1.16405126900691e-002;

            __statist_i_h_wts[10, 4] = -2.71869287105018e-002;

            __statist_i_h_wts[10, 5] = -2.86491936124735e-002;

            __statist_i_h_wts[10, 6] = -4.19586876353821e-002;

            __statist_i_h_wts[10, 7] = -2.22111327893429e-002;

            __statist_i_h_wts[10, 8] = -3.67837114896043e-003;

            __statist_i_h_wts[10, 9] = -2.28405479256956e-002;

            __statist_i_h_wts[10, 10] = -1.39845499959837e-002;

            __statist_i_h_wts[10, 11] = -2.16721161024726e-002;

            __statist_i_h_wts[10, 12] = 4.45364547764709e-002;

            __statist_i_h_wts[10, 13] = -1.94583348915311e-002;

            __statist_i_h_wts[10, 14] = -2.17327421053664e-002;

            __statist_i_h_wts[10, 15] = -2.29464789240522e-002;

            __statist_i_h_wts[10, 16] = -1.84278481758023e-002;

            __statist_i_h_wts[10, 17] = -5.98608545412577e-003;

            __statist_i_h_wts[10, 18] = -1.06996144078557e-002;

            __statist_i_h_wts[10, 19] = 3.24763088153242e-002;

            __statist_i_h_wts[10, 20] = 2.53385605474734e-002;

            __statist_i_h_wts[10, 21] = -3.15389904510706e-003;

            __statist_i_h_wts[10, 22] = 6.47994322703502e-003;

            __statist_i_h_wts[10, 23] = 2.03946440862013e-003;

            __statist_i_h_wts[10, 24] = 1.95703019086166e-002;

            __statist_i_h_wts[10, 25] = -1.60250538840146e-002;

            __statist_i_h_wts[10, 26] = -2.43507712681238e-002;

            __statist_i_h_wts[10, 27] = -2.98740702241805e-002;

            __statist_i_h_wts[10, 28] = -2.22082186833143e-003;

            __statist_i_h_wts[10, 29] = -1.31553207009025e-002;

            __statist_i_h_wts[10, 30] = -3.44877808636307e-003;

            __statist_i_h_wts[10, 31] = 6.51689209101853e-003;

            __statist_i_h_wts[10, 32] = -8.70341021864868e-004;

            __statist_i_h_wts[10, 33] = -3.80404422807582e-002;

            __statist_i_h_wts[10, 34] = -6.22619890860763e-002;

            __statist_i_h_wts[10, 35] = -1.80559308262242e-002;

            __statist_i_h_wts[10, 36] = -1.41114647592535e-002;

            __statist_i_h_wts[10, 37] = -7.11781131345046e-003;

            __statist_i_h_wts[10, 38] = -4.05345002425133e-003;

            __statist_i_h_wts[10, 39] = -8.61302626632799e-003;

            __statist_i_h_wts[10, 40] = 9.56598684433433e-003;

            __statist_i_h_wts[10, 41] = -2.05005977664764e-002;

            __statist_i_h_wts[10, 42] = -2.59856701810876e-001;

            __statist_i_h_wts[10, 43] = -1.19163072703286e-001;

            __statist_i_h_wts[10, 44] = 4.30371264953658e-002;

            __statist_i_h_wts[10, 45] = -1.16829595052221e-001;

            __statist_i_h_wts[10, 46] = -2.37125659615839e-001;

            __statist_i_h_wts[10, 47] = 5.41574646159607e-002;

            __statist_i_h_wts[10, 48] = -5.07898430886353e-001;

            __statist_i_h_wts[10, 49] = 6.66073242082311e-002;

            __statist_i_h_wts[10, 50] = 1.04920929392551e-001;

            __statist_i_h_wts[10, 51] = 1.95304200425535e-001;

            __statist_i_h_wts[10, 52] = -4.41396080838583e-001;

            __statist_i_h_wts[10, 53] = -7.54585369845019e-002;

            __statist_i_h_wts[10, 54] = -1.23972883537402e-001;

            __statist_i_h_wts[10, 55] = -9.16397461966392e-002;

            __statist_i_h_wts[10, 56] = -8.14629982889331e-002;

            __statist_i_h_wts[10, 57] = -3.62868565098957e-001;

            __statist_i_h_wts[10, 58] = -5.25300979240859e-002;

            __statist_i_h_wts[10, 59] = 8.27595667189944e-002;

            __statist_i_h_wts[10, 60] = -1.52644288460684e-001;

            __statist_i_h_wts[10, 61] = -2.43278974588180e-001;

            __statist_i_h_wts[10, 62] = 8.45438478867562e-002;

            __statist_i_h_wts[10, 63] = -6.84209003808785e-001;

            __statist_i_h_wts[10, 64] = 1.91069057469541e-001;

            __statist_i_h_wts[10, 65] = 1.46247741363181e-001;

            __statist_i_h_wts[10, 66] = 1.02063016082914e-001;

            __statist_i_h_wts[10, 67] = -2.85361623218727e-001;

            __statist_i_h_wts[10, 68] = -1.45477161775368e-001;

            __statist_i_h_wts[10, 69] = -2.17620367352871e-001;

            __statist_i_h_wts[10, 70] = 2.29480737410789e-002;

            __statist_i_h_wts[10, 71] = -1.23804614005116e-001;

            __statist_i_h_wts[10, 72] = 1.09185447614557e-001;

            __statist_i_h_wts[10, 73] = -5.77757779745774e-001;

            __statist_i_h_wts[10, 74] = 1.59490134854328e-001;

            __statist_i_h_wts[10, 75] = 3.76997484150256e-001;

            __statist_i_h_wts[10, 76] = -9.15252370227737e-001;

            __statist_i_h_wts[10, 77] = 2.05314258372017e-001;

            __statist_i_h_wts[10, 78] = 5.57759231372486e-001;

            __statist_i_h_wts[10, 79] = -5.17168061934682e-001;

            __statist_i_h_wts[10, 80] = -3.68581054957504e-001;

            __statist_i_h_wts[10, 81] = -2.79049414771574e-001;

            __statist_i_h_wts[10, 82] = -9.44033876579474e-002;

            __statist_i_h_wts[10, 83] = 5.86840759664899e-002;

            __statist_i_h_wts[10, 84] = -1.66017565903969e-001;

            __statist_i_h_wts[10, 85] = -2.31955491867271e-001;

            __statist_i_h_wts[10, 86] = 5.96279684252902e-002;

            __statist_i_h_wts[10, 87] = -6.43819834009115e-001;

            __statist_i_h_wts[10, 88] = 1.88213752503908e-001;

            __statist_i_h_wts[10, 89] = 1.44602711674641e-001;

            __statist_i_h_wts[10, 90] = 6.70069464052766e-002;

            __statist_i_h_wts[10, 91] = -2.32494078417547e-001;

            __statist_i_h_wts[10, 92] = -1.35979308177933e-001;

            __statist_i_h_wts[10, 93] = -2.39930914753350e-001;

            __statist_i_h_wts[10, 94] = -5.24008144350467e-003;

            __statist_i_h_wts[10, 95] = -1.00173185642889e-001;

            __statist_i_h_wts[10, 96] = -2.48052177324803e-001;

            __statist_i_h_wts[10, 97] = -1.27231094086991e-001;

            __statist_i_h_wts[10, 98] = 4.17506582275643e-002;

            __statist_i_h_wts[10, 99] = -1.23496236775843e-001;

            __statist_i_h_wts[10, 100] = -2.47197116050925e-001;

            __statist_i_h_wts[10, 101] = 4.22840259326724e-002;

            __statist_i_h_wts[10, 102] = -4.51037458478110e-001;

            __statist_i_h_wts[10, 103] = 5.59642208017060e-002;

            __statist_i_h_wts[10, 104] = 7.23636220428979e-002;

            __statist_i_h_wts[10, 105] = 1.65469819259359e-001;

            __statist_i_h_wts[10, 106] = -4.14324972645024e-001;

            __statist_i_h_wts[10, 107] = -6.70949127314279e-002;

            __statist_i_h_wts[10, 108] = -8.47304668252667e-002;

            __statist_i_h_wts[10, 109] = -1.97903858426272e-001;

            __statist_i_h_wts[10, 110] = -3.56634332632435e-002;

            __statist_i_h_wts[10, 111] = 9.34266572930007e-001;

            __statist_i_h_wts[10, 112] = -7.72958174237266e-001;

            __statist_i_h_wts[10, 113] = -4.63506925515567e-001;



            __statist_i_h_wts[11, 0] = 5.77013460201565e-002;

            __statist_i_h_wts[11, 1] = 2.86754505352343e-003;

            __statist_i_h_wts[11, 2] = 3.34695148870088e-002;

            __statist_i_h_wts[11, 3] = 2.26673866963528e-002;

            __statist_i_h_wts[11, 4] = -1.50824057609588e-002;

            __statist_i_h_wts[11, 5] = 2.64541707621240e-002;

            __statist_i_h_wts[11, 6] = -2.09869415067304e-002;

            __statist_i_h_wts[11, 7] = -7.54317906410691e-002;

            __statist_i_h_wts[11, 8] = -1.80831600993911e-003;

            __statist_i_h_wts[11, 9] = -3.67841047842428e-003;

            __statist_i_h_wts[11, 10] = 2.78931284735226e-002;

            __statist_i_h_wts[11, 11] = -1.24603179863607e-002;

            __statist_i_h_wts[11, 12] = -3.42452142975990e-002;

            __statist_i_h_wts[11, 13] = -1.26310833833490e-002;

            __statist_i_h_wts[11, 14] = 6.05904335141977e-002;

            __statist_i_h_wts[11, 15] = 3.53695458843213e-002;

            __statist_i_h_wts[11, 16] = 1.42723510749029e-002;

            __statist_i_h_wts[11, 17] = -4.44875916231421e-003;

            __statist_i_h_wts[11, 18] = -3.18410822319018e-002;

            __statist_i_h_wts[11, 19] = 4.47922910028097e-003;

            __statist_i_h_wts[11, 20] = -5.65409394669428e-002;

            __statist_i_h_wts[11, 21] = 6.34432072954645e-002;

            __statist_i_h_wts[11, 22] = -3.84779550165668e-002;

            __statist_i_h_wts[11, 23] = 9.75356323089510e-003;

            __statist_i_h_wts[11, 24] = -1.15773741670613e-002;

            __statist_i_h_wts[11, 25] = 4.67816866213323e-002;

            __statist_i_h_wts[11, 26] = -1.71302737161143e-002;

            __statist_i_h_wts[11, 27] = -1.99142861355265e-002;

            __statist_i_h_wts[11, 28] = 2.56175176567221e-004;

            __statist_i_h_wts[11, 29] = -1.29805658174918e-002;

            __statist_i_h_wts[11, 30] = 1.07444917799570e-002;

            __statist_i_h_wts[11, 31] = -9.60533359855899e-002;

            __statist_i_h_wts[11, 32] = 3.83925856116350e-003;

            __statist_i_h_wts[11, 33] = 4.49497599788757e-002;

            __statist_i_h_wts[11, 34] = -2.09674293011536e-002;

            __statist_i_h_wts[11, 35] = 3.13411513783181e-002;

            __statist_i_h_wts[11, 36] = 2.39090837895164e-003;

            __statist_i_h_wts[11, 37] = 8.53433018541809e-003;

            __statist_i_h_wts[11, 38] = -7.86387058624774e-003;

            __statist_i_h_wts[11, 39] = -1.64695914470190e-002;

            __statist_i_h_wts[11, 40] = -1.39200988149014e-002;

            __statist_i_h_wts[11, 41] = 3.20837028363857e-002;

            __statist_i_h_wts[11, 42] = 1.03385451388935e-001;

            __statist_i_h_wts[11, 43] = -6.20453649732460e-002;

            __statist_i_h_wts[11, 44] = -1.06327666313483e-002;

            __statist_i_h_wts[11, 45] = 1.32755540764451e-001;

            __statist_i_h_wts[11, 46] = -5.59212468098145e-002;

            __statist_i_h_wts[11, 47] = -2.98052781762331e-002;

            __statist_i_h_wts[11, 48] = -8.13269914027498e-002;

            __statist_i_h_wts[11, 49] = 2.11983743447519e-001;

            __statist_i_h_wts[11, 50] = -1.30951832539052e-001;

            __statist_i_h_wts[11, 51] = 1.86304875771622e-001;

            __statist_i_h_wts[11, 52] = -1.10820066647058e-001;

            __statist_i_h_wts[11, 53] = -6.96575397749790e-002;

            __statist_i_h_wts[11, 54] = 4.66984313432949e-002;

            __statist_i_h_wts[11, 55] = 2.09878986564339e-003;

            __statist_i_h_wts[11, 56] = -5.45562673905907e-002;

            __statist_i_h_wts[11, 57] = 1.04821825682877e-001;

            __statist_i_h_wts[11, 58] = -3.65195391079277e-002;

            __statist_i_h_wts[11, 59] = -5.11095927827977e-002;

            __statist_i_h_wts[11, 60] = 9.10373048112205e-002;

            __statist_i_h_wts[11, 61] = 3.42626622547396e-002;

            __statist_i_h_wts[11, 62] = -1.04500482881821e-001;

            __statist_i_h_wts[11, 63] = 4.90871957093168e-003;

            __statist_i_h_wts[11, 64] = 1.67251154568133e-001;

            __statist_i_h_wts[11, 65] = -1.32911637391547e-001;

            __statist_i_h_wts[11, 66] = 1.84998106797741e-001;

            __statist_i_h_wts[11, 67] = -1.49867026245991e-001;

            __statist_i_h_wts[11, 68] = -2.47358014252082e-004;

            __statist_i_h_wts[11, 69] = 2.41526437335187e-002;

            __statist_i_h_wts[11, 70] = 3.18887323393793e-003;

            __statist_i_h_wts[11, 71] = 1.54926573286515e-002;

            __statist_i_h_wts[11, 72] = 4.06816450898125e-001;

            __statist_i_h_wts[11, 73] = -3.47950607668563e-001;

            __statist_i_h_wts[11, 74] = -4.43136084010058e-002;

            __statist_i_h_wts[11, 75] = 6.78706675367506e-001;

            __statist_i_h_wts[11, 76] = -5.77875172363821e-001;

            __statist_i_h_wts[11, 77] = -7.11773022768420e-002;

            __statist_i_h_wts[11, 78] = 4.78084635605874e-001;

            __statist_i_h_wts[11, 79] = -2.96464066946261e-001;

            __statist_i_h_wts[11, 80] = -1.83198681506712e-001;

            __statist_i_h_wts[11, 81] = 8.66137137930312e-003;

            __statist_i_h_wts[11, 82] = 2.75893314186379e-002;

            __statist_i_h_wts[11, 83] = -4.56019674892672e-002;

            __statist_i_h_wts[11, 84] = 1.06160896877934e-001;

            __statist_i_h_wts[11, 85] = 1.18932416876730e-002;

            __statist_i_h_wts[11, 86] = -5.86680991608366e-002;

            __statist_i_h_wts[11, 87] = 2.33872741032085e-002;

            __statist_i_h_wts[11, 88] = 1.87347973806946e-001;

            __statist_i_h_wts[11, 89] = -1.49058175019617e-001;

            __statist_i_h_wts[11, 90] = 2.15364998168311e-001;

            __statist_i_h_wts[11, 91] = -1.71842344229556e-001;

            __statist_i_h_wts[11, 92] = -1.30078021972466e-002;

            __statist_i_h_wts[11, 93] = 1.80976344786416e-002;

            __statist_i_h_wts[11, 94] = -4.74995315853732e-002;

            __statist_i_h_wts[11, 95] = 1.99847455855188e-002;

            __statist_i_h_wts[11, 96] = -5.19533831967969e-002;

            __statist_i_h_wts[11, 97] = 2.89541329993447e-002;

            __statist_i_h_wts[11, 98] = 2.19830008583449e-002;

            __statist_i_h_wts[11, 99] = -3.73619045668100e-002;

            __statist_i_h_wts[11, 100] = 5.17907230176659e-002;

            __statist_i_h_wts[11, 101] = 8.81666818103878e-003;

            __statist_i_h_wts[11, 102] = -1.36064669838271e-001;

            __statist_i_h_wts[11, 103] = 1.78956209999836e-001;

            __statist_i_h_wts[11, 104] = -2.57378356218112e-002;

            __statist_i_h_wts[11, 105] = 1.61258095973085e-001;

            __statist_i_h_wts[11, 106] = -4.36240296909713e-002;

            __statist_i_h_wts[11, 107] = -8.74314942500656e-002;

            __statist_i_h_wts[11, 108] = -1.00384109803637e-001;

            __statist_i_h_wts[11, 109] = 1.33654511835314e-001;

            __statist_i_h_wts[11, 110] = 5.51072254232434e-003;

            __statist_i_h_wts[11, 111] = 5.24252886394632e-001;

            __statist_i_h_wts[11, 112] = -3.33030309436339e-001;

            __statist_i_h_wts[11, 113] = -1.76198267440560e-001;



            __statist_i_h_wts[12, 0] = 8.87314124892925e-002;

            __statist_i_h_wts[12, 1] = 3.49417758073375e-002;

            __statist_i_h_wts[12, 2] = 1.10311105247363e-001;

            __statist_i_h_wts[12, 3] = 7.17720790494249e-002;

            __statist_i_h_wts[12, 4] = -1.60361122738769e-001;

            __statist_i_h_wts[12, 5] = -3.31740278625637e-003;

            __statist_i_h_wts[12, 6] = -3.10942128509016e-002;

            __statist_i_h_wts[12, 7] = -8.75890682339156e-002;

            __statist_i_h_wts[12, 8] = 1.30942348784960e-001;

            __statist_i_h_wts[12, 9] = 6.44731850436201e-002;

            __statist_i_h_wts[12, 10] = 1.05342248724192e-001;

            __statist_i_h_wts[12, 11] = 1.07141159257649e-001;

            __statist_i_h_wts[12, 12] = 1.11234832822891e-001;

            __statist_i_h_wts[12, 13] = 2.36934276112049e-002;

            __statist_i_h_wts[12, 14] = -1.34375303542218e-001;

            __statist_i_h_wts[12, 15] = -2.29488039079246e-003;

            __statist_i_h_wts[12, 16] = -1.36179844582901e-002;

            __statist_i_h_wts[12, 17] = -1.45781901810474e-001;

            __statist_i_h_wts[12, 18] = -1.31827193442272e-001;

            __statist_i_h_wts[12, 19] = 7.95617187351596e-004;

            __statist_i_h_wts[12, 20] = 1.41271039359094e-002;

            __statist_i_h_wts[12, 21] = -3.51547133577113e-002;

            __statist_i_h_wts[12, 22] = -1.88205966100580e-002;

            __statist_i_h_wts[12, 23] = -2.19479696451175e-002;

            __statist_i_h_wts[12, 24] = 3.62869419474944e-003;

            __statist_i_h_wts[12, 25] = -3.05407793251966e-002;

            __statist_i_h_wts[12, 26] = 8.33615131376198e-002;

            __statist_i_h_wts[12, 27] = 7.15927800222452e-002;

            __statist_i_h_wts[12, 28] = 3.64326476916685e-002;

            __statist_i_h_wts[12, 29] = -1.08063604828352e-001;

            __statist_i_h_wts[12, 30] = -8.77796624673745e-002;

            __statist_i_h_wts[12, 31] = 3.24717586215771e-003;

            __statist_i_h_wts[12, 32] = 1.18476884768995e-002;

            __statist_i_h_wts[12, 33] = -9.66399071319949e-002;

            __statist_i_h_wts[12, 34] = 1.33433436786822e-002;

            __statist_i_h_wts[12, 35] = 1.37330202927716e-001;

            __statist_i_h_wts[12, 36] = -5.00319882924410e-003;

            __statist_i_h_wts[12, 37] = -3.13910589077297e-002;

            __statist_i_h_wts[12, 38] = -4.75542583304054e-002;

            __statist_i_h_wts[12, 39] = 6.27539270898156e-002;

            __statist_i_h_wts[12, 40] = 3.44299999091563e-002;

            __statist_i_h_wts[12, 41] = -2.02121649988559e-002;

            __statist_i_h_wts[12, 42] = 1.00449447907534e-001;

            __statist_i_h_wts[12, 43] = 5.78907673174822e-002;

            __statist_i_h_wts[12, 44] = -7.88859771183770e-002;

            __statist_i_h_wts[12, 45] = 5.34026547426816e-002;

            __statist_i_h_wts[12, 46] = 8.06663171554496e-002;

            __statist_i_h_wts[12, 47] = -5.84617451159527e-002;

            __statist_i_h_wts[12, 48] = 4.02367314923359e-001;

            __statist_i_h_wts[12, 49] = -1.36506948195030e-001;

            __statist_i_h_wts[12, 50] = -1.95304954261824e-001;

            __statist_i_h_wts[12, 51] = 2.40458895981432e-002;

            __statist_i_h_wts[12, 52] = 6.23922116283872e-002;

            __statist_i_h_wts[12, 53] = -1.80514865675452e-002;

            __statist_i_h_wts[12, 54] = -1.53722462286961e-002;

            __statist_i_h_wts[12, 55] = 5.35611051724024e-002;

            __statist_i_h_wts[12, 56] = 1.61239832179641e-002;

            __statist_i_h_wts[12, 57] = 6.83778238302329e-002;

            __statist_i_h_wts[12, 58] = 1.37172771017461e-001;

            __statist_i_h_wts[12, 59] = -1.25886387795215e-001;

            __statist_i_h_wts[12, 60] = 1.17291656478074e-001;

            __statist_i_h_wts[12, 61] = 9.44843263231391e-002;

            __statist_i_h_wts[12, 62] = -1.68986069884294e-001;

            __statist_i_h_wts[12, 63] = 5.33557659338724e-001;

            __statist_i_h_wts[12, 64] = -3.03815631902885e-003;

            __statist_i_h_wts[12, 65] = -4.49843044822013e-001;

            __statist_i_h_wts[12, 66] = -1.44502283758419e-001;

            __statist_i_h_wts[12, 67] = -2.79932300277237e-002;

            __statist_i_h_wts[12, 68] = 2.28066371434750e-001;

            __statist_i_h_wts[12, 69] = -1.03880336486235e-001;

            __statist_i_h_wts[12, 70] = 9.82227110299087e-002;

            __statist_i_h_wts[12, 71] = 7.69608811487316e-002;

            __statist_i_h_wts[12, 72] = -8.01707284911653e-003;

            __statist_i_h_wts[12, 73] = 3.80604346548882e-001;

            __statist_i_h_wts[12, 74] = -3.23008411033874e-001;

            __statist_i_h_wts[12, 75] = -5.20172315424683e-002;

            __statist_i_h_wts[12, 76] = 6.41202207830819e-001;

            __statist_i_h_wts[12, 77] = -5.23714423336471e-001;

            __statist_i_h_wts[12, 78] = -3.03369280956319e-001;

            __statist_i_h_wts[12, 79] = 3.21127244558190e-002;

            __statist_i_h_wts[12, 80] = 3.28518966345880e-001;

            __statist_i_h_wts[12, 81] = 7.71692088666577e-002;

            __statist_i_h_wts[12, 82] = 1.44287337237424e-001;

            __statist_i_h_wts[12, 83] = -1.27863529440475e-001;

            __statist_i_h_wts[12, 84] = 1.11802855837986e-001;

            __statist_i_h_wts[12, 85] = 1.33226634883087e-001;

            __statist_i_h_wts[12, 86] = -1.84143037132753e-001;

            __statist_i_h_wts[12, 87] = 6.07131275155561e-001;

            __statist_i_h_wts[12, 88] = -2.32112723336835e-002;

            __statist_i_h_wts[12, 89] = -5.16073247053480e-001;

            __statist_i_h_wts[12, 90] = -1.49678090957732e-001;

            __statist_i_h_wts[12, 91] = 2.79135627153365e-002;

            __statist_i_h_wts[12, 92] = 1.71532419707045e-001;

            __statist_i_h_wts[12, 93] = -1.59951759420436e-001;

            __statist_i_h_wts[12, 94] = -3.75040852304924e-003;

            __statist_i_h_wts[12, 95] = 2.31996030813055e-001;

            __statist_i_h_wts[12, 96] = 1.10474462638265e-001;

            __statist_i_h_wts[12, 97] = 1.12085767397064e-001;

            __statist_i_h_wts[12, 98] = -1.50300329242307e-001;

            __statist_i_h_wts[12, 99] = -1.79818267590052e-002;

            __statist_i_h_wts[12, 100] = 2.27351751253504e-001;

            __statist_i_h_wts[12, 101] = -1.33020761325942e-001;

            __statist_i_h_wts[12, 102] = 3.12926900754983e-001;

            __statist_i_h_wts[12, 103] = -3.70890085493962e-002;

            __statist_i_h_wts[12, 104] = -1.86963027134586e-001;

            __statist_i_h_wts[12, 105] = -4.12052925317998e-002;

            __statist_i_h_wts[12, 106] = 3.75535155050149e-002;

            __statist_i_h_wts[12, 107] = 7.90085717252253e-002;

            __statist_i_h_wts[12, 108] = -1.20303540907217e-001;

            __statist_i_h_wts[12, 109] = 5.83882444394970e-002;

            __statist_i_h_wts[12, 110] = 1.48779812377230e-001;

            __statist_i_h_wts[12, 111] = -1.28701675349287e+000;

            __statist_i_h_wts[12, 112] = 2.89473191003412e-001;

            __statist_i_h_wts[12, 113] = 1.05823075357026e+000;



            __statist_i_h_wts[13, 0] = 2.11524566960123e-002;

            __statist_i_h_wts[13, 1] = -4.64616571368349e-002;

            __statist_i_h_wts[13, 2] = 3.73483324558563e-002;

            __statist_i_h_wts[13, 3] = 6.89149252028468e-003;

            __statist_i_h_wts[13, 4] = -2.56631627762617e-002;

            __statist_i_h_wts[13, 5] = -4.04182674708121e-003;

            __statist_i_h_wts[13, 6] = 1.18054679836486e-002;

            __statist_i_h_wts[13, 7] = 4.60479662042839e-002;

            __statist_i_h_wts[13, 8] = 5.27755461059098e-002;

            __statist_i_h_wts[13, 9] = 1.94301536494966e-002;

            __statist_i_h_wts[13, 10] = 5.32651607687218e-002;

            __statist_i_h_wts[13, 11] = 7.90913017004342e-002;

            __statist_i_h_wts[13, 12] = 4.22045264512675e-002;

            __statist_i_h_wts[13, 13] = -3.06267668601834e-003;

            __statist_i_h_wts[13, 14] = -5.24823704588216e-002;

            __statist_i_h_wts[13, 15] = 1.49721797392659e-002;

            __statist_i_h_wts[13, 16] = 1.35455843029944e-002;

            __statist_i_h_wts[13, 17] = -5.08777160147938e-002;

            __statist_i_h_wts[13, 18] = -5.45496921281849e-002;

            __statist_i_h_wts[13, 19] = -5.34244356810453e-002;

            __statist_i_h_wts[13, 20] = -5.25543504622296e-002;

            __statist_i_h_wts[13, 21] = -3.91801180323471e-002;

            __statist_i_h_wts[13, 22] = -3.67914627867760e-002;

            __statist_i_h_wts[13, 23] = -2.35597401668867e-002;

            __statist_i_h_wts[13, 24] = -1.26579582530011e-002;

            __statist_i_h_wts[13, 25] = 9.83004055831881e-003;

            __statist_i_h_wts[13, 26] = 3.68291970558912e-002;

            __statist_i_h_wts[13, 27] = 3.72364979619021e-002;

            __statist_i_h_wts[13, 28] = -4.31134704536238e-003;

            __statist_i_h_wts[13, 29] = -1.44899226997969e-002;

            __statist_i_h_wts[13, 30] = -1.18451454297865e-002;

            __statist_i_h_wts[13, 31] = -1.79365583088090e-002;

            __statist_i_h_wts[13, 32] = -8.70229207479394e-003;

            __statist_i_h_wts[13, 33] = 1.76468643631023e-002;

            __statist_i_h_wts[13, 34] = 3.73932249111177e-002;

            __statist_i_h_wts[13, 35] = 5.01170381217625e-002;

            __statist_i_h_wts[13, 36] = 1.58850839355878e-002;

            __statist_i_h_wts[13, 37] = -1.77358004847038e-002;

            __statist_i_h_wts[13, 38] = -2.82437764901282e-002;

            __statist_i_h_wts[13, 39] = 1.29010599088166e-002;

            __statist_i_h_wts[13, 40] = -5.03767054416211e-003;

            __statist_i_h_wts[13, 41] = 4.37471595250443e-003;

            __statist_i_h_wts[13, 42] = -4.75154977869960e-002;

            __statist_i_h_wts[13, 43] = 1.69729727506617e-001;

            __statist_i_h_wts[13, 44] = -9.30280513927908e-002;

            __statist_i_h_wts[13, 45] = -1.83995982422078e-001;

            __statist_i_h_wts[13, 46] = 2.74778006252777e-001;

            __statist_i_h_wts[13, 47] = -7.29234617056096e-002;

            __statist_i_h_wts[13, 48] = 3.78437354740765e-001;

            __statist_i_h_wts[13, 49] = -1.20482289220794e-001;

            __statist_i_h_wts[13, 50] = -1.81193585945615e-001;

            __statist_i_h_wts[13, 51] = -4.73186065820984e-001;

            __statist_i_h_wts[13, 52] = 4.66194434838966e-001;

            __statist_i_h_wts[13, 53] = 7.40038212366410e-002;

            __statist_i_h_wts[13, 54] = -1.37776514162264e-001;

            __statist_i_h_wts[13, 55] = 8.28421459513441e-002;

            __statist_i_h_wts[13, 56] = 1.11117230124223e-001;

            __statist_i_h_wts[13, 57] = 7.89174608500674e-002;

            __statist_i_h_wts[13, 58] = 8.92874074336738e-002;

            __statist_i_h_wts[13, 59] = -1.28337366397102e-001;

            __statist_i_h_wts[13, 60] = -3.22139656531731e-002;

            __statist_i_h_wts[13, 61] = 2.59900334504420e-001;

            __statist_i_h_wts[13, 62] = -1.61389778480312e-001;

            __statist_i_h_wts[13, 63] = 6.27785671993316e-001;

            __statist_i_h_wts[13, 64] = -2.37532150223744e-001;

            __statist_i_h_wts[13, 65] = -3.31809119330059e-001;

            __statist_i_h_wts[13, 66] = -3.55105955636786e-001;

            __statist_i_h_wts[13, 67] = 2.03117419365626e-001;

            __statist_i_h_wts[13, 68] = 2.31137758706150e-001;

            __statist_i_h_wts[13, 69] = -4.40548989355201e-002;

            __statist_i_h_wts[13, 70] = -8.71517824977512e-002;

            __statist_i_h_wts[13, 71] = 1.69947381612466e-001;

            __statist_i_h_wts[13, 72] = -2.48967524947124e-001;

            __statist_i_h_wts[13, 73] = 6.33819644086924e-001;

            __statist_i_h_wts[13, 74] = -3.08432348807186e-001;

            __statist_i_h_wts[13, 75] = -5.22533803809152e-001;

            __statist_i_h_wts[13, 76] = 9.95639798548251e-001;

            __statist_i_h_wts[13, 77] = -4.42584371341555e-001;

            __statist_i_h_wts[13, 78] = -9.37780178889480e-001;

            __statist_i_h_wts[13, 79] = 3.48553162909108e-001;

            __statist_i_h_wts[13, 80] = 6.42552651430545e-001;

            __statist_i_h_wts[13, 81] = -2.84583863488820e-002;

            __statist_i_h_wts[13, 82] = 1.82132997630174e-001;

            __statist_i_h_wts[13, 83] = -1.05812341068543e-001;

            __statist_i_h_wts[13, 84] = -8.21205589803487e-002;

            __statist_i_h_wts[13, 85] = 2.65950735426698e-001;

            __statist_i_h_wts[13, 86] = -1.31408071944822e-001;

            __statist_i_h_wts[13, 87] = 5.83848060743093e-001;

            __statist_i_h_wts[13, 88] = -2.04236617414340e-001;

            __statist_i_h_wts[13, 89] = -3.22267397911468e-001;

            __statist_i_h_wts[13, 90] = -3.96727287446603e-001;

            __statist_i_h_wts[13, 91] = 2.58752384568056e-001;

            __statist_i_h_wts[13, 92] = 1.90864814607808e-001;

            __statist_i_h_wts[13, 93] = -1.29672248351099e-001;

            __statist_i_h_wts[13, 94] = -1.29130921595437e-002;

            __statist_i_h_wts[13, 95] = 1.89386596484262e-001;

            __statist_i_h_wts[13, 96] = 2.23491212026926e-002;

            __statist_i_h_wts[13, 97] = 1.46010513667959e-001;

            __statist_i_h_wts[13, 98] = -9.90035047400487e-002;

            __statist_i_h_wts[13, 99] = -1.08429468420299e-001;

            __statist_i_h_wts[13, 100] = 2.46643722095381e-001;

            __statist_i_h_wts[13, 101] = -8.83293351314180e-002;

            __statist_i_h_wts[13, 102] = 3.79571554574470e-001;

            __statist_i_h_wts[13, 103] = -1.40803904558110e-001;

            __statist_i_h_wts[13, 104] = -1.76585594976897e-001;

            __statist_i_h_wts[13, 105] = -4.17031553649649e-001;

            __statist_i_h_wts[13, 106] = 3.59567437008060e-001;

            __statist_i_h_wts[13, 107] = 9.68583199475644e-002;

            __statist_i_h_wts[13, 108] = -2.00627939844020e-001;

            __statist_i_h_wts[13, 109] = 1.31728293200921e-001;

            __statist_i_h_wts[13, 110] = 1.02736410594097e-001;

            __statist_i_h_wts[13, 111] = -1.70798405438786e+000;

            __statist_i_h_wts[13, 112] = 6.80447991180755e-001;

            __statist_i_h_wts[13, 113] = 1.03620714317362e+000;



            __statist_i_h_wts[14, 0] = 6.42272841717936e-002;

            __statist_i_h_wts[14, 1] = 1.75585133663922e-002;

            __statist_i_h_wts[14, 2] = 3.42176181848207e-002;

            __statist_i_h_wts[14, 3] = 4.01652496508568e-002;

            __statist_i_h_wts[14, 4] = -1.16340711418869e-001;

            __statist_i_h_wts[14, 5] = -9.67183551291371e-003;

            __statist_i_h_wts[14, 6] = -5.35715975131695e-002;

            __statist_i_h_wts[14, 7] = -5.06689915552869e-002;

            __statist_i_h_wts[14, 8] = 9.78658704404645e-002;

            __statist_i_h_wts[14, 9] = 2.28205773451433e-002;

            __statist_i_h_wts[14, 10] = 6.55904671313060e-002;

            __statist_i_h_wts[14, 11] = 8.78724880875977e-002;

            __statist_i_h_wts[14, 12] = 1.05580020957940e-001;

            __statist_i_h_wts[14, 13] = 1.17520791333601e-002;

            __statist_i_h_wts[14, 14] = -6.17076594785459e-002;

            __statist_i_h_wts[14, 15] = -4.44274520979296e-002;

            __statist_i_h_wts[14, 16] = -1.09252344839459e-002;

            __statist_i_h_wts[14, 17] = -9.55152390247426e-002;

            __statist_i_h_wts[14, 18] = -8.74726548637206e-002;

            __statist_i_h_wts[14, 19] = -5.54684143352868e-002;

            __statist_i_h_wts[14, 20] = -2.58501148731617e-002;

            __statist_i_h_wts[14, 21] = -4.13801535847335e-003;

            __statist_i_h_wts[14, 22] = -2.98252015672628e-002;

            __statist_i_h_wts[14, 23] = -1.01168691083483e-002;

            __statist_i_h_wts[14, 24] = 3.66628176002529e-004;

            __statist_i_h_wts[14, 25] = 2.78621567667640e-003;

            __statist_i_h_wts[14, 26] = 5.67774332563921e-002;

            __statist_i_h_wts[14, 27] = 4.59065632886646e-002;

            __statist_i_h_wts[14, 28] = 1.15530902987320e-002;

            __statist_i_h_wts[14, 29] = -6.90855146840620e-002;

            __statist_i_h_wts[14, 30] = -4.73072424440526e-002;

            __statist_i_h_wts[14, 31] = 2.74231557039521e-003;

            __statist_i_h_wts[14, 32] = 3.62058351681307e-002;

            __statist_i_h_wts[14, 33] = -1.46850892695435e-002;

            __statist_i_h_wts[14, 34] = 4.40537791047004e-002;

            __statist_i_h_wts[14, 35] = 1.06525699511294e-001;

            __statist_i_h_wts[14, 36] = 8.76978341043560e-003;

            __statist_i_h_wts[14, 37] = -1.60666864119933e-002;

            __statist_i_h_wts[14, 38] = -3.63057830377700e-002;

            __statist_i_h_wts[14, 39] = 3.72649349829188e-002;

            __statist_i_h_wts[14, 40] = -6.28041308614771e-003;

            __statist_i_h_wts[14, 41] = -1.58267569364945e-002;

            __statist_i_h_wts[14, 42] = 1.16101847715180e-001;

            __statist_i_h_wts[14, 43] = -6.14545098398042e-002;

            __statist_i_h_wts[14, 44] = -7.12800818239538e-002;

            __statist_i_h_wts[14, 45] = 8.04487244235921e-002;

            __statist_i_h_wts[14, 46] = -5.71445503302322e-002;

            __statist_i_h_wts[14, 47] = -4.65542665066302e-002;

            __statist_i_h_wts[14, 48] = 1.10794474911894e-001;

            __statist_i_h_wts[14, 49] = 4.39732130229603e-002;

            __statist_i_h_wts[14, 50] = -1.79827114087458e-001;

            __statist_i_h_wts[14, 51] = -4.36838762750488e-002;

            __statist_i_h_wts[14, 52] = 4.48929272409810e-002;

            __statist_i_h_wts[14, 53] = -2.24425216700402e-002;

            __statist_i_h_wts[14, 54] = -1.02482503451801e-002;

            __statist_i_h_wts[14, 55] = -2.51457419180636e-002;

            __statist_i_h_wts[14, 56] = 2.09539633787386e-002;

            __statist_i_h_wts[14, 57] = 1.14544275933495e-001;

            __statist_i_h_wts[14, 58] = -2.60131803737243e-002;

            __statist_i_h_wts[14, 59] = -1.20251561796743e-001;

            __statist_i_h_wts[14, 60] = 1.23889240810796e-001;

            __statist_i_h_wts[14, 61] = 2.44728336326750e-002;

            __statist_i_h_wts[14, 62] = -1.82365508271690e-001;

            __statist_i_h_wts[14, 63] = 3.57155530592437e-001;

            __statist_i_h_wts[14, 64] = 1.96496747118764e-002;

            __statist_i_h_wts[14, 65] = -3.92798306319327e-001;

            __statist_i_h_wts[14, 66] = -5.54340321048289e-002;

            __statist_i_h_wts[14, 67] = -1.10728353129290e-001;

            __statist_i_h_wts[14, 68] = 1.20539399007049e-001;

            __statist_i_h_wts[14, 69] = 9.60608471473617e-003;

            __statist_i_h_wts[14, 70] = -7.03695467615369e-002;

            __statist_i_h_wts[14, 71] = 3.38926370999453e-002;

            __statist_i_h_wts[14, 72] = 3.80797576330738e-002;

            __statist_i_h_wts[14, 73] = 1.54234055344773e-001;

            __statist_i_h_wts[14, 74] = -2.32923676888245e-001;

            __statist_i_h_wts[14, 75] = 5.65065513765771e-002;

            __statist_i_h_wts[14, 76] = 3.09899526133956e-001;

            __statist_i_h_wts[14, 77] = -3.78492370033573e-001;

            __statist_i_h_wts[14, 78] = -2.49733405582228e-001;

            __statist_i_h_wts[14, 79] = -3.64063323061132e-002;

            __statist_i_h_wts[14, 80] = 2.55748995657992e-001;

            __statist_i_h_wts[14, 81] = 4.69572914039819e-002;

            __statist_i_h_wts[14, 82] = 2.76442547526509e-002;

            __statist_i_h_wts[14, 83] = -1.11628642954973e-001;

            __statist_i_h_wts[14, 84] = 1.16358375520645e-001;

            __statist_i_h_wts[14, 85] = 2.51810881494401e-002;

            __statist_i_h_wts[14, 86] = -1.60632280002047e-001;

            __statist_i_h_wts[14, 87] = 4.34997224894111e-001;

            __statist_i_h_wts[14, 88] = -3.02578230250783e-002;

            __statist_i_h_wts[14, 89] = -4.25443164631188e-001;

            __statist_i_h_wts[14, 90] = -5.66458662982406e-002;

            __statist_i_h_wts[14, 91] = -1.18801336951275e-001;

            __statist_i_h_wts[14, 92] = 1.68453918946125e-001;

            __statist_i_h_wts[14, 93] = -6.05243429074002e-002;

            __statist_i_h_wts[14, 94] = -1.27431439786066e-001;

            __statist_i_h_wts[14, 95] = 1.60405260647081e-001;

            __statist_i_h_wts[14, 96] = -1.57950522546182e-003;

            __statist_i_h_wts[14, 97] = 9.80418338197845e-002;

            __statist_i_h_wts[14, 98] = -1.22512463911119e-001;

            __statist_i_h_wts[14, 99] = 6.39889546963313e-002;

            __statist_i_h_wts[14, 100] = 4.04992520435935e-002;

            __statist_i_h_wts[14, 101] = -1.47249345989725e-001;

            __statist_i_h_wts[14, 102] = 1.61950483320784e-001;

            __statist_i_h_wts[14, 103] = -9.22555082964544e-003;

            __statist_i_h_wts[14, 104] = -1.70024051054665e-001;

            __statist_i_h_wts[14, 105] = -6.75703220430356e-002;

            __statist_i_h_wts[14, 106] = 5.13482050579748e-002;

            __statist_i_h_wts[14, 107] = 2.79224325681087e-002;

            __statist_i_h_wts[14, 108] = -1.07424325638519e-001;

            __statist_i_h_wts[14, 109] = 1.51270867571242e-003;

            __statist_i_h_wts[14, 110] = 7.22459796911955e-002;

            __statist_i_h_wts[14, 111] = -9.45099970422671e-001;

            __statist_i_h_wts[14, 112] = 1.35829009254512e-001;

            __statist_i_h_wts[14, 113] = 7.52478565663872e-001;



            __statist_i_h_wts[15, 0] = -1.10287394106689e-001;

            __statist_i_h_wts[15, 1] = -1.14666333748138e-001;

            __statist_i_h_wts[15, 2] = -9.23894201076259e-002;

            __statist_i_h_wts[15, 3] = 1.64100864928670e-001;

            __statist_i_h_wts[15, 4] = -7.81562282861376e-003;

            __statist_i_h_wts[15, 5] = 1.07669138954669e-001;

            __statist_i_h_wts[15, 6] = -1.36253215246365e-001;

            __statist_i_h_wts[15, 7] = -1.47044899443732e-001;

            __statist_i_h_wts[15, 8] = 6.09269147097484e-002;

            __statist_i_h_wts[15, 9] = -8.02024853959552e-002;

            __statist_i_h_wts[15, 10] = 1.65794122778848e-002;

            __statist_i_h_wts[15, 11] = -1.10646729352720e-002;

            __statist_i_h_wts[15, 12] = -1.00371950707643e-001;

            __statist_i_h_wts[15, 13] = -8.77493610099979e-002;

            __statist_i_h_wts[15, 14] = -2.73627221610607e-003;

            __statist_i_h_wts[15, 15] = 5.69992641492473e-002;

            __statist_i_h_wts[15, 16] = 7.13974825961701e-002;

            __statist_i_h_wts[15, 17] = 5.49459057361067e-002;

            __statist_i_h_wts[15, 18] = -1.15736410336641e-003;

            __statist_i_h_wts[15, 19] = -9.53351556655126e-003;

            __statist_i_h_wts[15, 20] = -3.82553891245251e-002;

            __statist_i_h_wts[15, 21] = 8.16534726331056e-003;

            __statist_i_h_wts[15, 22] = -1.62512737481213e-002;

            __statist_i_h_wts[15, 23] = 3.54300406284212e-002;

            __statist_i_h_wts[15, 24] = -4.05870234120802e-003;

            __statist_i_h_wts[15, 25] = -5.26683829802032e-002;

            __statist_i_h_wts[15, 26] = -4.31842350004114e-002;

            __statist_i_h_wts[15, 27] = 1.19273139731817e-001;

            __statist_i_h_wts[15, 28] = -9.23150050320075e-002;

            __statist_i_h_wts[15, 29] = -8.12262046178601e-003;

            __statist_i_h_wts[15, 30] = -1.20768540884254e-002;

            __statist_i_h_wts[15, 31] = -1.78863875413600e-003;

            __statist_i_h_wts[15, 32] = -4.83402185667116e-004;

            __statist_i_h_wts[15, 33] = 1.97315606650706e-002;

            __statist_i_h_wts[15, 34] = 6.48787621039437e-002;

            __statist_i_h_wts[15, 35] = 4.26275441202821e-002;

            __statist_i_h_wts[15, 36] = 8.95835085665736e-003;

            __statist_i_h_wts[15, 37] = 8.85269366134694e-002;

            __statist_i_h_wts[15, 38] = -1.42476687028329e-002;

            __statist_i_h_wts[15, 39] = 8.24609868479571e-003;

            __statist_i_h_wts[15, 40] = 3.02280922814424e-002;

            __statist_i_h_wts[15, 41] = -3.44997240103295e-002;

            __statist_i_h_wts[15, 42] = -4.30972119685873e-002;

            __statist_i_h_wts[15, 43] = -2.00917168475834e-001;

            __statist_i_h_wts[15, 44] = -7.54155722749133e-003;

            __statist_i_h_wts[15, 45] = -3.09881586701227e-001;

            __statist_i_h_wts[15, 46] = 1.60542903397394e-001;

            __statist_i_h_wts[15, 47] = -1.01359498593027e-001;

            __statist_i_h_wts[15, 48] = -4.64519341900120e-001;

            __statist_i_h_wts[15, 49] = 2.45644377826410e-001;

            __statist_i_h_wts[15, 50] = -6.81044169012822e-002;

            __statist_i_h_wts[15, 51] = -2.36990223591743e-001;

            __statist_i_h_wts[15, 52] = -1.65061767588447e-002;

            __statist_i_h_wts[15, 53] = 7.59328355677107e-003;

            __statist_i_h_wts[15, 54] = -1.39503623204209e-001;

            __statist_i_h_wts[15, 55] = 3.35651146809566e-002;

            __statist_i_h_wts[15, 56] = -1.39219678979175e-001;

            __statist_i_h_wts[15, 57] = -2.03658943400739e-001;

            __statist_i_h_wts[15, 58] = -4.92711321340835e-002;

            __statist_i_h_wts[15, 59] = -4.49239701178595e-002;

            __statist_i_h_wts[15, 60] = -3.01500894466925e-001;

            __statist_i_h_wts[15, 61] = 9.05500226883875e-002;

            __statist_i_h_wts[15, 62] = -9.25054075181410e-002;

            __statist_i_h_wts[15, 63] = -4.06744763941716e-001;

            __statist_i_h_wts[15, 64] = 4.14069920162713e-001;

            __statist_i_h_wts[15, 65] = -2.73656605711899e-001;

            __statist_i_h_wts[15, 66] = -2.22721747989198e-001;

            __statist_i_h_wts[15, 67] = -2.01597943633955e-002;

            __statist_i_h_wts[15, 68] = -1.78925485975834e-004;

            __statist_i_h_wts[15, 69] = -9.63248091884358e-002;

            __statist_i_h_wts[15, 70] = -2.02838271220414e-002;

            __statist_i_h_wts[15, 71] = -1.54681931243693e-001;

            __statist_i_h_wts[15, 72] = -1.30877017560597e-001;

            __statist_i_h_wts[15, 73] = 1.54690769762198e-002;

            __statist_i_h_wts[15, 74] = -1.71205491828105e-001;

            __statist_i_h_wts[15, 75] = -1.02972251176196e-001;

            __statist_i_h_wts[15, 76] = -7.97679909512184e-002;

            __statist_i_h_wts[15, 77] = -7.48919965270632e-002;

            __statist_i_h_wts[15, 78] = -2.73941217123456e-001;

            __statist_i_h_wts[15, 79] = 1.28705014952476e-001;

            __statist_i_h_wts[15, 80] = -1.13114635198429e-001;

            __statist_i_h_wts[15, 81] = 2.81192044073985e-002;

            __statist_i_h_wts[15, 82] = -2.87100166556815e-001;

            __statist_i_h_wts[15, 83] = 1.51637367366967e-002;

            __statist_i_h_wts[15, 84] = -3.20924487749181e-001;

            __statist_i_h_wts[15, 85] = 8.82138104446289e-002;

            __statist_i_h_wts[15, 86] = -2.66364787189382e-002;

            __statist_i_h_wts[15, 87] = -3.65944305530940e-001;

            __statist_i_h_wts[15, 88] = 3.12959890140752e-001;

            __statist_i_h_wts[15, 89] = -2.43495587571572e-001;

            __statist_i_h_wts[15, 90] = -2.74834706795855e-001;

            __statist_i_h_wts[15, 91] = 1.97898014843618e-001;

            __statist_i_h_wts[15, 92] = -1.83331644216078e-001;

            __statist_i_h_wts[15, 93] = -1.10023469730580e-001;

            __statist_i_h_wts[15, 94] = -3.22843141507660e-002;

            __statist_i_h_wts[15, 95] = -7.91676021990020e-002;

            __statist_i_h_wts[15, 96] = -9.23245860379727e-002;

            __statist_i_h_wts[15, 97] = -6.53779302766370e-002;

            __statist_i_h_wts[15, 98] = -1.14535515093619e-001;

            __statist_i_h_wts[15, 99] = -4.12410432155862e-002;

            __statist_i_h_wts[15, 100] = -1.76025044721497e-001;

            __statist_i_h_wts[15, 101] = -7.62063223600678e-002;

            __statist_i_h_wts[15, 102] = -3.09257517712192e-001;

            __statist_i_h_wts[15, 103] = 7.93894216939115e-002;

            __statist_i_h_wts[15, 104] = -3.96016427629386e-002;

            __statist_i_h_wts[15, 105] = -6.96830451507239e-002;

            __statist_i_h_wts[15, 106] = -2.25517459402892e-001;

            __statist_i_h_wts[15, 107] = 1.21453229424086e-002;

            __statist_i_h_wts[15, 108] = -3.64233968646490e-002;

            __statist_i_h_wts[15, 109] = -2.80659882439480e-001;

            __statist_i_h_wts[15, 110] = 2.57662414324627e-002;

            __statist_i_h_wts[15, 111] = -4.10877091920435e-001;

            __statist_i_h_wts[15, 112] = -4.76506221033212e-001;

            __statist_i_h_wts[15, 113] = 6.04093993966703e-001;



            __statist_i_h_wts[16, 0] = -4.89046409649894e-002;

            __statist_i_h_wts[16, 1] = 4.52284537937395e-002;

            __statist_i_h_wts[16, 2] = 1.13919005111195e-001;

            __statist_i_h_wts[16, 3] = 6.13970964382682e-002;

            __statist_i_h_wts[16, 4] = -1.90101733428266e-001;

            __statist_i_h_wts[16, 5] = -1.48592770945893e-003;

            __statist_i_h_wts[16, 6] = -6.97791732251943e-002;

            __statist_i_h_wts[16, 7] = -6.03411257497612e-002;

            __statist_i_h_wts[16, 8] = 2.04755411061420e-001;

            __statist_i_h_wts[16, 9] = 9.93621410155290e-002;

            __statist_i_h_wts[16, 10] = 1.24184192285376e-001;

            __statist_i_h_wts[16, 11] = 1.00185295954738e-001;

            __statist_i_h_wts[16, 12] = 8.68664826259640e-002;

            __statist_i_h_wts[16, 13] = -3.31653600492010e-004;

            __statist_i_h_wts[16, 14] = -1.18956128176422e-001;

            __statist_i_h_wts[16, 15] = -5.50630950088294e-004;

            __statist_i_h_wts[16, 16] = 3.42130503225731e-002;

            __statist_i_h_wts[16, 17] = -1.23600148236033e-001;

            __statist_i_h_wts[16, 18] = -1.60510806992728e-001;

            __statist_i_h_wts[16, 19] = 3.95045939724231e-002;

            __statist_i_h_wts[16, 20] = -3.51755041880925e-002;

            __statist_i_h_wts[16, 21] = -3.51837086923784e-002;

            __statist_i_h_wts[16, 22] = -1.75136016471456e-002;

            __statist_i_h_wts[16, 23] = 2.11231980575023e-005;

            __statist_i_h_wts[16, 24] = 3.99260593933356e-002;

            __statist_i_h_wts[16, 25] = -4.56699814205334e-002;

            __statist_i_h_wts[16, 26] = 6.58007073082272e-002;

            __statist_i_h_wts[16, 27] = 1.13270440079408e-001;

            __statist_i_h_wts[16, 28] = -8.05364338296134e-003;

            __statist_i_h_wts[16, 29] = -1.47588803445660e-001;

            __statist_i_h_wts[16, 30] = -1.33911963768718e-001;

            __statist_i_h_wts[16, 31] = 3.09380156190806e-002;

            __statist_i_h_wts[16, 32] = 3.99556389976714e-002;

            __statist_i_h_wts[16, 33] = -1.28042873841087e-001;

            __statist_i_h_wts[16, 34] = 4.82844592520894e-002;

            __statist_i_h_wts[16, 35] = 1.69478272036467e-001;

            __statist_i_h_wts[16, 36] = -1.62570664100422e-003;

            __statist_i_h_wts[16, 37] = -3.75048416792537e-002;

            __statist_i_h_wts[16, 38] = -1.26495978687798e-001;

            __statist_i_h_wts[16, 39] = 5.47903757080164e-003;

            __statist_i_h_wts[16, 40] = 8.19232083297259e-002;

            __statist_i_h_wts[16, 41] = 2.72937757669503e-003;

            __statist_i_h_wts[16, 42] = 2.09952032463314e-002;

            __statist_i_h_wts[16, 43] = 7.88195521172063e-002;

            __statist_i_h_wts[16, 44] = -7.82849971713486e-002;

            __statist_i_h_wts[16, 45] = -2.19556904862889e-002;

            __statist_i_h_wts[16, 46] = 7.36906322388415e-002;

            __statist_i_h_wts[16, 47] = -4.77742585364996e-002;

            __statist_i_h_wts[16, 48] = 3.61999286463190e-001;

            __statist_i_h_wts[16, 49] = -2.51674114715103e-002;

            __statist_i_h_wts[16, 50] = -3.53568564187236e-001;

            __statist_i_h_wts[16, 51] = 7.39411970945625e-002;

            __statist_i_h_wts[16, 52] = -1.88706161715380e-002;

            __statist_i_h_wts[16, 53] = -5.57541613064090e-002;

            __statist_i_h_wts[16, 54] = 1.48623922688881e-002;

            __statist_i_h_wts[16, 55] = -5.20504788536405e-002;

            __statist_i_h_wts[16, 56] = 4.46197429775845e-002;

            __statist_i_h_wts[16, 57] = 9.28022626877230e-002;

            __statist_i_h_wts[16, 58] = 2.98002543522214e-002;

            __statist_i_h_wts[16, 59] = -1.10996206518394e-001;

            __statist_i_h_wts[16, 60] = 8.78222982004110e-002;

            __statist_i_h_wts[16, 61] = 1.40937887286977e-001;

            __statist_i_h_wts[16, 62] = -2.28555246695048e-001;

            __statist_i_h_wts[16, 63] = 7.11455817424477e-001;

            __statist_i_h_wts[16, 64] = -1.61320697239082e-001;

            __statist_i_h_wts[16, 65] = -5.75519594456866e-001;

            __statist_i_h_wts[16, 66] = -6.00695585724972e-002;

            __statist_i_h_wts[16, 67] = -4.23675691481109e-002;

            __statist_i_h_wts[16, 68] = 9.66213041222518e-002;

            __statist_i_h_wts[16, 69] = -6.05462416635047e-003;

            __statist_i_h_wts[16, 70] = -4.18788334057805e-002;

            __statist_i_h_wts[16, 71] = 2.00917959860979e-002;

            __statist_i_h_wts[16, 72] = 5.72285520937862e-002;

            __statist_i_h_wts[16, 73] = 2.72952288600186e-001;

            __statist_i_h_wts[16, 74] = -3.59386976433849e-001;

            __statist_i_h_wts[16, 75] = -9.55462668877948e-002;

            __statist_i_h_wts[16, 76] = 6.84816323046260e-001;

            __statist_i_h_wts[16, 77] = -5.87124535367955e-001;

            __statist_i_h_wts[16, 78] = -4.10500155680456e-001;

            __statist_i_h_wts[16, 79] = -6.24004488741010e-002;

            __statist_i_h_wts[16, 80] = 4.64497264732191e-001;

            __statist_i_h_wts[16, 81] = 3.42832099640667e-002;

            __statist_i_h_wts[16, 82] = 7.73935999249627e-002;

            __statist_i_h_wts[16, 83] = -1.22864928484826e-001;

            __statist_i_h_wts[16, 84] = 6.39525286033558e-002;

            __statist_i_h_wts[16, 85] = 8.87792401624268e-002;

            __statist_i_h_wts[16, 86] = -1.67062040930795e-001;

            __statist_i_h_wts[16, 87] = 7.70514024999821e-001;

            __statist_i_h_wts[16, 88] = -1.40699661888962e-001;

            __statist_i_h_wts[16, 89] = -6.18843786917334e-001;

            __statist_i_h_wts[16, 90] = -1.77386030103162e-001;

            __statist_i_h_wts[16, 91] = -5.94014879702355e-002;

            __statist_i_h_wts[16, 92] = 2.31571613522455e-001;

            __statist_i_h_wts[16, 93] = -6.22717731168543e-002;

            __statist_i_h_wts[16, 94] = -2.50857916230785e-001;

            __statist_i_h_wts[16, 95] = 2.76521223078012e-001;

            __statist_i_h_wts[16, 96] = 2.43972494203916e-001;

            __statist_i_h_wts[16, 97] = -2.63589239191524e-002;

            __statist_i_h_wts[16, 98] = -2.00125707525888e-001;

            __statist_i_h_wts[16, 99] = 1.66101703945848e-001;

            __statist_i_h_wts[16, 100] = -2.68882802947820e-002;

            __statist_i_h_wts[16, 101] = -1.44504121795688e-001;

            __statist_i_h_wts[16, 102] = 3.29387800852641e-001;

            __statist_i_h_wts[16, 103] = -8.47926815443870e-002;

            __statist_i_h_wts[16, 104] = -2.57782473712263e-001;

            __statist_i_h_wts[16, 105] = -2.68341314686824e-002;

            __statist_i_h_wts[16, 106] = -1.42759241928981e-002;

            __statist_i_h_wts[16, 107] = 4.62867138336701e-002;

            __statist_i_h_wts[16, 108] = -3.68294479318918e-003;

            __statist_i_h_wts[16, 109] = -1.45469491911101e-001;

            __statist_i_h_wts[16, 110] = 1.61849196265303e-001;

            __statist_i_h_wts[16, 111] = -1.55928773728542e+000;

            __statist_i_h_wts[16, 112] = 2.27769270822646e-001;

            __statist_i_h_wts[16, 113] = 1.31858902551613e+000;



            double[,] __statist_h_o_wts = new double[2, 17];



            __statist_h_o_wts[0, 0] = 4.07310672290340e-001;

            __statist_h_o_wts[0, 1] = 5.76312485199240e-001;

            __statist_h_o_wts[0, 2] = 1.45062792627442e+000;

            __statist_h_o_wts[0, 3] = 3.78349477024131e-001;

            __statist_h_o_wts[0, 4] = 1.53594191817758e+000;

            __statist_h_o_wts[0, 5] = -4.98335856568740e-001;

            __statist_h_o_wts[0, 6] = 6.28500987669865e-001;

            __statist_h_o_wts[0, 7] = 1.51857384244004e+000;

            __statist_h_o_wts[0, 8] = -1.97103259228568e+000;

            __statist_h_o_wts[0, 9] = 1.22719645448685e-001;

            __statist_h_o_wts[0, 10] = -6.27684514670649e-001;

            __statist_h_o_wts[0, 11] = -3.72607747245165e-001;

            __statist_h_o_wts[0, 12] = -1.25159814273884e+000;

            __statist_h_o_wts[0, 13] = -1.67813883128131e-001;

            __statist_h_o_wts[0, 14] = -8.73951193497668e-001;

            __statist_h_o_wts[0, 15] = -1.92754347247789e+000;

            __statist_h_o_wts[0, 16] = -1.41342840622556e+000;



            __statist_h_o_wts[1, 0] = -4.26407646138960e-001;

            __statist_h_o_wts[1, 1] = -5.93238537457344e-001;

            __statist_h_o_wts[1, 2] = -1.47202520066954e+000;

            __statist_h_o_wts[1, 3] = -3.53912663264296e-001;

            __statist_h_o_wts[1, 4] = -1.55719836792147e+000;

            __statist_h_o_wts[1, 5] = 4.86434068853829e-001;

            __statist_h_o_wts[1, 6] = -6.08062294940713e-001;

            __statist_h_o_wts[1, 7] = -1.53011940799557e+000;

            __statist_h_o_wts[1, 8] = 1.94395538074931e+000;

            __statist_h_o_wts[1, 9] = -1.10172103957021e-001;

            __statist_h_o_wts[1, 10] = 6.98127674745780e-001;

            __statist_h_o_wts[1, 11] = 3.80415192904941e-001;

            __statist_h_o_wts[1, 12] = 1.26689585447359e+000;

            __statist_h_o_wts[1, 13] = 1.67118966989233e-001;

            __statist_h_o_wts[1, 14] = 9.04788668198208e-001;

            __statist_h_o_wts[1, 15] = 1.93536268907877e+000;

            __statist_h_o_wts[1, 16] = 1.36784113352332e+000;



            double[] __statist_hidden_bias = new double[17];

            __statist_hidden_bias[0] = 4.52561389228632e-001;

            __statist_hidden_bias[1] = 1.02530841537534e-002;

            __statist_hidden_bias[2] = 1.70699583991035e-001;

            __statist_hidden_bias[3] = -1.32626770812529e-001;

            __statist_hidden_bias[4] = -1.13933593629390e-001;

            __statist_hidden_bias[5] = 9.52166179073567e-003;

            __statist_hidden_bias[6] = -5.56477519549518e-002;

            __statist_hidden_bias[7] = -1.48022483859991e-002;

            __statist_hidden_bias[8] = -4.43107478985028e-001;

            __statist_hidden_bias[9] = -2.76069313293659e-001;

            __statist_hidden_bias[10] = -3.35981361235005e-001;

            __statist_hidden_bias[11] = 2.86669924352358e-002;

            __statist_hidden_bias[12] = 5.73927250037945e-002;

            __statist_hidden_bias[13] = 3.54109634919848e-002;

            __statist_hidden_bias[14] = -9.21884238439257e-003;

            __statist_hidden_bias[15] = -2.74537663466031e-001;

            __statist_hidden_bias[16] = -8.73808666599640e-005;



            double[] __statist_output_bias = new double[2];

            __statist_output_bias[0] = 1.23478096046979e+000;

            __statist_output_bias[1] = -1.29673982298006e+000;



            double[] __statist_inputs = new double[114];



            double[] __statist_hidden = new double[17];



            double[] __statist_outputs = new double[2];

            __statist_outputs[0] = -1.0e+307;

            __statist_outputs[1] = -1.0e+307;





            if (Var4 == "0")
            {

                __statist_inputs[0] = 1;

            }

            else
            {

                __statist_inputs[0] = 0;

            }



            if (Var4 == "1")
            {

                __statist_inputs[1] = 1;

            }

            else
            {

                __statist_inputs[1] = 0;

            }



            if (Var4 == "10")
            {

                __statist_inputs[2] = 1;

            }

            else
            {

                __statist_inputs[2] = 0;

            }



            if (Var4 == "11")
            {

                __statist_inputs[3] = 1;

            }

            else
            {

                __statist_inputs[3] = 0;

            }



            if (Var4 == "12")
            {

                __statist_inputs[4] = 1;

            }

            else
            {

                __statist_inputs[4] = 0;

            }



            if (Var4 == "13")
            {

                __statist_inputs[5] = 1;

            }

            else
            {

                __statist_inputs[5] = 0;

            }



            if (Var4 == "14")
            {

                __statist_inputs[6] = 1;

            }

            else
            {

                __statist_inputs[6] = 0;

            }



            if (Var4 == "15")
            {

                __statist_inputs[7] = 1;

            }

            else
            {

                __statist_inputs[7] = 0;

            }



            if (Var4 == "16")
            {

                __statist_inputs[8] = 1;

            }

            else
            {

                __statist_inputs[8] = 0;

            }



            if (Var4 == "17")
            {

                __statist_inputs[9] = 1;

            }

            else
            {

                __statist_inputs[9] = 0;

            }



            if (Var4 == "18")
            {

                __statist_inputs[10] = 1;

            }

            else
            {

                __statist_inputs[10] = 0;

            }



            if (Var4 == "19")
            {

                __statist_inputs[11] = 1;

            }

            else
            {

                __statist_inputs[11] = 0;

            }



            if (Var4 == "2")
            {

                __statist_inputs[12] = 1;

            }

            else
            {

                __statist_inputs[12] = 0;

            }



            if (Var4 == "20")
            {

                __statist_inputs[13] = 1;

            }

            else
            {

                __statist_inputs[13] = 0;

            }



            if (Var4 == "21")
            {

                __statist_inputs[14] = 1;

            }

            else
            {

                __statist_inputs[14] = 0;

            }



            if (Var4 == "22")
            {

                __statist_inputs[15] = 1;

            }

            else
            {

                __statist_inputs[15] = 0;

            }



            if (Var4 == "23")
            {

                __statist_inputs[16] = 1;

            }

            else
            {

                __statist_inputs[16] = 0;

            }



            if (Var4 == "24")
            {

                __statist_inputs[17] = 1;

            }

            else
            {

                __statist_inputs[17] = 0;

            }



            if (Var4 == "25")
            {

                __statist_inputs[18] = 1;

            }

            else
            {

                __statist_inputs[18] = 0;

            }



            if (Var4 == "26")
            {

                __statist_inputs[19] = 1;

            }

            else
            {

                __statist_inputs[19] = 0;

            }



            if (Var4 == "27")
            {

                __statist_inputs[20] = 1;

            }

            else
            {

                __statist_inputs[20] = 0;

            }



            if (Var4 == "28")
            {

                __statist_inputs[21] = 1;

            }

            else
            {

                __statist_inputs[21] = 0;

            }



            if (Var4 == "29")
            {

                __statist_inputs[22] = 1;

            }

            else
            {

                __statist_inputs[22] = 0;

            }



            if (Var4 == "3")
            {

                __statist_inputs[23] = 1;

            }

            else
            {

                __statist_inputs[23] = 0;

            }



            if (Var4 == "30")
            {

                __statist_inputs[24] = 1;

            }

            else
            {

                __statist_inputs[24] = 0;

            }



            if (Var4 == "31")
            {

                __statist_inputs[25] = 1;

            }

            else
            {

                __statist_inputs[25] = 0;

            }



            if (Var4 == "32")
            {

                __statist_inputs[26] = 1;

            }

            else
            {

                __statist_inputs[26] = 0;

            }



            if (Var4 == "33")
            {

                __statist_inputs[27] = 1;

            }

            else
            {

                __statist_inputs[27] = 0;

            }



            if (Var4 == "34")
            {

                __statist_inputs[28] = 1;

            }

            else
            {

                __statist_inputs[28] = 0;

            }



            if (Var4 == "35")
            {

                __statist_inputs[29] = 1;

            }

            else
            {

                __statist_inputs[29] = 0;

            }



            if (Var4 == "36")
            {

                __statist_inputs[30] = 1;

            }

            else
            {

                __statist_inputs[30] = 0;

            }



            if (Var4 == "37")
            {

                __statist_inputs[31] = 1;

            }

            else
            {

                __statist_inputs[31] = 0;

            }



            if (Var4 == "38")
            {

                __statist_inputs[32] = 1;

            }

            else
            {

                __statist_inputs[32] = 0;

            }



            if (Var4 == "39")
            {

                __statist_inputs[33] = 1;

            }

            else
            {

                __statist_inputs[33] = 0;

            }



            if (Var4 == "4")
            {

                __statist_inputs[34] = 1;

            }

            else
            {

                __statist_inputs[34] = 0;

            }



            if (Var4 == "40")
            {

                __statist_inputs[35] = 1;

            }

            else
            {

                __statist_inputs[35] = 0;

            }



            if (Var4 == "41")
            {

                __statist_inputs[36] = 1;

            }

            else
            {

                __statist_inputs[36] = 0;

            }



            if (Var4 == "5")
            {

                __statist_inputs[37] = 1;

            }

            else
            {

                __statist_inputs[37] = 0;

            }



            if (Var4 == "6")
            {

                __statist_inputs[38] = 1;

            }

            else
            {

                __statist_inputs[38] = 0;

            }



            if (Var4 == "7")
            {

                __statist_inputs[39] = 1;

            }

            else
            {

                __statist_inputs[39] = 0;

            }



            if (Var4 == "8")
            {

                __statist_inputs[40] = 1;

            }

            else
            {

                __statist_inputs[40] = 0;

            }



            if (Var4 == "9")
            {

                __statist_inputs[41] = 1;

            }

            else
            {

                __statist_inputs[41] = 0;

            }



            if (Var6 == "0")
            {

                __statist_inputs[42] = 1;

            }

            else
            {

                __statist_inputs[42] = 0;

            }



            if (Var6 == "1")
            {

                __statist_inputs[43] = 1;

            }

            else
            {

                __statist_inputs[43] = 0;

            }



            if (Var6 == "2")
            {

                __statist_inputs[44] = 1;

            }

            else
            {

                __statist_inputs[44] = 0;

            }



            if (Var7 == "0")
            {

                __statist_inputs[45] = 1;

            }

            else
            {

                __statist_inputs[45] = 0;

            }



            if (Var7 == "1")
            {

                __statist_inputs[46] = 1;

            }

            else
            {

                __statist_inputs[46] = 0;

            }



            if (Var7 == "2")
            {

                __statist_inputs[47] = 1;

            }

            else
            {

                __statist_inputs[47] = 0;

            }



            if (Var8 == "0")
            {

                __statist_inputs[48] = 1;

            }

            else
            {

                __statist_inputs[48] = 0;

            }



            if (Var8 == "1")
            {

                __statist_inputs[49] = 1;

            }

            else
            {

                __statist_inputs[49] = 0;

            }



            if (Var8 == "2")
            {

                __statist_inputs[50] = 1;

            }

            else
            {

                __statist_inputs[50] = 0;

            }



            if (Var9 == "0")
            {

                __statist_inputs[51] = 1;

            }

            else
            {

                __statist_inputs[51] = 0;

            }



            if (Var9 == "1")
            {

                __statist_inputs[52] = 1;

            }

            else
            {

                __statist_inputs[52] = 0;

            }



            if (Var9 == "2")
            {

                __statist_inputs[53] = 1;

            }

            else
            {

                __statist_inputs[53] = 0;

            }



            if (Var10 == "0")
            {

                __statist_inputs[54] = 1;

            }

            else
            {

                __statist_inputs[54] = 0;

            }



            if (Var10 == "1")
            {

                __statist_inputs[55] = 1;

            }

            else
            {

                __statist_inputs[55] = 0;

            }



            if (Var10 == "2")
            {

                __statist_inputs[56] = 1;

            }

            else
            {

                __statist_inputs[56] = 0;

            }



            if (Var11 == "0")
            {

                __statist_inputs[57] = 1;

            }

            else
            {

                __statist_inputs[57] = 0;

            }



            if (Var11 == "1")
            {

                __statist_inputs[58] = 1;

            }

            else
            {

                __statist_inputs[58] = 0;

            }



            if (Var11 == "2")
            {

                __statist_inputs[59] = 1;

            }

            else
            {

                __statist_inputs[59] = 0;

            }



            if (Var12 == "0")
            {

                __statist_inputs[60] = 1;

            }

            else
            {

                __statist_inputs[60] = 0;

            }



            if (Var12 == "1")
            {

                __statist_inputs[61] = 1;

            }

            else
            {

                __statist_inputs[61] = 0;

            }



            if (Var12 == "2")
            {

                __statist_inputs[62] = 1;

            }

            else
            {

                __statist_inputs[62] = 0;

            }



            if (Var13 == "0")
            {

                __statist_inputs[63] = 1;

            }

            else
            {

                __statist_inputs[63] = 0;

            }



            if (Var13 == "1")
            {

                __statist_inputs[64] = 1;

            }

            else
            {

                __statist_inputs[64] = 0;

            }



            if (Var13 == "2")
            {

                __statist_inputs[65] = 1;

            }

            else
            {

                __statist_inputs[65] = 0;

            }



            if (Var14 == "0")
            {

                __statist_inputs[66] = 1;

            }

            else
            {

                __statist_inputs[66] = 0;

            }



            if (Var14 == "1")
            {

                __statist_inputs[67] = 1;

            }

            else
            {

                __statist_inputs[67] = 0;

            }



            if (Var14 == "2")
            {

                __statist_inputs[68] = 1;

            }

            else
            {

                __statist_inputs[68] = 0;

            }



            if (Var15 == "0")
            {

                __statist_inputs[69] = 1;

            }

            else
            {

                __statist_inputs[69] = 0;

            }



            if (Var15 == "1")
            {

                __statist_inputs[70] = 1;

            }

            else
            {

                __statist_inputs[70] = 0;

            }



            if (Var15 == "2")
            {

                __statist_inputs[71] = 1;

            }

            else
            {

                __statist_inputs[71] = 0;

            }



            if (Var16 == "0")
            {

                __statist_inputs[72] = 1;

            }

            else
            {

                __statist_inputs[72] = 0;

            }



            if (Var16 == "1")
            {

                __statist_inputs[73] = 1;

            }

            else
            {

                __statist_inputs[73] = 0;

            }



            if (Var16 == "2")
            {

                __statist_inputs[74] = 1;

            }

            else
            {

                __statist_inputs[74] = 0;

            }



            if (Var17 == "0")
            {

                __statist_inputs[75] = 1;

            }

            else
            {

                __statist_inputs[75] = 0;

            }



            if (Var17 == "1")
            {

                __statist_inputs[76] = 1;

            }

            else
            {

                __statist_inputs[76] = 0;

            }



            if (Var17 == "2")
            {

                __statist_inputs[77] = 1;

            }

            else
            {

                __statist_inputs[77] = 0;

            }



            if (Var20 == "0")
            {

                __statist_inputs[78] = 1;

            }

            else
            {

                __statist_inputs[78] = 0;

            }



            if (Var20 == "1")
            {

                __statist_inputs[79] = 1;

            }

            else
            {

                __statist_inputs[79] = 0;

            }



            if (Var20 == "2")
            {

                __statist_inputs[80] = 1;

            }

            else
            {

                __statist_inputs[80] = 0;

            }



            if (Var21 == "0")
            {

                __statist_inputs[81] = 1;

            }

            else
            {

                __statist_inputs[81] = 0;

            }



            if (Var21 == "1")
            {

                __statist_inputs[82] = 1;

            }

            else
            {

                __statist_inputs[82] = 0;

            }



            if (Var21 == "2")
            {

                __statist_inputs[83] = 1;

            }

            else
            {

                __statist_inputs[83] = 0;

            }



            if (Var22 == "0")
            {

                __statist_inputs[84] = 1;

            }

            else
            {

                __statist_inputs[84] = 0;

            }



            if (Var22 == "1")
            {

                __statist_inputs[85] = 1;

            }

            else
            {

                __statist_inputs[85] = 0;

            }



            if (Var22 == "2")
            {

                __statist_inputs[86] = 1;

            }

            else
            {

                __statist_inputs[86] = 0;

            }



            if (Var23 == "0")
            {

                __statist_inputs[87] = 1;

            }

            else
            {

                __statist_inputs[87] = 0;

            }



            if (Var23 == "1")
            {

                __statist_inputs[88] = 1;

            }

            else
            {

                __statist_inputs[88] = 0;

            }



            if (Var23 == "2")
            {

                __statist_inputs[89] = 1;

            }

            else
            {

                __statist_inputs[89] = 0;

            }



            if (Var24 == "0")
            {

                __statist_inputs[90] = 1;

            }

            else
            {

                __statist_inputs[90] = 0;

            }



            if (Var24 == "1")
            {

                __statist_inputs[91] = 1;

            }

            else
            {

                __statist_inputs[91] = 0;

            }



            if (Var24 == "2")
            {

                __statist_inputs[92] = 1;

            }

            else
            {

                __statist_inputs[92] = 0;

            }



            if (Var25 == "0")
            {

                __statist_inputs[93] = 1;

            }

            else
            {

                __statist_inputs[93] = 0;

            }



            if (Var25 == "1")
            {

                __statist_inputs[94] = 1;

            }

            else
            {

                __statist_inputs[94] = 0;

            }



            if (Var25 == "2")
            {

                __statist_inputs[95] = 1;

            }

            else
            {

                __statist_inputs[95] = 0;

            }



            if (Var26 == "0")
            {

                __statist_inputs[96] = 1;

            }

            else
            {

                __statist_inputs[96] = 0;

            }



            if (Var26 == "1")
            {

                __statist_inputs[97] = 1;

            }

            else
            {

                __statist_inputs[97] = 0;

            }



            if (Var26 == "2")
            {

                __statist_inputs[98] = 1;

            }

            else
            {

                __statist_inputs[98] = 0;

            }



            if (Var27 == "0")
            {

                __statist_inputs[99] = 1;

            }

            else
            {

                __statist_inputs[99] = 0;

            }



            if (Var27 == "1")
            {

                __statist_inputs[100] = 1;

            }

            else
            {

                __statist_inputs[100] = 0;

            }



            if (Var27 == "2")
            {

                __statist_inputs[101] = 1;

            }

            else
            {

                __statist_inputs[101] = 0;

            }



            if (Var28 == "0")
            {

                __statist_inputs[102] = 1;

            }

            else
            {

                __statist_inputs[102] = 0;

            }



            if (Var28 == "1")
            {

                __statist_inputs[103] = 1;

            }

            else
            {

                __statist_inputs[103] = 0;

            }



            if (Var28 == "2")
            {

                __statist_inputs[104] = 1;

            }

            else
            {

                __statist_inputs[104] = 0;

            }



            if (Var29 == "0")
            {

                __statist_inputs[105] = 1;

            }

            else
            {

                __statist_inputs[105] = 0;

            }



            if (Var29 == "1")
            {

                __statist_inputs[106] = 1;

            }

            else
            {

                __statist_inputs[106] = 0;

            }



            if (Var29 == "2")
            {

                __statist_inputs[107] = 1;

            }

            else
            {

                __statist_inputs[107] = 0;

            }



            if (Var30 == "0")
            {

                __statist_inputs[108] = 1;

            }

            else
            {

                __statist_inputs[108] = 0;

            }



            if (Var30 == "1")
            {

                __statist_inputs[109] = 1;

            }

            else
            {

                __statist_inputs[109] = 0;

            }



            if (Var30 == "2")
            {

                __statist_inputs[110] = 1;

            }

            else
            {

                __statist_inputs[110] = 0;

            }



            if (Var19 == "0")
            {

                __statist_inputs[111] = 1;

            }

            else
            {

                __statist_inputs[111] = 0;

            }



            if (Var19 == "1")
            {

                __statist_inputs[112] = 1;

            }

            else
            {

                __statist_inputs[112] = 0;

            }



            if (Var19 == "2")
            {

                __statist_inputs[113] = 1;

            }

            else
            {

                __statist_inputs[113] = 0;

            }



            double __statist_delta = 0;

            double __statist_maximum = 1;

            double __statist_minimum = 0;

            int __statist_ninputs = 114;

            int __statist_nhidden = 17;



            /*Compute feed forward signals from Input layer to hidden layer*/

            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                __statist_hidden[__statist_row] = 0.0;

                for (int __statist_col = 0; __statist_col < __statist_ninputs; __statist_col++)
                {

                    __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + (__statist_i_h_wts[__statist_row, __statist_col] * __statist_inputs[__statist_col]);

                }

                __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + __statist_hidden_bias[__statist_row];

            }



            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                if (__statist_hidden[__statist_row] > 100.0)
                {

                    __statist_hidden[__statist_row] = 1.0;

                }

                else
                {

                    if (__statist_hidden[__statist_row] < -100.0)
                    {

                        __statist_hidden[__statist_row] = -1.0;

                    }

                    else
                    {

                        __statist_hidden[__statist_row] = Math.Tanh(__statist_hidden[__statist_row]);

                    }

                }

            }



            int __statist_noutputs = 2;



            /*Compute feed forward signals from hidden layer to output layer*/

            for (int __statist_row2 = 0; __statist_row2 < __statist_noutputs; __statist_row2++)
            {

                __statist_outputs[__statist_row2] = 0.0;

                for (int __statist_col2 = 0; __statist_col2 < __statist_nhidden; __statist_col2++)
                {

                    __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + (__statist_h_o_wts[__statist_row2, __statist_col2] * __statist_hidden[__statist_col2]);

                }

                __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + __statist_output_bias[__statist_row2];

            }





            double __statist_sum = 0.0;

            double __statist_maxIndex = 0;

            for (int __statist_jj = 0; __statist_jj < __statist_noutputs; __statist_jj++)
            {

                if (__statist_outputs[__statist_jj] > 200)
                {

                    double __statist_max = __statist_outputs[1];

                    __statist_maxIndex = 0;

                    for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
                    {

                        if (__statist_outputs[__statist_ii] > __statist_max)
                        {

                            __statist_max = __statist_outputs[__statist_ii];

                            __statist_maxIndex = __statist_ii;

                        }

                    }



                    for (int __statist_kk = 0; __statist_kk < __statist_noutputs; __statist_kk++)
                    {

                        if (__statist_kk == __statist_maxIndex)
                        {

                            __statist_outputs[__statist_jj] = 1.0;

                        }

                        else
                        {

                            __statist_outputs[__statist_kk] = 0.0;

                        }

                    }

                }

                else
                {

                    __statist_outputs[__statist_jj] = Math.Exp(__statist_outputs[__statist_jj]);

                    __statist_sum = __statist_sum + __statist_outputs[__statist_jj];

                }

            }

            for (int __statist_ll = 0; __statist_ll < __statist_noutputs; __statist_ll++)
            {

                if (__statist_sum != 0)
                {

                    __statist_outputs[__statist_ll] = __statist_outputs[__statist_ll] / __statist_sum;

                }

            }



            int __statist_PredIndex = 1;

            for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
            {

                if (__statist_ConfLevel < __statist_outputs[__statist_ii])
                {

                    __statist_ConfLevel = __statist_outputs[__statist_ii];

                    __statist_PredIndex = __statist_ii;

                }

            }



            __statist_PredCat = __statist_DCats[__statist_PredIndex];


            string[] prediction = new string[2] { __statist_PredCat, __statist_ConfLevel.ToString() };
            
            return prediction;
        }



        public static string[] Main(string[] args)
        {

            int argID = 0;

            string[] CatInputs = new string[25];

            int catID = 0;


            if (args.Length >= 25)
            {

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

            }

            else
            {

                string Comment = "";

                string Comment1 = "**************************************************************************\n";

                Comment += Comment1;

                string Comment2 = "Please enter at least NaN command line parameters in the following order for \nthe program to Predict.\n";

                Comment += Comment2;

                Comment += Comment1;

                string Comment3 = "Var4  Type - String (categories are { \"0\"  \"1\"  \"10\"  \"11\"  \"12\"  \"13\"  \"14\"  \"15\"  \"16\"  \"17\"  \"18\"  \"19\"  \"2\"  \"20\"  \"21\"  \"22\"  \"23\"  \"24\"  \"25\"  \"26\"  \"27\"  \"28\"  \"29\"  \"3\"  \"30\"  \"31\"  \"32\"  \"33\"  \"34\"  \"35\"  \"36\"  \"37\"  \"38\"  \"39\"  \"4\"  \"40\"  \"41\"  \"5\"  \"6\"  \"7\"  \"8\"  \"9\" } )\n";

                Comment += Comment3;

                string Comment4 = "Var6  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment4;

                string Comment5 = "Var7  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment5;

                string Comment6 = "Var8  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment6;

                string Comment7 = "Var9  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment7;

                string Comment8 = "Var10  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment8;

                string Comment9 = "Var11  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment9;

                string Comment10 = "Var12  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment10;

                string Comment11 = "Var13  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment11;

                string Comment12 = "Var14  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment12;

                string Comment13 = "Var15  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment13;

                string Comment14 = "Var16  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment14;

                string Comment15 = "Var17  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment15;

                string Comment16 = "Var20  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment16;

                string Comment17 = "Var21  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment17;

                string Comment18 = "Var22  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment18;

                string Comment19 = "Var23  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment19;

                string Comment20 = "Var24  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment20;

                string Comment21 = "Var25  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment21;

                string Comment22 = "Var26  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment22;

                string Comment23 = "Var27  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment23;

                string Comment24 = "Var28  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment24;

                string Comment25 = "Var29  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment25;

                string Comment26 = "Var30  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment26;

                string Comment27 = "Var19  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment27;

                Comment += Comment1;

                return new string[] { Comment };

            }

            return MLP_114_17_2(CatInputs);

        }
    }
}
