﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nn4
{
    class Predict_Left
    {
        /**C# deployment code of Neural Networks Model**/

        /**==========================================================================
        Before running the C# deployment code please read the following.

         STATISTICA variable names will be exported as-is into the C# deployment script;
        please verify the resulting script to ensure that the variable names follow the C#
        naming conventions and modify the names if necessary.

        ==========================================================================**/

        public static string[] MLP_114_19_2(string[] CatInputs)
        {
            int Cat_idx = 0;

            string Var4 = CatInputs[Cat_idx++]; //Input Variable

            string Var6 = CatInputs[Cat_idx++]; //Input Variable

            string Var7 = CatInputs[Cat_idx++]; //Input Variable

            string Var8 = CatInputs[Cat_idx++]; //Input Variable

            string Var9 = CatInputs[Cat_idx++]; //Input Variable

            string Var10 = CatInputs[Cat_idx++]; //Input Variable

            string Var11 = CatInputs[Cat_idx++]; //Input Variable

            string Var12 = CatInputs[Cat_idx++]; //Input Variable

            string Var13 = CatInputs[Cat_idx++]; //Input Variable

            string Var14 = CatInputs[Cat_idx++]; //Input Variable

            string Var15 = CatInputs[Cat_idx++]; //Input Variable

            string Var16 = CatInputs[Cat_idx++]; //Input Variable

            string Var17 = CatInputs[Cat_idx++]; //Input Variable

            string Var19 = CatInputs[Cat_idx++]; //Input Variable

            string Var20 = CatInputs[Cat_idx++]; //Input Variable

            string Var21 = CatInputs[Cat_idx++]; //Input Variable

            string Var22 = CatInputs[Cat_idx++]; //Input Variable

            string Var23 = CatInputs[Cat_idx++]; //Input Variable

            string Var24 = CatInputs[Cat_idx++]; //Input Variable

            string Var25 = CatInputs[Cat_idx++]; //Input Variable

            string Var26 = CatInputs[Cat_idx++]; //Input Variable

            string Var27 = CatInputs[Cat_idx++]; //Input Variable

            string Var28 = CatInputs[Cat_idx++]; //Input Variable

            string Var29 = CatInputs[Cat_idx++]; //Input Variable

            string Var30 = CatInputs[Cat_idx++]; //Input Variable

            string __statist_PredCat = "";

            string[] __statist_DCats = new string[2];

            __statist_DCats[0] = "0";

            __statist_DCats[1] = "4";



            double __statist_ConfLevel = 3.0E-300;







            double[,] __statist_i_h_wts = new double[19, 114];



            __statist_i_h_wts[0, 0] = 7.31634425418503e-003;

            __statist_i_h_wts[0, 1] = 2.64641938129602e-002;

            __statist_i_h_wts[0, 2] = -5.11627854101480e-003;

            __statist_i_h_wts[0, 3] = 1.10410882703174e-003;

            __statist_i_h_wts[0, 4] = -1.42740206609291e-002;

            __statist_i_h_wts[0, 5] = 1.69020566950643e-002;

            __statist_i_h_wts[0, 6] = -3.38731127771151e-003;

            __statist_i_h_wts[0, 7] = -4.38754995996360e-003;

            __statist_i_h_wts[0, 8] = -1.68642374997582e-003;

            __statist_i_h_wts[0, 9] = 3.98389873053315e-003;

            __statist_i_h_wts[0, 10] = -4.06153733666446e-003;

            __statist_i_h_wts[0, 11] = -2.00964498733459e-002;

            __statist_i_h_wts[0, 12] = 1.49652800934557e-003;

            __statist_i_h_wts[0, 13] = 2.70191034028232e-003;

            __statist_i_h_wts[0, 14] = -4.74009570435693e-003;

            __statist_i_h_wts[0, 15] = 2.02846818818421e-003;

            __statist_i_h_wts[0, 16] = -4.64798967700880e-003;

            __statist_i_h_wts[0, 17] = 9.12206836209302e-003;

            __statist_i_h_wts[0, 18] = 1.91700906487132e-003;

            __statist_i_h_wts[0, 19] = 2.84164133588027e-002;

            __statist_i_h_wts[0, 20] = 8.65137622191180e-006;

            __statist_i_h_wts[0, 21] = 2.41857694896794e-003;

            __statist_i_h_wts[0, 22] = -3.93316591936944e-004;

            __statist_i_h_wts[0, 23] = 4.30760362133160e-003;

            __statist_i_h_wts[0, 24] = 1.25383382139417e-002;

            __statist_i_h_wts[0, 25] = 1.91168608548874e-002;

            __statist_i_h_wts[0, 26] = 1.01449099692563e-002;

            __statist_i_h_wts[0, 27] = -1.19450659420928e-002;

            __statist_i_h_wts[0, 28] = 5.97082612184982e-004;

            __statist_i_h_wts[0, 29] = 1.27263417379736e-002;

            __statist_i_h_wts[0, 30] = -5.83460654114604e-003;

            __statist_i_h_wts[0, 31] = 8.37309001608390e-003;

            __statist_i_h_wts[0, 32] = 1.09941701946179e-002;

            __statist_i_h_wts[0, 33] = -1.83876557320233e-003;

            __statist_i_h_wts[0, 34] = 7.05654638669993e-003;

            __statist_i_h_wts[0, 35] = -4.55438510775837e-005;

            __statist_i_h_wts[0, 36] = -1.04588347777576e-002;

            __statist_i_h_wts[0, 37] = -1.40929299490501e-002;

            __statist_i_h_wts[0, 38] = 7.44377633802256e-003;

            __statist_i_h_wts[0, 39] = 1.02261243345671e-002;

            __statist_i_h_wts[0, 40] = 1.12975093775926e-002;

            __statist_i_h_wts[0, 41] = 7.83727793874185e-003;

            __statist_i_h_wts[0, 42] = 1.46970984277351e-002;

            __statist_i_h_wts[0, 43] = 8.20288244917199e-002;

            __statist_i_h_wts[0, 44] = 3.28399723472128e-002;

            __statist_i_h_wts[0, 45] = -8.01540958955880e-002;

            __statist_i_h_wts[0, 46] = 1.69754653203161e-001;

            __statist_i_h_wts[0, 47] = 4.15418324796197e-002;

            __statist_i_h_wts[0, 48] = 5.79542231099731e-001;

            __statist_i_h_wts[0, 49] = -3.81245441421386e-001;

            __statist_i_h_wts[0, 50] = -7.07864256433947e-002;

            __statist_i_h_wts[0, 51] = 4.78513072023130e-002;

            __statist_i_h_wts[0, 52] = 1.14931396874455e-001;

            __statist_i_h_wts[0, 53] = -3.17250391912825e-002;

            __statist_i_h_wts[0, 54] = 1.00428995070900e-001;

            __statist_i_h_wts[0, 55] = 5.58977688596240e-002;

            __statist_i_h_wts[0, 56] = -5.52676641406977e-002;

            __statist_i_h_wts[0, 57] = 1.35723810312112e-001;

            __statist_i_h_wts[0, 58] = -5.32520389474480e-002;

            __statist_i_h_wts[0, 59] = 7.86841839077620e-002;

            __statist_i_h_wts[0, 60] = 3.05277722745316e-002;

            __statist_i_h_wts[0, 61] = 4.78698342905800e-002;

            __statist_i_h_wts[0, 62] = 6.35665008746952e-002;

            __statist_i_h_wts[0, 63] = 7.98154764762667e-001;

            __statist_i_h_wts[0, 64] = -5.14584588547524e-001;

            __statist_i_h_wts[0, 65] = -1.30895753290988e-001;

            __statist_i_h_wts[0, 66] = 1.25323717860154e-001;

            __statist_i_h_wts[0, 67] = 6.87396982732344e-002;

            __statist_i_h_wts[0, 68] = -7.91801920601089e-002;

            __statist_i_h_wts[0, 69] = 1.68379919863842e-001;

            __statist_i_h_wts[0, 70] = 8.68819950260027e-003;

            __statist_i_h_wts[0, 71] = -6.28270686410232e-002;

            __statist_i_h_wts[0, 72] = -7.41095370332936e-001;

            __statist_i_h_wts[0, 73] = 5.30761811518250e-001;

            __statist_i_h_wts[0, 74] = 3.03892345355690e-001;

            __statist_i_h_wts[0, 75] = -9.88286960891542e-001;

            __statist_i_h_wts[0, 76] = 6.17687321692511e-001;

            __statist_i_h_wts[0, 77] = 5.23623791426078e-001;

            __statist_i_h_wts[0, 78] = -5.69556827064571e-001;

            __statist_i_h_wts[0, 79] = 8.47645453411739e-001;

            __statist_i_h_wts[0, 80] = -1.56727144976941e-001;

            __statist_i_h_wts[0, 81] = -3.88028582251896e-001;

            __statist_i_h_wts[0, 82] = 6.15255980687741e-001;

            __statist_i_h_wts[0, 83] = -1.15048314798169e-001;

            __statist_i_h_wts[0, 84] = 1.42105824431391e-001;

            __statist_i_h_wts[0, 85] = -6.73197166120607e-002;

            __statist_i_h_wts[0, 86] = 2.30881644782508e-002;

            __statist_i_h_wts[0, 87] = 1.41710166465875e-002;

            __statist_i_h_wts[0, 88] = 4.49911517604515e-002;

            __statist_i_h_wts[0, 89] = 5.47687367132963e-002;

            __statist_i_h_wts[0, 90] = 8.38192560539810e-001;

            __statist_i_h_wts[0, 91] = -5.44541488563844e-001;

            __statist_i_h_wts[0, 92] = -1.56093955177351e-001;

            __statist_i_h_wts[0, 93] = 1.62852517974215e-001;

            __statist_i_h_wts[0, 94] = 3.44174020745364e-002;

            __statist_i_h_wts[0, 95] = -5.95784802816752e-002;

            __statist_i_h_wts[0, 96] = 2.28029937368978e-001;

            __statist_i_h_wts[0, 97] = -6.18212359686826e-002;

            __statist_i_h_wts[0, 98] = -6.88687779543985e-002;

            __statist_i_h_wts[0, 99] = 6.03148186368315e-002;

            __statist_i_h_wts[0, 100] = 2.27981778645772e-003;

            __statist_i_h_wts[0, 101] = 5.25348329927473e-002;

            __statist_i_h_wts[0, 102] = -4.85982955150438e-002;

            __statist_i_h_wts[0, 103] = 1.18869471055176e-001;

            __statist_i_h_wts[0, 104] = 8.92389050910573e-002;

            __statist_i_h_wts[0, 105] = 6.68725174909730e-001;

            __statist_i_h_wts[0, 106] = -4.47450817136832e-001;

            __statist_i_h_wts[0, 107] = -8.17050450980136e-002;

            __statist_i_h_wts[0, 108] = 9.15412687618976e-002;

            __statist_i_h_wts[0, 109] = 4.17187494951587e-002;

            __statist_i_h_wts[0, 110] = -3.02009397394741e-002;

            __statist_i_h_wts[0, 111] = 1.72694753549244e-001;

            __statist_i_h_wts[0, 112] = -4.06622536814498e-002;

            __statist_i_h_wts[0, 113] = -2.85362281902553e-002;



            __statist_i_h_wts[1, 0] = 9.54569710298661e-003;

            __statist_i_h_wts[1, 1] = 3.50363266023798e-002;

            __statist_i_h_wts[1, 2] = 4.20096081018405e-003;

            __statist_i_h_wts[1, 3] = 1.89504195444473e-002;

            __statist_i_h_wts[1, 4] = 1.57605372363972e-002;

            __statist_i_h_wts[1, 5] = 2.15519947349260e-002;

            __statist_i_h_wts[1, 6] = 8.52114284997399e-003;

            __statist_i_h_wts[1, 7] = -5.63982710483943e-003;

            __statist_i_h_wts[1, 8] = -1.51298793535470e-002;

            __statist_i_h_wts[1, 9] = -1.21557727342368e-002;

            __statist_i_h_wts[1, 10] = 2.36864099823713e-002;

            __statist_i_h_wts[1, 11] = -1.64237999436236e-002;

            __statist_i_h_wts[1, 12] = 3.20842146103454e-004;

            __statist_i_h_wts[1, 13] = -1.01669445010944e-002;

            __statist_i_h_wts[1, 14] = -1.05496778420820e-002;

            __statist_i_h_wts[1, 15] = -9.19008230347003e-003;

            __statist_i_h_wts[1, 16] = -4.46793467898298e-003;

            __statist_i_h_wts[1, 17] = 2.95285555281347e-003;

            __statist_i_h_wts[1, 18] = 1.01156125530989e-002;

            __statist_i_h_wts[1, 19] = 4.52071167666495e-002;

            __statist_i_h_wts[1, 20] = -9.03857314842621e-003;

            __statist_i_h_wts[1, 21] = -3.39668868182034e-002;

            __statist_i_h_wts[1, 22] = -7.16722110603876e-003;

            __statist_i_h_wts[1, 23] = 2.50228013184341e-002;

            __statist_i_h_wts[1, 24] = 3.50731012054478e-002;

            __statist_i_h_wts[1, 25] = -1.79120304883458e-002;

            __statist_i_h_wts[1, 26] = 8.31101594362764e-003;

            __statist_i_h_wts[1, 27] = 5.67916445223356e-003;

            __statist_i_h_wts[1, 28] = -2.00205831164605e-002;

            __statist_i_h_wts[1, 29] = -7.50340782994304e-003;

            __statist_i_h_wts[1, 30] = 2.13372121661853e-003;

            __statist_i_h_wts[1, 31] = 2.27232911890453e-002;

            __statist_i_h_wts[1, 32] = 6.20528383683491e-006;

            __statist_i_h_wts[1, 33] = 6.51808241580810e-003;

            __statist_i_h_wts[1, 34] = -3.60711466609657e-003;

            __statist_i_h_wts[1, 35] = 9.59175983959638e-003;

            __statist_i_h_wts[1, 36] = -3.73555395304813e-003;

            __statist_i_h_wts[1, 37] = -7.12476741380338e-003;

            __statist_i_h_wts[1, 38] = 3.49614880549069e-002;

            __statist_i_h_wts[1, 39] = 6.92572025721119e-003;

            __statist_i_h_wts[1, 40] = 3.43464556704372e-002;

            __statist_i_h_wts[1, 41] = 7.20518704970240e-003;

            __statist_i_h_wts[1, 42] = 8.85899125771177e-002;

            __statist_i_h_wts[1, 43] = 9.01141682947453e-002;

            __statist_i_h_wts[1, 44] = 7.58153997394864e-002;

            __statist_i_h_wts[1, 45] = 2.92503046520325e-006;

            __statist_i_h_wts[1, 46] = 2.21610976693323e-001;

            __statist_i_h_wts[1, 47] = 5.56749420175515e-002;

            __statist_i_h_wts[1, 48] = 2.74012268933547e-001;

            __statist_i_h_wts[1, 49] = 7.89507850264754e-002;

            __statist_i_h_wts[1, 50] = -9.90953125072625e-002;

            __statist_i_h_wts[1, 51] = 1.52151669067678e-001;

            __statist_i_h_wts[1, 52] = 1.39303057356910e-001;

            __statist_i_h_wts[1, 53] = -6.44399376443686e-002;

            __statist_i_h_wts[1, 54] = 1.80488929583014e-001;

            __statist_i_h_wts[1, 55] = 1.49352370989740e-001;

            __statist_i_h_wts[1, 56] = -6.15352440274337e-002;

            __statist_i_h_wts[1, 57] = 1.41322200226946e-001;

            __statist_i_h_wts[1, 58] = -9.38532485265654e-003;

            __statist_i_h_wts[1, 59] = 9.40285600200177e-002;

            __statist_i_h_wts[1, 60] = 5.86944525775895e-002;

            __statist_i_h_wts[1, 61] = 1.04241316391013e-001;

            __statist_i_h_wts[1, 62] = 9.05417734510891e-002;

            __statist_i_h_wts[1, 63] = 4.16856657881154e-001;

            __statist_i_h_wts[1, 64] = 4.58691230969776e-002;

            __statist_i_h_wts[1, 65] = -1.86796624087196e-001;

            __statist_i_h_wts[1, 66] = 1.73486205537619e-001;

            __statist_i_h_wts[1, 67] = 1.82945431835789e-001;

            __statist_i_h_wts[1, 68] = -1.23274637203200e-001;

            __statist_i_h_wts[1, 69] = 1.88087325477862e-001;

            __statist_i_h_wts[1, 70] = 1.73281899837568e-001;

            __statist_i_h_wts[1, 71] = -9.53720958516643e-002;

            __statist_i_h_wts[1, 72] = -5.10755164125580e-001;

            __statist_i_h_wts[1, 73] = 2.90313711883512e-001;

            __statist_i_h_wts[1, 74] = 4.69572691776546e-001;

            __statist_i_h_wts[1, 75] = -8.94230820486118e-001;

            __statist_i_h_wts[1, 76] = 3.19249216033898e-001;

            __statist_i_h_wts[1, 77] = 8.29611997175181e-001;

            __statist_i_h_wts[1, 78] = -1.27057652516749e-001;

            __statist_i_h_wts[1, 79] = 6.26718993885851e-001;

            __statist_i_h_wts[1, 80] = -2.50625550831680e-001;

            __statist_i_h_wts[1, 81] = 5.38933657875001e-002;

            __statist_i_h_wts[1, 82] = 3.91667905304009e-001;

            __statist_i_h_wts[1, 83] = -2.14744100398706e-001;

            __statist_i_h_wts[1, 84] = 1.60980643532467e-001;

            __statist_i_h_wts[1, 85] = 2.90637012055019e-002;

            __statist_i_h_wts[1, 86] = 6.44263256745640e-002;

            __statist_i_h_wts[1, 87] = 5.89810865885366e-003;

            __statist_i_h_wts[1, 88] = 1.42222254396617e-001;

            __statist_i_h_wts[1, 89] = 9.98859793190306e-002;

            __statist_i_h_wts[1, 90] = 4.11224730628836e-001;

            __statist_i_h_wts[1, 91] = 3.01771062513930e-002;

            __statist_i_h_wts[1, 92] = -1.99304354678813e-001;

            __statist_i_h_wts[1, 93] = 2.32241442547912e-001;

            __statist_i_h_wts[1, 94] = 1.45569440554388e-001;

            __statist_i_h_wts[1, 95] = -1.05842139226169e-001;

            __statist_i_h_wts[1, 96] = 2.49040685487746e-001;

            __statist_i_h_wts[1, 97] = 8.45599806701485e-002;

            __statist_i_h_wts[1, 98] = -8.74523744429214e-002;

            __statist_i_h_wts[1, 99] = 1.20580259381398e-001;

            __statist_i_h_wts[1, 100] = 5.52294588252773e-002;

            __statist_i_h_wts[1, 101] = 9.45784634165159e-002;

            __statist_i_h_wts[1, 102] = -1.89422938992113e-002;

            __statist_i_h_wts[1, 103] = 1.55234537297939e-001;

            __statist_i_h_wts[1, 104] = 1.11253401349895e-001;

            __statist_i_h_wts[1, 105] = 3.15933764382692e-001;

            __statist_i_h_wts[1, 106] = 6.88952167696340e-002;

            __statist_i_h_wts[1, 107] = -9.98727818108462e-002;

            __statist_i_h_wts[1, 108] = 1.80725259512279e-001;

            __statist_i_h_wts[1, 109] = 1.09255245257783e-001;

            __statist_i_h_wts[1, 110] = -6.15231425924295e-002;

            __statist_i_h_wts[1, 111] = 2.56668594376630e-001;

            __statist_i_h_wts[1, 112] = 3.50678957289920e-002;

            __statist_i_h_wts[1, 113] = -4.56489466019066e-002;



            __statist_i_h_wts[2, 0] = -6.13586926912900e-003;

            __statist_i_h_wts[2, 1] = 8.83452912747715e-003;

            __statist_i_h_wts[2, 2] = -1.56848978925183e-002;

            __statist_i_h_wts[2, 3] = 4.42147443455113e-003;

            __statist_i_h_wts[2, 4] = -9.09196711020371e-003;

            __statist_i_h_wts[2, 5] = -1.73678174527393e-002;

            __statist_i_h_wts[2, 6] = 3.14621882669798e-003;

            __statist_i_h_wts[2, 7] = 8.01697114671223e-003;

            __statist_i_h_wts[2, 8] = -7.31275767923883e-003;

            __statist_i_h_wts[2, 9] = 5.04565835574263e-003;

            __statist_i_h_wts[2, 10] = 8.93412888412014e-003;

            __statist_i_h_wts[2, 11] = 7.56423085652142e-003;

            __statist_i_h_wts[2, 12] = -1.66621408813625e-002;

            __statist_i_h_wts[2, 13] = -3.08303445081869e-003;

            __statist_i_h_wts[2, 14] = 1.43936833965572e-002;

            __statist_i_h_wts[2, 15] = 2.90634447242068e-003;

            __statist_i_h_wts[2, 16] = -1.86249654846420e-003;

            __statist_i_h_wts[2, 17] = -1.49803688923966e-002;

            __statist_i_h_wts[2, 18] = 4.04627693134948e-003;

            __statist_i_h_wts[2, 19] = -1.43261499484771e-002;

            __statist_i_h_wts[2, 20] = -3.25225276452669e-003;

            __statist_i_h_wts[2, 21] = -6.68619533185845e-003;

            __statist_i_h_wts[2, 22] = 5.47771618632899e-003;

            __statist_i_h_wts[2, 23] = -1.43076652896412e-002;

            __statist_i_h_wts[2, 24] = -1.15900653244696e-002;

            __statist_i_h_wts[2, 25] = 3.96416950528370e-003;

            __statist_i_h_wts[2, 26] = -1.37008983612531e-003;

            __statist_i_h_wts[2, 27] = 7.01766895735307e-003;

            __statist_i_h_wts[2, 28] = -3.56823516779056e-003;

            __statist_i_h_wts[2, 29] = -2.23782191210917e-003;

            __statist_i_h_wts[2, 30] = -3.27840481516674e-003;

            __statist_i_h_wts[2, 31] = 4.90789907328589e-003;

            __statist_i_h_wts[2, 32] = 1.20092333497309e-002;

            __statist_i_h_wts[2, 33] = 3.28620270054943e-003;

            __statist_i_h_wts[2, 34] = 4.58307396535319e-003;

            __statist_i_h_wts[2, 35] = 3.25082901113966e-003;

            __statist_i_h_wts[2, 36] = 1.40473606152765e-002;

            __statist_i_h_wts[2, 37] = 9.72873834457653e-003;

            __statist_i_h_wts[2, 38] = -1.63347013435988e-002;

            __statist_i_h_wts[2, 39] = -1.23055790647264e-002;

            __statist_i_h_wts[2, 40] = 6.92923213157582e-004;

            __statist_i_h_wts[2, 41] = -4.46132842766691e-003;

            __statist_i_h_wts[2, 42] = 1.26596771202479e-002;

            __statist_i_h_wts[2, 43] = -5.89684069284569e-002;

            __statist_i_h_wts[2, 44] = -4.68097599901237e-003;

            __statist_i_h_wts[2, 45] = 6.84437089614014e-002;

            __statist_i_h_wts[2, 46] = -1.36148633183453e-001;

            __statist_i_h_wts[2, 47] = -2.44918033545133e-002;

            __statist_i_h_wts[2, 48] = -3.88774304628044e-001;

            __statist_i_h_wts[2, 49] = 2.59826082940138e-001;

            __statist_i_h_wts[2, 50] = 1.35979282376202e-002;

            __statist_i_h_wts[2, 51] = -7.80673169976895e-003;

            __statist_i_h_wts[2, 52] = -5.85683346981036e-002;

            __statist_i_h_wts[2, 53] = 6.83821933629598e-003;

            __statist_i_h_wts[2, 54] = -6.70606027038115e-002;

            __statist_i_h_wts[2, 55] = -5.35745058903208e-002;

            __statist_i_h_wts[2, 56] = 3.45332505252878e-002;

            __statist_i_h_wts[2, 57] = -6.48000552233337e-002;

            __statist_i_h_wts[2, 58] = 1.15304000271989e-002;

            __statist_i_h_wts[2, 59] = -1.63263036777808e-002;

            __statist_i_h_wts[2, 60] = -1.16947236669307e-002;

            __statist_i_h_wts[2, 61] = -3.62371071131820e-002;

            __statist_i_h_wts[2, 62] = -3.36136580440056e-002;

            __statist_i_h_wts[2, 63] = -4.56426084451057e-001;

            __statist_i_h_wts[2, 64] = 3.44903025022354e-001;

            __statist_i_h_wts[2, 65] = 6.08034552446044e-002;

            __statist_i_h_wts[2, 66] = -5.80964514223285e-002;

            __statist_i_h_wts[2, 67] = -2.14624919940675e-002;

            __statist_i_h_wts[2, 68] = 2.92533810625094e-003;

            __statist_i_h_wts[2, 69] = -7.52638769221136e-002;

            __statist_i_h_wts[2, 70] = -1.37533644423582e-002;

            __statist_i_h_wts[2, 71] = 1.80263173138761e-002;

            __statist_i_h_wts[2, 72] = 4.12041074596542e-001;

            __statist_i_h_wts[2, 73] = -3.45567219257812e-001;

            __statist_i_h_wts[2, 74] = -1.09728933042190e-001;

            __statist_i_h_wts[2, 75] = 4.82002255309513e-001;

            __statist_i_h_wts[2, 76] = -3.70345914465798e-001;

            __statist_i_h_wts[2, 77] = -1.87548581040805e-001;

            __statist_i_h_wts[2, 78] = 3.78358808619996e-001;

            __statist_i_h_wts[2, 79] = -4.81368753061215e-001;

            __statist_i_h_wts[2, 80] = 1.41072971434218e-002;

            __statist_i_h_wts[2, 81] = 2.89015925916052e-001;

            __statist_i_h_wts[2, 82] = -4.01059134010666e-001;

            __statist_i_h_wts[2, 83] = 2.85550007522925e-002;

            __statist_i_h_wts[2, 84] = -5.84481542174019e-002;

            __statist_i_h_wts[2, 85] = 1.80533612128101e-002;

            __statist_i_h_wts[2, 86] = -1.72474291027234e-002;

            __statist_i_h_wts[2, 87] = 2.60049420741560e-003;

            __statist_i_h_wts[2, 88] = -5.49542666885778e-002;

            __statist_i_h_wts[2, 89] = -2.13364780974287e-002;

            __statist_i_h_wts[2, 90] = -4.80197247463260e-001;

            __statist_i_h_wts[2, 91] = 3.59550404706260e-001;

            __statist_i_h_wts[2, 92] = 5.98884237302869e-002;

            __statist_i_h_wts[2, 93] = -8.03821463529472e-002;

            __statist_i_h_wts[2, 94] = -3.69626099457226e-002;

            __statist_i_h_wts[2, 95] = 3.61826705992992e-002;

            __statist_i_h_wts[2, 96] = -1.24381335205024e-001;

            __statist_i_h_wts[2, 97] = 4.38542388080336e-002;

            __statist_i_h_wts[2, 98] = 7.51055619909913e-003;

            __statist_i_h_wts[2, 99] = -3.04612912809974e-002;

            __statist_i_h_wts[2, 100] = -1.30164386400492e-002;

            __statist_i_h_wts[2, 101] = -2.28582185613981e-002;

            __statist_i_h_wts[2, 102] = 2.61231670056848e-002;

            __statist_i_h_wts[2, 103] = -7.73431262897506e-002;

            __statist_i_h_wts[2, 104] = -2.51200090932924e-002;

            __statist_i_h_wts[2, 105] = -3.97863083029352e-001;

            __statist_i_h_wts[2, 106] = 2.92266039307867e-001;

            __statist_i_h_wts[2, 107] = 5.06862258744409e-002;

            __statist_i_h_wts[2, 108] = -4.76356674700329e-002;

            __statist_i_h_wts[2, 109] = -3.36178648358302e-002;

            __statist_i_h_wts[2, 110] = -7.18552387525385e-003;

            __statist_i_h_wts[2, 111] = -9.07436234907103e-002;

            __statist_i_h_wts[2, 112] = -1.92053584727689e-003;

            __statist_i_h_wts[2, 113] = -1.94120605991058e-003;



            __statist_i_h_wts[3, 0] = 2.10004011353414e-002;

            __statist_i_h_wts[3, 1] = 1.93342935545718e-002;

            __statist_i_h_wts[3, 2] = -4.04358221188698e-003;

            __statist_i_h_wts[3, 3] = 4.00013324112630e-002;

            __statist_i_h_wts[3, 4] = 6.39939949367474e-003;

            __statist_i_h_wts[3, 5] = -1.16105181657352e-002;

            __statist_i_h_wts[3, 6] = 1.15883568128880e-002;

            __statist_i_h_wts[3, 7] = -3.14713245999752e-002;

            __statist_i_h_wts[3, 8] = -4.80355824353039e-002;

            __statist_i_h_wts[3, 9] = -7.86701333190287e-003;

            __statist_i_h_wts[3, 10] = 2.25306082241644e-002;

            __statist_i_h_wts[3, 11] = -2.45199477756882e-002;

            __statist_i_h_wts[3, 12] = -9.39450511747627e-003;

            __statist_i_h_wts[3, 13] = -8.36895255061026e-003;

            __statist_i_h_wts[3, 14] = 6.53996727143545e-003;

            __statist_i_h_wts[3, 15] = 2.19502680704343e-003;

            __statist_i_h_wts[3, 16] = -1.24534307515570e-003;

            __statist_i_h_wts[3, 17] = 2.67118467639982e-003;

            __statist_i_h_wts[3, 18] = 1.07721397411025e-002;

            __statist_i_h_wts[3, 19] = 2.07998864168895e-002;

            __statist_i_h_wts[3, 20] = 2.28988748447528e-002;

            __statist_i_h_wts[3, 21] = -2.18661119593237e-002;

            __statist_i_h_wts[3, 22] = -1.96090673601401e-002;

            __statist_i_h_wts[3, 23] = 2.21903553058143e-003;

            __statist_i_h_wts[3, 24] = 7.60588079795109e-003;

            __statist_i_h_wts[3, 25] = 3.23381386354794e-003;

            __statist_i_h_wts[3, 26] = -1.81300351017266e-002;

            __statist_i_h_wts[3, 27] = 2.06095287526087e-002;

            __statist_i_h_wts[3, 28] = -1.40924754490135e-002;

            __statist_i_h_wts[3, 29] = -9.85824412370593e-003;

            __statist_i_h_wts[3, 30] = 9.18948067122919e-003;

            __statist_i_h_wts[3, 31] = 5.84710667075169e-003;

            __statist_i_h_wts[3, 32] = -1.24866369470659e-002;

            __statist_i_h_wts[3, 33] = -2.80989037210097e-002;

            __statist_i_h_wts[3, 34] = 6.80607727201024e-003;

            __statist_i_h_wts[3, 35] = -3.97900989751691e-003;

            __statist_i_h_wts[3, 36] = 1.36655500755977e-002;

            __statist_i_h_wts[3, 37] = -3.37239363059095e-003;

            __statist_i_h_wts[3, 38] = 2.57751768104712e-002;

            __statist_i_h_wts[3, 39] = -1.90948495031801e-003;

            __statist_i_h_wts[3, 40] = -7.16147807458959e-003;

            __statist_i_h_wts[3, 41] = -1.39993492208043e-002;

            __statist_i_h_wts[3, 42] = -6.56236178898032e-002;

            __statist_i_h_wts[3, 43] = 4.71372017017371e-003;

            __statist_i_h_wts[3, 44] = 3.19891706886113e-002;

            __statist_i_h_wts[3, 45] = -4.27308237938144e-002;

            __statist_i_h_wts[3, 46] = 6.07484087928437e-003;

            __statist_i_h_wts[3, 47] = 1.21861007236646e-002;

            __statist_i_h_wts[3, 48] = 7.32145551746506e-002;

            __statist_i_h_wts[3, 49] = -5.80896697849790e-002;

            __statist_i_h_wts[3, 50] = -4.69732707347636e-002;

            __statist_i_h_wts[3, 51] = -1.43316504578690e-002;

            __statist_i_h_wts[3, 52] = 1.67731758920157e-002;

            __statist_i_h_wts[3, 53] = -3.35370168826431e-002;

            __statist_i_h_wts[3, 54] = -9.98565779075299e-003;

            __statist_i_h_wts[3, 55] = 1.01671925116747e-002;

            __statist_i_h_wts[3, 56] = -3.44038021150824e-002;

            __statist_i_h_wts[3, 57] = -3.18887653065986e-002;

            __statist_i_h_wts[3, 58] = -4.93403957616367e-002;

            __statist_i_h_wts[3, 59] = 5.70907415347278e-002;

            __statist_i_h_wts[3, 60] = -2.01656442653486e-002;

            __statist_i_h_wts[3, 61] = -3.74551442823441e-002;

            __statist_i_h_wts[3, 62] = 3.56805619368314e-002;

            __statist_i_h_wts[3, 63] = 2.04911803405783e-001;

            __statist_i_h_wts[3, 64] = -7.44836243051561e-002;

            __statist_i_h_wts[3, 65] = -1.84664059589842e-001;

            __statist_i_h_wts[3, 66] = 2.01647696852003e-002;

            __statist_i_h_wts[3, 67] = 6.04176923612194e-002;

            __statist_i_h_wts[3, 68] = -1.25299266966915e-001;

            __statist_i_h_wts[3, 69] = 4.08237522685928e-002;

            __statist_i_h_wts[3, 70] = 1.96184412409835e-002;

            __statist_i_h_wts[3, 71] = -1.03212593266092e-001;

            __statist_i_h_wts[3, 72] = -2.50635660973256e-001;

            __statist_i_h_wts[3, 73] = 6.26281861979290e-002;

            __statist_i_h_wts[3, 74] = 1.44956828151043e-001;

            __statist_i_h_wts[3, 75] = -5.04991607083615e-001;

            __statist_i_h_wts[3, 76] = 1.10467483990261e-001;

            __statist_i_h_wts[3, 77] = 3.45716827462054e-001;

            __statist_i_h_wts[3, 78] = -3.87536732252811e-002;

            __statist_i_h_wts[3, 79] = 2.18044712200045e-001;

            __statist_i_h_wts[3, 80] = -2.17297933141267e-001;

            __statist_i_h_wts[3, 81] = -6.13312861360582e-003;

            __statist_i_h_wts[3, 82] = 9.23683329439840e-002;

            __statist_i_h_wts[3, 83] = -1.21148849885276e-001;

            __statist_i_h_wts[3, 84] = 1.09934827106874e-002;

            __statist_i_h_wts[3, 85] = -4.53825836130833e-002;

            __statist_i_h_wts[3, 86] = 2.70260671224931e-002;

            __statist_i_h_wts[3, 87] = -1.10773054265221e-002;

            __statist_i_h_wts[3, 88] = -1.94578018195537e-002;

            __statist_i_h_wts[3, 89] = 2.61582636244492e-002;

            __statist_i_h_wts[3, 90] = 1.96115117691688e-001;

            __statist_i_h_wts[3, 91] = -9.36938755764857e-002;

            __statist_i_h_wts[3, 92] = -1.49048372800655e-001;

            __statist_i_h_wts[3, 93] = 5.98622762764484e-002;

            __statist_i_h_wts[3, 94] = 3.66477322860535e-002;

            __statist_i_h_wts[3, 95] = -1.17045738715112e-001;

            __statist_i_h_wts[3, 96] = 2.05855670221426e-002;

            __statist_i_h_wts[3, 97] = 3.21584391258919e-002;

            __statist_i_h_wts[3, 98] = -9.31538774232820e-002;

            __statist_i_h_wts[3, 99] = -2.84274888026973e-002;

            __statist_i_h_wts[3, 100] = -2.89225835205316e-002;

            __statist_i_h_wts[3, 101] = 2.78230908193204e-002;

            __statist_i_h_wts[3, 102] = -5.15712683110590e-002;

            __statist_i_h_wts[3, 103] = 5.99915987939622e-004;

            __statist_i_h_wts[3, 104] = 2.03281700560294e-002;

            __statist_i_h_wts[3, 105] = 9.22170502425009e-002;

            __statist_i_h_wts[3, 106] = -2.60401218822028e-002;

            __statist_i_h_wts[3, 107] = -8.33793559184578e-002;

            __statist_i_h_wts[3, 108] = -5.67043213359514e-003;

            __statist_i_h_wts[3, 109] = 1.87971219050002e-002;

            __statist_i_h_wts[3, 110] = -2.85131630534466e-002;

            __statist_i_h_wts[3, 111] = 2.43071961632953e-002;

            __statist_i_h_wts[3, 112] = -1.65709648921158e-002;

            __statist_i_h_wts[3, 113] = -3.37761046265311e-002;



            __statist_i_h_wts[4, 0] = -2.51414182789800e-003;

            __statist_i_h_wts[4, 1] = 1.24559332148328e-002;

            __statist_i_h_wts[4, 2] = -1.16147560126063e-002;

            __statist_i_h_wts[4, 3] = 1.98507234134362e-002;

            __statist_i_h_wts[4, 4] = 1.13601087398900e-003;

            __statist_i_h_wts[4, 5] = 3.66962004129028e-002;

            __statist_i_h_wts[4, 6] = 2.19837272779168e-002;

            __statist_i_h_wts[4, 7] = -1.79850705761485e-002;

            __statist_i_h_wts[4, 8] = -1.13593619373787e-002;

            __statist_i_h_wts[4, 9] = -7.63239417913890e-003;

            __statist_i_h_wts[4, 10] = 2.19775134241819e-002;

            __statist_i_h_wts[4, 11] = -1.94761682779626e-002;

            __statist_i_h_wts[4, 12] = 1.75044626805026e-003;

            __statist_i_h_wts[4, 13] = -1.35693394553551e-003;

            __statist_i_h_wts[4, 14] = -8.01989511173993e-003;

            __statist_i_h_wts[4, 15] = -2.07718037553568e-003;

            __statist_i_h_wts[4, 16] = -1.32101251247409e-002;

            __statist_i_h_wts[4, 17] = 9.39054264321524e-003;

            __statist_i_h_wts[4, 18] = 4.66616791089250e-003;

            __statist_i_h_wts[4, 19] = 5.60855981455860e-002;

            __statist_i_h_wts[4, 20] = 3.55356787609397e-003;

            __statist_i_h_wts[4, 21] = -1.28528648532379e-002;

            __statist_i_h_wts[4, 22] = 2.28742362488191e-003;

            __statist_i_h_wts[4, 23] = 1.96136198766035e-002;

            __statist_i_h_wts[4, 24] = 1.23668871906609e-002;

            __statist_i_h_wts[4, 25] = 6.26377604292280e-003;

            __statist_i_h_wts[4, 26] = -5.36010113657564e-004;

            __statist_i_h_wts[4, 27] = -1.08177779180603e-002;

            __statist_i_h_wts[4, 28] = -2.00093728713156e-002;

            __statist_i_h_wts[4, 29] = -4.12244276391972e-003;

            __statist_i_h_wts[4, 30] = -2.48542986599394e-003;

            __statist_i_h_wts[4, 31] = 9.69039903734706e-003;

            __statist_i_h_wts[4, 32] = -8.53795350243756e-003;

            __statist_i_h_wts[4, 33] = 7.66849614761887e-003;

            __statist_i_h_wts[4, 34] = 2.03927657992047e-003;

            __statist_i_h_wts[4, 35] = -1.03351421903807e-002;

            __statist_i_h_wts[4, 36] = 7.34995435765379e-003;

            __statist_i_h_wts[4, 37] = -1.69110774761983e-002;

            __statist_i_h_wts[4, 38] = 1.85287212537824e-002;

            __statist_i_h_wts[4, 39] = 1.45874948816381e-002;

            __statist_i_h_wts[4, 40] = 1.19040622743575e-002;

            __statist_i_h_wts[4, 41] = -2.61116063342775e-003;

            __statist_i_h_wts[4, 42] = 1.42140922789258e-002;

            __statist_i_h_wts[4, 43] = 1.01857054123346e-001;

            __statist_i_h_wts[4, 44] = 5.70553375991820e-002;

            __statist_i_h_wts[4, 45] = -1.22543378395645e-001;

            __statist_i_h_wts[4, 46] = 2.69121964514678e-001;

            __statist_i_h_wts[4, 47] = 4.98332033998636e-002;

            __statist_i_h_wts[4, 48] = 1.02473235815567e+000;

            __statist_i_h_wts[4, 49] = -7.15253848136788e-001;

            __statist_i_h_wts[4, 50] = -1.40018751648616e-001;

            __statist_i_h_wts[4, 51] = 4.02596362367715e-002;

            __statist_i_h_wts[4, 52] = 1.58778758651670e-001;

            __statist_i_h_wts[4, 53] = -3.66312573342154e-002;

            __statist_i_h_wts[4, 54] = 1.34646378050885e-001;

            __statist_i_h_wts[4, 55] = 1.10293233034624e-001;

            __statist_i_h_wts[4, 56] = -4.67510483898610e-002;

            __statist_i_h_wts[4, 57] = 1.94274574112188e-001;

            __statist_i_h_wts[4, 58] = -1.24663817157633e-001;

            __statist_i_h_wts[4, 59] = 1.05446672443272e-001;

            __statist_i_h_wts[4, 60] = 3.26194049954444e-002;

            __statist_i_h_wts[4, 61] = 4.18402874994941e-002;

            __statist_i_h_wts[4, 62] = 7.23362442443102e-002;

            __statist_i_h_wts[4, 63] = 1.40954210705811e+000;

            __statist_i_h_wts[4, 64] = -9.68823324887803e-001;

            __statist_i_h_wts[4, 65] = -2.61321371084162e-001;

            __statist_i_h_wts[4, 66] = 2.02795912832073e-001;

            __statist_i_h_wts[4, 67] = 8.87349814989544e-002;

            __statist_i_h_wts[4, 68] = -1.09156489814869e-001;

            __statist_i_h_wts[4, 69] = 2.84105860056947e-001;

            __statist_i_h_wts[4, 70] = -2.10692857310659e-003;

            __statist_i_h_wts[4, 71] = -1.00865813462344e-001;

            __statist_i_h_wts[4, 72] = -1.28065287456798e+000;

            __statist_i_h_wts[4, 73] = 9.48758268499827e-001;

            __statist_i_h_wts[4, 74] = 4.87349397950224e-001;

            __statist_i_h_wts[4, 75] = -1.71986159042671e+000;

            __statist_i_h_wts[4, 76] = 1.06109618795361e+000;

            __statist_i_h_wts[4, 77] = 8.29698748221340e-001;

            __statist_i_h_wts[4, 78] = -1.00720525352073e+000;

            __statist_i_h_wts[4, 79] = 1.41618853545555e+000;

            __statist_i_h_wts[4, 80] = -2.28170866651127e-001;

            __statist_i_h_wts[4, 81] = -7.02661344886134e-001;

            __statist_i_h_wts[4, 82] = 1.07224061918863e+000;

            __statist_i_h_wts[4, 83] = -1.93119262854523e-001;

            __statist_i_h_wts[4, 84] = 2.40650921952481e-001;

            __statist_i_h_wts[4, 85] = -1.26144148829215e-001;

            __statist_i_h_wts[4, 86] = 4.69842571985525e-002;

            __statist_i_h_wts[4, 87] = 2.91228482518281e-002;

            __statist_i_h_wts[4, 88] = 7.28485963904306e-002;

            __statist_i_h_wts[4, 89] = 7.78081219582786e-002;

            __statist_i_h_wts[4, 90] = 1.44309004950183e+000;

            __statist_i_h_wts[4, 91] = -1.00819026578733e+000;

            __statist_i_h_wts[4, 92] = -2.44316177823077e-001;

            __statist_i_h_wts[4, 93] = 2.93742197576249e-001;

            __statist_i_h_wts[4, 94] = -1.09413200268511e-002;

            __statist_i_h_wts[4, 95] = -1.10323771384996e-001;

            __statist_i_h_wts[4, 96] = 3.59254847310850e-001;

            __statist_i_h_wts[4, 97] = -1.16207493320770e-001;

            __statist_i_h_wts[4, 98] = -8.99389260551138e-002;

            __statist_i_h_wts[4, 99] = 9.38963117740343e-002;

            __statist_i_h_wts[4, 100] = -1.13102912515126e-002;

            __statist_i_h_wts[4, 101] = 9.06329229010073e-002;

            __statist_i_h_wts[4, 102] = -9.50069142685547e-002;

            __statist_i_h_wts[4, 103] = 1.62768339004770e-001;

            __statist_i_h_wts[4, 104] = 1.12644392139753e-001;

            __statist_i_h_wts[4, 105] = 1.15692113222216e+000;

            __statist_i_h_wts[4, 106] = -8.24616734749017e-001;

            __statist_i_h_wts[4, 107] = -1.70059288446463e-001;

            __statist_i_h_wts[4, 108] = 1.56274176192465e-001;

            __statist_i_h_wts[4, 109] = 5.32730180242358e-002;

            __statist_i_h_wts[4, 110] = -3.07608387804057e-002;

            __statist_i_h_wts[4, 111] = 2.85738494452413e-001;

            __statist_i_h_wts[4, 112] = -6.82948524620520e-002;

            __statist_i_h_wts[4, 113] = -4.36307758272678e-002;



            __statist_i_h_wts[5, 0] = -7.20520319996605e-003;

            __statist_i_h_wts[5, 1] = -1.87932472931394e-002;

            __statist_i_h_wts[5, 2] = 1.07503539107656e-002;

            __statist_i_h_wts[5, 3] = -3.40375837456522e-003;

            __statist_i_h_wts[5, 4] = 1.03343200867661e-002;

            __statist_i_h_wts[5, 5] = -3.91610734538814e-002;

            __statist_i_h_wts[5, 6] = -4.86675860799891e-003;

            __statist_i_h_wts[5, 7] = 1.75780635286086e-002;

            __statist_i_h_wts[5, 8] = 1.92079452786266e-002;

            __statist_i_h_wts[5, 9] = -1.98077763477946e-003;

            __statist_i_h_wts[5, 10] = -1.25996969260353e-002;

            __statist_i_h_wts[5, 11] = 4.06283144117070e-002;

            __statist_i_h_wts[5, 12] = 7.01575751167724e-003;

            __statist_i_h_wts[5, 13] = 2.75114487443719e-003;

            __statist_i_h_wts[5, 14] = -5.52405429554064e-004;

            __statist_i_h_wts[5, 15] = 1.80834798033169e-002;

            __statist_i_h_wts[5, 16] = 3.48470845023159e-003;

            __statist_i_h_wts[5, 17] = -2.45864297059792e-002;

            __statist_i_h_wts[5, 18] = -4.25880553812679e-002;

            __statist_i_h_wts[5, 19] = -4.53461406969285e-002;

            __statist_i_h_wts[5, 20] = 1.51184616192834e-002;

            __statist_i_h_wts[5, 21] = 1.61388442798333e-002;

            __statist_i_h_wts[5, 22] = 1.93555916148251e-002;

            __statist_i_h_wts[5, 23] = -8.88974439910943e-003;

            __statist_i_h_wts[5, 24] = -2.36190827645693e-002;

            __statist_i_h_wts[5, 25] = -2.26097648745365e-002;

            __statist_i_h_wts[5, 26] = 3.06571312076565e-002;

            __statist_i_h_wts[5, 27] = 1.15128554654727e-003;

            __statist_i_h_wts[5, 28] = 5.46303788037912e-003;

            __statist_i_h_wts[5, 29] = 1.90265021866648e-002;

            __statist_i_h_wts[5, 30] = 1.75194330178326e-002;

            __statist_i_h_wts[5, 31] = -7.95598746437959e-004;

            __statist_i_h_wts[5, 32] = 2.44836129675520e-003;

            __statist_i_h_wts[5, 33] = 2.73460228782451e-002;

            __statist_i_h_wts[5, 34] = -2.60565862597727e-004;

            __statist_i_h_wts[5, 35] = -3.33911998107378e-003;

            __statist_i_h_wts[5, 36] = 2.84283566442022e-003;

            __statist_i_h_wts[5, 37] = 2.75307506245212e-002;

            __statist_i_h_wts[5, 38] = -2.76690290904628e-002;

            __statist_i_h_wts[5, 39] = 4.62016843132573e-003;

            __statist_i_h_wts[5, 40] = -2.31427782686883e-002;

            __statist_i_h_wts[5, 41] = -5.41141159590667e-003;

            __statist_i_h_wts[5, 42] = 9.27537269760436e-002;

            __statist_i_h_wts[5, 43] = -9.77862274699982e-002;

            __statist_i_h_wts[5, 44] = -5.88590016778887e-002;

            __statist_i_h_wts[5, 45] = 2.80871027329185e-001;

            __statist_i_h_wts[5, 46] = -3.05875761962831e-001;

            __statist_i_h_wts[5, 47] = -2.80192334544503e-002;

            __statist_i_h_wts[5, 48] = -1.24744468473656e+000;

            __statist_i_h_wts[5, 49] = 1.00274249841899e+000;

            __statist_i_h_wts[5, 50] = 1.71742968183293e-001;

            __statist_i_h_wts[5, 51] = 2.68076279391513e-002;

            __statist_i_h_wts[5, 52] = -1.75313936303961e-001;

            __statist_i_h_wts[5, 53] = 5.72362752226434e-002;

            __statist_i_h_wts[5, 54] = -1.17130803105701e-001;

            __statist_i_h_wts[5, 55] = -6.35502276233823e-002;

            __statist_i_h_wts[5, 56] = 5.39739642885136e-002;

            __statist_i_h_wts[5, 57] = -1.65844127896357e-001;

            __statist_i_h_wts[5, 58] = 1.66442106979236e-001;

            __statist_i_h_wts[5, 59] = -1.12977044506318e-001;

            __statist_i_h_wts[5, 60] = 3.02222818109945e-002;

            __statist_i_h_wts[5, 61] = -2.95691272718372e-002;

            __statist_i_h_wts[5, 62] = -9.65633098499910e-002;

            __statist_i_h_wts[5, 63] = -1.67540771727146e+000;

            __statist_i_h_wts[5, 64] = 1.31182352864790e+000;

            __statist_i_h_wts[5, 65] = 2.97849849539312e-001;

            __statist_i_h_wts[5, 66] = -1.83143986418260e-001;

            __statist_i_h_wts[5, 67] = -3.62837354480639e-002;

            __statist_i_h_wts[5, 68] = 1.10935805246057e-001;

            __statist_i_h_wts[5, 69] = -2.39775018606394e-001;

            __statist_i_h_wts[5, 70] = 3.17728314530295e-002;

            __statist_i_h_wts[5, 71] = 1.17677286006539e-001;

            __statist_i_h_wts[5, 72] = 1.54672814819930e+000;

            __statist_i_h_wts[5, 73] = -1.08536891694327e+000;

            __statist_i_h_wts[5, 74] = -5.24213986694858e-001;

            __statist_i_h_wts[5, 75] = 2.00037669969115e+000;

            __statist_i_h_wts[5, 76] = -1.20114771930885e+000;

            __statist_i_h_wts[5, 77] = -8.97460080629874e-001;

            __statist_i_h_wts[5, 78] = 1.29457601749784e+000;

            __statist_i_h_wts[5, 79] = -1.61600574525119e+000;

            __statist_i_h_wts[5, 80] = 2.59191378748586e-001;

            __statist_i_h_wts[5, 81] = 9.45868130146826e-001;

            __statist_i_h_wts[5, 82] = -1.23361936705864e+000;

            __statist_i_h_wts[5, 83] = 2.10649958069836e-001;

            __statist_i_h_wts[5, 84] = -1.82320270852961e-001;

            __statist_i_h_wts[5, 85] = 1.58127176322971e-001;

            __statist_i_h_wts[5, 86] = -6.55342646807955e-002;

            __statist_i_h_wts[5, 87] = 7.36555111042311e-002;

            __statist_i_h_wts[5, 88] = -7.97637458865437e-002;

            __statist_i_h_wts[5, 89] = -1.03197644710878e-001;

            __statist_i_h_wts[5, 90] = -1.74549805041398e+000;

            __statist_i_h_wts[5, 91] = 1.38224396051381e+000;

            __statist_i_h_wts[5, 92] = 2.70390424831244e-001;

            __statist_i_h_wts[5, 93] = -2.19865031557364e-001;

            __statist_i_h_wts[5, 94] = 2.94571668046396e-002;

            __statist_i_h_wts[5, 95] = 1.27863935111089e-001;

            __statist_i_h_wts[5, 96] = -3.94701492696659e-001;

            __statist_i_h_wts[5, 97] = 2.19226609690783e-001;

            __statist_i_h_wts[5, 98] = 8.18034831029825e-002;

            __statist_i_h_wts[5, 99] = -3.53971748184401e-002;

            __statist_i_h_wts[5, 100] = 2.47873659480331e-002;

            __statist_i_h_wts[5, 101] = -1.01185173574323e-001;

            __statist_i_h_wts[5, 102] = 1.86887403162765e-001;

            __statist_i_h_wts[5, 103] = -1.75438358575317e-001;

            __statist_i_h_wts[5, 104] = -1.08367336673454e-001;

            __statist_i_h_wts[5, 105] = -1.39858971060440e+000;

            __statist_i_h_wts[5, 106] = 1.14512864423326e+000;

            __statist_i_h_wts[5, 107] = 1.72914148166983e-001;

            __statist_i_h_wts[5, 108] = -8.46736859296158e-002;

            __statist_i_h_wts[5, 109] = -2.71322397665860e-002;

            __statist_i_h_wts[5, 110] = 5.02117947470417e-002;

            __statist_i_h_wts[5, 111] = -2.91710563027958e-001;

            __statist_i_h_wts[5, 112] = 1.27126143545741e-001;

            __statist_i_h_wts[5, 113] = 3.93370679252306e-002;



            __statist_i_h_wts[6, 0] = 2.97109358075526e-002;

            __statist_i_h_wts[6, 1] = 1.35084877340623e-002;

            __statist_i_h_wts[6, 2] = -1.15004914854510e-002;

            __statist_i_h_wts[6, 3] = 4.38443646122384e-002;

            __statist_i_h_wts[6, 4] = 2.37379412392549e-002;

            __statist_i_h_wts[6, 5] = 6.28421690918338e-003;

            __statist_i_h_wts[6, 6] = 2.29046367805684e-002;

            __statist_i_h_wts[6, 7] = -2.23555328765939e-002;

            __statist_i_h_wts[6, 8] = -6.45982373137135e-003;

            __statist_i_h_wts[6, 9] = 1.75176830357876e-003;

            __statist_i_h_wts[6, 10] = 4.68293741853668e-002;

            __statist_i_h_wts[6, 11] = -1.91220474174422e-002;

            __statist_i_h_wts[6, 12] = -2.30821736111297e-002;

            __statist_i_h_wts[6, 13] = 3.59225435369334e-003;

            __statist_i_h_wts[6, 14] = -3.40121526961931e-002;

            __statist_i_h_wts[6, 15] = 8.38743857630371e-003;

            __statist_i_h_wts[6, 16] = 1.83137626189787e-003;

            __statist_i_h_wts[6, 17] = 1.06764993293204e-002;

            __statist_i_h_wts[6, 18] = -1.51490669166513e-002;

            __statist_i_h_wts[6, 19] = 4.53175215584867e-002;

            __statist_i_h_wts[6, 20] = -1.41411702765921e-002;

            __statist_i_h_wts[6, 21] = -4.86191103095266e-003;

            __statist_i_h_wts[6, 22] = 7.92623861822128e-005;

            __statist_i_h_wts[6, 23] = 2.18392692287943e-003;

            __statist_i_h_wts[6, 24] = 7.58246945795316e-003;

            __statist_i_h_wts[6, 25] = 1.94062593598546e-003;

            __statist_i_h_wts[6, 26] = 8.92444156390188e-003;

            __statist_i_h_wts[6, 27] = -3.60977204597265e-003;

            __statist_i_h_wts[6, 28] = -5.38939269417390e-003;

            __statist_i_h_wts[6, 29] = -3.37803732916982e-003;

            __statist_i_h_wts[6, 30] = 1.82221084294700e-002;

            __statist_i_h_wts[6, 31] = 4.61420318578355e-003;

            __statist_i_h_wts[6, 32] = -1.50843191418483e-002;

            __statist_i_h_wts[6, 33] = -2.93454088339974e-002;

            __statist_i_h_wts[6, 34] = 2.73156025968232e-002;

            __statist_i_h_wts[6, 35] = -1.38237491565385e-002;

            __statist_i_h_wts[6, 36] = -1.67377808811454e-003;

            __statist_i_h_wts[6, 37] = 7.84784043940107e-003;

            __statist_i_h_wts[6, 38] = 2.47156600170661e-002;

            __statist_i_h_wts[6, 39] = 1.06873484446369e-002;

            __statist_i_h_wts[6, 40] = 1.27024562217001e-002;

            __statist_i_h_wts[6, 41] = -4.39321712899737e-003;

            __statist_i_h_wts[6, 42] = 1.57561752348045e-002;

            __statist_i_h_wts[6, 43] = 7.93745478529077e-002;

            __statist_i_h_wts[6, 44] = 3.09474197807681e-002;

            __statist_i_h_wts[6, 45] = -4.87666898269850e-002;

            __statist_i_h_wts[6, 46] = 1.81939371632272e-001;

            __statist_i_h_wts[6, 47] = 3.49242821841407e-002;

            __statist_i_h_wts[6, 48] = 4.28698052192685e-001;

            __statist_i_h_wts[6, 49] = -1.76308077161788e-001;

            __statist_i_h_wts[6, 50] = -9.89427586379340e-002;

            __statist_i_h_wts[6, 51] = 1.08739270965257e-001;

            __statist_i_h_wts[6, 52] = 7.70376104432937e-002;

            __statist_i_h_wts[6, 53] = -3.21724033698647e-002;

            __statist_i_h_wts[6, 54] = 1.23373836134715e-001;

            __statist_i_h_wts[6, 55] = 5.41313640127021e-002;

            __statist_i_h_wts[6, 56] = -1.88679876030760e-002;

            __statist_i_h_wts[6, 57] = 1.09771971164367e-001;

            __statist_i_h_wts[6, 58] = -2.03316201497775e-002;

            __statist_i_h_wts[6, 59] = 4.01687409934872e-002;

            __statist_i_h_wts[6, 60] = 1.17471462579263e-002;

            __statist_i_h_wts[6, 61] = 7.40022918433198e-002;

            __statist_i_h_wts[6, 62] = 7.44302322349898e-002;

            __statist_i_h_wts[6, 63] = 6.20013650296887e-001;

            __statist_i_h_wts[6, 64] = -2.80986398562141e-001;

            __statist_i_h_wts[6, 65] = -1.49394812025025e-001;

            __statist_i_h_wts[6, 66] = 1.49170281313914e-001;

            __statist_i_h_wts[6, 67] = 8.13486180656592e-002;

            __statist_i_h_wts[6, 68] = -8.28397543923454e-002;

            __statist_i_h_wts[6, 69] = 1.89325775249950e-001;

            __statist_i_h_wts[6, 70] = 5.89241730992800e-002;

            __statist_i_h_wts[6, 71] = -8.48639634940437e-002;

            __statist_i_h_wts[6, 72] = -6.41017486002023e-001;

            __statist_i_h_wts[6, 73] = 4.60016244835849e-001;

            __statist_i_h_wts[6, 74] = 3.36330259491498e-001;

            __statist_i_h_wts[6, 75] = -9.93940023127382e-001;

            __statist_i_h_wts[6, 76] = 4.99211957768519e-001;

            __statist_i_h_wts[6, 77] = 6.44752734026041e-001;

            __statist_i_h_wts[6, 78] = -3.68413069832322e-001;

            __statist_i_h_wts[6, 79] = 7.16344742335301e-001;

            __statist_i_h_wts[6, 80] = -1.87710386621899e-001;

            __statist_i_h_wts[6, 81] = -1.58006360596456e-001;

            __statist_i_h_wts[6, 82] = 4.36689519373609e-001;

            __statist_i_h_wts[6, 83] = -1.32380229475652e-001;

            __statist_i_h_wts[6, 84] = 1.43660695109416e-001;

            __statist_i_h_wts[6, 85] = -3.28623616046511e-003;

            __statist_i_h_wts[6, 86] = 2.42890328293484e-002;

            __statist_i_h_wts[6, 87] = 1.75725201337783e-002;

            __statist_i_h_wts[6, 88] = 6.85323325942031e-002;

            __statist_i_h_wts[6, 89] = 7.94152011823504e-002;

            __statist_i_h_wts[6, 90] = 6.31954048664751e-001;

            __statist_i_h_wts[6, 91] = -3.03700474720762e-001;

            __statist_i_h_wts[6, 92] = -1.59670038623408e-001;

            __statist_i_h_wts[6, 93] = 2.12517280674076e-001;

            __statist_i_h_wts[6, 94] = 2.74925998160373e-002;

            __statist_i_h_wts[6, 95] = -8.12618815168940e-002;

            __statist_i_h_wts[6, 96] = 2.41657827464516e-001;

            __statist_i_h_wts[6, 97] = -8.07411656502260e-003;

            __statist_i_h_wts[6, 98] = -5.65035084312927e-002;

            __statist_i_h_wts[6, 99] = 8.30056081049035e-002;

            __statist_i_h_wts[6, 100] = 4.09859615702440e-003;

            __statist_i_h_wts[6, 101] = 4.84982541917778e-002;

            __statist_i_h_wts[6, 102] = -4.62801446839676e-002;

            __statist_i_h_wts[6, 103] = 1.27384072993087e-001;

            __statist_i_h_wts[6, 104] = 6.91695299223751e-002;

            __statist_i_h_wts[6, 105] = 4.51670218429148e-001;

            __statist_i_h_wts[6, 106] = -2.21616087642121e-001;

            __statist_i_h_wts[6, 107] = -9.39219993216247e-002;

            __statist_i_h_wts[6, 108] = 1.27184539854625e-001;

            __statist_i_h_wts[6, 109] = 7.15696126717957e-002;

            __statist_i_h_wts[6, 110] = -2.05342685978366e-002;

            __statist_i_h_wts[6, 111] = 2.26998130269705e-001;

            __statist_i_h_wts[6, 112] = -1.37316622736816e-002;

            __statist_i_h_wts[6, 113] = -4.00819072855239e-002;



            __statist_i_h_wts[7, 0] = -1.60602580218155e-002;

            __statist_i_h_wts[7, 1] = -2.19164257586006e-002;

            __statist_i_h_wts[7, 2] = -1.97565423192413e-002;

            __statist_i_h_wts[7, 3] = -4.06239525588900e-003;

            __statist_i_h_wts[7, 4] = 3.03447611881696e-004;

            __statist_i_h_wts[7, 5] = -1.55534260854973e-003;

            __statist_i_h_wts[7, 6] = -3.79282096226398e-003;

            __statist_i_h_wts[7, 7] = 6.62900980543326e-004;

            __statist_i_h_wts[7, 8] = 1.89042530180284e-002;

            __statist_i_h_wts[7, 9] = 6.23014743921278e-003;

            __statist_i_h_wts[7, 10] = -2.41718616977012e-002;

            __statist_i_h_wts[7, 11] = 9.14759105020253e-003;

            __statist_i_h_wts[7, 12] = 8.72393082121200e-003;

            __statist_i_h_wts[7, 13] = -4.39821163047394e-003;

            __statist_i_h_wts[7, 14] = 5.10019279855031e-003;

            __statist_i_h_wts[7, 15] = 4.79063426108556e-003;

            __statist_i_h_wts[7, 16] = 1.10687872030908e-002;

            __statist_i_h_wts[7, 17] = -4.85925875067904e-003;

            __statist_i_h_wts[7, 18] = 5.95867126590101e-003;

            __statist_i_h_wts[7, 19] = -4.54005700675156e-003;

            __statist_i_h_wts[7, 20] = -1.16927781132908e-002;

            __statist_i_h_wts[7, 21] = 4.90337458547201e-003;

            __statist_i_h_wts[7, 22] = 1.10087190549707e-003;

            __statist_i_h_wts[7, 23] = -7.30397560292086e-003;

            __statist_i_h_wts[7, 24] = -8.16913528791598e-003;

            __statist_i_h_wts[7, 25] = -9.77207715513945e-003;

            __statist_i_h_wts[7, 26] = -1.60688200937093e-002;

            __statist_i_h_wts[7, 27] = -3.98296467285763e-003;

            __statist_i_h_wts[7, 28] = -7.26581795960870e-003;

            __statist_i_h_wts[7, 29] = 6.69984725577298e-003;

            __statist_i_h_wts[7, 30] = 3.51309610619947e-003;

            __statist_i_h_wts[7, 31] = -9.83939097915799e-003;

            __statist_i_h_wts[7, 32] = 5.19017614489332e-003;

            __statist_i_h_wts[7, 33] = 7.21496313615745e-003;

            __statist_i_h_wts[7, 34] = 5.84385400706447e-003;

            __statist_i_h_wts[7, 35] = -1.96913431798739e-003;

            __statist_i_h_wts[7, 36] = 1.59393916183477e-002;

            __statist_i_h_wts[7, 37] = 4.67317585342299e-003;

            __statist_i_h_wts[7, 38] = -2.92100743989909e-003;

            __statist_i_h_wts[7, 39] = 2.42390634079511e-003;

            __statist_i_h_wts[7, 40] = -1.60964863934615e-002;

            __statist_i_h_wts[7, 41] = -1.64043493855659e-002;

            __statist_i_h_wts[7, 42] = 1.40872954038822e-003;

            __statist_i_h_wts[7, 43] = -1.53358695994361e-002;

            __statist_i_h_wts[7, 44] = 5.61660421134686e-003;

            __statist_i_h_wts[7, 45] = 3.01167511021140e-002;

            __statist_i_h_wts[7, 46] = -5.60121163896530e-002;

            __statist_i_h_wts[7, 47] = -8.59634385079208e-003;

            __statist_i_h_wts[7, 48] = -1.84888216684813e-001;

            __statist_i_h_wts[7, 49] = 1.14127742109112e-001;

            __statist_i_h_wts[7, 50] = 4.46327825749841e-004;

            __statist_i_h_wts[7, 51] = -2.30699227111887e-003;

            __statist_i_h_wts[7, 52] = -2.81741452327383e-002;

            __statist_i_h_wts[7, 53] = 3.79951078464227e-003;

            __statist_i_h_wts[7, 54] = -2.44912896791327e-002;

            __statist_i_h_wts[7, 55] = -3.26610414842183e-002;

            __statist_i_h_wts[7, 56] = 5.95153282285603e-003;

            __statist_i_h_wts[7, 57] = -3.06773467469275e-002;

            __statist_i_h_wts[7, 58] = -4.18383516416398e-003;

            __statist_i_h_wts[7, 59] = -2.76040005412919e-003;

            __statist_i_h_wts[7, 60] = -5.68475416363692e-003;

            __statist_i_h_wts[7, 61] = -2.12714530566027e-002;

            __statist_i_h_wts[7, 62] = -5.38251227399894e-003;

            __statist_i_h_wts[7, 63] = -2.11715791799461e-001;

            __statist_i_h_wts[7, 64] = 1.70211822771398e-001;

            __statist_i_h_wts[7, 65] = 2.95245339261729e-002;

            __statist_i_h_wts[7, 66] = -2.09978784796482e-002;

            __statist_i_h_wts[7, 67] = -1.60025855303819e-002;

            __statist_i_h_wts[7, 68] = 1.80735659077885e-002;

            __statist_i_h_wts[7, 69] = -5.16955288384134e-002;

            __statist_i_h_wts[7, 70] = 2.97883465274414e-003;

            __statist_i_h_wts[7, 71] = -1.23538061300444e-002;

            __statist_i_h_wts[7, 72] = 1.79263308777245e-001;

            __statist_i_h_wts[7, 73] = -1.66322873273011e-001;

            __statist_i_h_wts[7, 74] = -7.93548784365642e-002;

            __statist_i_h_wts[7, 75] = 2.65025179376810e-001;

            __statist_i_h_wts[7, 76] = -1.82104250888784e-001;

            __statist_i_h_wts[7, 77] = -1.20890586485799e-001;

            __statist_i_h_wts[7, 78] = 1.59989095513928e-001;

            __statist_i_h_wts[7, 79] = -2.40721887964256e-001;

            __statist_i_h_wts[7, 80] = 3.21113721721320e-002;

            __statist_i_h_wts[7, 81] = 1.16639971422461e-001;

            __statist_i_h_wts[7, 82] = -1.65420792217891e-001;

            __statist_i_h_wts[7, 83] = 1.72125388919399e-002;

            __statist_i_h_wts[7, 84] = -3.87783961235905e-002;

            __statist_i_h_wts[7, 85] = 1.59019209177067e-002;

            __statist_i_h_wts[7, 86] = -1.97565138638525e-003;

            __statist_i_h_wts[7, 87] = 4.51526885905072e-003;

            __statist_i_h_wts[7, 88] = -2.69012245317346e-002;

            __statist_i_h_wts[7, 89] = -6.16954218967419e-003;

            __statist_i_h_wts[7, 90] = -2.31811259730625e-001;

            __statist_i_h_wts[7, 91] = 1.46158373329227e-001;

            __statist_i_h_wts[7, 92] = 3.12625125831193e-002;

            __statist_i_h_wts[7, 93] = -4.63271481730342e-002;

            __statist_i_h_wts[7, 94] = -8.74726953965450e-003;

            __statist_i_h_wts[7, 95] = 3.29212242658187e-002;

            __statist_i_h_wts[7, 96] = -6.56388165439644e-002;

            __statist_i_h_wts[7, 97] = 2.15241956938475e-002;

            __statist_i_h_wts[7, 98] = -7.79844643560249e-004;

            __statist_i_h_wts[7, 99] = -1.34532403289233e-003;

            __statist_i_h_wts[7, 100] = -1.54847066038950e-002;

            __statist_i_h_wts[7, 101] = -3.26240576182117e-003;

            __statist_i_h_wts[7, 102] = 1.20105704142121e-002;

            __statist_i_h_wts[7, 103] = -3.22816091352011e-002;

            __statist_i_h_wts[7, 104] = -1.67736094255935e-002;

            __statist_i_h_wts[7, 105] = -1.93312149037564e-001;

            __statist_i_h_wts[7, 106] = 1.18598753492325e-001;

            __statist_i_h_wts[7, 107] = 3.14059180674364e-002;

            __statist_i_h_wts[7, 108] = -2.76495206621564e-002;

            __statist_i_h_wts[7, 109] = -6.75873571352120e-003;

            __statist_i_h_wts[7, 110] = 1.43980570702426e-002;

            __statist_i_h_wts[7, 111] = -4.33348230394659e-002;

            __statist_i_h_wts[7, 112] = -8.16231585100979e-004;

            __statist_i_h_wts[7, 113] = 1.00411900216275e-002;



            __statist_i_h_wts[8, 0] = 1.54517230773583e-002;

            __statist_i_h_wts[8, 1] = -6.30532761611619e-003;

            __statist_i_h_wts[8, 2] = -9.45739472318326e-003;

            __statist_i_h_wts[8, 3] = 6.71261299512833e-003;

            __statist_i_h_wts[8, 4] = 3.31489841006140e-003;

            __statist_i_h_wts[8, 5] = 1.50400972209213e-002;

            __statist_i_h_wts[8, 6] = 5.34594329577430e-003;

            __statist_i_h_wts[8, 7] = -5.47022917767119e-003;

            __statist_i_h_wts[8, 8] = -1.26705964087585e-002;

            __statist_i_h_wts[8, 9] = -1.17690857917386e-002;

            __statist_i_h_wts[8, 10] = 1.61192513129052e-002;

            __statist_i_h_wts[8, 11] = -1.62629104669427e-002;

            __statist_i_h_wts[8, 12] = -8.76584361470644e-003;

            __statist_i_h_wts[8, 13] = 4.66163132077095e-003;

            __statist_i_h_wts[8, 14] = -3.35509043687628e-004;

            __statist_i_h_wts[8, 15] = -2.07686127730999e-002;

            __statist_i_h_wts[8, 16] = 5.83105219799786e-004;

            __statist_i_h_wts[8, 17] = 8.48240664452656e-003;

            __statist_i_h_wts[8, 18] = 1.27329651378849e-002;

            __statist_i_h_wts[8, 19] = 2.09579238748795e-002;

            __statist_i_h_wts[8, 20] = -1.83394871093825e-003;

            __statist_i_h_wts[8, 21] = -2.00093837318357e-002;

            __statist_i_h_wts[8, 22] = -9.79427098778903e-003;

            __statist_i_h_wts[8, 23] = -4.19596408116861e-003;

            __statist_i_h_wts[8, 24] = 8.83651115200602e-003;

            __statist_i_h_wts[8, 25] = -7.98813402097971e-004;

            __statist_i_h_wts[8, 26] = -5.71301206978878e-004;

            __statist_i_h_wts[8, 27] = -1.44723663389860e-002;

            __statist_i_h_wts[8, 28] = -6.32168763833172e-003;

            __statist_i_h_wts[8, 29] = -6.12105391310094e-003;

            __statist_i_h_wts[8, 30] = 2.05515740479384e-002;

            __statist_i_h_wts[8, 31] = 5.93235808758886e-003;

            __statist_i_h_wts[8, 32] = 4.12838553962407e-003;

            __statist_i_h_wts[8, 33] = -3.03151186242765e-003;

            __statist_i_h_wts[8, 34] = 9.43761561446058e-003;

            __statist_i_h_wts[8, 35] = 1.91016663407748e-002;

            __statist_i_h_wts[8, 36] = -4.66673163952068e-003;

            __statist_i_h_wts[8, 37] = 2.16211004378782e-002;

            __statist_i_h_wts[8, 38] = 3.40893383499228e-003;

            __statist_i_h_wts[8, 39] = 1.54024237666045e-002;

            __statist_i_h_wts[8, 40] = 7.71515356800991e-003;

            __statist_i_h_wts[8, 41] = -5.45312328057124e-004;

            __statist_i_h_wts[8, 42] = 7.56916467857909e-003;

            __statist_i_h_wts[8, 43] = 3.75905054326350e-002;

            __statist_i_h_wts[8, 44] = 2.24379227633080e-002;

            __statist_i_h_wts[8, 45] = -5.35655462813987e-002;

            __statist_i_h_wts[8, 46] = 1.12877655732014e-001;

            __statist_i_h_wts[8, 47] = -1.17108555680112e-003;

            __statist_i_h_wts[8, 48] = 3.00105369417027e-001;

            __statist_i_h_wts[8, 49] = -2.15721566315655e-001;

            __statist_i_h_wts[8, 50] = -6.56298271715248e-002;

            __statist_i_h_wts[8, 51] = 1.81601881409349e-002;

            __statist_i_h_wts[8, 52] = 5.29383687211601e-002;

            __statist_i_h_wts[8, 53] = -9.37347018699721e-003;

            __statist_i_h_wts[8, 54] = 3.55528185176682e-002;

            __statist_i_h_wts[8, 55] = 3.07630928699859e-002;

            __statist_i_h_wts[8, 56] = -2.52312550062583e-002;

            __statist_i_h_wts[8, 57] = 5.08008107313905e-002;

            __statist_i_h_wts[8, 58] = -3.53371089686673e-002;

            __statist_i_h_wts[8, 59] = 2.03350973270569e-002;

            __statist_i_h_wts[8, 60] = 4.63978835383222e-003;

            __statist_i_h_wts[8, 61] = 3.12816902003774e-002;

            __statist_i_h_wts[8, 62] = 3.97465801749969e-002;

            __statist_i_h_wts[8, 63] = 4.60248894791762e-001;

            __statist_i_h_wts[8, 64] = -2.75793320139036e-001;

            __statist_i_h_wts[8, 65] = -6.86843933345814e-002;

            __statist_i_h_wts[8, 66] = 7.00794439375093e-002;

            __statist_i_h_wts[8, 67] = 3.73562396409519e-002;

            __statist_i_h_wts[8, 68] = -3.86404540612425e-002;

            __statist_i_h_wts[8, 69] = 9.05237039724187e-002;

            __statist_i_h_wts[8, 70] = 1.95109697920801e-002;

            __statist_i_h_wts[8, 71] = -4.80788620480845e-002;

            __statist_i_h_wts[8, 72] = -4.10910011649705e-001;

            __statist_i_h_wts[8, 73] = 2.91164889708268e-001;

            __statist_i_h_wts[8, 74] = 1.73438802038743e-001;

            __statist_i_h_wts[8, 75] = -5.51863839052763e-001;

            __statist_i_h_wts[8, 76] = 3.41961151968624e-001;

            __statist_i_h_wts[8, 77] = 2.77651655632249e-001;

            __statist_i_h_wts[8, 78] = -3.29464154283254e-001;

            __statist_i_h_wts[8, 79] = 4.76150218371167e-001;

            __statist_i_h_wts[8, 80] = -7.94773977770653e-002;

            __statist_i_h_wts[8, 81] = -2.29222312216738e-001;

            __statist_i_h_wts[8, 82] = 3.43351835502813e-001;

            __statist_i_h_wts[8, 83] = -5.62736357338006e-002;

            __statist_i_h_wts[8, 84] = 8.31241953417937e-002;

            __statist_i_h_wts[8, 85] = -3.14807974868507e-002;

            __statist_i_h_wts[8, 86] = 1.96465487686818e-002;

            __statist_i_h_wts[8, 87] = -1.13163884667858e-002;

            __statist_i_h_wts[8, 88] = 5.00957383785130e-002;

            __statist_i_h_wts[8, 89] = 1.65923962258351e-002;

            __statist_i_h_wts[8, 90] = 4.54412600445223e-001;

            __statist_i_h_wts[8, 91] = -2.98140049101290e-001;

            __statist_i_h_wts[8, 92] = -9.74395829238546e-002;

            __statist_i_h_wts[8, 93] = 7.75704713660451e-002;

            __statist_i_h_wts[8, 94] = 1.77886230275241e-002;

            __statist_i_h_wts[8, 95] = -2.43288884639915e-002;

            __statist_i_h_wts[8, 96] = 1.20666666186641e-001;

            __statist_i_h_wts[8, 97] = -4.70505533691323e-002;

            __statist_i_h_wts[8, 98] = -3.54253777063308e-002;

            __statist_i_h_wts[8, 99] = 2.29870901430107e-002;

            __statist_i_h_wts[8, 100] = 1.66041718941813e-002;

            __statist_i_h_wts[8, 101] = 3.56589413837807e-002;

            __statist_i_h_wts[8, 102] = -3.51633033278280e-002;

            __statist_i_h_wts[8, 103] = 6.39716805072827e-002;

            __statist_i_h_wts[8, 104] = 2.03300436783554e-002;

            __statist_i_h_wts[8, 105] = 3.47725312350694e-001;

            __statist_i_h_wts[8, 106] = -2.48752578453829e-001;

            __statist_i_h_wts[8, 107] = -5.29000119356775e-002;

            __statist_i_h_wts[8, 108] = 3.39404205745745e-002;

            __statist_i_h_wts[8, 109] = 1.99353676177490e-002;

            __statist_i_h_wts[8, 110] = -3.62929927698833e-003;

            __statist_i_h_wts[8, 111] = 8.14276360837882e-002;

            __statist_i_h_wts[8, 112] = -8.17653030301701e-003;

            __statist_i_h_wts[8, 113] = -9.26532671833878e-003;



            __statist_i_h_wts[9, 0] = 6.05808609080637e-002;

            __statist_i_h_wts[9, 1] = 4.37571556191801e-002;

            __statist_i_h_wts[9, 2] = -1.10492324704814e-002;

            __statist_i_h_wts[9, 3] = 2.76771380752115e-002;

            __statist_i_h_wts[9, 4] = -5.52462067830260e-002;

            __statist_i_h_wts[9, 5] = -1.79677661067505e-002;

            __statist_i_h_wts[9, 6] = 8.83077301078966e-003;

            __statist_i_h_wts[9, 7] = -3.73868042999450e-002;

            __statist_i_h_wts[9, 8] = -2.05633372347298e-002;

            __statist_i_h_wts[9, 9] = -6.48718218488046e-002;

            __statist_i_h_wts[9, 10] = 3.81644345583888e-003;

            __statist_i_h_wts[9, 11] = -9.11911299680802e-002;

            __statist_i_h_wts[9, 12] = -2.25995985603120e-002;

            __statist_i_h_wts[9, 13] = -2.62923727557756e-002;

            __statist_i_h_wts[9, 14] = 7.10757717622860e-002;

            __statist_i_h_wts[9, 15] = 4.24448915855775e-003;

            __statist_i_h_wts[9, 16] = 3.39486900592419e-002;

            __statist_i_h_wts[9, 17] = 8.20381880915795e-002;

            __statist_i_h_wts[9, 18] = 4.69630807277013e-002;

            __statist_i_h_wts[9, 19] = 7.20232763746728e-002;

            __statist_i_h_wts[9, 20] = 6.04308168187052e-002;

            __statist_i_h_wts[9, 21] = -1.25913134559305e-002;

            __statist_i_h_wts[9, 22] = -3.02693298300466e-002;

            __statist_i_h_wts[9, 23] = 2.70428322848165e-002;

            __statist_i_h_wts[9, 24] = 1.62603362893956e-002;

            __statist_i_h_wts[9, 25] = -1.50849033686006e-002;

            __statist_i_h_wts[9, 26] = -6.87123608777415e-002;

            __statist_i_h_wts[9, 27] = -2.44489162635795e-002;

            __statist_i_h_wts[9, 28] = -3.78095492556193e-002;

            __statist_i_h_wts[9, 29] = 2.07573256889241e-002;

            __statist_i_h_wts[9, 30] = 3.63599046141673e-002;

            __statist_i_h_wts[9, 31] = 3.60134843370860e-002;

            __statist_i_h_wts[9, 32] = -3.72168324354541e-002;

            __statist_i_h_wts[9, 33] = -7.03340717949236e-002;

            __statist_i_h_wts[9, 34] = 2.59253068506509e-002;

            __statist_i_h_wts[9, 35] = -1.45181274435773e-002;

            __statist_i_h_wts[9, 36] = 1.87901924542599e-003;

            __statist_i_h_wts[9, 37] = 2.50191629020376e-002;

            __statist_i_h_wts[9, 38] = 2.66864900903795e-002;

            __statist_i_h_wts[9, 39] = -2.38794755434104e-002;

            __statist_i_h_wts[9, 40] = -4.87501454564726e-002;

            __statist_i_h_wts[9, 41] = -7.83015600814565e-002;

            __statist_i_h_wts[9, 42] = -8.59204593505139e-002;

            __statist_i_h_wts[9, 43] = -1.02167273180202e-001;

            __statist_i_h_wts[9, 44] = 9.02953927976904e-002;

            __statist_i_h_wts[9, 45] = -4.60806496012508e-002;

            __statist_i_h_wts[9, 46] = -6.30401183366916e-002;

            __statist_i_h_wts[9, 47] = 4.11494419269201e-002;

            __statist_i_h_wts[9, 48] = -1.85916702180160e-002;

            __statist_i_h_wts[9, 49] = 2.06027638764002e-002;

            __statist_i_h_wts[9, 50] = -1.19507720207397e-001;

            __statist_i_h_wts[9, 51] = -7.73820556178234e-003;

            __statist_i_h_wts[9, 52] = 8.36982849087802e-003;

            __statist_i_h_wts[9, 53] = -1.08064449045432e-001;

            __statist_i_h_wts[9, 54] = -1.35344167814404e-002;

            __statist_i_h_wts[9, 55] = 1.28994807036079e-002;

            __statist_i_h_wts[9, 56] = -1.20346255154364e-001;

            __statist_i_h_wts[9, 57] = -1.50925519937340e-001;

            __statist_i_h_wts[9, 58] = -1.24393796624575e-001;

            __statist_i_h_wts[9, 59] = 1.45495017795325e-001;

            __statist_i_h_wts[9, 60] = -1.26849249226344e-001;

            __statist_i_h_wts[9, 61] = -1.16952471425257e-001;

            __statist_i_h_wts[9, 62] = 1.40430885369450e-001;

            __statist_i_h_wts[9, 63] = 1.97915900886924e-001;

            __statist_i_h_wts[9, 64] = 1.12171390709670e-001;

            __statist_i_h_wts[9, 65] = -3.74403599584869e-001;

            __statist_i_h_wts[9, 66] = 9.49577860833552e-002;

            __statist_i_h_wts[9, 67] = 1.26464403473580e-001;

            __statist_i_h_wts[9, 68] = -3.32966081185059e-001;

            __statist_i_h_wts[9, 69] = 9.35219038310284e-002;

            __statist_i_h_wts[9, 70] = 9.54962821157896e-002;

            __statist_i_h_wts[9, 71] = -2.91414947456468e-001;

            __statist_i_h_wts[9, 72] = -1.47279682203518e-001;

            __statist_i_h_wts[9, 73] = -1.22056715437391e-001;

            __statist_i_h_wts[9, 74] = 1.76801658661666e-001;

            __statist_i_h_wts[9, 75] = -7.24547026982371e-001;

            __statist_i_h_wts[9, 76] = -1.42753482655008e-002;

            __statist_i_h_wts[9, 77] = 6.48640409498204e-001;

            __statist_i_h_wts[9, 78] = 2.41596058735108e-001;

            __statist_i_h_wts[9, 79] = 1.82833515866959e-001;

            __statist_i_h_wts[9, 80] = -5.02568276084830e-001;

            __statist_i_h_wts[9, 81] = 9.40780700216416e-002;

            __statist_i_h_wts[9, 82] = 1.19390570778902e-001;

            __statist_i_h_wts[9, 83] = -2.98383416585041e-001;

            __statist_i_h_wts[9, 84] = -1.26932608427754e-001;

            __statist_i_h_wts[9, 85] = -9.76987130904564e-002;

            __statist_i_h_wts[9, 86] = 8.50142175156452e-002;

            __statist_i_h_wts[9, 87] = -1.02583864295420e-001;

            __statist_i_h_wts[9, 88] = -9.88057577391468e-002;

            __statist_i_h_wts[9, 89] = 8.23292584155804e-002;

            __statist_i_h_wts[9, 90] = 1.63216730807200e-001;

            __statist_i_h_wts[9, 91] = 5.13267879947836e-002;

            __statist_i_h_wts[9, 92] = -3.32494472068670e-001;

            __statist_i_h_wts[9, 93] = 1.45712323831049e-001;

            __statist_i_h_wts[9, 94] = 4.88107237150528e-002;

            __statist_i_h_wts[9, 95] = -3.15624556254574e-001;

            __statist_i_h_wts[9, 96] = 2.96187728696615e-002;

            __statist_i_h_wts[9, 97] = 3.71486421386223e-002;

            __statist_i_h_wts[9, 98] = -2.01149296776897e-001;

            __statist_i_h_wts[9, 99] = -7.66070961752774e-002;

            __statist_i_h_wts[9, 100] = -7.40247935721543e-002;

            __statist_i_h_wts[9, 101] = 4.12125268340956e-002;

            __statist_i_h_wts[9, 102] = -6.36981875229045e-002;

            __statist_i_h_wts[9, 103] = -7.18642702929369e-002;

            __statist_i_h_wts[9, 104] = 2.18503085742935e-002;

            __statist_i_h_wts[9, 105] = -5.39051322829211e-002;

            __statist_i_h_wts[9, 106] = 3.93512859066335e-002;

            __statist_i_h_wts[9, 107] = -1.07479288610225e-001;

            __statist_i_h_wts[9, 108] = -4.94330889526416e-002;

            __statist_i_h_wts[9, 109] = 3.86031835470556e-002;

            __statist_i_h_wts[9, 110] = -1.12805947736988e-001;

            __statist_i_h_wts[9, 111] = -1.98635132620536e-002;

            __statist_i_h_wts[9, 112] = 3.55131320861717e-002;

            __statist_i_h_wts[9, 113] = -1.23673116178574e-001;



            __statist_i_h_wts[10, 0] = 4.99494014428580e-003;

            __statist_i_h_wts[10, 1] = -1.33341149166635e-002;

            __statist_i_h_wts[10, 2] = -7.86421706163211e-003;

            __statist_i_h_wts[10, 3] = -1.60860331489763e-002;

            __statist_i_h_wts[10, 4] = 6.34297159653606e-003;

            __statist_i_h_wts[10, 5] = 1.07900410898507e-002;

            __statist_i_h_wts[10, 6] = 1.74448426268904e-003;

            __statist_i_h_wts[10, 7] = 8.56628260928214e-003;

            __statist_i_h_wts[10, 8] = 4.75778987566414e-003;

            __statist_i_h_wts[10, 9] = 5.09485292159324e-004;

            __statist_i_h_wts[10, 10] = -3.07880895832938e-002;

            __statist_i_h_wts[10, 11] = -2.41422608269665e-003;

            __statist_i_h_wts[10, 12] = 3.50160557169918e-003;

            __statist_i_h_wts[10, 13] = 1.36582871678691e-002;

            __statist_i_h_wts[10, 14] = -6.25914204840461e-004;

            __statist_i_h_wts[10, 15] = 5.68495315677773e-003;

            __statist_i_h_wts[10, 16] = 3.42907236362076e-003;

            __statist_i_h_wts[10, 17] = 3.98653164790982e-003;

            __statist_i_h_wts[10, 18] = -2.05942156003139e-002;

            __statist_i_h_wts[10, 19] = -8.45879940226020e-003;

            __statist_i_h_wts[10, 20] = 2.71614674324051e-003;

            __statist_i_h_wts[10, 21] = -4.76142535148568e-003;

            __statist_i_h_wts[10, 22] = 9.08113661861343e-003;

            __statist_i_h_wts[10, 23] = 8.91946584593979e-004;

            __statist_i_h_wts[10, 24] = -2.16037397852106e-002;

            __statist_i_h_wts[10, 25] = 1.24805661378693e-002;

            __statist_i_h_wts[10, 26] = 1.57666469338804e-002;

            __statist_i_h_wts[10, 27] = -1.92815379583330e-002;

            __statist_i_h_wts[10, 28] = 1.64453596044279e-002;

            __statist_i_h_wts[10, 29] = -3.82685321831157e-003;

            __statist_i_h_wts[10, 30] = -1.85028647795463e-002;

            __statist_i_h_wts[10, 31] = -6.80233229467349e-003;

            __statist_i_h_wts[10, 32] = 1.31458722960162e-002;

            __statist_i_h_wts[10, 33] = 2.11045104768417e-002;

            __statist_i_h_wts[10, 34] = -2.38345176076651e-002;

            __statist_i_h_wts[10, 35] = -5.62166630234572e-003;

            __statist_i_h_wts[10, 36] = -1.06452778186696e-003;

            __statist_i_h_wts[10, 37] = 2.02779466318352e-002;

            __statist_i_h_wts[10, 38] = -1.50259664046855e-002;

            __statist_i_h_wts[10, 39] = 4.38634185813440e-004;

            __statist_i_h_wts[10, 40] = 4.15904921695706e-003;

            __statist_i_h_wts[10, 41] = 1.87933398648280e-002;

            __statist_i_h_wts[10, 42] = 2.17066360942486e-002;

            __statist_i_h_wts[10, 43] = -1.75446264148520e-002;

            __statist_i_h_wts[10, 44] = -2.76383409312116e-002;

            __statist_i_h_wts[10, 45] = 3.53896028095753e-002;

            __statist_i_h_wts[10, 46] = -4.39672959099564e-002;

            __statist_i_h_wts[10, 47] = -3.57695920990106e-003;

            __statist_i_h_wts[10, 48] = -1.50732632506981e-001;

            __statist_i_h_wts[10, 49] = 7.92556811488124e-002;

            __statist_i_h_wts[10, 50] = 6.55085407218489e-002;

            __statist_i_h_wts[10, 51] = -4.03775263220270e-003;

            __statist_i_h_wts[10, 52] = -4.34381191574493e-002;

            __statist_i_h_wts[10, 53] = 2.18692487030602e-002;

            __statist_i_h_wts[10, 54] = -2.36337991191995e-002;

            __statist_i_h_wts[10, 55] = -1.45923497374091e-002;

            __statist_i_h_wts[10, 56] = 6.24093767720638e-003;

            __statist_i_h_wts[10, 57] = -2.22354110259722e-002;

            __statist_i_h_wts[10, 58] = 2.86803679353544e-002;

            __statist_i_h_wts[10, 59] = -3.06876260212794e-002;

            __statist_i_h_wts[10, 60] = -2.25470810221005e-003;

            __statist_i_h_wts[10, 61] = -3.48388513734597e-003;

            __statist_i_h_wts[10, 62] = -2.98022197006992e-002;

            __statist_i_h_wts[10, 63] = -2.49819167144098e-001;

            __statist_i_h_wts[10, 64] = 1.58090692517394e-001;

            __statist_i_h_wts[10, 65] = 9.03604094752582e-002;

            __statist_i_h_wts[10, 66] = -5.21361763219833e-002;

            __statist_i_h_wts[10, 67] = -5.97021514862444e-002;

            __statist_i_h_wts[10, 68] = 5.16915260192082e-002;

            __statist_i_h_wts[10, 69] = -4.71803368050122e-002;

            __statist_i_h_wts[10, 70] = -1.81233504634414e-002;

            __statist_i_h_wts[10, 71] = 5.84977107034054e-002;

            __statist_i_h_wts[10, 72] = 2.60666992079691e-001;

            __statist_i_h_wts[10, 73] = -1.66076485198212e-001;

            __statist_i_h_wts[10, 74] = -1.26589741985265e-001;

            __statist_i_h_wts[10, 75] = 4.40288697993672e-001;

            __statist_i_h_wts[10, 76] = -1.97205351631114e-001;

            __statist_i_h_wts[10, 77] = -2.73318154241195e-001;

            __statist_i_h_wts[10, 78] = 1.50185076151172e-001;

            __statist_i_h_wts[10, 79] = -3.00697688156769e-001;

            __statist_i_h_wts[10, 80] = 9.18713364924054e-002;

            __statist_i_h_wts[10, 81] = 6.47741266303363e-002;

            __statist_i_h_wts[10, 82] = -1.69403302941147e-001;

            __statist_i_h_wts[10, 83] = 6.59072016183412e-002;

            __statist_i_h_wts[10, 84] = -5.82914775059559e-002;

            __statist_i_h_wts[10, 85] = 2.98449943932018e-002;

            __statist_i_h_wts[10, 86] = 5.11471824127239e-003;

            __statist_i_h_wts[10, 87] = 6.98673956308996e-003;

            __statist_i_h_wts[10, 88] = 1.39354863938062e-002;

            __statist_i_h_wts[10, 89] = -3.00315524701967e-002;

            __statist_i_h_wts[10, 90] = -2.53301188327737e-001;

            __statist_i_h_wts[10, 91] = 1.48910681563747e-001;

            __statist_i_h_wts[10, 92] = 9.99604096212965e-002;

            __statist_i_h_wts[10, 93] = -7.02646987338280e-002;

            __statist_i_h_wts[10, 94] = -1.35949119048528e-002;

            __statist_i_h_wts[10, 95] = 5.25297886955938e-002;

            __statist_i_h_wts[10, 96] = -5.23133905764629e-002;

            __statist_i_h_wts[10, 97] = -1.86573013652033e-002;

            __statist_i_h_wts[10, 98] = 5.62862533419950e-002;

            __statist_i_h_wts[10, 99] = -2.03709652266086e-002;

            __statist_i_h_wts[10, 100] = 4.28504560623134e-003;

            __statist_i_h_wts[10, 101] = -2.34728088778933e-002;

            __statist_i_h_wts[10, 102] = 2.96435098758216e-002;

            __statist_i_h_wts[10, 103] = -3.17149257712740e-002;

            __statist_i_h_wts[10, 104] = -2.51417950227930e-002;

            __statist_i_h_wts[10, 105] = -1.91123523426369e-001;

            __statist_i_h_wts[10, 106] = 1.00828641316010e-001;

            __statist_i_h_wts[10, 107] = 4.49895461889474e-002;

            __statist_i_h_wts[10, 108] = -3.72901263076158e-003;

            __statist_i_h_wts[10, 109] = -2.35553202919414e-002;

            __statist_i_h_wts[10, 110] = 1.34952578902347e-002;

            __statist_i_h_wts[10, 111] = -6.20429436083464e-002;

            __statist_i_h_wts[10, 112] = -5.04911470108964e-004;

            __statist_i_h_wts[10, 113] = 6.56624228090786e-003;



            __statist_i_h_wts[11, 0] = 3.18570899092431e-002;

            __statist_i_h_wts[11, 1] = 2.33144319916159e-002;

            __statist_i_h_wts[11, 2] = 2.12844087692200e-003;

            __statist_i_h_wts[11, 3] = 1.84732352868386e-002;

            __statist_i_h_wts[11, 4] = -1.66540686090649e-002;

            __statist_i_h_wts[11, 5] = -8.65346707629338e-003;

            __statist_i_h_wts[11, 6] = 5.91477913748317e-003;

            __statist_i_h_wts[11, 7] = -2.27111310796479e-002;

            __statist_i_h_wts[11, 8] = -1.24913206134653e-002;

            __statist_i_h_wts[11, 9] = -3.44341740617710e-002;

            __statist_i_h_wts[11, 10] = -7.65852843343073e-003;

            __statist_i_h_wts[11, 11] = -5.60301666473997e-002;

            __statist_i_h_wts[11, 12] = -2.33201046097296e-002;

            __statist_i_h_wts[11, 13] = -3.82401572151743e-003;

            __statist_i_h_wts[11, 14] = 3.94838937547352e-002;

            __statist_i_h_wts[11, 15] = 1.39347015633100e-002;

            __statist_i_h_wts[11, 16] = 1.91166739849746e-002;

            __statist_i_h_wts[11, 17] = 5.74020287037615e-002;

            __statist_i_h_wts[11, 18] = 3.34032890396826e-002;

            __statist_i_h_wts[11, 19] = 7.77905912340121e-002;

            __statist_i_h_wts[11, 20] = 2.45296362844662e-002;

            __statist_i_h_wts[11, 21] = -3.01959182944208e-002;

            __statist_i_h_wts[11, 22] = -1.59301587911658e-002;

            __statist_i_h_wts[11, 23] = 6.35036196698621e-003;

            __statist_i_h_wts[11, 24] = 2.54544042262274e-003;

            __statist_i_h_wts[11, 25] = 2.74065159124898e-002;

            __statist_i_h_wts[11, 26] = -4.21107244629936e-002;

            __statist_i_h_wts[11, 27] = -8.05063192142859e-003;

            __statist_i_h_wts[11, 28] = -2.43483080991622e-002;

            __statist_i_h_wts[11, 29] = -7.61800931428882e-003;

            __statist_i_h_wts[11, 30] = -1.29959085420038e-002;

            __statist_i_h_wts[11, 31] = 2.44048078416003e-002;

            __statist_i_h_wts[11, 32] = -4.58088996608280e-002;

            __statist_i_h_wts[11, 33] = -5.28873016968373e-002;

            __statist_i_h_wts[11, 34] = 3.13734885485766e-002;

            __statist_i_h_wts[11, 35] = 1.15210662545984e-002;

            __statist_i_h_wts[11, 36] = -6.22262902161491e-003;

            __statist_i_h_wts[11, 37] = -2.33730187254720e-003;

            __statist_i_h_wts[11, 38] = 1.04449890357594e-002;

            __statist_i_h_wts[11, 39] = -3.91086201934653e-002;

            __statist_i_h_wts[11, 40] = -4.51990085925885e-002;

            __statist_i_h_wts[11, 41] = -1.76446599977255e-002;

            __statist_i_h_wts[11, 42] = -1.16387280340691e-001;

            __statist_i_h_wts[11, 43] = -1.02873054616515e-001;

            __statist_i_h_wts[11, 44] = 6.35199783045678e-002;

            __statist_i_h_wts[11, 45] = -1.46834910529090e-001;

            __statist_i_h_wts[11, 46] = -2.34324224866359e-002;

            __statist_i_h_wts[11, 47] = 4.69687936688300e-002;

            __statist_i_h_wts[11, 48] = 1.50350293172510e-001;

            __statist_i_h_wts[11, 49] = -1.96442141732115e-001;

            __statist_i_h_wts[11, 50] = -1.27019365589688e-001;

            __statist_i_h_wts[11, 51] = -1.91045861646770e-002;

            __statist_i_h_wts[11, 52] = -4.32083627650158e-002;

            __statist_i_h_wts[11, 53] = -8.12144871509878e-002;

            __statist_i_h_wts[11, 54] = -3.36615681461678e-003;

            __statist_i_h_wts[11, 55] = -3.20806411353141e-002;

            __statist_i_h_wts[11, 56] = -9.12833383455998e-002;

            __statist_i_h_wts[11, 57] = -8.52534163289973e-002;

            __statist_i_h_wts[11, 58] = -1.85710446568034e-001;

            __statist_i_h_wts[11, 59] = 1.03036406774853e-001;

            __statist_i_h_wts[11, 60] = -1.01714792910272e-001;

            __statist_i_h_wts[11, 61] = -1.03982704458438e-001;

            __statist_i_h_wts[11, 62] = 6.57550758031640e-002;

            __statist_i_h_wts[11, 63] = 3.20904112646381e-001;

            __statist_i_h_wts[11, 64] = -1.52886410243012e-001;

            __statist_i_h_wts[11, 65] = -3.23062338953081e-001;

            __statist_i_h_wts[11, 66] = 8.22500643987523e-002;

            __statist_i_h_wts[11, 67] = 5.23679567327424e-002;

            __statist_i_h_wts[11, 68] = -2.53677861540803e-001;

            __statist_i_h_wts[11, 69] = 5.22112148724634e-002;

            __statist_i_h_wts[11, 70] = 5.01722468451199e-002;

            __statist_i_h_wts[11, 71] = -2.39292685032750e-001;

            __statist_i_h_wts[11, 72] = -3.20020672647297e-001;

            __statist_i_h_wts[11, 73] = -8.71516459458813e-003;

            __statist_i_h_wts[11, 74] = 1.95696861646089e-001;

            __statist_i_h_wts[11, 75] = -7.19795977065094e-001;

            __statist_i_h_wts[11, 76] = 5.02757837065054e-002;

            __statist_i_h_wts[11, 77] = 5.64841129962727e-001;

            __statist_i_h_wts[11, 78] = 2.68343304659966e-002;

            __statist_i_h_wts[11, 79] = 2.74014802020821e-001;

            __statist_i_h_wts[11, 80] = -4.48272817127626e-001;

            __statist_i_h_wts[11, 81] = -5.90680104378089e-002;

            __statist_i_h_wts[11, 82] = 2.29616676392584e-001;

            __statist_i_h_wts[11, 83] = -3.11809334782548e-001;

            __statist_i_h_wts[11, 84] = -1.00572350939342e-001;

            __statist_i_h_wts[11, 85] = -1.24628651111926e-001;

            __statist_i_h_wts[11, 86] = 8.07339218270894e-002;

            __statist_i_h_wts[11, 87] = -1.50189837357490e-001;

            __statist_i_h_wts[11, 88] = -2.95414940282454e-002;

            __statist_i_h_wts[11, 89] = 4.88643079142084e-002;

            __statist_i_h_wts[11, 90] = 3.03140523006898e-001;

            __statist_i_h_wts[11, 91] = -1.46825685303076e-001;

            __statist_i_h_wts[11, 92] = -2.96386134818571e-001;

            __statist_i_h_wts[11, 93] = 6.74453918573142e-002;

            __statist_i_h_wts[11, 94] = 2.95468180931228e-002;

            __statist_i_h_wts[11, 95] = -2.46032613464939e-001;

            __statist_i_h_wts[11, 96] = 4.29083525248677e-002;

            __statist_i_h_wts[11, 97] = -2.59265310923253e-002;

            __statist_i_h_wts[11, 98] = -1.37721411165392e-001;

            __statist_i_h_wts[11, 99] = -1.16339621394898e-001;

            __statist_i_h_wts[11, 100] = -6.70730504667179e-002;

            __statist_i_h_wts[11, 101] = 2.43426906248146e-002;

            __statist_i_h_wts[11, 102] = -1.25004863784272e-001;

            __statist_i_h_wts[11, 103] = -1.98709702713258e-002;

            __statist_i_h_wts[11, 104] = 7.41779107842717e-003;

            __statist_i_h_wts[11, 105] = 1.64050503299501e-001;

            __statist_i_h_wts[11, 106] = -1.82545675049870e-001;

            __statist_i_h_wts[11, 107] = -1.32735114603051e-001;

            __statist_i_h_wts[11, 108] = -4.43908380834394e-002;

            __statist_i_h_wts[11, 109] = -2.15188146829348e-002;

            __statist_i_h_wts[11, 110] = -5.81231203236015e-002;

            __statist_i_h_wts[11, 111] = -5.45647364320511e-003;

            __statist_i_h_wts[11, 112] = -4.43139295464705e-002;

            __statist_i_h_wts[11, 113] = -8.48127062888913e-002;



            __statist_i_h_wts[12, 0] = -7.35929327156258e-004;

            __statist_i_h_wts[12, 1] = -1.91371757142016e-002;

            __statist_i_h_wts[12, 2] = -3.78832272065792e-002;

            __statist_i_h_wts[12, 3] = -1.08541393473050e-002;

            __statist_i_h_wts[12, 4] = 6.77392863304911e-003;

            __statist_i_h_wts[12, 5] = 8.36508792989141e-003;

            __statist_i_h_wts[12, 6] = 9.65819402943765e-003;

            __statist_i_h_wts[12, 7] = 2.15853706593183e-002;

            __statist_i_h_wts[12, 8] = 4.42280999160486e-002;

            __statist_i_h_wts[12, 9] = 1.87403938983767e-002;

            __statist_i_h_wts[12, 10] = 3.40101339485131e-002;

            __statist_i_h_wts[12, 11] = 3.24360648816482e-002;

            __statist_i_h_wts[12, 12] = 1.72033565547013e-002;

            __statist_i_h_wts[12, 13] = 1.80645922631673e-002;

            __statist_i_h_wts[12, 14] = -4.67678426256618e-002;

            __statist_i_h_wts[12, 15] = -1.96318981327146e-002;

            __statist_i_h_wts[12, 16] = -2.38807478069723e-002;

            __statist_i_h_wts[12, 17] = -5.26216286631399e-002;

            __statist_i_h_wts[12, 18] = -3.47025204363330e-003;

            __statist_i_h_wts[12, 19] = -4.12865297339362e-002;

            __statist_i_h_wts[12, 20] = -5.46966155157439e-002;

            __statist_i_h_wts[12, 21] = 3.28008074715535e-002;

            __statist_i_h_wts[12, 22] = -2.23475931615636e-002;

            __statist_i_h_wts[12, 23] = -3.87997566676469e-002;

            __statist_i_h_wts[12, 24] = 1.16373190559361e-002;

            __statist_i_h_wts[12, 25] = -4.12586043555072e-002;

            __statist_i_h_wts[12, 26] = 2.75464732965298e-002;

            __statist_i_h_wts[12, 27] = -4.76632915060470e-003;

            __statist_i_h_wts[12, 28] = -7.21154426765799e-003;

            __statist_i_h_wts[12, 29] = -3.83748211673304e-003;

            __statist_i_h_wts[12, 30] = 2.95265736927026e-002;

            __statist_i_h_wts[12, 31] = -2.39684753755006e-002;

            __statist_i_h_wts[12, 32] = 4.51664860506373e-002;

            __statist_i_h_wts[12, 33] = 4.55403884925555e-002;

            __statist_i_h_wts[12, 34] = -4.03094373627294e-002;

            __statist_i_h_wts[12, 35] = -1.51222872042909e-002;

            __statist_i_h_wts[12, 36] = 1.77187311267585e-003;

            __statist_i_h_wts[12, 37] = 1.16868638243824e-002;

            __statist_i_h_wts[12, 38] = 7.77298294952602e-003;

            __statist_i_h_wts[12, 39] = 1.92513826993698e-002;

            __statist_i_h_wts[12, 40] = 4.08877314789173e-002;

            __statist_i_h_wts[12, 41] = -4.51286138760312e-003;

            __statist_i_h_wts[12, 42] = 4.34185529426472e-003;

            __statist_i_h_wts[12, 43] = -2.53780308288720e-002;

            __statist_i_h_wts[12, 44] = -6.10187727321652e-002;

            __statist_i_h_wts[12, 45] = -4.09048371778626e-002;

            __statist_i_h_wts[12, 46] = 4.43925286548098e-002;

            __statist_i_h_wts[12, 47] = -6.09284733052348e-002;

            __statist_i_h_wts[12, 48] = 1.06698878676509e-001;

            __statist_i_h_wts[12, 49] = -2.13070298978017e-001;

            __statist_i_h_wts[12, 50] = 5.05084935036096e-002;

            __statist_i_h_wts[12, 51] = -3.08631114178256e-002;

            __statist_i_h_wts[12, 52] = -6.68678114150884e-002;

            __statist_i_h_wts[12, 53] = 5.43367943427474e-002;

            __statist_i_h_wts[12, 54] = -5.31948996384393e-002;

            __statist_i_h_wts[12, 55] = -7.19448613693336e-002;

            __statist_i_h_wts[12, 56] = 5.07904484504794e-002;

            __statist_i_h_wts[12, 57] = 2.13918556718917e-002;

            __statist_i_h_wts[12, 58] = -7.96036528221300e-003;

            __statist_i_h_wts[12, 59] = -1.00194908668412e-001;

            __statist_i_h_wts[12, 60] = -4.70457054764936e-002;

            __statist_i_h_wts[12, 61] = 3.26226063570334e-002;

            __statist_i_h_wts[12, 62] = -6.15115093133373e-002;

            __statist_i_h_wts[12, 63] = 1.72382295345242e-001;

            __statist_i_h_wts[12, 64] = -4.49935668903755e-001;

            __statist_i_h_wts[12, 65] = 2.39059533543104e-001;

            __statist_i_h_wts[12, 66] = -8.33557712610579e-002;

            __statist_i_h_wts[12, 67] = -1.63061646098662e-001;

            __statist_i_h_wts[12, 68] = 1.95017369659968e-001;

            __statist_i_h_wts[12, 69] = -1.18583927240824e-002;

            __statist_i_h_wts[12, 70] = -1.88875606638776e-001;

            __statist_i_h_wts[12, 71] = 1.32467562338661e-001;

            __statist_i_h_wts[12, 72] = -2.33403625716641e-001;

            __statist_i_h_wts[12, 73] = 2.93201967650159e-001;

            __statist_i_h_wts[12, 74] = -1.34838254530314e-001;

            __statist_i_h_wts[12, 75] = -4.75984945069307e-002;

            __statist_i_h_wts[12, 76] = 2.98612490461490e-001;

            __statist_i_h_wts[12, 77] = -3.27222214454584e-001;

            __statist_i_h_wts[12, 78] = -5.77224004586534e-001;

            __statist_i_h_wts[12, 79] = 2.75942851055372e-001;

            __statist_i_h_wts[12, 80] = 2.60603338350288e-001;

            __statist_i_h_wts[12, 81] = -3.85069679838757e-001;

            __statist_i_h_wts[12, 82] = 1.11187284066793e-001;

            __statist_i_h_wts[12, 83] = 1.92661871451567e-001;

            __statist_i_h_wts[12, 84] = 2.43555971025693e-002;

            __statist_i_h_wts[12, 85] = -1.67098050759415e-002;

            __statist_i_h_wts[12, 86] = -7.51003697936017e-002;

            __statist_i_h_wts[12, 87] = -1.92742118265598e-003;

            __statist_i_h_wts[12, 88] = -3.60348839565101e-002;

            __statist_i_h_wts[12, 89] = -2.70443748874585e-002;

            __statist_i_h_wts[12, 90] = 2.17167910730642e-001;

            __statist_i_h_wts[12, 91] = -4.53076499871954e-001;

            __statist_i_h_wts[12, 92] = 1.84331344374973e-001;

            __statist_i_h_wts[12, 93] = -2.54207347629447e-002;

            __statist_i_h_wts[12, 94] = -1.94888568815629e-001;

            __statist_i_h_wts[12, 95] = 1.82956263940271e-001;

            __statist_i_h_wts[12, 96] = -1.50674564093593e-002;

            __statist_i_h_wts[12, 97] = -1.70050116784951e-001;

            __statist_i_h_wts[12, 98] = 1.22609125971895e-001;

            __statist_i_h_wts[12, 99] = -5.38810378441355e-002;

            __statist_i_h_wts[12, 100] = -2.20230588881911e-003;

            __statist_i_h_wts[12, 101] = 1.31018150809111e-002;

            __statist_i_h_wts[12, 102] = -1.34748455791457e-001;

            __statist_i_h_wts[12, 103] = 5.47739406060755e-002;

            __statist_i_h_wts[12, 104] = 1.20108146037178e-002;

            __statist_i_h_wts[12, 105] = 7.25553766638142e-002;

            __statist_i_h_wts[12, 106] = -2.46031161309938e-001;

            __statist_i_h_wts[12, 107] = 1.09244569597384e-001;

            __statist_i_h_wts[12, 108] = -1.38554219689915e-001;

            __statist_i_h_wts[12, 109] = 1.34810395259948e-002;

            __statist_i_h_wts[12, 110] = 4.73395664027977e-002;

            __statist_i_h_wts[12, 111] = -6.55488831809751e-002;

            __statist_i_h_wts[12, 112] = -1.99184854303158e-002;

            __statist_i_h_wts[12, 113] = 3.33008585207703e-002;



            __statist_i_h_wts[13, 0] = -5.38087866772416e-003;

            __statist_i_h_wts[13, 1] = -1.98755159806908e-002;

            __statist_i_h_wts[13, 2] = 6.94352598976981e-003;

            __statist_i_h_wts[13, 3] = -8.41586407232193e-002;

            __statist_i_h_wts[13, 4] = -4.04939594003788e-002;

            __statist_i_h_wts[13, 5] = 1.11340288072433e-002;

            __statist_i_h_wts[13, 6] = -4.77293509310947e-002;

            __statist_i_h_wts[13, 7] = -9.33105552688368e-004;

            __statist_i_h_wts[13, 8] = 3.79108220716587e-002;

            __statist_i_h_wts[13, 9] = 2.48618432981374e-002;

            __statist_i_h_wts[13, 10] = -3.63740273945174e-002;

            __statist_i_h_wts[13, 11] = 2.29266154356125e-002;

            __statist_i_h_wts[13, 12] = 2.07009950136504e-002;

            __statist_i_h_wts[13, 13] = -7.51775256803790e-003;

            __statist_i_h_wts[13, 14] = 2.22733286508634e-002;

            __statist_i_h_wts[13, 15] = -2.95816669245045e-003;

            __statist_i_h_wts[13, 16] = 1.06673839840297e-002;

            __statist_i_h_wts[13, 17] = 9.44556704506387e-003;

            __statist_i_h_wts[13, 18] = -1.11994432713210e-002;

            __statist_i_h_wts[13, 19] = -4.45677572639397e-002;

            __statist_i_h_wts[13, 20] = 2.78325698123366e-003;

            __statist_i_h_wts[13, 21] = 5.95138599526987e-002;

            __statist_i_h_wts[13, 22] = 1.90166215259288e-002;

            __statist_i_h_wts[13, 23] = 6.05952408533087e-003;

            __statist_i_h_wts[13, 24] = -6.85297967048161e-003;

            __statist_i_h_wts[13, 25] = 2.84162515835189e-002;

            __statist_i_h_wts[13, 26] = 4.22103086401670e-002;

            __statist_i_h_wts[13, 27] = -5.14414447853604e-002;

            __statist_i_h_wts[13, 28] = 3.25903556492511e-002;

            __statist_i_h_wts[13, 29] = 8.25498059615078e-004;

            __statist_i_h_wts[13, 30] = 1.69201875468963e-003;

            __statist_i_h_wts[13, 31] = -1.54179225160959e-002;

            __statist_i_h_wts[13, 32] = 2.65943820464096e-002;

            __statist_i_h_wts[13, 33] = 2.91921224685044e-002;

            __statist_i_h_wts[13, 34] = -1.07277285123724e-002;

            __statist_i_h_wts[13, 35] = 7.11297117907074e-003;

            __statist_i_h_wts[13, 36] = -1.79283320804768e-003;

            __statist_i_h_wts[13, 37] = 2.01130613110435e-003;

            __statist_i_h_wts[13, 38] = -3.84368348597578e-002;

            __statist_i_h_wts[13, 39] = 8.09757420637056e-003;

            __statist_i_h_wts[13, 40] = -2.51689861860070e-002;

            __statist_i_h_wts[13, 41] = 1.72857080755373e-002;

            __statist_i_h_wts[13, 42] = 9.49733024042615e-002;

            __statist_i_h_wts[13, 43] = -4.82496133527697e-002;

            __statist_i_h_wts[13, 44] = -3.34003328468779e-002;

            __statist_i_h_wts[13, 45] = 9.81108410985921e-002;

            __statist_i_h_wts[13, 46] = -9.39657266793918e-002;

            __statist_i_h_wts[13, 47] = -7.23025910797863e-003;

            __statist_i_h_wts[13, 48] = -2.51754119669695e-001;

            __statist_i_h_wts[13, 49] = 1.20138822488624e-001;

            __statist_i_h_wts[13, 50] = 1.23672126516453e-001;

            __statist_i_h_wts[13, 51] = 4.54180090479172e-002;

            __statist_i_h_wts[13, 52] = -9.81427036148100e-002;

            __statist_i_h_wts[13, 53] = 3.69044341917986e-002;

            __statist_i_h_wts[13, 54] = 5.93843831514652e-002;

            __statist_i_h_wts[13, 55] = -1.01906879591201e-001;

            __statist_i_h_wts[13, 56] = 3.93351217218499e-002;

            __statist_i_h_wts[13, 57] = -2.09734499216676e-003;

            __statist_i_h_wts[13, 58] = 1.02881358773977e-001;

            __statist_i_h_wts[13, 59] = -8.34760973058884e-002;

            __statist_i_h_wts[13, 60] = 4.10044059186744e-002;

            __statist_i_h_wts[13, 61] = 3.96101665497051e-002;

            __statist_i_h_wts[13, 62] = -6.34989988700866e-002;

            __statist_i_h_wts[13, 63] = -5.30155230439201e-001;

            __statist_i_h_wts[13, 64] = 2.74599765614269e-001;

            __statist_i_h_wts[13, 65] = 2.41520970517300e-001;

            __statist_i_h_wts[13, 66] = -1.63936916913746e-002;

            __statist_i_h_wts[13, 67] = -1.05301486475111e-001;

            __statist_i_h_wts[13, 68] = 1.25135476892524e-001;

            __statist_i_h_wts[13, 69] = -7.49770364737661e-002;

            __statist_i_h_wts[13, 70] = -5.87780916359527e-002;

            __statist_i_h_wts[13, 71] = 1.15935262707657e-001;

            __statist_i_h_wts[13, 72] = 6.50219805402941e-001;

            __statist_i_h_wts[13, 73] = -2.59574634827552e-001;

            __statist_i_h_wts[13, 74] = -4.25939029539794e-001;

            __statist_i_h_wts[13, 75] = 1.00257979287710e+000;

            __statist_i_h_wts[13, 76] = -3.14008312747552e-001;

            __statist_i_h_wts[13, 77] = -7.17860868245596e-001;

            __statist_i_h_wts[13, 78] = 3.57566657379237e-001;

            __statist_i_h_wts[13, 79] = -6.57240870338745e-001;

            __statist_i_h_wts[13, 80] = 3.02812163379855e-001;

            __statist_i_h_wts[13, 81] = 1.51960486418074e-001;

            __statist_i_h_wts[13, 82] = -3.72649975070133e-001;

            __statist_i_h_wts[13, 83] = 1.72854171099298e-001;

            __statist_i_h_wts[13, 84] = -7.80683631933059e-002;

            __statist_i_h_wts[13, 85] = 1.07162556356708e-001;

            __statist_i_h_wts[13, 86] = -3.13853632737848e-002;

            __statist_i_h_wts[13, 87] = 8.95422763811367e-003;

            __statist_i_h_wts[13, 88] = 2.07864886465117e-002;

            __statist_i_h_wts[13, 89] = -4.53165198712848e-002;

            __statist_i_h_wts[13, 90] = -5.87390669302616e-001;

            __statist_i_h_wts[13, 91] = 3.60523978246237e-001;

            __statist_i_h_wts[13, 92] = 2.55163838532736e-001;

            __statist_i_h_wts[13, 93] = -1.24183050381057e-001;

            __statist_i_h_wts[13, 94] = -3.47779355431377e-002;

            __statist_i_h_wts[13, 95] = 1.38038507394880e-001;

            __statist_i_h_wts[13, 96] = -5.92847925089550e-002;

            __statist_i_h_wts[13, 97] = -6.74742684898964e-002;

            __statist_i_h_wts[13, 98] = 1.07448957788706e-001;

            __statist_i_h_wts[13, 99] = -4.12905858664109e-003;

            __statist_i_h_wts[13, 100] = 6.69169597445935e-002;

            __statist_i_h_wts[13, 101] = -7.69808639460150e-002;

            __statist_i_h_wts[13, 102] = 7.75380583946132e-002;

            __statist_i_h_wts[13, 103] = -2.08159074179400e-002;

            __statist_i_h_wts[13, 104] = -7.87776803003105e-002;

            __statist_i_h_wts[13, 105] = -4.00211075654771e-001;

            __statist_i_h_wts[13, 106] = 2.25429473840786e-001;

            __statist_i_h_wts[13, 107] = 1.74398333383364e-001;

            __statist_i_h_wts[13, 108] = -1.96868014896329e-002;

            __statist_i_h_wts[13, 109] = -4.82227293553463e-002;

            __statist_i_h_wts[13, 110] = 5.43400833315099e-002;

            __statist_i_h_wts[13, 111] = -8.24986153735583e-002;

            __statist_i_h_wts[13, 112] = 2.73149785406275e-002;

            __statist_i_h_wts[13, 113] = 5.09286270388377e-002;



            __statist_i_h_wts[14, 0] = -1.01751000749628e-002;

            __statist_i_h_wts[14, 1] = -1.77589730632116e-002;

            __statist_i_h_wts[14, 2] = 2.01510020493505e-002;

            __statist_i_h_wts[14, 3] = -3.10588047742395e-002;

            __statist_i_h_wts[14, 4] = 4.13365062164199e-003;

            __statist_i_h_wts[14, 5] = -2.86756663001608e-002;

            __statist_i_h_wts[14, 6] = -2.40402482106567e-002;

            __statist_i_h_wts[14, 7] = 2.12786769371820e-002;

            __statist_i_h_wts[14, 8] = 9.11372496903736e-003;

            __statist_i_h_wts[14, 9] = 1.21694422930857e-002;

            __statist_i_h_wts[14, 10] = -2.39236742160437e-002;

            __statist_i_h_wts[14, 11] = 1.77285936893999e-002;

            __statist_i_h_wts[14, 12] = 4.75135915644559e-003;

            __statist_i_h_wts[14, 13] = 1.04185155194986e-002;

            __statist_i_h_wts[14, 14] = 1.08577792756156e-002;

            __statist_i_h_wts[14, 15] = -1.56619264209552e-003;

            __statist_i_h_wts[14, 16] = 8.50794057797581e-003;

            __statist_i_h_wts[14, 17] = -1.05818574798568e-002;

            __statist_i_h_wts[14, 18] = 3.22365508068704e-003;

            __statist_i_h_wts[14, 19] = -2.63308910375091e-002;

            __statist_i_h_wts[14, 20] = 7.13650708760187e-003;

            __statist_i_h_wts[14, 21] = 1.24122241439328e-002;

            __statist_i_h_wts[14, 22] = -2.66445579153157e-002;

            __statist_i_h_wts[14, 23] = -2.13992763830383e-002;

            __statist_i_h_wts[14, 24] = -9.49081504777512e-003;

            __statist_i_h_wts[14, 25] = 1.33336805842490e-002;

            __statist_i_h_wts[14, 26] = 3.26590510543445e-002;

            __statist_i_h_wts[14, 27] = 5.33558422866221e-004;

            __statist_i_h_wts[14, 28] = 9.37522539387097e-003;

            __statist_i_h_wts[14, 29] = 4.46516463251438e-004;

            __statist_i_h_wts[14, 30] = 5.20672232894614e-003;

            __statist_i_h_wts[14, 31] = -3.33044646285234e-003;

            __statist_i_h_wts[14, 32] = 1.79369535281193e-002;

            __statist_i_h_wts[14, 33] = -8.40949597081362e-003;

            __statist_i_h_wts[14, 34] = 1.18436951925766e-004;

            __statist_i_h_wts[14, 35] = 1.10054013618410e-002;

            __statist_i_h_wts[14, 36] = -2.05546200691788e-003;

            __statist_i_h_wts[14, 37] = 1.76445507107666e-003;

            __statist_i_h_wts[14, 38] = -7.55767550851167e-003;

            __statist_i_h_wts[14, 39] = -1.93260032011439e-002;

            __statist_i_h_wts[14, 40] = -1.37227713862889e-002;

            __statist_i_h_wts[14, 41] = -1.38143358451159e-002;

            __statist_i_h_wts[14, 42] = 6.12050365951136e-002;

            __statist_i_h_wts[14, 43] = -4.88829038826343e-002;

            __statist_i_h_wts[14, 44] = -6.46566961535715e-002;

            __statist_i_h_wts[14, 45] = 1.99726019397681e-001;

            __statist_i_h_wts[14, 46] = -2.36002561196838e-001;

            __statist_i_h_wts[14, 47] = -3.83669465761488e-002;

            __statist_i_h_wts[14, 48] = -9.16052717369387e-001;

            __statist_i_h_wts[14, 49] = 7.07382079676912e-001;

            __statist_i_h_wts[14, 50] = 1.58977471870415e-001;

            __statist_i_h_wts[14, 51] = 2.37210358852564e-002;

            __statist_i_h_wts[14, 52] = -1.30255402779646e-001;

            __statist_i_h_wts[14, 53] = 5.39146925181693e-002;

            __statist_i_h_wts[14, 54] = -5.08969369473567e-002;

            __statist_i_h_wts[14, 55] = -6.85783609688931e-002;

            __statist_i_h_wts[14, 56] = 7.51142147834211e-002;

            __statist_i_h_wts[14, 57] = -1.26797075752178e-001;

            __statist_i_h_wts[14, 58] = 1.65550904374472e-001;

            __statist_i_h_wts[14, 59] = -8.64561674911242e-002;

            __statist_i_h_wts[14, 60] = 8.17061070817248e-003;

            __statist_i_h_wts[14, 61] = 6.15957760710613e-003;

            __statist_i_h_wts[14, 62] = -7.60137365535280e-002;

            __statist_i_h_wts[14, 63] = -1.26880527951264e+000;

            __statist_i_h_wts[14, 64] = 9.49557107703868e-001;

            __statist_i_h_wts[14, 65] = 2.58422473524339e-001;

            __statist_i_h_wts[14, 66] = -1.26115487917662e-001;

            __statist_i_h_wts[14, 67] = -6.21815709441846e-002;

            __statist_i_h_wts[14, 68] = 1.13142195833994e-001;

            __statist_i_h_wts[14, 69] = -1.68186372600656e-001;

            __statist_i_h_wts[14, 70] = 1.49243662107060e-002;

            __statist_i_h_wts[14, 71] = 1.02423404345074e-001;

            __statist_i_h_wts[14, 72] = 1.21376095160744e+000;

            __statist_i_h_wts[14, 73] = -7.84547813317718e-001;

            __statist_i_h_wts[14, 74] = -4.73173035165399e-001;

            __statist_i_h_wts[14, 75] = 1.60028876815349e+000;

            __statist_i_h_wts[14, 76] = -8.99849783909669e-001;

            __statist_i_h_wts[14, 77] = -7.99600722660478e-001;

            __statist_i_h_wts[14, 78] = 9.78742347201935e-001;

            __statist_i_h_wts[14, 79] = -1.27773492611119e+000;

            __statist_i_h_wts[14, 80] = 2.40711000233905e-001;

            __statist_i_h_wts[14, 81] = 6.86085536380133e-001;

            __statist_i_h_wts[14, 82] = -9.38157602540626e-001;

            __statist_i_h_wts[14, 83] = 1.93901834466011e-001;

            __statist_i_h_wts[14, 84] = -1.40323983089190e-001;

            __statist_i_h_wts[14, 85] = 1.46271347393981e-001;

            __statist_i_h_wts[14, 86] = -4.93446875874321e-002;

            __statist_i_h_wts[14, 87] = 3.46602683359691e-002;

            __statist_i_h_wts[14, 88] = -2.67006813212023e-002;

            __statist_i_h_wts[14, 89] = -4.96155545573712e-002;

            __statist_i_h_wts[14, 90] = -1.29317848526104e+000;

            __statist_i_h_wts[14, 91] = 9.87600626727257e-001;

            __statist_i_h_wts[14, 92] = 2.53869432556137e-001;

            __statist_i_h_wts[14, 93] = -1.86592070164121e-001;

            __statist_i_h_wts[14, 94] = 1.87102042183746e-002;

            __statist_i_h_wts[14, 95] = 1.10435865866998e-001;

            __statist_i_h_wts[14, 96] = -2.55229294727584e-001;

            __statist_i_h_wts[14, 97] = 1.18790811086221e-001;

            __statist_i_h_wts[14, 98] = 8.61672692951465e-002;

            __statist_i_h_wts[14, 99] = -2.17272290823144e-002;

            __statist_i_h_wts[14, 100] = 4.65807494476521e-002;

            __statist_i_h_wts[14, 101] = -8.51963673412581e-002;

            __statist_i_h_wts[14, 102] = 1.60407596676053e-001;

            __statist_i_h_wts[14, 103] = -1.25198946338738e-001;

            __statist_i_h_wts[14, 104] = -1.02319228253120e-001;

            __statist_i_h_wts[14, 105] = -1.02732175873044e+000;

            __statist_i_h_wts[14, 106] = 8.20229050905033e-001;

            __statist_i_h_wts[14, 107] = 1.50890910683345e-001;

            __statist_i_h_wts[14, 108] = -9.48882987514043e-002;

            __statist_i_h_wts[14, 109] = -3.72491672166923e-002;

            __statist_i_h_wts[14, 110] = 5.69681198155115e-002;

            __statist_i_h_wts[14, 111] = -1.88745408727551e-001;

            __statist_i_h_wts[14, 112] = 8.06069203103852e-002;

            __statist_i_h_wts[14, 113] = 5.58544250534739e-002;



            __statist_i_h_wts[15, 0] = -2.43015921503359e-003;

            __statist_i_h_wts[15, 1] = 1.23106929589212e-002;

            __statist_i_h_wts[15, 2] = 4.66046476906812e-003;

            __statist_i_h_wts[15, 3] = -3.89117992644758e-003;

            __statist_i_h_wts[15, 4] = -2.06084588764677e-002;

            __statist_i_h_wts[15, 5] = 1.20973225089864e-003;

            __statist_i_h_wts[15, 6] = -3.24696419749553e-004;

            __statist_i_h_wts[15, 7] = -1.53801540526466e-002;

            __statist_i_h_wts[15, 8] = -4.54281861472127e-003;

            __statist_i_h_wts[15, 9] = -2.00522442148963e-002;

            __statist_i_h_wts[15, 10] = -1.86561204450419e-002;

            __statist_i_h_wts[15, 11] = -2.74522208485091e-002;

            __statist_i_h_wts[15, 12] = 5.34781053753119e-003;

            __statist_i_h_wts[15, 13] = -8.06005679533961e-003;

            __statist_i_h_wts[15, 14] = 2.98566863647229e-002;

            __statist_i_h_wts[15, 15] = 9.08124385220479e-003;

            __statist_i_h_wts[15, 16] = 1.67039834985668e-002;

            __statist_i_h_wts[15, 17] = 2.06662795078315e-002;

            __statist_i_h_wts[15, 18] = 1.25869607460824e-002;

            __statist_i_h_wts[15, 19] = 2.60400118656411e-002;

            __statist_i_h_wts[15, 20] = 3.25354347941650e-002;

            __statist_i_h_wts[15, 21] = 5.40830051168456e-003;

            __statist_i_h_wts[15, 22] = 1.20665695097310e-003;

            __statist_i_h_wts[15, 23] = 8.72753463988374e-003;

            __statist_i_h_wts[15, 24] = 1.51398468444371e-002;

            __statist_i_h_wts[15, 25] = 3.56645729213037e-002;

            __statist_i_h_wts[15, 26] = 2.63018138984909e-003;

            __statist_i_h_wts[15, 27] = -9.71448138681364e-003;

            __statist_i_h_wts[15, 28] = -1.01793740892112e-002;

            __statist_i_h_wts[15, 29] = -1.55159312049129e-002;

            __statist_i_h_wts[15, 30] = 3.23020394252992e-003;

            __statist_i_h_wts[15, 31] = 1.61405489953425e-002;

            __statist_i_h_wts[15, 32] = 3.37917170947672e-003;

            __statist_i_h_wts[15, 33] = -1.38878795236068e-002;

            __statist_i_h_wts[15, 34] = 7.62365443147231e-004;

            __statist_i_h_wts[15, 35] = 1.76389229766060e-003;

            __statist_i_h_wts[15, 36] = -5.21739729639540e-004;

            __statist_i_h_wts[15, 37] = -9.72177138985008e-004;

            __statist_i_h_wts[15, 38] = -1.02326531643300e-002;

            __statist_i_h_wts[15, 39] = -2.73234616213785e-002;

            __statist_i_h_wts[15, 40] = -3.69271774762319e-002;

            __statist_i_h_wts[15, 41] = -4.05252386179348e-003;

            __statist_i_h_wts[15, 42] = 8.30873712635988e-002;

            __statist_i_h_wts[15, 43] = -1.21403698090281e-002;

            __statist_i_h_wts[15, 44] = 2.63616372593836e-002;

            __statist_i_h_wts[15, 45] = 7.27222278193796e-002;

            __statist_i_h_wts[15, 46] = -2.40040900527967e-002;

            __statist_i_h_wts[15, 47] = 1.86523156069822e-002;

            __statist_i_h_wts[15, 48] = -5.13033104333416e-002;

            __statist_i_h_wts[15, 49] = 1.34610617218218e-001;

            __statist_i_h_wts[15, 50] = -9.25681273382465e-003;

            __statist_i_h_wts[15, 51] = 1.06257943097795e-001;

            __statist_i_h_wts[15, 52] = 1.29902759711199e-003;

            __statist_i_h_wts[15, 53] = -2.30797359671521e-002;

            __statist_i_h_wts[15, 54] = 8.79992352928675e-002;

            __statist_i_h_wts[15, 55] = 6.15068794629196e-002;

            __statist_i_h_wts[15, 56] = -3.21768874665858e-002;

            __statist_i_h_wts[15, 57] = 4.62230090518529e-002;

            __statist_i_h_wts[15, 58] = -3.29144778090616e-003;

            __statist_i_h_wts[15, 59] = 4.27960959859600e-002;

            __statist_i_h_wts[15, 60] = 7.22236945641682e-002;

            __statist_i_h_wts[15, 61] = -1.43559501990033e-002;

            __statist_i_h_wts[15, 62] = 4.24159970079424e-002;

            __statist_i_h_wts[15, 63] = -6.11301320307604e-002;

            __statist_i_h_wts[15, 64] = 2.52598548391490e-001;

            __statist_i_h_wts[15, 65] = -9.38710405942088e-002;

            __statist_i_h_wts[15, 66] = 1.25964713735893e-001;

            __statist_i_h_wts[15, 67] = 5.41312283871016e-002;

            __statist_i_h_wts[15, 68] = -9.02570108252583e-002;

            __statist_i_h_wts[15, 69] = 9.82092497140852e-002;

            __statist_i_h_wts[15, 70] = 7.62042271498535e-002;

            __statist_i_h_wts[15, 71] = -6.66711311017732e-002;

            __statist_i_h_wts[15, 72] = 1.70023324484494e-001;

            __statist_i_h_wts[15, 73] = -1.44170015577202e-001;

            __statist_i_h_wts[15, 74] = 4.32132221817790e-002;

            __statist_i_h_wts[15, 75] = 1.01882887172309e-001;

            __statist_i_h_wts[15, 76] = -1.22676616092362e-001;

            __statist_i_h_wts[15, 77] = 1.36518737403609e-001;

            __statist_i_h_wts[15, 78] = 2.88658580223467e-001;

            __statist_i_h_wts[15, 79] = -6.49509489730524e-002;

            __statist_i_h_wts[15, 80] = -1.26450204528895e-001;

            __statist_i_h_wts[15, 81] = 1.75457907156816e-001;

            __statist_i_h_wts[15, 82] = 1.18597943518745e-002;

            __statist_i_h_wts[15, 83] = -1.05730159551689e-001;

            __statist_i_h_wts[15, 84] = 4.14792042097985e-002;

            __statist_i_h_wts[15, 85] = 7.41083885152534e-003;

            __statist_i_h_wts[15, 86] = 3.99596950005953e-002;

            __statist_i_h_wts[15, 87] = 4.42571289269180e-002;

            __statist_i_h_wts[15, 88] = -6.70741474825796e-003;

            __statist_i_h_wts[15, 89] = 2.35229872300374e-002;

            __statist_i_h_wts[15, 90] = -6.98129383423393e-002;

            __statist_i_h_wts[15, 91] = 2.33602101336214e-001;

            __statist_i_h_wts[15, 92] = -8.61787369769107e-002;

            __statist_i_h_wts[15, 93] = 1.14968340131164e-001;

            __statist_i_h_wts[15, 94] = 3.84830691033882e-002;

            __statist_i_h_wts[15, 95] = -7.94279458818948e-002;

            __statist_i_h_wts[15, 96] = 8.89601018475798e-002;

            __statist_i_h_wts[15, 97] = 5.54286410192928e-002;

            __statist_i_h_wts[15, 98] = -3.36330063996735e-002;

            __statist_i_h_wts[15, 99] = 5.81972504272544e-002;

            __statist_i_h_wts[15, 100] = 3.45072562830772e-003;

            __statist_i_h_wts[15, 101] = 2.78232944478645e-002;

            __statist_i_h_wts[15, 102] = 7.63445214904473e-002;

            __statist_i_h_wts[15, 103] = -5.25664244903204e-003;

            __statist_i_h_wts[15, 104] = 1.99946271923536e-002;

            __statist_i_h_wts[15, 105] = -6.24590119858659e-002;

            __statist_i_h_wts[15, 106] = 1.81629917262673e-001;

            __statist_i_h_wts[15, 107] = 8.40025999431636e-003;

            __statist_i_h_wts[15, 108] = 7.94037376943376e-002;

            __statist_i_h_wts[15, 109] = 2.58688602136122e-002;

            __statist_i_h_wts[15, 110] = -1.61847017022632e-002;

            __statist_i_h_wts[15, 111] = 8.19569117043075e-002;

            __statist_i_h_wts[15, 112] = 5.42426347910092e-002;

            __statist_i_h_wts[15, 113] = -3.39372289025354e-002;



            __statist_i_h_wts[16, 0] = -1.74100852235220e-003;

            __statist_i_h_wts[16, 1] = 2.62559788835649e-003;

            __statist_i_h_wts[16, 2] = 2.61240136021955e-003;

            __statist_i_h_wts[16, 3] = -6.31729003690999e-003;

            __statist_i_h_wts[16, 4] = -1.35487933972840e-002;

            __statist_i_h_wts[16, 5] = 1.53858069802805e-003;

            __statist_i_h_wts[16, 6] = -1.58236905174076e-002;

            __statist_i_h_wts[16, 7] = -2.21268358888005e-003;

            __statist_i_h_wts[16, 8] = 8.78387903276273e-003;

            __statist_i_h_wts[16, 9] = 1.13362728185885e-002;

            __statist_i_h_wts[16, 10] = 4.18454173665056e-003;

            __statist_i_h_wts[16, 11] = -7.87874116799357e-004;

            __statist_i_h_wts[16, 12] = 7.27321291073799e-004;

            __statist_i_h_wts[16, 13] = 1.77573078431032e-002;

            __statist_i_h_wts[16, 14] = -1.41361060352178e-002;

            __statist_i_h_wts[16, 15] = 6.70614061059226e-003;

            __statist_i_h_wts[16, 16] = 1.19595819391146e-002;

            __statist_i_h_wts[16, 17] = 2.26776885211866e-003;

            __statist_i_h_wts[16, 18] = 1.50398502502466e-002;

            __statist_i_h_wts[16, 19] = -2.09482180121798e-003;

            __statist_i_h_wts[16, 20] = -1.16163722634245e-002;

            __statist_i_h_wts[16, 21] = 3.78039051651844e-003;

            __statist_i_h_wts[16, 22] = 9.75995160212572e-003;

            __statist_i_h_wts[16, 23] = -1.32989561304867e-002;

            __statist_i_h_wts[16, 24] = -6.54686706515377e-003;

            __statist_i_h_wts[16, 25] = 2.90805151045037e-003;

            __statist_i_h_wts[16, 26] = -5.33575278287541e-003;

            __statist_i_h_wts[16, 27] = -1.35759015442715e-002;

            __statist_i_h_wts[16, 28] = 2.43420423578059e-003;

            __statist_i_h_wts[16, 29] = -8.70178688771406e-004;

            __statist_i_h_wts[16, 30] = -1.91694245869939e-003;

            __statist_i_h_wts[16, 31] = -1.17316181127113e-002;

            __statist_i_h_wts[16, 32] = -1.32054811215933e-002;

            __statist_i_h_wts[16, 33] = 4.16963082264695e-003;

            __statist_i_h_wts[16, 34] = -1.02104349668506e-003;

            __statist_i_h_wts[16, 35] = -3.30728481050978e-003;

            __statist_i_h_wts[16, 36] = -2.41779546870423e-003;

            __statist_i_h_wts[16, 37] = -6.56028662013871e-003;

            __statist_i_h_wts[16, 38] = -1.03504432210502e-002;

            __statist_i_h_wts[16, 39] = -6.36266052689905e-003;

            __statist_i_h_wts[16, 40] = 5.62460861565897e-003;

            __statist_i_h_wts[16, 41] = -5.01155723510213e-003;

            __statist_i_h_wts[16, 42] = -2.17316455158682e-003;

            __statist_i_h_wts[16, 43] = 4.19854473892779e-002;

            __statist_i_h_wts[16, 44] = 2.04347904740713e-002;

            __statist_i_h_wts[16, 45] = -3.59247361443846e-002;

            __statist_i_h_wts[16, 46] = 4.86174715125785e-002;

            __statist_i_h_wts[16, 47] = 1.01445747516579e-002;

            __statist_i_h_wts[16, 48] = 1.40146197729738e-001;

            __statist_i_h_wts[16, 49] = -8.74799810095671e-002;

            __statist_i_h_wts[16, 50] = -6.20206236230848e-003;

            __statist_i_h_wts[16, 51] = -3.59308116039588e-003;

            __statist_i_h_wts[16, 52] = 2.46559332388420e-002;

            __statist_i_h_wts[16, 53] = 9.19715699389093e-003;

            __statist_i_h_wts[16, 54] = 3.85350978085727e-002;

            __statist_i_h_wts[16, 55] = 9.12899285004522e-003;

            __statist_i_h_wts[16, 56] = -1.02634657145464e-002;

            __statist_i_h_wts[16, 57] = 3.00772464541299e-002;

            __statist_i_h_wts[16, 58] = 8.24874475382275e-003;

            __statist_i_h_wts[16, 59] = -1.41954948401287e-002;

            __statist_i_h_wts[16, 60] = -3.37188740692509e-003;

            __statist_i_h_wts[16, 61] = 2.38646454928940e-002;

            __statist_i_h_wts[16, 62] = 1.87534516352756e-003;

            __statist_i_h_wts[16, 63] = 1.74223869020645e-001;

            __statist_i_h_wts[16, 64] = -1.24522185381621e-001;

            __statist_i_h_wts[16, 65] = -4.99012267606043e-003;

            __statist_i_h_wts[16, 66] = 1.50017376928436e-002;

            __statist_i_h_wts[16, 67] = 1.14251001283382e-002;

            __statist_i_h_wts[16, 68] = 7.61171849058124e-003;

            __statist_i_h_wts[16, 69] = 5.90511494011042e-002;

            __statist_i_h_wts[16, 70] = -1.18717307625610e-003;

            __statist_i_h_wts[16, 71] = -9.26329733905860e-003;

            __statist_i_h_wts[16, 72] = -1.32819835216885e-001;

            __statist_i_h_wts[16, 73] = 1.45539944242746e-001;

            __statist_i_h_wts[16, 74] = 5.02040082391716e-002;

            __statist_i_h_wts[16, 75] = -1.77873836901856e-001;

            __statist_i_h_wts[16, 76] = 1.61570111540970e-001;

            __statist_i_h_wts[16, 77] = 5.49470871329615e-002;

            __statist_i_h_wts[16, 78] = -1.35680611997231e-001;

            __statist_i_h_wts[16, 79] = 1.93021830735960e-001;

            __statist_i_h_wts[16, 80] = 2.69192697478391e-003;

            __statist_i_h_wts[16, 81] = -1.25178714898651e-001;

            __statist_i_h_wts[16, 82] = 1.47230825923377e-001;

            __statist_i_h_wts[16, 83] = 6.58018533253724e-003;

            __statist_i_h_wts[16, 84] = 3.21302669396135e-002;

            __statist_i_h_wts[16, 85] = -4.29730012761546e-005;

            __statist_i_h_wts[16, 86] = -1.81528471761718e-003;

            __statist_i_h_wts[16, 87] = 9.16247945053625e-003;

            __statist_i_h_wts[16, 88] = 2.13585291206209e-002;

            __statist_i_h_wts[16, 89] = -3.21494234785477e-003;

            __statist_i_h_wts[16, 90] = 1.70079743719942e-001;

            __statist_i_h_wts[16, 91] = -1.25717427143952e-001;

            __statist_i_h_wts[16, 92] = -1.85907461092070e-002;

            __statist_i_h_wts[16, 93] = 3.29177759775386e-002;

            __statist_i_h_wts[16, 94] = 7.50355624616802e-003;

            __statist_i_h_wts[16, 95] = 1.98304158948112e-002;

            __statist_i_h_wts[16, 96] = 4.53265838858567e-002;

            __statist_i_h_wts[16, 97] = -1.89884610811183e-002;

            __statist_i_h_wts[16, 98] = 1.25562751442566e-003;

            __statist_i_h_wts[16, 99] = 1.60422248902234e-002;

            __statist_i_h_wts[16, 100] = 2.90269788700143e-002;

            __statist_i_h_wts[16, 101] = -5.51915509726905e-003;

            __statist_i_h_wts[16, 102] = 3.01676629269123e-003;

            __statist_i_h_wts[16, 103] = 3.82615663129527e-002;

            __statist_i_h_wts[16, 104] = 5.45840201925007e-003;

            __statist_i_h_wts[16, 105] = 1.60733739702284e-001;

            __statist_i_h_wts[16, 106] = -9.94999626528051e-002;

            __statist_i_h_wts[16, 107] = -2.14059426006236e-002;

            __statist_i_h_wts[16, 108] = 1.11119713814125e-002;

            __statist_i_h_wts[16, 109] = -2.09159021585218e-003;

            __statist_i_h_wts[16, 110] = 9.28664787022917e-003;

            __statist_i_h_wts[16, 111] = 2.74484625576667e-002;

            __statist_i_h_wts[16, 112] = 9.88041683921792e-003;

            __statist_i_h_wts[16, 113] = -4.86072145806480e-003;



            __statist_i_h_wts[17, 0] = -3.48797948488562e-002;

            __statist_i_h_wts[17, 1] = -3.40192523416579e-002;

            __statist_i_h_wts[17, 2] = 1.81646920435702e-002;

            __statist_i_h_wts[17, 3] = -4.99921798396808e-002;

            __statist_i_h_wts[17, 4] = -1.93484868700118e-004;

            __statist_i_h_wts[17, 5] = 5.90607790960694e-003;

            __statist_i_h_wts[17, 6] = -2.38577504435853e-002;

            __statist_i_h_wts[17, 7] = 4.56095591011357e-002;

            __statist_i_h_wts[17, 8] = 7.00354613083740e-003;

            __statist_i_h_wts[17, 9] = 6.82353323266909e-003;

            __statist_i_h_wts[17, 10] = -7.27122088148898e-002;

            __statist_i_h_wts[17, 11] = 4.11350474205466e-002;

            __statist_i_h_wts[17, 12] = 4.89647516168034e-002;

            __statist_i_h_wts[17, 13] = 3.52077518896392e-002;

            __statist_i_h_wts[17, 14] = 2.82413241785140e-002;

            __statist_i_h_wts[17, 15] = 2.78367691161409e-002;

            __statist_i_h_wts[17, 16] = 6.42629054050960e-003;

            __statist_i_h_wts[17, 17] = 4.27518838790831e-004;

            __statist_i_h_wts[17, 18] = -3.08096261280541e-002;

            __statist_i_h_wts[17, 19] = -2.07448906083236e-002;

            __statist_i_h_wts[17, 20] = 1.52778474246188e-002;

            __statist_i_h_wts[17, 21] = 2.45597872752854e-002;

            __statist_i_h_wts[17, 22] = 4.91058251350752e-002;

            __statist_i_h_wts[17, 23] = -7.84403742992723e-003;

            __statist_i_h_wts[17, 24] = 2.14223791228668e-002;

            __statist_i_h_wts[17, 25] = 1.94926345374250e-002;

            __statist_i_h_wts[17, 26] = 3.10480688172188e-002;

            __statist_i_h_wts[17, 27] = -1.75233432236071e-002;

            __statist_i_h_wts[17, 28] = 5.29452968171821e-002;

            __statist_i_h_wts[17, 29] = 2.47563181352557e-002;

            __statist_i_h_wts[17, 30] = -3.88627985958008e-002;

            __statist_i_h_wts[17, 31] = 1.29481814810977e-002;

            __statist_i_h_wts[17, 32] = 4.66207602114734e-004;

            __statist_i_h_wts[17, 33] = 4.84880098953608e-002;

            __statist_i_h_wts[17, 34] = -2.65318574598147e-002;

            __statist_i_h_wts[17, 35] = 1.15355231879875e-002;

            __statist_i_h_wts[17, 36] = 1.48073138403187e-003;

            __statist_i_h_wts[17, 37] = 3.07094851748905e-002;

            __statist_i_h_wts[17, 38] = -7.31876763879506e-002;

            __statist_i_h_wts[17, 39] = 1.42826057328118e-002;

            __statist_i_h_wts[17, 40] = -2.61547069090468e-002;

            __statist_i_h_wts[17, 41] = -7.81765721152734e-003;

            __statist_i_h_wts[17, 42] = 7.73866124868781e-002;

            __statist_i_h_wts[17, 43] = 1.05574779710876e-001;

            __statist_i_h_wts[17, 44] = -8.02544685286541e-003;

            __statist_i_h_wts[17, 45] = 6.18935503413082e-003;

            __statist_i_h_wts[17, 46] = 1.17424819490760e-001;

            __statist_i_h_wts[17, 47] = 4.70593774435751e-003;

            __statist_i_h_wts[17, 48] = 2.01681981277830e-001;

            __statist_i_h_wts[17, 49] = -1.73021379864673e-001;

            __statist_i_h_wts[17, 50] = 1.45080388585185e-001;

            __statist_i_h_wts[17, 51] = -5.91799798819134e-002;

            __statist_i_h_wts[17, 52] = 1.36976177115405e-001;

            __statist_i_h_wts[17, 53] = 4.88867973572229e-002;

            __statist_i_h_wts[17, 54] = 4.17200043002938e-002;

            __statist_i_h_wts[17, 55] = 7.62314305478285e-002;

            __statist_i_h_wts[17, 56] = 3.51724005383764e-002;

            __statist_i_h_wts[17, 57] = 1.15243753189742e-001;

            __statist_i_h_wts[17, 58] = 1.04239483547470e-001;

            __statist_i_h_wts[17, 59] = -5.89542372635184e-002;

            __statist_i_h_wts[17, 60] = 1.08544783910298e-001;

            __statist_i_h_wts[17, 61] = 1.38678825741813e-001;

            __statist_i_h_wts[17, 62] = -7.88426102511500e-002;

            __statist_i_h_wts[17, 63] = -3.66546757817895e-002;

            __statist_i_h_wts[17, 64] = -5.67258469583196e-002;

            __statist_i_h_wts[17, 65] = 2.51263050044477e-001;

            __statist_i_h_wts[17, 66] = -4.45865704728682e-002;

            __statist_i_h_wts[17, 67] = 4.05561992932083e-002;

            __statist_i_h_wts[17, 68] = 1.65414212508882e-001;

            __statist_i_h_wts[17, 69] = 1.39797319482288e-002;

            __statist_i_h_wts[17, 70] = 1.61264496712982e-002;

            __statist_i_h_wts[17, 71] = 1.46620668917005e-001;

            __statist_i_h_wts[17, 72] = 1.05066443488130e-001;

            __statist_i_h_wts[17, 73] = 3.20254636149634e-001;

            __statist_i_h_wts[17, 74] = -2.47126738279386e-001;

            __statist_i_h_wts[17, 75] = 5.13918792852438e-001;

            __statist_i_h_wts[17, 76] = 2.62723370827391e-001;

            __statist_i_h_wts[17, 77] = -6.14633245675094e-001;

            __statist_i_h_wts[17, 78] = -3.30160233379619e-001;

            __statist_i_h_wts[17, 79] = 1.06711888538887e-001;

            __statist_i_h_wts[17, 80] = 3.87314478554252e-001;

            __statist_i_h_wts[17, 81] = -2.62129913456170e-001;

            __statist_i_h_wts[17, 82] = 2.44980295311325e-001;

            __statist_i_h_wts[17, 83] = 1.84959674191932e-001;

            __statist_i_h_wts[17, 84] = 5.55225777146956e-002;

            __statist_i_h_wts[17, 85] = 6.34304848821443e-002;

            __statist_i_h_wts[17, 86] = 2.52261831521348e-002;

            __statist_i_h_wts[17, 87] = 1.07299855111024e-001;

            __statist_i_h_wts[17, 88] = 1.44240147392204e-001;

            __statist_i_h_wts[17, 89] = -8.73564616336826e-002;

            __statist_i_h_wts[17, 90] = -6.21247342137523e-003;

            __statist_i_h_wts[17, 91] = -1.91670206635055e-002;

            __statist_i_h_wts[17, 92] = 1.97545879214442e-001;

            __statist_i_h_wts[17, 93] = -2.21772166413665e-002;

            __statist_i_h_wts[17, 94] = 2.57979748713708e-002;

            __statist_i_h_wts[17, 95] = 1.56766616993661e-001;

            __statist_i_h_wts[17, 96] = 8.97591109681812e-002;

            __statist_i_h_wts[17, 97] = 2.55224222127051e-003;

            __statist_i_h_wts[17, 98] = 9.07947958585920e-002;

            __statist_i_h_wts[17, 99] = 9.40530066887407e-002;

            __statist_i_h_wts[17, 100] = 7.53641164671662e-002;

            __statist_i_h_wts[17, 101] = -3.71090013441542e-002;

            __statist_i_h_wts[17, 102] = 6.99329875715571e-002;

            __statist_i_h_wts[17, 103] = 9.88555925298301e-002;

            __statist_i_h_wts[17, 104] = -2.81949738879948e-002;

            __statist_i_h_wts[17, 105] = 1.48655831570803e-001;

            __statist_i_h_wts[17, 106] = -1.08125913070079e-001;

            __statist_i_h_wts[17, 107] = 1.30972057983726e-001;

            __statist_i_h_wts[17, 108] = 8.98910333761628e-003;

            __statist_i_h_wts[17, 109] = 8.29528700745692e-002;

            __statist_i_h_wts[17, 110] = 7.06276285119323e-002;

            __statist_i_h_wts[17, 111] = 4.49164817864813e-002;

            __statist_i_h_wts[17, 112] = 6.04901146319362e-002;

            __statist_i_h_wts[17, 113] = 7.93749139266789e-002;



            __statist_i_h_wts[18, 0] = 1.03876310868368e-002;

            __statist_i_h_wts[18, 1] = 9.92493433091728e-004;

            __statist_i_h_wts[18, 2] = -7.50735445358915e-003;

            __statist_i_h_wts[18, 3] = -6.31058684253924e-004;

            __statist_i_h_wts[18, 4] = -7.60256131068006e-004;

            __statist_i_h_wts[18, 5] = 2.36995628934825e-002;

            __statist_i_h_wts[18, 6] = 1.16673274675005e-002;

            __statist_i_h_wts[18, 7] = -1.67812652246046e-002;

            __statist_i_h_wts[18, 8] = -1.97522860052515e-003;

            __statist_i_h_wts[18, 9] = 2.37901876174668e-003;

            __statist_i_h_wts[18, 10] = 1.13726311489153e-002;

            __statist_i_h_wts[18, 11] = -9.25983454429787e-003;

            __statist_i_h_wts[18, 12] = 5.68845428086368e-004;

            __statist_i_h_wts[18, 13] = 8.35518950906731e-003;

            __statist_i_h_wts[18, 14] = -2.81909678448448e-003;

            __statist_i_h_wts[18, 15] = -3.90274967440931e-003;

            __statist_i_h_wts[18, 16] = -1.63678937734820e-002;

            __statist_i_h_wts[18, 17] = 3.09888150795348e-002;

            __statist_i_h_wts[18, 18] = 1.74792953842934e-002;

            __statist_i_h_wts[18, 19] = 2.02583949827186e-002;

            __statist_i_h_wts[18, 20] = 7.35495138851257e-003;

            __statist_i_h_wts[18, 21] = -1.35801446834659e-002;

            __statist_i_h_wts[18, 22] = -1.39949430330433e-002;

            __statist_i_h_wts[18, 23] = 1.79206994901149e-002;

            __statist_i_h_wts[18, 24] = 2.35740890225078e-002;

            __statist_i_h_wts[18, 25] = 3.34120424569699e-003;

            __statist_i_h_wts[18, 26] = -1.12443455909502e-002;

            __statist_i_h_wts[18, 27] = -7.24047047832134e-003;

            __statist_i_h_wts[18, 28] = 1.69307955029389e-005;

            __statist_i_h_wts[18, 29] = 2.37649592010185e-003;

            __statist_i_h_wts[18, 30] = -2.61469352295214e-002;

            __statist_i_h_wts[18, 31] = 1.42381686757494e-003;

            __statist_i_h_wts[18, 32] = -4.15018680086633e-003;

            __statist_i_h_wts[18, 33] = -9.86327902275243e-003;

            __statist_i_h_wts[18, 34] = 6.03158375493297e-003;

            __statist_i_h_wts[18, 35] = -4.86270155972870e-003;

            __statist_i_h_wts[18, 36] = 9.99178483861879e-003;

            __statist_i_h_wts[18, 37] = 3.50699151600159e-004;

            __statist_i_h_wts[18, 38] = -1.16503520283319e-003;

            __statist_i_h_wts[18, 39] = 3.55264173903531e-003;

            __statist_i_h_wts[18, 40] = -8.41405504672432e-003;

            __statist_i_h_wts[18, 41] = 1.34239493322366e-002;

            __statist_i_h_wts[18, 42] = -1.84980121998526e-002;

            __statist_i_h_wts[18, 43] = 5.66558578507895e-002;

            __statist_i_h_wts[18, 44] = 5.78239182903023e-002;

            __statist_i_h_wts[18, 45] = -1.82838226983109e-001;

            __statist_i_h_wts[18, 46] = 2.27383311828723e-001;

            __statist_i_h_wts[18, 47] = 3.72464208682468e-002;

            __statist_i_h_wts[18, 48] = 8.35122066831082e-001;

            __statist_i_h_wts[18, 49] = -6.21493396639790e-001;

            __statist_i_h_wts[18, 50] = -1.20045906742914e-001;

            __statist_i_h_wts[18, 51] = 2.79163876590812e-002;

            __statist_i_h_wts[18, 52] = 1.38226304549675e-001;

            __statist_i_h_wts[18, 53] = -3.33675150991528e-002;

            __statist_i_h_wts[18, 54] = 9.01087848962759e-002;

            __statist_i_h_wts[18, 55] = 8.33416555394867e-002;

            __statist_i_h_wts[18, 56] = -5.33724243018090e-002;

            __statist_i_h_wts[18, 57] = 1.33064165927889e-001;

            __statist_i_h_wts[18, 58] = -1.30413218065129e-001;

            __statist_i_h_wts[18, 59] = 7.91720437400451e-002;

            __statist_i_h_wts[18, 60] = -2.66645578897761e-004;

            __statist_i_h_wts[18, 61] = 2.23050329571400e-002;

            __statist_i_h_wts[18, 62] = 6.37636395237848e-002;

            __statist_i_h_wts[18, 63] = 1.13882543906037e+000;

            __statist_i_h_wts[18, 64] = -8.46933891853944e-001;

            __statist_i_h_wts[18, 65] = -2.17199747731293e-001;

            __statist_i_h_wts[18, 66] = 1.15132735372206e-001;

            __statist_i_h_wts[18, 67] = 5.91389066597269e-002;

            __statist_i_h_wts[18, 68] = -9.22027548391356e-002;

            __statist_i_h_wts[18, 69] = 1.80297736444192e-001;

            __statist_i_h_wts[18, 70] = 1.44992116879437e-002;

            __statist_i_h_wts[18, 71] = -7.38621594344566e-002;

            __statist_i_h_wts[18, 72] = -1.07027471030058e+000;

            __statist_i_h_wts[18, 73] = 7.40152065845387e-001;

            __statist_i_h_wts[18, 74] = 4.12375341290331e-001;

            __statist_i_h_wts[18, 75] = -1.39527800525627e+000;

            __statist_i_h_wts[18, 76] = 8.32650939398481e-001;

            __statist_i_h_wts[18, 77] = 6.54497213289679e-001;

            __statist_i_h_wts[18, 78] = -8.54178082477324e-001;

            __statist_i_h_wts[18, 79] = 1.13357021513629e+000;

            __statist_i_h_wts[18, 80] = -1.88647694722198e-001;

            __statist_i_h_wts[18, 81] = -6.04854516972519e-001;

            __statist_i_h_wts[18, 82] = 8.54532131740910e-001;

            __statist_i_h_wts[18, 83] = -1.47769318322372e-001;

            __statist_i_h_wts[18, 84] = 1.44802640130155e-001;

            __statist_i_h_wts[18, 85] = -9.76461294880146e-002;

            __statist_i_h_wts[18, 86] = 5.01368190383447e-002;

            __statist_i_h_wts[18, 87] = -2.46797963090145e-002;

            __statist_i_h_wts[18, 88] = 6.11213106211052e-002;

            __statist_i_h_wts[18, 89] = 5.38193135011419e-002;

            __statist_i_h_wts[18, 90] = 1.16865210779459e+000;

            __statist_i_h_wts[18, 91] = -8.81734508047880e-001;

            __statist_i_h_wts[18, 92] = -2.12186428663653e-001;

            __statist_i_h_wts[18, 93] = 1.85602885721438e-001;

            __statist_i_h_wts[18, 94] = -7.45754385711864e-003;

            __statist_i_h_wts[18, 95] = -7.97751789285443e-002;

            __statist_i_h_wts[18, 96] = 2.51636457433161e-001;

            __statist_i_h_wts[18, 97] = -1.11463713852303e-001;

            __statist_i_h_wts[18, 98] = -7.54225939106967e-002;

            __statist_i_h_wts[18, 99] = 2.29066424682826e-002;

            __statist_i_h_wts[18, 100] = -1.90515459087890e-002;

            __statist_i_h_wts[18, 101] = 5.72224525243683e-002;

            __statist_i_h_wts[18, 102] = -1.25840160771506e-001;

            __statist_i_h_wts[18, 103] = 1.25057155866948e-001;

            __statist_i_h_wts[18, 104] = 9.56516716675934e-002;

            __statist_i_h_wts[18, 105] = 9.46392836285863e-001;

            __statist_i_h_wts[18, 106] = -7.33091774238025e-001;

            __statist_i_h_wts[18, 107] = -1.08217354703520e-001;

            __statist_i_h_wts[18, 108] = 9.38530588634821e-002;

            __statist_i_h_wts[18, 109] = 5.22873566225004e-002;

            __statist_i_h_wts[18, 110] = -3.23044309414362e-002;

            __statist_i_h_wts[18, 111] = 2.00074855828285e-001;

            __statist_i_h_wts[18, 112] = -7.35986389083095e-002;

            __statist_i_h_wts[18, 113] = -3.35159206190189e-002;



            double[,] __statist_h_o_wts = new double[2, 19];



            __statist_h_o_wts[0, 0] = -1.11047166196547e-002;

            __statist_h_o_wts[0, 1] = -1.56062275498540e+000;

            __statist_h_o_wts[0, 2] = -1.73164894120751e-001;

            __statist_h_o_wts[0, 3] = -6.97051339615479e-001;

            __statist_h_o_wts[0, 4] = -9.72211778240560e-003;

            __statist_h_o_wts[0, 5] = -4.68938504170636e-001;

            __statist_h_o_wts[0, 6] = -6.63539918768182e-001;

            __statist_h_o_wts[0, 7] = 3.57465152856616e-002;

            __statist_h_o_wts[0, 8] = -9.03234938501567e-002;

            __statist_h_o_wts[0, 9] = -1.78274904638403e+000;

            __statist_h_o_wts[0, 10] = 3.64550715879984e-001;

            __statist_h_o_wts[0, 11] = -1.42128687073571e+000;

            __statist_h_o_wts[0, 12] = 1.32099690940638e+000;

            __statist_h_o_wts[0, 13] = 1.02536401219567e+000;

            __statist_h_o_wts[0, 14] = 6.71264770686556e-002;

            __statist_h_o_wts[0, 15] = -4.87143933474727e-001;

            __statist_h_o_wts[0, 16] = 6.56478988924476e-002;

            __statist_h_o_wts[0, 17] = 1.98870232978665e+000;

            __statist_h_o_wts[0, 18] = 1.58100544966652e-001;



            __statist_h_o_wts[1, 0] = 1.98894523940174e-002;

            __statist_h_o_wts[1, 1] = 1.54249637825186e+000;

            __statist_h_o_wts[1, 2] = 2.16081318427446e-001;

            __statist_h_o_wts[1, 3] = 7.83589778728838e-001;

            __statist_h_o_wts[1, 4] = 7.90999313740692e-003;

            __statist_h_o_wts[1, 5] = 4.77911546730970e-001;

            __statist_h_o_wts[1, 6] = 6.61940554702830e-001;

            __statist_h_o_wts[1, 7] = -4.32848061743822e-002;

            __statist_h_o_wts[1, 8] = 6.98761369217133e-002;

            __statist_h_o_wts[1, 9] = 1.82317042559225e+000;

            __statist_h_o_wts[1, 10] = -3.45916723769152e-001;

            __statist_h_o_wts[1, 11] = 1.46151531579312e+000;

            __statist_h_o_wts[1, 12] = -1.28699898256900e+000;

            __statist_h_o_wts[1, 13] = -1.04740118957449e+000;

            __statist_h_o_wts[1, 14] = -7.96440650124762e-002;

            __statist_h_o_wts[1, 15] = 4.79103851465665e-001;

            __statist_h_o_wts[1, 16] = -5.09352763529113e-002;

            __statist_h_o_wts[1, 17] = -2.01521602097235e+000;

            __statist_h_o_wts[1, 18] = -1.41074099062125e-001;



            double[] __statist_hidden_bias = new double[19];

            __statist_hidden_bias[0] = 1.29845860093766e-001;

            __statist_hidden_bias[1] = 2.41929064644659e-001;

            __statist_hidden_bias[2] = -8.51528288818821e-002;

            __statist_hidden_bias[3] = -4.61697952310290e-002;

            __statist_hidden_bias[4] = 1.79028423788241e-001;

            __statist_hidden_bias[5] = -9.69701643371187e-002;

            __statist_hidden_bias[6] = 1.43199495747703e-001;

            __statist_hidden_bias[7] = -3.56489575539478e-002;

            __statist_hidden_bias[8] = 5.49557096226251e-002;

            __statist_hidden_bias[9] = -1.11195186747610e-001;

            __statist_hidden_bias[10] = -1.87060810796830e-002;

            __statist_hidden_bias[11] = -1.44165374101397e-001;

            __statist_hidden_bias[12] = -5.77832590441885e-002;

            __statist_hidden_bias[13] = -1.09057614013270e-002;

            __statist_hidden_bias[14] = -7.04067520233734e-002;

            __statist_hidden_bias[15] = 7.79591071017365e-002;

            __statist_hidden_bias[16] = 3.45704484651481e-002;

            __statist_hidden_bias[17] = 1.65245401853090e-001;

            __statist_hidden_bias[18] = 8.42650542745324e-002;



            double[] __statist_output_bias = new double[2];

            __statist_output_bias[0] = 1.47756040205204e+000;

            __statist_output_bias[1] = -1.51181360154891e+000;



            double[] __statist_inputs = new double[114];



            double[] __statist_hidden = new double[19];



            double[] __statist_outputs = new double[2];

            __statist_outputs[0] = -1.0e+307;

            __statist_outputs[1] = -1.0e+307;





            if (Var4 == "0")
            {

                __statist_inputs[0] = 1;

            }

            else
            {

                __statist_inputs[0] = 0;

            }



            if (Var4 == "1")
            {

                __statist_inputs[1] = 1;

            }

            else
            {

                __statist_inputs[1] = 0;

            }



            if (Var4 == "10")
            {

                __statist_inputs[2] = 1;

            }

            else
            {

                __statist_inputs[2] = 0;

            }



            if (Var4 == "11")
            {

                __statist_inputs[3] = 1;

            }

            else
            {

                __statist_inputs[3] = 0;

            }



            if (Var4 == "12")
            {

                __statist_inputs[4] = 1;

            }

            else
            {

                __statist_inputs[4] = 0;

            }



            if (Var4 == "13")
            {

                __statist_inputs[5] = 1;

            }

            else
            {

                __statist_inputs[5] = 0;

            }



            if (Var4 == "14")
            {

                __statist_inputs[6] = 1;

            }

            else
            {

                __statist_inputs[6] = 0;

            }



            if (Var4 == "15")
            {

                __statist_inputs[7] = 1;

            }

            else
            {

                __statist_inputs[7] = 0;

            }



            if (Var4 == "16")
            {

                __statist_inputs[8] = 1;

            }

            else
            {

                __statist_inputs[8] = 0;

            }



            if (Var4 == "17")
            {

                __statist_inputs[9] = 1;

            }

            else
            {

                __statist_inputs[9] = 0;

            }



            if (Var4 == "18")
            {

                __statist_inputs[10] = 1;

            }

            else
            {

                __statist_inputs[10] = 0;

            }



            if (Var4 == "19")
            {

                __statist_inputs[11] = 1;

            }

            else
            {

                __statist_inputs[11] = 0;

            }



            if (Var4 == "2")
            {

                __statist_inputs[12] = 1;

            }

            else
            {

                __statist_inputs[12] = 0;

            }



            if (Var4 == "20")
            {

                __statist_inputs[13] = 1;

            }

            else
            {

                __statist_inputs[13] = 0;

            }



            if (Var4 == "21")
            {

                __statist_inputs[14] = 1;

            }

            else
            {

                __statist_inputs[14] = 0;

            }



            if (Var4 == "22")
            {

                __statist_inputs[15] = 1;

            }

            else
            {

                __statist_inputs[15] = 0;

            }



            if (Var4 == "23")
            {

                __statist_inputs[16] = 1;

            }

            else
            {

                __statist_inputs[16] = 0;

            }



            if (Var4 == "24")
            {

                __statist_inputs[17] = 1;

            }

            else
            {

                __statist_inputs[17] = 0;

            }



            if (Var4 == "25")
            {

                __statist_inputs[18] = 1;

            }

            else
            {

                __statist_inputs[18] = 0;

            }



            if (Var4 == "26")
            {

                __statist_inputs[19] = 1;

            }

            else
            {

                __statist_inputs[19] = 0;

            }



            if (Var4 == "27")
            {

                __statist_inputs[20] = 1;

            }

            else
            {

                __statist_inputs[20] = 0;

            }



            if (Var4 == "28")
            {

                __statist_inputs[21] = 1;

            }

            else
            {

                __statist_inputs[21] = 0;

            }



            if (Var4 == "29")
            {

                __statist_inputs[22] = 1;

            }

            else
            {

                __statist_inputs[22] = 0;

            }



            if (Var4 == "3")
            {

                __statist_inputs[23] = 1;

            }

            else
            {

                __statist_inputs[23] = 0;

            }



            if (Var4 == "30")
            {

                __statist_inputs[24] = 1;

            }

            else
            {

                __statist_inputs[24] = 0;

            }



            if (Var4 == "31")
            {

                __statist_inputs[25] = 1;

            }

            else
            {

                __statist_inputs[25] = 0;

            }



            if (Var4 == "32")
            {

                __statist_inputs[26] = 1;

            }

            else
            {

                __statist_inputs[26] = 0;

            }



            if (Var4 == "33")
            {

                __statist_inputs[27] = 1;

            }

            else
            {

                __statist_inputs[27] = 0;

            }



            if (Var4 == "34")
            {

                __statist_inputs[28] = 1;

            }

            else
            {

                __statist_inputs[28] = 0;

            }



            if (Var4 == "35")
            {

                __statist_inputs[29] = 1;

            }

            else
            {

                __statist_inputs[29] = 0;

            }



            if (Var4 == "36")
            {

                __statist_inputs[30] = 1;

            }

            else
            {

                __statist_inputs[30] = 0;

            }



            if (Var4 == "37")
            {

                __statist_inputs[31] = 1;

            }

            else
            {

                __statist_inputs[31] = 0;

            }



            if (Var4 == "38")
            {

                __statist_inputs[32] = 1;

            }

            else
            {

                __statist_inputs[32] = 0;

            }



            if (Var4 == "39")
            {

                __statist_inputs[33] = 1;

            }

            else
            {

                __statist_inputs[33] = 0;

            }



            if (Var4 == "4")
            {

                __statist_inputs[34] = 1;

            }

            else
            {

                __statist_inputs[34] = 0;

            }



            if (Var4 == "40")
            {

                __statist_inputs[35] = 1;

            }

            else
            {

                __statist_inputs[35] = 0;

            }



            if (Var4 == "41")
            {

                __statist_inputs[36] = 1;

            }

            else
            {

                __statist_inputs[36] = 0;

            }



            if (Var4 == "5")
            {

                __statist_inputs[37] = 1;

            }

            else
            {

                __statist_inputs[37] = 0;

            }



            if (Var4 == "6")
            {

                __statist_inputs[38] = 1;

            }

            else
            {

                __statist_inputs[38] = 0;

            }



            if (Var4 == "7")
            {

                __statist_inputs[39] = 1;

            }

            else
            {

                __statist_inputs[39] = 0;

            }



            if (Var4 == "8")
            {

                __statist_inputs[40] = 1;

            }

            else
            {

                __statist_inputs[40] = 0;

            }



            if (Var4 == "9")
            {

                __statist_inputs[41] = 1;

            }

            else
            {

                __statist_inputs[41] = 0;

            }



            if (Var6 == "0")
            {

                __statist_inputs[42] = 1;

            }

            else
            {

                __statist_inputs[42] = 0;

            }



            if (Var6 == "1")
            {

                __statist_inputs[43] = 1;

            }

            else
            {

                __statist_inputs[43] = 0;

            }



            if (Var6 == "2")
            {

                __statist_inputs[44] = 1;

            }

            else
            {

                __statist_inputs[44] = 0;

            }



            if (Var7 == "0")
            {

                __statist_inputs[45] = 1;

            }

            else
            {

                __statist_inputs[45] = 0;

            }



            if (Var7 == "1")
            {

                __statist_inputs[46] = 1;

            }

            else
            {

                __statist_inputs[46] = 0;

            }



            if (Var7 == "2")
            {

                __statist_inputs[47] = 1;

            }

            else
            {

                __statist_inputs[47] = 0;

            }



            if (Var8 == "0")
            {

                __statist_inputs[48] = 1;

            }

            else
            {

                __statist_inputs[48] = 0;

            }



            if (Var8 == "1")
            {

                __statist_inputs[49] = 1;

            }

            else
            {

                __statist_inputs[49] = 0;

            }



            if (Var8 == "2")
            {

                __statist_inputs[50] = 1;

            }

            else
            {

                __statist_inputs[50] = 0;

            }



            if (Var9 == "0")
            {

                __statist_inputs[51] = 1;

            }

            else
            {

                __statist_inputs[51] = 0;

            }



            if (Var9 == "1")
            {

                __statist_inputs[52] = 1;

            }

            else
            {

                __statist_inputs[52] = 0;

            }



            if (Var9 == "2")
            {

                __statist_inputs[53] = 1;

            }

            else
            {

                __statist_inputs[53] = 0;

            }



            if (Var10 == "0")
            {

                __statist_inputs[54] = 1;

            }

            else
            {

                __statist_inputs[54] = 0;

            }



            if (Var10 == "1")
            {

                __statist_inputs[55] = 1;

            }

            else
            {

                __statist_inputs[55] = 0;

            }



            if (Var10 == "2")
            {

                __statist_inputs[56] = 1;

            }

            else
            {

                __statist_inputs[56] = 0;

            }



            if (Var11 == "0")
            {

                __statist_inputs[57] = 1;

            }

            else
            {

                __statist_inputs[57] = 0;

            }



            if (Var11 == "1")
            {

                __statist_inputs[58] = 1;

            }

            else
            {

                __statist_inputs[58] = 0;

            }



            if (Var11 == "2")
            {

                __statist_inputs[59] = 1;

            }

            else
            {

                __statist_inputs[59] = 0;

            }



            if (Var12 == "0")
            {

                __statist_inputs[60] = 1;

            }

            else
            {

                __statist_inputs[60] = 0;

            }



            if (Var12 == "1")
            {

                __statist_inputs[61] = 1;

            }

            else
            {

                __statist_inputs[61] = 0;

            }



            if (Var12 == "2")
            {

                __statist_inputs[62] = 1;

            }

            else
            {

                __statist_inputs[62] = 0;

            }



            if (Var13 == "0")
            {

                __statist_inputs[63] = 1;

            }

            else
            {

                __statist_inputs[63] = 0;

            }



            if (Var13 == "1")
            {

                __statist_inputs[64] = 1;

            }

            else
            {

                __statist_inputs[64] = 0;

            }



            if (Var13 == "2")
            {

                __statist_inputs[65] = 1;

            }

            else
            {

                __statist_inputs[65] = 0;

            }



            if (Var14 == "0")
            {

                __statist_inputs[66] = 1;

            }

            else
            {

                __statist_inputs[66] = 0;

            }



            if (Var14 == "1")
            {

                __statist_inputs[67] = 1;

            }

            else
            {

                __statist_inputs[67] = 0;

            }



            if (Var14 == "2")
            {

                __statist_inputs[68] = 1;

            }

            else
            {

                __statist_inputs[68] = 0;

            }



            if (Var15 == "0")
            {

                __statist_inputs[69] = 1;

            }

            else
            {

                __statist_inputs[69] = 0;

            }



            if (Var15 == "1")
            {

                __statist_inputs[70] = 1;

            }

            else
            {

                __statist_inputs[70] = 0;

            }



            if (Var15 == "2")
            {

                __statist_inputs[71] = 1;

            }

            else
            {

                __statist_inputs[71] = 0;

            }



            if (Var16 == "0")
            {

                __statist_inputs[72] = 1;

            }

            else
            {

                __statist_inputs[72] = 0;

            }



            if (Var16 == "1")
            {

                __statist_inputs[73] = 1;

            }

            else
            {

                __statist_inputs[73] = 0;

            }



            if (Var16 == "2")
            {

                __statist_inputs[74] = 1;

            }

            else
            {

                __statist_inputs[74] = 0;

            }



            if (Var17 == "0")
            {

                __statist_inputs[75] = 1;

            }

            else
            {

                __statist_inputs[75] = 0;

            }



            if (Var17 == "1")
            {

                __statist_inputs[76] = 1;

            }

            else
            {

                __statist_inputs[76] = 0;

            }



            if (Var17 == "2")
            {

                __statist_inputs[77] = 1;

            }

            else
            {

                __statist_inputs[77] = 0;

            }



            if (Var19 == "0")
            {

                __statist_inputs[78] = 1;

            }

            else
            {

                __statist_inputs[78] = 0;

            }



            if (Var19 == "1")
            {

                __statist_inputs[79] = 1;

            }

            else
            {

                __statist_inputs[79] = 0;

            }



            if (Var19 == "2")
            {

                __statist_inputs[80] = 1;

            }

            else
            {

                __statist_inputs[80] = 0;

            }



            if (Var20 == "0")
            {

                __statist_inputs[81] = 1;

            }

            else
            {

                __statist_inputs[81] = 0;

            }



            if (Var20 == "1")
            {

                __statist_inputs[82] = 1;

            }

            else
            {

                __statist_inputs[82] = 0;

            }



            if (Var20 == "2")
            {

                __statist_inputs[83] = 1;

            }

            else
            {

                __statist_inputs[83] = 0;

            }



            if (Var21 == "0")
            {

                __statist_inputs[84] = 1;

            }

            else
            {

                __statist_inputs[84] = 0;

            }



            if (Var21 == "1")
            {

                __statist_inputs[85] = 1;

            }

            else
            {

                __statist_inputs[85] = 0;

            }



            if (Var21 == "2")
            {

                __statist_inputs[86] = 1;

            }

            else
            {

                __statist_inputs[86] = 0;

            }



            if (Var22 == "0")
            {

                __statist_inputs[87] = 1;

            }

            else
            {

                __statist_inputs[87] = 0;

            }



            if (Var22 == "1")
            {

                __statist_inputs[88] = 1;

            }

            else
            {

                __statist_inputs[88] = 0;

            }



            if (Var22 == "2")
            {

                __statist_inputs[89] = 1;

            }

            else
            {

                __statist_inputs[89] = 0;

            }



            if (Var23 == "0")
            {

                __statist_inputs[90] = 1;

            }

            else
            {

                __statist_inputs[90] = 0;

            }



            if (Var23 == "1")
            {

                __statist_inputs[91] = 1;

            }

            else
            {

                __statist_inputs[91] = 0;

            }



            if (Var23 == "2")
            {

                __statist_inputs[92] = 1;

            }

            else
            {

                __statist_inputs[92] = 0;

            }



            if (Var24 == "0")
            {

                __statist_inputs[93] = 1;

            }

            else
            {

                __statist_inputs[93] = 0;

            }



            if (Var24 == "1")
            {

                __statist_inputs[94] = 1;

            }

            else
            {

                __statist_inputs[94] = 0;

            }



            if (Var24 == "2")
            {

                __statist_inputs[95] = 1;

            }

            else
            {

                __statist_inputs[95] = 0;

            }



            if (Var25 == "0")
            {

                __statist_inputs[96] = 1;

            }

            else
            {

                __statist_inputs[96] = 0;

            }



            if (Var25 == "1")
            {

                __statist_inputs[97] = 1;

            }

            else
            {

                __statist_inputs[97] = 0;

            }



            if (Var25 == "2")
            {

                __statist_inputs[98] = 1;

            }

            else
            {

                __statist_inputs[98] = 0;

            }



            if (Var26 == "0")
            {

                __statist_inputs[99] = 1;

            }

            else
            {

                __statist_inputs[99] = 0;

            }



            if (Var26 == "1")
            {

                __statist_inputs[100] = 1;

            }

            else
            {

                __statist_inputs[100] = 0;

            }



            if (Var26 == "2")
            {

                __statist_inputs[101] = 1;

            }

            else
            {

                __statist_inputs[101] = 0;

            }



            if (Var27 == "0")
            {

                __statist_inputs[102] = 1;

            }

            else
            {

                __statist_inputs[102] = 0;

            }



            if (Var27 == "1")
            {

                __statist_inputs[103] = 1;

            }

            else
            {

                __statist_inputs[103] = 0;

            }



            if (Var27 == "2")
            {

                __statist_inputs[104] = 1;

            }

            else
            {

                __statist_inputs[104] = 0;

            }



            if (Var28 == "0")
            {

                __statist_inputs[105] = 1;

            }

            else
            {

                __statist_inputs[105] = 0;

            }



            if (Var28 == "1")
            {

                __statist_inputs[106] = 1;

            }

            else
            {

                __statist_inputs[106] = 0;

            }



            if (Var28 == "2")
            {

                __statist_inputs[107] = 1;

            }

            else
            {

                __statist_inputs[107] = 0;

            }



            if (Var29 == "0")
            {

                __statist_inputs[108] = 1;

            }

            else
            {

                __statist_inputs[108] = 0;

            }



            if (Var29 == "1")
            {

                __statist_inputs[109] = 1;

            }

            else
            {

                __statist_inputs[109] = 0;

            }



            if (Var29 == "2")
            {

                __statist_inputs[110] = 1;

            }

            else
            {

                __statist_inputs[110] = 0;

            }



            if (Var30 == "0")
            {

                __statist_inputs[111] = 1;

            }

            else
            {

                __statist_inputs[111] = 0;

            }



            if (Var30 == "1")
            {

                __statist_inputs[112] = 1;

            }

            else
            {

                __statist_inputs[112] = 0;

            }



            if (Var30 == "2")
            {

                __statist_inputs[113] = 1;

            }

            else
            {

                __statist_inputs[113] = 0;

            }



            double __statist_delta = 0;

            double __statist_maximum = 1;

            double __statist_minimum = 0;

            int __statist_ninputs = 114;

            int __statist_nhidden = 19;



            /*Compute feed forward signals from Input layer to hidden layer*/

            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                __statist_hidden[__statist_row] = 0.0;

                for (int __statist_col = 0; __statist_col < __statist_ninputs; __statist_col++)
                {

                    __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + (__statist_i_h_wts[__statist_row, __statist_col] * __statist_inputs[__statist_col]);

                }

                __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + __statist_hidden_bias[__statist_row];

            }



            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                if (__statist_hidden[__statist_row] > 100.0)
                {

                    __statist_hidden[__statist_row] = 1.0;

                }

                else
                {

                    if (__statist_hidden[__statist_row] < -100.0)
                    {

                        __statist_hidden[__statist_row] = -1.0;

                    }

                    else
                    {

                        __statist_hidden[__statist_row] = Math.Tanh(__statist_hidden[__statist_row]);

                    }

                }

            }



            int __statist_noutputs = 2;



            /*Compute feed forward signals from hidden layer to output layer*/

            for (int __statist_row2 = 0; __statist_row2 < __statist_noutputs; __statist_row2++)
            {

                __statist_outputs[__statist_row2] = 0.0;

                for (int __statist_col2 = 0; __statist_col2 < __statist_nhidden; __statist_col2++)
                {

                    __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + (__statist_h_o_wts[__statist_row2, __statist_col2] * __statist_hidden[__statist_col2]);

                }

                __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + __statist_output_bias[__statist_row2];

            }





            double __statist_sum = 0.0;

            double __statist_maxIndex = 0;

            for (int __statist_jj = 0; __statist_jj < __statist_noutputs; __statist_jj++)
            {

                if (__statist_outputs[__statist_jj] > 200)
                {

                    double __statist_max = __statist_outputs[1];

                    __statist_maxIndex = 0;

                    for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
                    {

                        if (__statist_outputs[__statist_ii] > __statist_max)
                        {

                            __statist_max = __statist_outputs[__statist_ii];

                            __statist_maxIndex = __statist_ii;

                        }

                    }



                    for (int __statist_kk = 0; __statist_kk < __statist_noutputs; __statist_kk++)
                    {

                        if (__statist_kk == __statist_maxIndex)
                        {

                            __statist_outputs[__statist_jj] = 1.0;

                        }

                        else
                        {

                            __statist_outputs[__statist_kk] = 0.0;

                        }

                    }

                }

                else
                {

                    __statist_outputs[__statist_jj] = Math.Exp(__statist_outputs[__statist_jj]);

                    __statist_sum = __statist_sum + __statist_outputs[__statist_jj];

                }

            }

            for (int __statist_ll = 0; __statist_ll < __statist_noutputs; __statist_ll++)
            {

                if (__statist_sum != 0)
                {

                    __statist_outputs[__statist_ll] = __statist_outputs[__statist_ll] / __statist_sum;

                }

            }



            int __statist_PredIndex = 1;

            for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
            {

                if (__statist_ConfLevel < __statist_outputs[__statist_ii])
                {

                    __statist_ConfLevel = __statist_outputs[__statist_ii];

                    __statist_PredIndex = __statist_ii;

                }

            }



            __statist_PredCat = __statist_DCats[__statist_PredIndex];

            string[] prediction = new string[2] { __statist_PredCat, __statist_ConfLevel.ToString() };

            return prediction;
        }



        public static string[] Main(string[] args)
        {
            int argID = 0;

            string[] CatInputs = new string[25];

            int catID = 0;

            if (args.Length >= 25)
            {

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

            }

            else
            {

                string Comment = "";

                string Comment1 = "**************************************************************************\n";

                Comment += Comment1;

                string Comment2 = "Please enter at least NaN command line parameters in the following order for \nthe program to Predict.\n";

                Comment += Comment2;

                Comment += Comment1;

                string Comment3 = "Var4  Type - String (categories are { \"0\"  \"1\"  \"10\"  \"11\"  \"12\"  \"13\"  \"14\"  \"15\"  \"16\"  \"17\"  \"18\"  \"19\"  \"2\"  \"20\"  \"21\"  \"22\"  \"23\"  \"24\"  \"25\"  \"26\"  \"27\"  \"28\"  \"29\"  \"3\"  \"30\"  \"31\"  \"32\"  \"33\"  \"34\"  \"35\"  \"36\"  \"37\"  \"38\"  \"39\"  \"4\"  \"40\"  \"41\"  \"5\"  \"6\"  \"7\"  \"8\"  \"9\" } )\n";

                Comment += Comment3;

                string Comment4 = "Var6  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment4;

                string Comment5 = "Var7  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment5;

                string Comment6 = "Var8  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment6;

                string Comment7 = "Var9  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment7;

                string Comment8 = "Var10  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment8;

                string Comment9 = "Var11  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment9;

                string Comment10 = "Var12  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment10;

                string Comment11 = "Var13  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment11;

                string Comment12 = "Var14  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment12;

                string Comment13 = "Var15  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment13;

                string Comment14 = "Var16  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment14;

                string Comment15 = "Var17  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment15;

                string Comment16 = "Var20  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment16;

                string Comment17 = "Var21  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment17;

                string Comment18 = "Var22  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment18;

                string Comment19 = "Var23  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment19;

                string Comment20 = "Var24  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment20;

                string Comment21 = "Var25  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment21;

                string Comment22 = "Var26  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment22;

                string Comment23 = "Var27  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment23;

                string Comment24 = "Var28  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment24;

                string Comment25 = "Var29  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment25;

                string Comment26 = "Var30  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment26;

                string Comment27 = "Var19  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment27;

                Comment += Comment1;

                return new string[] { Comment };

            }

            return MLP_114_19_2(CatInputs);

        }
    }
}
