﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nn4
{
    class Predict_Top
    {
        public static string[] MLP_114_14_2(string[] CatInputs)
        {
            int Cat_idx = 0;

            string Var4 = CatInputs[Cat_idx++]; //Input Variable

            string Var6 = CatInputs[Cat_idx++]; //Input Variable

            string Var7 = CatInputs[Cat_idx++]; //Input Variable

            string Var8 = CatInputs[Cat_idx++]; //Input Variable

            string Var9 = CatInputs[Cat_idx++]; //Input Variable

            string Var10 = CatInputs[Cat_idx++]; //Input Variable

            string Var11 = CatInputs[Cat_idx++]; //Input Variable

            string Var12 = CatInputs[Cat_idx++]; //Input Variable

            string Var13 = CatInputs[Cat_idx++]; //Input Variable

            string Var14 = CatInputs[Cat_idx++]; //Input Variable

            string Var15 = CatInputs[Cat_idx++]; //Input Variable

            string Var16 = CatInputs[Cat_idx++]; //Input Variable

            string Var17 = CatInputs[Cat_idx++]; //Input Variable

            string Var19 = CatInputs[Cat_idx++]; //Input Variable

            string Var20 = CatInputs[Cat_idx++]; //Input Variable

            string Var21 = CatInputs[Cat_idx++]; //Input Variable

            string Var22 = CatInputs[Cat_idx++]; //Input Variable

            string Var23 = CatInputs[Cat_idx++]; //Input Variable

            string Var24 = CatInputs[Cat_idx++]; //Input Variable

            string Var25 = CatInputs[Cat_idx++]; //Input Variable

            string Var26 = CatInputs[Cat_idx++]; //Input Variable

            string Var27 = CatInputs[Cat_idx++]; //Input Variable

            string Var28 = CatInputs[Cat_idx++]; //Input Variable

            string Var29 = CatInputs[Cat_idx++]; //Input Variable

            string Var30 = CatInputs[Cat_idx++]; //Input Variable

            string __statist_PredCat = "";

            string[] __statist_DCats = new string[2];

            __statist_DCats[0] = "0";

            __statist_DCats[1] = "1";



            double __statist_ConfLevel = 3.0E-300;







            double[,] __statist_i_h_wts = new double[14, 114];



            __statist_i_h_wts[0, 0] = -1.52684034849604e-003;

            __statist_i_h_wts[0, 1] = -1.33706124200056e-002;

            __statist_i_h_wts[0, 2] = 4.00977057066708e-002;

            __statist_i_h_wts[0, 3] = 5.46172005244968e-002;

            __statist_i_h_wts[0, 4] = -4.97415917139191e-002;

            __statist_i_h_wts[0, 5] = -2.77485453710908e-002;

            __statist_i_h_wts[0, 6] = 5.67832230261099e-002;

            __statist_i_h_wts[0, 7] = -6.14084260610329e-002;

            __statist_i_h_wts[0, 8] = -8.06739773242950e-003;

            __statist_i_h_wts[0, 9] = -2.71037183236090e-002;

            __statist_i_h_wts[0, 10] = 2.12768334387899e-002;

            __statist_i_h_wts[0, 11] = -1.61402940573653e-002;

            __statist_i_h_wts[0, 12] = 3.15618365630871e-002;

            __statist_i_h_wts[0, 13] = 1.40639989043052e-002;

            __statist_i_h_wts[0, 14] = 1.13792124961325e-002;

            __statist_i_h_wts[0, 15] = -5.97827727363600e-002;

            __statist_i_h_wts[0, 16] = 1.55893981927131e-002;

            __statist_i_h_wts[0, 17] = -8.83894184967205e-003;

            __statist_i_h_wts[0, 18] = 2.37624257884380e-002;

            __statist_i_h_wts[0, 19] = -3.16052845553436e-002;

            __statist_i_h_wts[0, 20] = 2.63302815149095e-003;

            __statist_i_h_wts[0, 21] = -1.33774548162607e-002;

            __statist_i_h_wts[0, 22] = -1.96361141019705e-003;

            __statist_i_h_wts[0, 23] = -1.27485902661855e-002;

            __statist_i_h_wts[0, 24] = 1.12585530890128e-002;

            __statist_i_h_wts[0, 25] = 8.62842225836706e-003;

            __statist_i_h_wts[0, 26] = -2.20678037735742e-002;

            __statist_i_h_wts[0, 27] = -6.99308846479276e-004;

            __statist_i_h_wts[0, 28] = -3.61723174661208e-002;

            __statist_i_h_wts[0, 29] = -2.88795426189068e-002;

            __statist_i_h_wts[0, 30] = 4.07662410308457e-002;

            __statist_i_h_wts[0, 31] = 5.83816165588629e-003;

            __statist_i_h_wts[0, 32] = -4.96097928483734e-002;

            __statist_i_h_wts[0, 33] = 7.51091015398739e-003;

            __statist_i_h_wts[0, 34] = -7.49408766131141e-004;

            __statist_i_h_wts[0, 35] = 2.84308218776028e-002;

            __statist_i_h_wts[0, 36] = -4.59268700095257e-003;

            __statist_i_h_wts[0, 37] = -1.95400345349265e-002;

            __statist_i_h_wts[0, 38] = 3.06125888922009e-002;

            __statist_i_h_wts[0, 39] = -2.97222952318873e-002;

            __statist_i_h_wts[0, 40] = 6.25215334088235e-003;

            __statist_i_h_wts[0, 41] = 1.04660245394391e-002;

            __statist_i_h_wts[0, 42] = 9.86320800563849e-002;

            __statist_i_h_wts[0, 43] = 3.29985920649929e-002;

            __statist_i_h_wts[0, 44] = -1.26506336374857e-001;

            __statist_i_h_wts[0, 45] = -1.64990278743185e-003;

            __statist_i_h_wts[0, 46] = 1.29938471232527e-001;

            __statist_i_h_wts[0, 47] = -1.86342458375266e-001;

            __statist_i_h_wts[0, 48] = 1.77661014103509e-001;

            __statist_i_h_wts[0, 49] = 2.61827723349745e-001;

            __statist_i_h_wts[0, 50] = -4.84591615292087e-001;

            __statist_i_h_wts[0, 51] = 1.37621326182928e-002;

            __statist_i_h_wts[0, 52] = 1.12980323790161e-001;

            __statist_i_h_wts[0, 53] = -1.50928239480575e-001;

            __statist_i_h_wts[0, 54] = 4.91653706118053e-002;

            __statist_i_h_wts[0, 55] = 6.67738380469244e-003;

            __statist_i_h_wts[0, 56] = -9.94838532031221e-002;

            __statist_i_h_wts[0, 57] = 8.72504325099318e-002;

            __statist_i_h_wts[0, 58] = -7.84495414111604e-002;

            __statist_i_h_wts[0, 59] = -5.50866550436981e-002;

            __statist_i_h_wts[0, 60] = 3.09401142420254e-002;

            __statist_i_h_wts[0, 61] = 8.16376258094864e-002;

            __statist_i_h_wts[0, 62] = -1.16464911493723e-001;

            __statist_i_h_wts[0, 63] = 5.46359226041159e-001;

            __statist_i_h_wts[0, 64] = 2.16216827076063e-001;

            __statist_i_h_wts[0, 65] = -7.92404922759735e-001;

            __statist_i_h_wts[0, 66] = -6.71852629329914e-004;

            __statist_i_h_wts[0, 67] = 1.71903927847078e-001;

            __statist_i_h_wts[0, 68] = -1.81886109495793e-001;

            __statist_i_h_wts[0, 69] = 5.07853697903768e-002;

            __statist_i_h_wts[0, 70] = 1.56401426205047e-002;

            __statist_i_h_wts[0, 71] = -1.03250997513965e-001;

            __statist_i_h_wts[0, 72] = 6.16717468662357e-003;

            __statist_i_h_wts[0, 73] = -1.32126403638764e-001;

            __statist_i_h_wts[0, 74] = 7.08214380708642e-002;

            __statist_i_h_wts[0, 75] = -1.95272534185051e-001;

            __statist_i_h_wts[0, 76] = -2.13853010906895e-001;

            __statist_i_h_wts[0, 77] = 3.84245267657306e-001;

            __statist_i_h_wts[0, 78] = -2.14802396862099e-001;

            __statist_i_h_wts[0, 79] = -9.06508105650363e-002;

            __statist_i_h_wts[0, 80] = 2.74345001744162e-001;

            __statist_i_h_wts[0, 81] = 4.76425368145374e-002;

            __statist_i_h_wts[0, 82] = -1.44138547158015e-001;

            __statist_i_h_wts[0, 83] = 8.79343641473924e-002;

            __statist_i_h_wts[0, 84] = 3.52070625653479e-002;

            __statist_i_h_wts[0, 85] = -1.59638005408692e-001;

            __statist_i_h_wts[0, 86] = 8.12514745436708e-002;

            __statist_i_h_wts[0, 87] = -1.61483439529365e-001;

            __statist_i_h_wts[0, 88] = -1.60942072594615e-001;

            __statist_i_h_wts[0, 89] = 2.65457239941963e-001;

            __statist_i_h_wts[0, 90] = -2.13345862705097e-001;

            __statist_i_h_wts[0, 91] = -2.82638739882491e-001;

            __statist_i_h_wts[0, 92] = 4.67228356096381e-001;

            __statist_i_h_wts[0, 93] = -1.94836990050155e-001;

            __statist_i_h_wts[0, 94] = -8.07550627260561e-002;

            __statist_i_h_wts[0, 95] = 2.38694622406478e-001;

            __statist_i_h_wts[0, 96] = -1.06449066829281e-001;

            __statist_i_h_wts[0, 97] = -5.50960791250928e-002;

            __statist_i_h_wts[0, 98] = 1.20656133139014e-001;

            __statist_i_h_wts[0, 99] = -4.08289212470245e-003;

            __statist_i_h_wts[0, 100] = -1.59598374129890e-001;

            __statist_i_h_wts[0, 101] = 1.32997135018382e-001;

            __statist_i_h_wts[0, 102] = -1.43368454368272e-001;

            __statist_i_h_wts[0, 103] = -8.66717206702758e-002;

            __statist_i_h_wts[0, 104] = 2.08462688772717e-001;

            __statist_i_h_wts[0, 105] = -2.38839948933212e-001;

            __statist_i_h_wts[0, 106] = -1.36925400805785e-001;

            __statist_i_h_wts[0, 107] = 3.66488430560467e-001;

            __statist_i_h_wts[0, 108] = -2.17030958896194e-001;

            __statist_i_h_wts[0, 109] = 3.18043469411173e-003;

            __statist_i_h_wts[0, 110] = 1.91110397577568e-001;

            __statist_i_h_wts[0, 111] = -7.41450856458598e-002;

            __statist_i_h_wts[0, 112] = -7.75267256066361e-002;

            __statist_i_h_wts[0, 113] = 1.46769920019061e-001;



            __statist_i_h_wts[1, 0] = 8.40507311540281e-002;

            __statist_i_h_wts[1, 1] = -5.94692262330703e-002;

            __statist_i_h_wts[1, 2] = 4.44619925845312e-002;

            __statist_i_h_wts[1, 3] = 4.38556499545675e-002;

            __statist_i_h_wts[1, 4] = -1.05185632995627e-001;

            __statist_i_h_wts[1, 5] = 4.35684714847047e-002;

            __statist_i_h_wts[1, 6] = 9.01263346545876e-003;

            __statist_i_h_wts[1, 7] = -3.96139028752559e-002;

            __statist_i_h_wts[1, 8] = 2.07295436737943e-002;

            __statist_i_h_wts[1, 9] = -9.67890851811045e-003;

            __statist_i_h_wts[1, 10] = 2.79928387085474e-002;

            __statist_i_h_wts[1, 11] = -3.54060180449197e-002;

            __statist_i_h_wts[1, 12] = -1.90597036291577e-002;

            __statist_i_h_wts[1, 13] = -1.06518208359041e-002;

            __statist_i_h_wts[1, 14] = -2.54315366406048e-002;

            __statist_i_h_wts[1, 15] = -4.78236413623421e-002;

            __statist_i_h_wts[1, 16] = 5.95271607442999e-002;

            __statist_i_h_wts[1, 17] = -8.19849739451892e-003;

            __statist_i_h_wts[1, 18] = 2.84993111463425e-002;

            __statist_i_h_wts[1, 19] = -6.41766681518074e-003;

            __statist_i_h_wts[1, 20] = 2.90378006054741e-002;

            __statist_i_h_wts[1, 21] = -1.94038856348296e-002;

            __statist_i_h_wts[1, 22] = 2.70872729848065e-002;

            __statist_i_h_wts[1, 23] = -1.86349145168806e-002;

            __statist_i_h_wts[1, 24] = -5.92555595464183e-003;

            __statist_i_h_wts[1, 25] = 7.82976255580500e-002;

            __statist_i_h_wts[1, 26] = 4.24038876457297e-003;

            __statist_i_h_wts[1, 27] = 5.73274835137166e-002;

            __statist_i_h_wts[1, 28] = -9.58358049819856e-003;

            __statist_i_h_wts[1, 29] = -6.74116190057343e-002;

            __statist_i_h_wts[1, 30] = 2.69809580689548e-003;

            __statist_i_h_wts[1, 31] = 4.93788375081273e-002;

            __statist_i_h_wts[1, 32] = -5.07842009404093e-002;

            __statist_i_h_wts[1, 33] = 3.01427942448962e-002;

            __statist_i_h_wts[1, 34] = -4.30756530814568e-003;

            __statist_i_h_wts[1, 35] = 3.69186801930521e-002;

            __statist_i_h_wts[1, 36] = -5.34283230764449e-003;

            __statist_i_h_wts[1, 37] = -5.93690678317676e-002;

            __statist_i_h_wts[1, 38] = 6.09451320231671e-002;

            __statist_i_h_wts[1, 39] = 8.05484509757266e-003;

            __statist_i_h_wts[1, 40] = -5.26113750267355e-002;

            __statist_i_h_wts[1, 41] = 1.67045901446394e-002;

            __statist_i_h_wts[1, 42] = 6.18265506572590e-002;

            __statist_i_h_wts[1, 43] = 7.62641311360237e-002;

            __statist_i_h_wts[1, 44] = -1.55773531389229e-001;

            __statist_i_h_wts[1, 45] = -9.54869165401289e-002;

            __statist_i_h_wts[1, 46] = 1.99868148162676e-001;

            __statist_i_h_wts[1, 47] = -1.47753224011737e-001;

            __statist_i_h_wts[1, 48] = 1.17553477443911e+000;

            __statist_i_h_wts[1, 49] = -1.47253749036563e-001;

            __statist_i_h_wts[1, 50] = -1.04737471007906e+000;

            __statist_i_h_wts[1, 51] = -1.78087118896243e-001;

            __statist_i_h_wts[1, 52] = 3.77720560323191e-001;

            __statist_i_h_wts[1, 53] = -2.11082736485523e-001;

            __statist_i_h_wts[1, 54] = 3.91251890679933e-002;

            __statist_i_h_wts[1, 55] = 1.43998101318783e-001;

            __statist_i_h_wts[1, 56] = -2.03378900812844e-001;

            __statist_i_h_wts[1, 57] = 4.14466688186602e-001;

            __statist_i_h_wts[1, 58] = -3.99066714607228e-001;

            __statist_i_h_wts[1, 59] = -2.20945427920913e-002;

            __statist_i_h_wts[1, 60] = 3.77685270979046e-001;

            __statist_i_h_wts[1, 61] = -1.00162524552442e-001;

            __statist_i_h_wts[1, 62] = -2.88561877677495e-001;

            __statist_i_h_wts[1, 63] = 2.41580916454277e+000;

            __statist_i_h_wts[1, 64] = -3.06043146078250e-001;

            __statist_i_h_wts[1, 65] = -2.10333458516932e+000;

            __statist_i_h_wts[1, 66] = 2.42380434543246e-001;

            __statist_i_h_wts[1, 67] = -7.80357162222134e-002;

            __statist_i_h_wts[1, 68] = -1.89486843276409e-001;

            __statist_i_h_wts[1, 69] = 1.75388123727762e-001;

            __statist_i_h_wts[1, 70] = -8.41579550926254e-002;

            __statist_i_h_wts[1, 71] = -1.03724451544252e-001;

            __statist_i_h_wts[1, 72] = -1.40471255243931e-001;

            __statist_i_h_wts[1, 73] = -6.40012364547611e-002;

            __statist_i_h_wts[1, 74] = 1.95044913721123e-001;

            __statist_i_h_wts[1, 75] = -5.21171993765631e-001;

            __statist_i_h_wts[1, 76] = -7.58877962404824e-002;

            __statist_i_h_wts[1, 77] = 5.95093276564821e-001;

            __statist_i_h_wts[1, 78] = -5.30146677394849e-001;

            __statist_i_h_wts[1, 79] = 3.83465551957215e-002;

            __statist_i_h_wts[1, 80] = 4.62124544976762e-001;

            __statist_i_h_wts[1, 81] = -1.59078783050995e-001;

            __statist_i_h_wts[1, 82] = -5.75475523107856e-002;

            __statist_i_h_wts[1, 83] = 1.76455633450260e-001;

            __statist_i_h_wts[1, 84] = -2.89403053553047e-001;

            __statist_i_h_wts[1, 85] = 1.62297526477533e-001;

            __statist_i_h_wts[1, 86] = 1.23911883471655e-001;

            __statist_i_h_wts[1, 87] = -3.96631393002136e-001;

            __statist_i_h_wts[1, 88] = 1.48830008922664e-001;

            __statist_i_h_wts[1, 89] = 2.62732598880496e-001;

            __statist_i_h_wts[1, 90] = -3.24172179906385e-001;

            __statist_i_h_wts[1, 91] = -3.66300510353826e-001;

            __statist_i_h_wts[1, 92] = 6.91148357467545e-001;

            __statist_i_h_wts[1, 93] = -1.96526971690713e-001;

            __statist_i_h_wts[1, 94] = -8.30038609528502e-002;

            __statist_i_h_wts[1, 95] = 2.70312187999648e-001;

            __statist_i_h_wts[1, 96] = -2.51728762088108e-001;

            __statist_i_h_wts[1, 97] = 9.62297471256028e-002;

            __statist_i_h_wts[1, 98] = 1.27965951161950e-001;

            __statist_i_h_wts[1, 99] = -2.68417854084365e-001;

            __statist_i_h_wts[1, 100] = 5.47952809345156e-002;

            __statist_i_h_wts[1, 101] = 1.68323396516358e-001;

            __statist_i_h_wts[1, 102] = -2.67964133417214e-001;

            __statist_i_h_wts[1, 103] = 6.19356262771468e-002;

            __statist_i_h_wts[1, 104] = 1.98953379423759e-001;

            __statist_i_h_wts[1, 105] = -3.92062638594110e-001;

            __statist_i_h_wts[1, 106] = -1.06598632574080e-001;

            __statist_i_h_wts[1, 107] = 4.78321428339146e-001;

            __statist_i_h_wts[1, 108] = -2.64385237711590e-001;

            __statist_i_h_wts[1, 109] = 5.86113941723220e-002;

            __statist_i_h_wts[1, 110] = 1.76780874086607e-001;

            __statist_i_h_wts[1, 111] = -3.06027408814708e-001;

            __statist_i_h_wts[1, 112] = 1.41451957702597e-001;

            __statist_i_h_wts[1, 113] = 1.64149512193097e-001;



            __statist_i_h_wts[2, 0] = 9.89984773382306e-002;

            __statist_i_h_wts[2, 1] = -5.51327458690890e-002;

            __statist_i_h_wts[2, 2] = 7.18786214179607e-002;

            __statist_i_h_wts[2, 3] = 4.53041660829453e-002;

            __statist_i_h_wts[2, 4] = -1.17930692616193e-001;

            __statist_i_h_wts[2, 5] = 3.30129994261393e-002;

            __statist_i_h_wts[2, 6] = 4.28096530200844e-002;

            __statist_i_h_wts[2, 7] = -7.88268017369510e-002;

            __statist_i_h_wts[2, 8] = 5.14106788519795e-003;

            __statist_i_h_wts[2, 9] = -4.36183744911259e-002;

            __statist_i_h_wts[2, 10] = 3.21927762228494e-002;

            __statist_i_h_wts[2, 11] = -3.09075643928314e-002;

            __statist_i_h_wts[2, 12] = -8.40327477060602e-003;

            __statist_i_h_wts[2, 13] = -1.54198997032661e-002;

            __statist_i_h_wts[2, 14] = -3.73726436347730e-002;

            __statist_i_h_wts[2, 15] = -6.15633606241288e-002;

            __statist_i_h_wts[2, 16] = 6.27967203442930e-002;

            __statist_i_h_wts[2, 17] = 1.44401962275930e-003;

            __statist_i_h_wts[2, 18] = 2.38306997557859e-004;

            __statist_i_h_wts[2, 19] = -6.03105463408480e-003;

            __statist_i_h_wts[2, 20] = 5.04092600798141e-002;

            __statist_i_h_wts[2, 21] = -2.63340154237562e-002;

            __statist_i_h_wts[2, 22] = 1.59719302513212e-002;

            __statist_i_h_wts[2, 23] = -1.86972734123315e-002;

            __statist_i_h_wts[2, 24] = -2.21273021600649e-002;

            __statist_i_h_wts[2, 25] = 1.06464123888369e-001;

            __statist_i_h_wts[2, 26] = -1.26250691864192e-002;

            __statist_i_h_wts[2, 27] = 9.13040999460774e-002;

            __statist_i_h_wts[2, 28] = -1.18013637662603e-002;

            __statist_i_h_wts[2, 29] = -7.75115672230237e-002;

            __statist_i_h_wts[2, 30] = -3.62344212739500e-003;

            __statist_i_h_wts[2, 31] = 2.67154547178556e-002;

            __statist_i_h_wts[2, 32] = -6.33847107961925e-002;

            __statist_i_h_wts[2, 33] = 4.01540459394222e-002;

            __statist_i_h_wts[2, 34] = 1.04932954627392e-002;

            __statist_i_h_wts[2, 35] = 2.10700288007304e-002;

            __statist_i_h_wts[2, 36] = 8.95885800427877e-003;

            __statist_i_h_wts[2, 37] = -5.96530673765302e-002;

            __statist_i_h_wts[2, 38] = 5.09388978646667e-002;

            __statist_i_h_wts[2, 39] = -1.22397954031527e-002;

            __statist_i_h_wts[2, 40] = -6.01438813307534e-002;

            __statist_i_h_wts[2, 41] = 2.79769780797398e-002;

            __statist_i_h_wts[2, 42] = 6.68850943183086e-002;

            __statist_i_h_wts[2, 43] = 1.84260416682973e-001;

            __statist_i_h_wts[2, 44] = -2.09712347129457e-001;

            __statist_i_h_wts[2, 45] = 9.49559517209629e-002;

            __statist_i_h_wts[2, 46] = 1.66737147485177e-001;

            __statist_i_h_wts[2, 47] = -1.97407257990311e-001;

            __statist_i_h_wts[2, 48] = 1.20295071319251e+000;

            __statist_i_h_wts[2, 49] = -1.58769535568466e-002;

            __statist_i_h_wts[2, 50] = -1.13850024359143e+000;

            __statist_i_h_wts[2, 51] = 7.34811408907459e-002;

            __statist_i_h_wts[2, 52] = 2.44496343185819e-001;

            __statist_i_h_wts[2, 53] = -2.49188456044531e-001;

            __statist_i_h_wts[2, 54] = 5.70484505719981e-002;

            __statist_i_h_wts[2, 55] = 2.12212368005085e-001;

            __statist_i_h_wts[2, 56] = -2.49718999056341e-001;

            __statist_i_h_wts[2, 57] = 2.54005782457885e-001;

            __statist_i_h_wts[2, 58] = -1.97962118595703e-001;

            __statist_i_h_wts[2, 59] = -2.35217045790158e-002;

            __statist_i_h_wts[2, 60] = 4.08380116539323e-001;

            __statist_i_h_wts[2, 61] = 1.67918313169911e-002;

            __statist_i_h_wts[2, 62] = -3.40809532782378e-001;

            __statist_i_h_wts[2, 63] = 2.48592260595424e+000;

            __statist_i_h_wts[2, 64] = -2.51338921311443e-001;

            __statist_i_h_wts[2, 65] = -2.15607679422087e+000;

            __statist_i_h_wts[2, 66] = 3.07971038365927e-001;

            __statist_i_h_wts[2, 67] = -1.32587989813651e-002;

            __statist_i_h_wts[2, 68] = -2.23056966172607e-001;

            __statist_i_h_wts[2, 69] = 5.82825277962372e-002;

            __statist_i_h_wts[2, 70] = 1.38119944757559e-001;

            __statist_i_h_wts[2, 71] = -1.18554663352653e-001;

            __statist_i_h_wts[2, 72] = -1.62344911355908e-001;

            __statist_i_h_wts[2, 73] = -8.25528361881176e-003;

            __statist_i_h_wts[2, 74] = 2.19610995951996e-001;

            __statist_i_h_wts[2, 75] = -4.69905912309674e-001;

            __statist_i_h_wts[2, 76] = -2.31830860472750e-001;

            __statist_i_h_wts[2, 77] = 7.24133085622114e-001;

            __statist_i_h_wts[2, 78] = -3.72129656827896e-001;

            __statist_i_h_wts[2, 79] = -1.36571796877918e-001;

            __statist_i_h_wts[2, 80] = 6.09000072529162e-001;

            __statist_i_h_wts[2, 81] = -1.02990947686662e-001;

            __statist_i_h_wts[2, 82] = -3.94091021196586e-002;

            __statist_i_h_wts[2, 83] = 2.08359845428999e-001;

            __statist_i_h_wts[2, 84] = -2.63315034846917e-001;

            __statist_i_h_wts[2, 85] = 1.64647645591892e-001;

            __statist_i_h_wts[2, 86] = 1.50773383142037e-001;

            __statist_i_h_wts[2, 87] = -3.21400064806530e-001;

            __statist_i_h_wts[2, 88] = 4.49351241222656e-002;

            __statist_i_h_wts[2, 89] = 3.43338031027985e-001;

            __statist_i_h_wts[2, 90] = -3.73823954712097e-001;

            __statist_i_h_wts[2, 91] = -4.30848180633902e-001;

            __statist_i_h_wts[2, 92] = 8.61551051211765e-001;

            __statist_i_h_wts[2, 93] = 3.91034108213617e-002;

            __statist_i_h_wts[2, 94] = -3.28726363989027e-001;

            __statist_i_h_wts[2, 95] = 3.52192662418527e-001;

            __statist_i_h_wts[2, 96] = -1.69795814193402e-001;

            __statist_i_h_wts[2, 97] = 6.95769343322924e-002;

            __statist_i_h_wts[2, 98] = 1.61978680880761e-001;

            __statist_i_h_wts[2, 99] = -1.14827917456539e-001;

            __statist_i_h_wts[2, 100] = -4.98443492010838e-002;

            __statist_i_h_wts[2, 101] = 2.03042827430858e-001;

            __statist_i_h_wts[2, 102] = 2.16104481200055e-002;

            __statist_i_h_wts[2, 103] = -1.81970834764402e-001;

            __statist_i_h_wts[2, 104] = 2.37609254023008e-001;

            __statist_i_h_wts[2, 105] = -3.58752067079283e-001;

            __statist_i_h_wts[2, 106] = -1.92520071455959e-001;

            __statist_i_h_wts[2, 107] = 6.15481757217411e-001;

            __statist_i_h_wts[2, 108] = 5.80320958807556e-002;

            __statist_i_h_wts[2, 109] = -2.14440725492094e-001;

            __statist_i_h_wts[2, 110] = 2.05126543683475e-001;

            __statist_i_h_wts[2, 111] = -1.15227133246447e-001;

            __statist_i_h_wts[2, 112] = -1.87802172181568e-002;

            __statist_i_h_wts[2, 113] = 1.88547462176505e-001;



            __statist_i_h_wts[3, 0] = -6.96367193879879e-002;

            __statist_i_h_wts[3, 1] = -2.96249440599074e-002;

            __statist_i_h_wts[3, 2] = 3.03805464900739e-003;

            __statist_i_h_wts[3, 3] = 1.39351923323952e-001;

            __statist_i_h_wts[3, 4] = -3.76861523644520e-003;

            __statist_i_h_wts[3, 5] = -1.39073302456422e-001;

            __statist_i_h_wts[3, 6] = -1.36677697739887e-002;

            __statist_i_h_wts[3, 7] = -1.10271572259789e-001;

            __statist_i_h_wts[3, 8] = -2.79112422940491e-002;

            __statist_i_h_wts[3, 9] = -1.16471503920314e-002;

            __statist_i_h_wts[3, 10] = 7.32611250223302e-002;

            __statist_i_h_wts[3, 11] = -4.78739328767890e-002;

            __statist_i_h_wts[3, 12] = 7.14856423877080e-002;

            __statist_i_h_wts[3, 13] = 1.30855604581848e-001;

            __statist_i_h_wts[3, 14] = 4.42622440441255e-002;

            __statist_i_h_wts[3, 15] = -1.93085176016244e-001;

            __statist_i_h_wts[3, 16] = 3.99995412375748e-002;

            __statist_i_h_wts[3, 17] = -3.40920714280156e-002;

            __statist_i_h_wts[3, 18] = 1.19376447303208e-001;

            __statist_i_h_wts[3, 19] = -1.19942914268451e-001;

            __statist_i_h_wts[3, 20] = 2.62389940593769e-003;

            __statist_i_h_wts[3, 21] = 5.58285161770073e-002;

            __statist_i_h_wts[3, 22] = 3.07719194213019e-002;

            __statist_i_h_wts[3, 23] = -6.49332782281878e-002;

            __statist_i_h_wts[3, 24] = 1.02058188656015e-001;

            __statist_i_h_wts[3, 25] = -4.76491549808342e-002;

            __statist_i_h_wts[3, 26] = -9.86179062356997e-002;

            __statist_i_h_wts[3, 27] = -1.13395954743184e-002;

            __statist_i_h_wts[3, 28] = -3.76199466196325e-002;

            __statist_i_h_wts[3, 29] = -2.77668551878171e-002;

            __statist_i_h_wts[3, 30] = 1.29190847478354e-001;

            __statist_i_h_wts[3, 31] = 2.77240483514588e-002;

            __statist_i_h_wts[3, 32] = -3.66855833574844e-002;

            __statist_i_h_wts[3, 33] = -1.58312543328807e-002;

            __statist_i_h_wts[3, 34] = -4.36423059262847e-002;

            __statist_i_h_wts[3, 35] = 6.29110438575016e-002;

            __statist_i_h_wts[3, 36] = 1.00922154364022e-003;

            __statist_i_h_wts[3, 37] = -6.17749396105322e-002;

            __statist_i_h_wts[3, 38] = 1.18991107715998e-001;

            __statist_i_h_wts[3, 39] = 2.29367183840567e-002;

            __statist_i_h_wts[3, 40] = 1.02600064357096e-001;

            __statist_i_h_wts[3, 41] = 7.81753083991827e-002;

            __statist_i_h_wts[3, 42] = 1.98295917946957e-001;

            __statist_i_h_wts[3, 43] = -7.81509626951053e-002;

            __statist_i_h_wts[3, 44] = -8.62214397122614e-002;

            __statist_i_h_wts[3, 45] = 2.07745532562904e-001;

            __statist_i_h_wts[3, 46] = 8.41389448498307e-002;

            __statist_i_h_wts[3, 47] = -2.58404214113387e-001;

            __statist_i_h_wts[3, 48] = 1.95982385871422e-001;

            __statist_i_h_wts[3, 49] = 3.17794652317212e-001;

            __statist_i_h_wts[3, 50] = -5.01178332956692e-001;

            __statist_i_h_wts[3, 51] = 8.46362408286640e-003;

            __statist_i_h_wts[3, 52] = 1.65089671962224e-001;

            __statist_i_h_wts[3, 53] = -1.78960920026264e-001;

            __statist_i_h_wts[3, 54] = 1.62021504809636e-001;

            __statist_i_h_wts[3, 55] = -1.10360288408846e-001;

            __statist_i_h_wts[3, 56] = 6.34504892958443e-003;

            __statist_i_h_wts[3, 57] = -1.21753463971707e-001;

            __statist_i_h_wts[3, 58] = 2.40159619676819e-001;

            __statist_i_h_wts[3, 59] = -9.23775314619380e-002;

            __statist_i_h_wts[3, 60] = 5.05953937542944e-002;

            __statist_i_h_wts[3, 61] = 1.54886940207570e-001;

            __statist_i_h_wts[3, 62] = -1.84105127252476e-001;

            __statist_i_h_wts[3, 63] = 6.26093973237479e-001;

            __statist_i_h_wts[3, 64] = 6.28698242845882e-002;

            __statist_i_h_wts[3, 65] = -6.60620756364755e-001;

            __statist_i_h_wts[3, 66] = 2.92384565768632e-001;

            __statist_i_h_wts[3, 67] = 1.31069006413002e-001;

            __statist_i_h_wts[3, 68] = -3.87038196287190e-001;

            __statist_i_h_wts[3, 69] = 1.41821593886732e-001;

            __statist_i_h_wts[3, 70] = 8.05362832488904e-002;

            __statist_i_h_wts[3, 71] = -1.70142653824672e-001;

            __statist_i_h_wts[3, 72] = -1.06111624087113e-001;

            __statist_i_h_wts[3, 73] = 3.75257642781183e-002;

            __statist_i_h_wts[3, 74] = 1.07214846131703e-001;

            __statist_i_h_wts[3, 75] = -4.65864475848319e-001;

            __statist_i_h_wts[3, 76] = -2.47148448790671e-001;

            __statist_i_h_wts[3, 77] = 7.18915463066789e-001;

            __statist_i_h_wts[3, 78] = -1.91547059241009e-001;

            __statist_i_h_wts[3, 79] = -1.80879634571100e-001;

            __statist_i_h_wts[3, 80] = 4.05412082534330e-001;

            __statist_i_h_wts[3, 81] = 7.25115486255313e-002;

            __statist_i_h_wts[3, 82] = -1.13047583287504e-001;

            __statist_i_h_wts[3, 83] = 8.57165537518657e-002;

            __statist_i_h_wts[3, 84] = 3.96778846623345e-002;

            __statist_i_h_wts[3, 85] = -2.14685425568420e-001;

            __statist_i_h_wts[3, 86] = 2.06748668018065e-001;

            __statist_i_h_wts[3, 87] = -1.11883197381474e-001;

            __statist_i_h_wts[3, 88] = -4.58657562065829e-001;

            __statist_i_h_wts[3, 89] = 5.98588684592196e-001;

            __statist_i_h_wts[3, 90] = -4.69827889093948e-001;

            __statist_i_h_wts[3, 91] = -3.45481195288580e-002;

            __statist_i_h_wts[3, 92] = 5.27225357398491e-001;

            __statist_i_h_wts[3, 93] = -1.98926141310808e-001;

            __statist_i_h_wts[3, 94] = -2.13707599043534e-001;

            __statist_i_h_wts[3, 95] = 4.39550605623142e-001;

            __statist_i_h_wts[3, 96] = -1.03102643378485e-001;

            __statist_i_h_wts[3, 97] = -5.72118486752114e-002;

            __statist_i_h_wts[3, 98] = 1.87482070975421e-001;

            __statist_i_h_wts[3, 99] = 1.19018719054606e-002;

            __statist_i_h_wts[3, 100] = -1.25808562651491e-001;

            __statist_i_h_wts[3, 101] = 1.39769315756281e-001;

            __statist_i_h_wts[3, 102] = -9.66109853064197e-002;

            __statist_i_h_wts[3, 103] = -3.10486535831066e-001;

            __statist_i_h_wts[3, 104] = 4.31472358783237e-001;

            __statist_i_h_wts[3, 105] = -3.86072994114737e-001;

            __statist_i_h_wts[3, 106] = -1.14565887531068e-001;

            __statist_i_h_wts[3, 107] = 5.04469690350273e-001;

            __statist_i_h_wts[3, 108] = -6.35848518326437e-002;

            __statist_i_h_wts[3, 109] = -2.74100944539202e-001;

            __statist_i_h_wts[3, 110] = 3.35990627968129e-001;

            __statist_i_h_wts[3, 111] = 9.52091949862694e-002;

            __statist_i_h_wts[3, 112] = -3.05945796454404e-001;

            __statist_i_h_wts[3, 113] = 2.26166027721057e-001;



            __statist_i_h_wts[4, 0] = 4.78984809122701e-002;

            __statist_i_h_wts[4, 1] = -3.78331059098869e-002;

            __statist_i_h_wts[4, 2] = 1.72777856607729e-002;

            __statist_i_h_wts[4, 3] = 4.17761816971460e-002;

            __statist_i_h_wts[4, 4] = -5.88497746491597e-002;

            __statist_i_h_wts[4, 5] = 6.59692846511762e-003;

            __statist_i_h_wts[4, 6] = 3.69443736165858e-002;

            __statist_i_h_wts[4, 7] = -1.84589001365673e-002;

            __statist_i_h_wts[4, 8] = -5.43360735154891e-003;

            __statist_i_h_wts[4, 9] = -1.24196240830991e-002;

            __statist_i_h_wts[4, 10] = 1.23011920929091e-002;

            __statist_i_h_wts[4, 11] = -1.18964938471914e-002;

            __statist_i_h_wts[4, 12] = 1.25638389038367e-002;

            __statist_i_h_wts[4, 13] = -1.05709716321695e-003;

            __statist_i_h_wts[4, 14] = -1.23035311193563e-002;

            __statist_i_h_wts[4, 15] = -1.40447305152627e-002;

            __statist_i_h_wts[4, 16] = 3.66494908669452e-002;

            __statist_i_h_wts[4, 17] = -1.90009010260234e-002;

            __statist_i_h_wts[4, 18] = -3.13727282812385e-002;

            __statist_i_h_wts[4, 19] = -7.60202544882575e-003;

            __statist_i_h_wts[4, 20] = 1.19018624390672e-002;

            __statist_i_h_wts[4, 21] = -2.05645607091181e-002;

            __statist_i_h_wts[4, 22] = -2.26062611785307e-003;

            __statist_i_h_wts[4, 23] = 7.22733669227255e-003;

            __statist_i_h_wts[4, 24] = -2.23928558517868e-003;

            __statist_i_h_wts[4, 25] = 6.19743637263505e-002;

            __statist_i_h_wts[4, 26] = -7.72136151823582e-003;

            __statist_i_h_wts[4, 27] = 5.25434882458677e-002;

            __statist_i_h_wts[4, 28] = -1.05091015945102e-002;

            __statist_i_h_wts[4, 29] = -4.60852670880627e-002;

            __statist_i_h_wts[4, 30] = 6.48675780208281e-003;

            __statist_i_h_wts[4, 31] = 2.50818853944648e-002;

            __statist_i_h_wts[4, 32] = -3.49797016173496e-002;

            __statist_i_h_wts[4, 33] = 1.59952219530623e-002;

            __statist_i_h_wts[4, 34] = -4.30205707811497e-003;

            __statist_i_h_wts[4, 35] = 1.48566832047079e-002;

            __statist_i_h_wts[4, 36] = 4.96271796984997e-003;

            __statist_i_h_wts[4, 37] = -2.89248524936580e-002;

            __statist_i_h_wts[4, 38] = 2.69040937438363e-002;

            __statist_i_h_wts[4, 39] = 1.96316038193160e-003;

            __statist_i_h_wts[4, 40] = -1.41553755633342e-002;

            __statist_i_h_wts[4, 41] = -2.15068530591926e-003;

            __statist_i_h_wts[4, 42] = 1.27679916046356e-001;

            __statist_i_h_wts[4, 43] = -2.45714243283951e-002;

            __statist_i_h_wts[4, 44] = -1.10551998781829e-001;

            __statist_i_h_wts[4, 45] = -5.27357011243423e-002;

            __statist_i_h_wts[4, 46] = 1.53258947844660e-001;

            __statist_i_h_wts[4, 47] = -9.79576751624170e-002;

            __statist_i_h_wts[4, 48] = 4.62652373425287e-001;

            __statist_i_h_wts[4, 49] = 6.05530123742351e-002;

            __statist_i_h_wts[4, 50] = -4.91518684104948e-001;

            __statist_i_h_wts[4, 51] = -1.54948415672319e-001;

            __statist_i_h_wts[4, 52] = 2.58657244440334e-001;

            __statist_i_h_wts[4, 53] = -9.33402819254188e-002;

            __statist_i_h_wts[4, 54] = 4.46285133379782e-002;

            __statist_i_h_wts[4, 55] = 8.70637661754543e-002;

            __statist_i_h_wts[4, 56] = -1.02437944720457e-001;

            __statist_i_h_wts[4, 57] = 2.54485204441456e-001;

            __statist_i_h_wts[4, 58] = -2.39017303023577e-001;

            __statist_i_h_wts[4, 59] = 8.05984275952986e-003;

            __statist_i_h_wts[4, 60] = 5.23104208477415e-002;

            __statist_i_h_wts[4, 61] = 5.42930806901541e-002;

            __statist_i_h_wts[4, 62] = -1.12514778839277e-001;

            __statist_i_h_wts[4, 63] = 9.77097986340234e-001;

            __statist_i_h_wts[4, 64] = -2.70449991787968e-002;

            __statist_i_h_wts[4, 65] = -9.27630935462986e-001;

            __statist_i_h_wts[4, 66] = -4.72752222565685e-002;

            __statist_i_h_wts[4, 67] = 1.43727375395885e-001;

            __statist_i_h_wts[4, 68] = -1.07134385897086e-001;

            __statist_i_h_wts[4, 69] = 8.09828454738982e-002;

            __statist_i_h_wts[4, 70] = -2.24873644039773e-002;

            __statist_i_h_wts[4, 71] = -4.90279434549689e-002;

            __statist_i_h_wts[4, 72] = -9.00824094987485e-002;

            __statist_i_h_wts[4, 73] = -2.64668700473947e-002;

            __statist_i_h_wts[4, 74] = 8.72939242810178e-002;

            __statist_i_h_wts[4, 75] = -3.82525480708692e-001;

            __statist_i_h_wts[4, 76] = 8.45319684557005e-002;

            __statist_i_h_wts[4, 77] = 3.06897916227377e-001;

            __statist_i_h_wts[4, 78] = -4.06460836593876e-001;

            __statist_i_h_wts[4, 79] = 1.77937699086405e-001;

            __statist_i_h_wts[4, 80] = 2.42702793333162e-001;

            __statist_i_h_wts[4, 81] = -1.09784091505946e-001;

            __statist_i_h_wts[4, 82] = -1.85030696774162e-002;

            __statist_i_h_wts[4, 83] = 1.21326753176828e-001;

            __statist_i_h_wts[4, 84] = 4.60264544953376e-002;

            __statist_i_h_wts[4, 85] = -1.09182031036242e-001;

            __statist_i_h_wts[4, 86] = 6.55630493107517e-002;

            __statist_i_h_wts[4, 87] = -1.78920167140756e-001;

            __statist_i_h_wts[4, 88] = 6.24016850648191e-002;

            __statist_i_h_wts[4, 89] = 1.40697773230728e-001;

            __statist_i_h_wts[4, 90] = 1.35193693508990e-002;

            __statist_i_h_wts[4, 91] = -3.72749529523416e-001;

            __statist_i_h_wts[4, 92] = 3.51513705436856e-001;

            __statist_i_h_wts[4, 93] = -8.75240163083512e-002;

            __statist_i_h_wts[4, 94] = -4.69122395307726e-002;

            __statist_i_h_wts[4, 95] = 1.40464447753470e-001;

            __statist_i_h_wts[4, 96] = 1.07854367722810e-002;

            __statist_i_h_wts[4, 97] = -7.67577688799989e-002;

            __statist_i_h_wts[4, 98] = 6.41869157727929e-002;

            __statist_i_h_wts[4, 99] = -5.40987430351068e-002;

            __statist_i_h_wts[4, 100] = -3.76605081582160e-002;

            __statist_i_h_wts[4, 101] = 1.02643063657160e-001;

            __statist_i_h_wts[4, 102] = -1.83228563750842e-001;

            __statist_i_h_wts[4, 103] = 7.37122712353985e-002;

            __statist_i_h_wts[4, 104] = 1.25598073110541e-001;

            __statist_i_h_wts[4, 105] = -8.60089997401818e-002;

            __statist_i_h_wts[4, 106] = -1.50786648452301e-001;

            __statist_i_h_wts[4, 107] = 2.51164403654387e-001;

            __statist_i_h_wts[4, 108] = -2.44108064598868e-001;

            __statist_i_h_wts[4, 109] = 1.25541787552578e-001;

            __statist_i_h_wts[4, 110] = 1.14993002456909e-001;

            __statist_i_h_wts[4, 111] = -1.16726800860796e-001;

            __statist_i_h_wts[4, 112] = 2.95335861282973e-002;

            __statist_i_h_wts[4, 113] = 9.19114833410754e-002;



            __statist_i_h_wts[5, 0] = 1.09830153927451e-001;

            __statist_i_h_wts[5, 1] = -5.33371572747831e-002;

            __statist_i_h_wts[5, 2] = 6.56070741136251e-002;

            __statist_i_h_wts[5, 3] = 2.74756473512185e-002;

            __statist_i_h_wts[5, 4] = -1.46931288080836e-001;

            __statist_i_h_wts[5, 5] = 3.12353807125198e-002;

            __statist_i_h_wts[5, 6] = 4.92378925175546e-002;

            __statist_i_h_wts[5, 7] = -6.09142968994119e-002;

            __statist_i_h_wts[5, 8] = 2.31719986399876e-002;

            __statist_i_h_wts[5, 9] = -4.61045339405600e-002;

            __statist_i_h_wts[5, 10] = 1.62624629612662e-002;

            __statist_i_h_wts[5, 11] = -5.08355085819405e-002;

            __statist_i_h_wts[5, 12] = 1.58458363630204e-002;

            __statist_i_h_wts[5, 13] = -1.04693895062361e-002;

            __statist_i_h_wts[5, 14] = -7.09479745495425e-003;

            __statist_i_h_wts[5, 15] = -6.03770286943102e-002;

            __statist_i_h_wts[5, 16] = 5.96094568679105e-002;

            __statist_i_h_wts[5, 17] = -1.38219086014544e-002;

            __statist_i_h_wts[5, 18] = 1.31392985371234e-002;

            __statist_i_h_wts[5, 19] = 2.88492441298545e-002;

            __statist_i_h_wts[5, 20] = 4.16792194732767e-002;

            __statist_i_h_wts[5, 21] = -2.48944346050040e-002;

            __statist_i_h_wts[5, 22] = 3.61914707000954e-004;

            __statist_i_h_wts[5, 23] = -1.97532322408061e-002;

            __statist_i_h_wts[5, 24] = -2.11960327551782e-003;

            __statist_i_h_wts[5, 25] = 1.27707174402577e-001;

            __statist_i_h_wts[5, 26] = -9.65653093798464e-003;

            __statist_i_h_wts[5, 27] = 1.29498920932492e-001;

            __statist_i_h_wts[5, 28] = -2.24204659287035e-002;

            __statist_i_h_wts[5, 29] = -8.06006921069938e-002;

            __statist_i_h_wts[5, 30] = 5.77200009789136e-003;

            __statist_i_h_wts[5, 31] = 6.12746329323631e-002;

            __statist_i_h_wts[5, 32] = -8.78915994342891e-002;

            __statist_i_h_wts[5, 33] = 5.32338827675706e-002;

            __statist_i_h_wts[5, 34] = -1.92663760190565e-002;

            __statist_i_h_wts[5, 35] = 1.65190281421288e-002;

            __statist_i_h_wts[5, 36] = -5.59940497297720e-003;

            __statist_i_h_wts[5, 37] = -6.28884825897121e-002;

            __statist_i_h_wts[5, 38] = 7.00920175600081e-002;

            __statist_i_h_wts[5, 39] = 6.39694186252801e-003;

            __statist_i_h_wts[5, 40] = -5.31350457619459e-002;

            __statist_i_h_wts[5, 41] = 3.51786703954575e-002;

            __statist_i_h_wts[5, 42] = 3.32650987290360e-004;

            __statist_i_h_wts[5, 43] = 2.73900739159348e-001;

            __statist_i_h_wts[5, 44] = -2.27556026959986e-001;

            __statist_i_h_wts[5, 45] = 1.17597501283966e-001;

            __statist_i_h_wts[5, 46] = 1.36120436804740e-001;

            __statist_i_h_wts[5, 47] = -2.29908421226056e-001;

            __statist_i_h_wts[5, 48] = 1.10583695943701e+000;

            __statist_i_h_wts[5, 49] = 6.17436219199191e-002;

            __statist_i_h_wts[5, 50] = -1.11710720637882e+000;

            __statist_i_h_wts[5, 51] = 1.96767319489253e-001;

            __statist_i_h_wts[5, 52] = 1.20865376084695e-001;

            __statist_i_h_wts[5, 53] = -2.84215613187617e-001;

            __statist_i_h_wts[5, 54] = 5.46766718997044e-003;

            __statist_i_h_wts[5, 55] = 2.59915837136903e-001;

            __statist_i_h_wts[5, 56] = -2.14451059775814e-001;

            __statist_i_h_wts[5, 57] = 8.29417528454653e-002;

            __statist_i_h_wts[5, 58] = -3.28222115199076e-002;

            __statist_i_h_wts[5, 59] = 9.71503165154123e-003;

            __statist_i_h_wts[5, 60] = 3.01472120730537e-001;

            __statist_i_h_wts[5, 61] = 1.46324430231047e-001;

            __statist_i_h_wts[5, 62] = -3.70272332716985e-001;

            __statist_i_h_wts[5, 63] = 2.31387395118141e+000;

            __statist_i_h_wts[5, 64] = -2.19349856774934e-001;

            __statist_i_h_wts[5, 65] = -2.04955794260879e+000;

            __statist_i_h_wts[5, 66] = 2.92656987202184e-001;

            __statist_i_h_wts[5, 67] = 1.09303210161378e-002;

            __statist_i_h_wts[5, 68] = -2.56032766509167e-001;

            __statist_i_h_wts[5, 69] = -1.16787029493319e-001;

            __statist_i_h_wts[5, 70] = 2.75377311964076e-001;

            __statist_i_h_wts[5, 71] = -1.16606838279348e-001;

            __statist_i_h_wts[5, 72] = -2.21941809771926e-001;

            __statist_i_h_wts[5, 73] = 3.21692207213514e-002;

            __statist_i_h_wts[5, 74] = 2.43863679293059e-001;

            __statist_i_h_wts[5, 75] = -5.04960159366913e-001;

            __statist_i_h_wts[5, 76] = -2.20042146398682e-001;

            __statist_i_h_wts[5, 77] = 7.50095693966846e-001;

            __statist_i_h_wts[5, 78] = -4.06131466174623e-001;

            __statist_i_h_wts[5, 79] = -1.59467145432351e-001;

            __statist_i_h_wts[5, 80] = 5.92744744428265e-001;

            __statist_i_h_wts[5, 81] = -1.34671314689959e-001;

            __statist_i_h_wts[5, 82] = 3.77343704414956e-002;

            __statist_i_h_wts[5, 83] = 1.74264758880049e-001;

            __statist_i_h_wts[5, 84] = -2.68234651419686e-001;

            __statist_i_h_wts[5, 85] = 2.03375755172392e-001;

            __statist_i_h_wts[5, 86] = 1.28571789199291e-001;

            __statist_i_h_wts[5, 87] = -3.09009431490352e-001;

            __statist_i_h_wts[5, 88] = -4.50411931585600e-003;

            __statist_i_h_wts[5, 89] = 3.60330740881576e-001;

            __statist_i_h_wts[5, 90] = -3.54552602629964e-001;

            __statist_i_h_wts[5, 91] = -4.59775037214153e-001;

            __statist_i_h_wts[5, 92] = 8.64534212232723e-001;

            __statist_i_h_wts[5, 93] = 1.26099927223167e-001;

            __statist_i_h_wts[5, 94] = -4.39826511257766e-001;

            __statist_i_h_wts[5, 95] = 3.56463907438488e-001;

            __statist_i_h_wts[5, 96] = -1.63822592277712e-001;

            __statist_i_h_wts[5, 97] = 7.70496226245555e-002;

            __statist_i_h_wts[5, 98] = 1.64115459010048e-001;

            __statist_i_h_wts[5, 99] = -3.16911120084453e-002;

            __statist_i_h_wts[5, 100] = -8.57218892561204e-002;

            __statist_i_h_wts[5, 101] = 1.68638871919923e-001;

            __statist_i_h_wts[5, 102] = 1.09736044142259e-001;

            __statist_i_h_wts[5, 103] = -3.14907065070530e-001;

            __statist_i_h_wts[5, 104] = 2.66418651692580e-001;

            __statist_i_h_wts[5, 105] = -2.65411554297626e-001;

            __statist_i_h_wts[5, 106] = -3.40959116216971e-001;

            __statist_i_h_wts[5, 107] = 6.57890405546797e-001;

            __statist_i_h_wts[5, 108] = 1.99309315747337e-001;

            __statist_i_h_wts[5, 109] = -3.64855356125775e-001;

            __statist_i_h_wts[5, 110] = 2.02245984892007e-001;

            __statist_i_h_wts[5, 111] = -6.40679060511416e-002;

            __statist_i_h_wts[5, 112] = -5.81041400014398e-002;

            __statist_i_h_wts[5, 113] = 2.01845717119711e-001;



            __statist_i_h_wts[6, 0] = 6.00497294498064e-003;

            __statist_i_h_wts[6, 1] = -4.04628262415050e-003;

            __statist_i_h_wts[6, 2] = 1.54578489659038e-002;

            __statist_i_h_wts[6, 3] = 3.22140953835377e-004;

            __statist_i_h_wts[6, 4] = -1.11098261083956e-002;

            __statist_i_h_wts[6, 5] = 5.31725438835488e-004;

            __statist_i_h_wts[6, 6] = 7.17727777246492e-003;

            __statist_i_h_wts[6, 7] = 1.29805765223207e-003;

            __statist_i_h_wts[6, 8] = -3.75573955057417e-003;

            __statist_i_h_wts[6, 9] = 5.76292373478800e-003;

            __statist_i_h_wts[6, 10] = 7.61760227237111e-003;

            __statist_i_h_wts[6, 11] = -1.86487073523452e-002;

            __statist_i_h_wts[6, 12] = 8.43192519589740e-003;

            __statist_i_h_wts[6, 13] = 6.48045975855526e-003;

            __statist_i_h_wts[6, 14] = -3.81788089799952e-002;

            __statist_i_h_wts[6, 15] = -2.84570113485088e-002;

            __statist_i_h_wts[6, 16] = 6.69187230810491e-003;

            __statist_i_h_wts[6, 17] = 6.87869543726926e-003;

            __statist_i_h_wts[6, 18] = 9.20869598878105e-003;

            __statist_i_h_wts[6, 19] = 2.58778560558386e-003;

            __statist_i_h_wts[6, 20] = -1.63131344518681e-002;

            __statist_i_h_wts[6, 21] = 6.29034443699898e-003;

            __statist_i_h_wts[6, 22] = 7.83677751365321e-004;

            __statist_i_h_wts[6, 23] = -7.82219314191805e-003;

            __statist_i_h_wts[6, 24] = 7.14088163953688e-004;

            __statist_i_h_wts[6, 25] = 7.80666018743507e-003;

            __statist_i_h_wts[6, 26] = -2.27664709398877e-003;

            __statist_i_h_wts[6, 27] = -1.86503376727840e-002;

            __statist_i_h_wts[6, 28] = -1.73368660981695e-002;

            __statist_i_h_wts[6, 29] = 1.37391271298561e-003;

            __statist_i_h_wts[6, 30] = -1.34168128015945e-002;

            __statist_i_h_wts[6, 31] = -9.82186340884484e-003;

            __statist_i_h_wts[6, 32] = 8.16492797334334e-004;

            __statist_i_h_wts[6, 33] = 2.53173555727269e-003;

            __statist_i_h_wts[6, 34] = -8.10640999530106e-003;

            __statist_i_h_wts[6, 35] = -1.15978822104931e-002;

            __statist_i_h_wts[6, 36] = -1.19699715048865e-002;

            __statist_i_h_wts[6, 37] = -6.00088117857142e-003;

            __statist_i_h_wts[6, 38] = -9.04352524187939e-004;

            __statist_i_h_wts[6, 39] = -2.28334040997835e-003;

            __statist_i_h_wts[6, 40] = 7.50847902816720e-003;

            __statist_i_h_wts[6, 41] = -7.87022777651121e-003;

            __statist_i_h_wts[6, 42] = -2.28493051413444e-002;

            __statist_i_h_wts[6, 43] = -7.41547211754230e-002;

            __statist_i_h_wts[6, 44] = -3.17745572214831e-002;

            __statist_i_h_wts[6, 45] = -1.15635674702312e-001;

            __statist_i_h_wts[6, 46] = 5.04031971571036e-002;

            __statist_i_h_wts[6, 47] = -5.02102588777329e-002;

            __statist_i_h_wts[6, 48] = 6.59639348356031e-001;

            __statist_i_h_wts[6, 49] = -4.55768782905748e-001;

            __statist_i_h_wts[6, 50] = -3.27717622102360e-001;

            __statist_i_h_wts[6, 51] = -1.50409107647017e-001;

            __statist_i_h_wts[6, 52] = 1.02359844504983e-001;

            __statist_i_h_wts[6, 53] = -7.22890299078260e-002;

            __statist_i_h_wts[6, 54] = -3.66930402056855e-002;

            __statist_i_h_wts[6, 55] = -2.21318669038154e-002;

            __statist_i_h_wts[6, 56] = -4.31362444425840e-002;

            __statist_i_h_wts[6, 57] = 1.91538482613790e-001;

            __statist_i_h_wts[6, 58] = -2.93347398276655e-001;

            __statist_i_h_wts[6, 59] = -2.38577813864620e-002;

            __statist_i_h_wts[6, 60] = 9.21385068069311e-002;

            __statist_i_h_wts[6, 61] = -1.30633949313099e-001;

            __statist_i_h_wts[6, 62] = -7.08150773461645e-002;

            __statist_i_h_wts[6, 63] = 9.67780452363086e-001;

            __statist_i_h_wts[6, 64] = -5.12479033510280e-001;

            __statist_i_h_wts[6, 65] = -5.74787842405845e-001;

            __statist_i_h_wts[6, 66] = 3.39830270309361e-002;

            __statist_i_h_wts[6, 67] = -7.74462014748874e-002;

            __statist_i_h_wts[6, 68] = -6.56447174853745e-002;

            __statist_i_h_wts[6, 69] = 1.43929197333232e-001;

            __statist_i_h_wts[6, 70] = -2.24904394095383e-001;

            __statist_i_h_wts[6, 71] = -6.00702479194007e-002;

            __statist_i_h_wts[6, 72] = -5.32701971956758e-001;

            __statist_i_h_wts[6, 73] = 3.49392198707759e-001;

            __statist_i_h_wts[6, 74] = 6.51598875986929e-002;

            __statist_i_h_wts[6, 75] = -7.29959386486743e-001;

            __statist_i_h_wts[6, 76] = 4.58287200374529e-001;

            __statist_i_h_wts[6, 77] = 1.69345621905515e-001;

            __statist_i_h_wts[6, 78] = -7.66196949609127e-001;

            __statist_i_h_wts[6, 79] = 5.38674178795909e-001;

            __statist_i_h_wts[6, 80] = 1.24419938398685e-001;

            __statist_i_h_wts[6, 81] = -5.38586856287836e-001;

            __statist_i_h_wts[6, 82] = 3.67158586233277e-001;

            __statist_i_h_wts[6, 83] = 3.37147982573018e-002;

            __statist_i_h_wts[6, 84] = -6.97496938665143e-002;

            __statist_i_h_wts[6, 85] = -8.29567020704616e-002;

            __statist_i_h_wts[6, 86] = 1.78080485990918e-002;

            __statist_i_h_wts[6, 87] = -1.56977606399322e-001;

            __statist_i_h_wts[6, 88] = -1.36608262301991e-002;

            __statist_i_h_wts[6, 89] = 6.33961857882612e-002;

            __statist_i_h_wts[6, 90] = 4.40039310244859e-001;

            __statist_i_h_wts[6, 91] = -7.45470342848220e-001;

            __statist_i_h_wts[6, 92] = 1.81481987378216e-001;

            __statist_i_h_wts[6, 93] = -2.17034874183627e-001;

            __statist_i_h_wts[6, 94] = 8.93905617523118e-003;

            __statist_i_h_wts[6, 95] = 6.36336610978348e-002;

            __statist_i_h_wts[6, 96] = -7.96171936848396e-002;

            __statist_i_h_wts[6, 97] = -4.87059220143454e-002;

            __statist_i_h_wts[6, 98] = 1.97997180125266e-002;

            __statist_i_h_wts[6, 99] = -1.09892950850120e-001;

            __statist_i_h_wts[6, 100] = -3.21173233994900e-002;

            __statist_i_h_wts[6, 101] = 6.62058515905350e-002;

            __statist_i_h_wts[6, 102] = -2.20074775254542e-001;

            __statist_i_h_wts[6, 103] = 5.24248387902708e-002;

            __statist_i_h_wts[6, 104] = 5.24842474583653e-002;

            __statist_i_h_wts[6, 105] = 3.03343989198251e-001;

            __statist_i_h_wts[6, 106] = -5.35890491850623e-001;

            __statist_i_h_wts[6, 107] = 1.10658492895663e-001;

            __statist_i_h_wts[6, 108] = -2.44976717793168e-001;

            __statist_i_h_wts[6, 109] = 8.95743626022656e-002;

            __statist_i_h_wts[6, 110] = 5.41083166708294e-002;

            __statist_i_h_wts[6, 111] = -1.55154141762487e-001;

            __statist_i_h_wts[6, 112] = -2.50603339969918e-003;

            __statist_i_h_wts[6, 113] = 5.65963399319003e-002;



            __statist_i_h_wts[7, 0] = 4.67993364101251e-002;

            __statist_i_h_wts[7, 1] = -1.37824112018128e-002;

            __statist_i_h_wts[7, 2] = 2.17384800274484e-002;

            __statist_i_h_wts[7, 3] = 2.74888125520489e-002;

            __statist_i_h_wts[7, 4] = -6.49661125455730e-002;

            __statist_i_h_wts[7, 5] = 1.07036705597313e-002;

            __statist_i_h_wts[7, 6] = -6.93445002361734e-003;

            __statist_i_h_wts[7, 7] = -2.20996145585702e-002;

            __statist_i_h_wts[7, 8] = 2.79377368900053e-003;

            __statist_i_h_wts[7, 9] = 1.13809940864906e-002;

            __statist_i_h_wts[7, 10] = 6.45266726237327e-003;

            __statist_i_h_wts[7, 11] = -1.46118033855584e-002;

            __statist_i_h_wts[7, 12] = 6.12821241160470e-003;

            __statist_i_h_wts[7, 13] = 1.04172332585848e-002;

            __statist_i_h_wts[7, 14] = 1.85602642713431e-003;

            __statist_i_h_wts[7, 15] = -3.06152267925231e-002;

            __statist_i_h_wts[7, 16] = 2.51604044061848e-002;

            __statist_i_h_wts[7, 17] = -2.10733203588121e-002;

            __statist_i_h_wts[7, 18] = -4.82124013068398e-003;

            __statist_i_h_wts[7, 19] = -6.54481488255146e-003;

            __statist_i_h_wts[7, 20] = -2.18613920971332e-003;

            __statist_i_h_wts[7, 21] = -6.99242110135937e-003;

            __statist_i_h_wts[7, 22] = 5.69376503114762e-003;

            __statist_i_h_wts[7, 23] = -2.56574946250883e-002;

            __statist_i_h_wts[7, 24] = -1.42391063877191e-002;

            __statist_i_h_wts[7, 25] = 5.91211771682138e-002;

            __statist_i_h_wts[7, 26] = -8.20661391624389e-003;

            __statist_i_h_wts[7, 27] = 5.49436988178984e-002;

            __statist_i_h_wts[7, 28] = -1.41603698487138e-002;

            __statist_i_h_wts[7, 29] = -2.92546296826791e-002;

            __statist_i_h_wts[7, 30] = 5.92165919417464e-003;

            __statist_i_h_wts[7, 31] = 9.69401687721692e-003;

            __statist_i_h_wts[7, 32] = -3.25439800727993e-002;

            __statist_i_h_wts[7, 33] = 2.63011974098039e-002;

            __statist_i_h_wts[7, 34] = 2.04996944481963e-002;

            __statist_i_h_wts[7, 35] = 1.78364602348923e-002;

            __statist_i_h_wts[7, 36] = -4.29034759670240e-004;

            __statist_i_h_wts[7, 37] = -2.93242883618143e-002;

            __statist_i_h_wts[7, 38] = 2.45707240708886e-002;

            __statist_i_h_wts[7, 39] = -5.38671389613704e-003;

            __statist_i_h_wts[7, 40] = -3.05160782277352e-002;

            __statist_i_h_wts[7, 41] = 5.74043574639579e-003;

            __statist_i_h_wts[7, 42] = 3.42576922204740e-002;

            __statist_i_h_wts[7, 43] = 6.05602112131464e-003;

            __statist_i_h_wts[7, 44] = -8.48725674274265e-002;

            __statist_i_h_wts[7, 45] = -1.09851114364126e-001;

            __statist_i_h_wts[7, 46] = 1.35989282186265e-001;

            __statist_i_h_wts[7, 47] = -5.59469749368828e-002;

            __statist_i_h_wts[7, 48] = 7.01484762708335e-001;

            __statist_i_h_wts[7, 49] = -2.41881693780866e-001;

            __statist_i_h_wts[7, 50] = -5.17181671218574e-001;

            __statist_i_h_wts[7, 51] = -2.22464643586679e-001;

            __statist_i_h_wts[7, 52] = 2.35306381357184e-001;

            __statist_i_h_wts[7, 53] = -6.42257945911450e-002;

            __statist_i_h_wts[7, 54] = -1.99631622345528e-003;

            __statist_i_h_wts[7, 55] = 2.98828995651986e-002;

            __statist_i_h_wts[7, 56] = -7.23562369135267e-002;

            __statist_i_h_wts[7, 57] = 1.96738173488550e-001;

            __statist_i_h_wts[7, 58] = -2.23811067992341e-001;

            __statist_i_h_wts[7, 59] = -1.29270172024266e-002;

            __statist_i_h_wts[7, 60] = 5.93795497710965e-002;

            __statist_i_h_wts[7, 61] = 2.53463497204514e-002;

            __statist_i_h_wts[7, 62] = -1.19263955948755e-001;

            __statist_i_h_wts[7, 63] = 1.27540269878175e+000;

            __statist_i_h_wts[7, 64] = -3.52056339326982e-001;

            __statist_i_h_wts[7, 65] = -9.75205769251233e-001;

            __statist_i_h_wts[7, 66] = -3.35406511990338e-002;

            __statist_i_h_wts[7, 67] = 7.38462125775148e-002;

            __statist_i_h_wts[7, 68] = -6.22302553789433e-002;

            __statist_i_h_wts[7, 69] = 5.54842778654225e-002;

            __statist_i_h_wts[7, 70] = -7.41655905418868e-002;

            __statist_i_h_wts[7, 71] = -3.87140478614588e-002;

            __statist_i_h_wts[7, 72] = -3.14663541506704e-001;

            __statist_i_h_wts[7, 73] = 1.50579965681356e-001;

            __statist_i_h_wts[7, 74] = 9.51739086537390e-002;

            __statist_i_h_wts[7, 75] = -5.93171044351405e-001;

            __statist_i_h_wts[7, 76] = 2.44172168020204e-001;

            __statist_i_h_wts[7, 77] = 2.85744693124898e-001;

            __statist_i_h_wts[7, 78] = -6.22440169246377e-001;

            __statist_i_h_wts[7, 79] = 3.66984545916855e-001;

            __statist_i_h_wts[7, 80] = 2.02810743702199e-001;

            __statist_i_h_wts[7, 81] = -3.09775594663237e-001;

            __statist_i_h_wts[7, 82] = 1.63276426269493e-001;

            __statist_i_h_wts[7, 83] = 7.94394150763966e-002;

            __statist_i_h_wts[7, 84] = -6.92355344929888e-002;

            __statist_i_h_wts[7, 85] = -4.42129546085368e-002;

            __statist_i_h_wts[7, 86] = 6.07398781492877e-002;

            __statist_i_h_wts[7, 87] = -2.30697116418359e-001;

            __statist_i_h_wts[7, 88] = 4.91845582123511e-002;

            __statist_i_h_wts[7, 89] = 1.03737597666452e-001;

            __statist_i_h_wts[7, 90] = 1.96415319568872e-001;

            __statist_i_h_wts[7, 91] = -5.12431937873378e-001;

            __statist_i_h_wts[7, 92] = 2.91945309366641e-001;

            __statist_i_h_wts[7, 93] = -1.52449351196715e-001;

            __statist_i_h_wts[7, 94] = -1.90596986397976e-002;

            __statist_i_h_wts[7, 95] = 1.26331131917559e-001;

            __statist_i_h_wts[7, 96] = -5.05934413967077e-002;

            __statist_i_h_wts[7, 97] = -7.21081029598838e-002;

            __statist_i_h_wts[7, 98] = 7.81614226965726e-002;

            __statist_i_h_wts[7, 99] = -1.20559192908432e-001;

            __statist_i_h_wts[7, 100] = 1.32844286830455e-002;

            __statist_i_h_wts[7, 101] = 6.83785597270102e-002;

            __statist_i_h_wts[7, 102] = -2.18394884614785e-001;

            __statist_i_h_wts[7, 103] = 8.13772875866358e-002;

            __statist_i_h_wts[7, 104] = 8.84228951968720e-002;

            __statist_i_h_wts[7, 105] = 6.33017999604835e-002;

            __statist_i_h_wts[7, 106] = -3.53371940153036e-001;

            __statist_i_h_wts[7, 107] = 2.07378949790953e-001;

            __statist_i_h_wts[7, 108] = -2.52849040748109e-001;

            __statist_i_h_wts[7, 109] = 1.13167723571242e-001;

            __statist_i_h_wts[7, 110] = 7.85416658375649e-002;

            __statist_i_h_wts[7, 111] = -1.43010311901774e-001;

            __statist_i_h_wts[7, 112] = 1.95286921719708e-002;

            __statist_i_h_wts[7, 113] = 6.70371686370698e-002;



            __statist_i_h_wts[8, 0] = 6.02540658091202e-002;

            __statist_i_h_wts[8, 1] = -4.70956807998109e-002;

            __statist_i_h_wts[8, 2] = 4.59624730290914e-002;

            __statist_i_h_wts[8, 3] = 2.67937906869452e-002;

            __statist_i_h_wts[8, 4] = -9.08942418624661e-002;

            __statist_i_h_wts[8, 5] = -4.23224036618388e-003;

            __statist_i_h_wts[8, 6] = 3.56612632792911e-002;

            __statist_i_h_wts[8, 7] = -6.13813789064461e-002;

            __statist_i_h_wts[8, 8] = 9.74862546792778e-003;

            __statist_i_h_wts[8, 9] = -2.79921882556746e-002;

            __statist_i_h_wts[8, 10] = 1.33530434142949e-002;

            __statist_i_h_wts[8, 11] = -6.70401503902946e-003;

            __statist_i_h_wts[8, 12] = -5.47445344867820e-003;

            __statist_i_h_wts[8, 13] = 1.60331521449088e-002;

            __statist_i_h_wts[8, 14] = -5.37783016206852e-003;

            __statist_i_h_wts[8, 15] = -2.24721560269729e-002;

            __statist_i_h_wts[8, 16] = 5.55463295930175e-002;

            __statist_i_h_wts[8, 17] = -3.38484587610191e-002;

            __statist_i_h_wts[8, 18] = -3.50084434179332e-002;

            __statist_i_h_wts[8, 19] = -4.72787782428642e-003;

            __statist_i_h_wts[8, 20] = 8.45085645269644e-003;

            __statist_i_h_wts[8, 21] = -1.88414813312577e-002;

            __statist_i_h_wts[8, 22] = -6.02136782489171e-003;

            __statist_i_h_wts[8, 23] = -5.86447345771337e-003;

            __statist_i_h_wts[8, 24] = -1.65680419154389e-002;

            __statist_i_h_wts[8, 25] = 7.81161997015551e-002;

            __statist_i_h_wts[8, 26] = -2.11445014542417e-002;

            __statist_i_h_wts[8, 27] = 5.21328455460453e-002;

            __statist_i_h_wts[8, 28] = -8.50431964757927e-003;

            __statist_i_h_wts[8, 29] = -5.91553517452572e-002;

            __statist_i_h_wts[8, 30] = -5.00436797540918e-003;

            __statist_i_h_wts[8, 31] = 4.11083888222751e-002;

            __statist_i_h_wts[8, 32] = -3.24023246749874e-002;

            __statist_i_h_wts[8, 33] = 2.26913881317261e-002;

            __statist_i_h_wts[8, 34] = -1.00173577259847e-002;

            __statist_i_h_wts[8, 35] = 3.80660150611957e-002;

            __statist_i_h_wts[8, 36] = 5.64480677122964e-003;

            __statist_i_h_wts[8, 37] = -4.86288588788251e-002;

            __statist_i_h_wts[8, 38] = 2.19683177649174e-002;

            __statist_i_h_wts[8, 39] = 1.08521975247118e-002;

            __statist_i_h_wts[8, 40] = -2.87320734341793e-002;

            __statist_i_h_wts[8, 41] = 3.41163753140921e-002;

            __statist_i_h_wts[8, 42] = 9.28022399408759e-002;

            __statist_i_h_wts[8, 43] = 1.65669457883557e-002;

            __statist_i_h_wts[8, 44] = -8.59215442915280e-002;

            __statist_i_h_wts[8, 45] = -9.53603813537653e-002;

            __statist_i_h_wts[8, 46] = 1.86444644594607e-001;

            __statist_i_h_wts[8, 47] = -9.73863775280646e-002;

            __statist_i_h_wts[8, 48] = 4.74202145455727e-001;

            __statist_i_h_wts[8, 49] = 6.20449554766716e-002;

            __statist_i_h_wts[8, 50] = -5.23891429762566e-001;

            __statist_i_h_wts[8, 51] = -2.00999861029993e-001;

            __statist_i_h_wts[8, 52] = 2.58499848921387e-001;

            __statist_i_h_wts[8, 53] = -7.95181762232919e-002;

            __statist_i_h_wts[8, 54] = 7.63721955067253e-003;

            __statist_i_h_wts[8, 55] = 7.07681776171209e-002;

            __statist_i_h_wts[8, 56] = -9.27213459757624e-002;

            __statist_i_h_wts[8, 57] = 1.48188803528527e-001;

            __statist_i_h_wts[8, 58] = -1.63234323963406e-001;

            __statist_i_h_wts[8, 59] = 1.27034811147014e-002;

            __statist_i_h_wts[8, 60] = -3.61318676229251e-002;

            __statist_i_h_wts[8, 61] = 1.58609932965773e-001;

            __statist_i_h_wts[8, 62] = -1.38650567241542e-001;

            __statist_i_h_wts[8, 63] = 1.05585278391853e+000;

            __statist_i_h_wts[8, 64] = -1.22277040397762e-001;

            __statist_i_h_wts[8, 65] = -9.44243280463804e-001;

            __statist_i_h_wts[8, 66] = -1.16256284947508e-001;

            __statist_i_h_wts[8, 67] = 2.03495427367135e-001;

            __statist_i_h_wts[8, 68] = -9.73299832602524e-002;

            __statist_i_h_wts[8, 69] = -4.97813170190566e-002;

            __statist_i_h_wts[8, 70] = 6.37597716650905e-002;

            __statist_i_h_wts[8, 71] = -3.56448776120531e-002;

            __statist_i_h_wts[8, 72] = -1.79289218315304e-001;

            __statist_i_h_wts[8, 73] = 7.05833394359274e-002;

            __statist_i_h_wts[8, 74] = 1.12087041962244e-001;

            __statist_i_h_wts[8, 75] = -4.76634001387219e-001;

            __statist_i_h_wts[8, 76] = 1.08409112188256e-001;

            __statist_i_h_wts[8, 77] = 3.63872258478832e-001;

            __statist_i_h_wts[8, 78] = -4.97279964276339e-001;

            __statist_i_h_wts[8, 79] = 2.46322637922100e-001;

            __statist_i_h_wts[8, 80] = 2.49793914509877e-001;

            __statist_i_h_wts[8, 81] = -1.76201945729395e-001;

            __statist_i_h_wts[8, 82] = 4.54158352406181e-002;

            __statist_i_h_wts[8, 83] = 1.26150876455712e-001;

            __statist_i_h_wts[8, 84] = 2.32422857876797e-002;

            __statist_i_h_wts[8, 85] = -9.34473079551369e-002;

            __statist_i_h_wts[8, 86] = 6.42096663746889e-002;

            __statist_i_h_wts[8, 87] = -2.21093467102881e-001;

            __statist_i_h_wts[8, 88] = 5.03333601177371e-002;

            __statist_i_h_wts[8, 89] = 1.55748130514339e-001;

            __statist_i_h_wts[8, 90] = 8.33582862784333e-002;

            __statist_i_h_wts[8, 91] = -4.37152503514380e-001;

            __statist_i_h_wts[8, 92] = 3.66853991676287e-001;

            __statist_i_h_wts[8, 93] = -6.14720984234147e-002;

            __statist_i_h_wts[8, 94] = -1.12629972432217e-001;

            __statist_i_h_wts[8, 95] = 1.68326242867463e-001;

            __statist_i_h_wts[8, 96] = 2.86319552971503e-002;

            __statist_i_h_wts[8, 97] = -1.31148261151631e-001;

            __statist_i_h_wts[8, 98] = 8.50460676212896e-002;

            __statist_i_h_wts[8, 99] = -4.78127637169527e-002;

            __statist_i_h_wts[8, 100] = -4.05731013264294e-002;

            __statist_i_h_wts[8, 101] = 9.87544569453333e-002;

            __statist_i_h_wts[8, 102] = -1.86474204449918e-001;

            __statist_i_h_wts[8, 103] = 3.10502864260728e-002;

            __statist_i_h_wts[8, 104] = 1.08380421665275e-001;

            __statist_i_h_wts[8, 105] = -4.11444438267792e-002;

            __statist_i_h_wts[8, 106] = -2.49385190508869e-001;

            __statist_i_h_wts[8, 107] = 2.76217480055009e-001;

            __statist_i_h_wts[8, 108] = -1.80581340978348e-001;

            __statist_i_h_wts[8, 109] = 8.17869781525102e-002;

            __statist_i_h_wts[8, 110] = 7.32750434822699e-002;

            __statist_i_h_wts[8, 111] = -8.28593445931426e-002;

            __statist_i_h_wts[8, 112] = 9.15976768918777e-003;

            __statist_i_h_wts[8, 113] = 9.65114714897571e-002;



            __statist_i_h_wts[9, 0] = 2.27778811362917e-002;

            __statist_i_h_wts[9, 1] = 2.88031939709807e-003;

            __statist_i_h_wts[9, 2] = 3.67781061212000e-003;

            __statist_i_h_wts[9, 3] = -1.51481229560718e-002;

            __statist_i_h_wts[9, 4] = -2.64114784062499e-002;

            __statist_i_h_wts[9, 5] = -4.22626611807860e-003;

            __statist_i_h_wts[9, 6] = 2.18761012907908e-002;

            __statist_i_h_wts[9, 7] = -2.43020824912697e-002;

            __statist_i_h_wts[9, 8] = -2.75309038897335e-003;

            __statist_i_h_wts[9, 9] = 1.58478664546680e-004;

            __statist_i_h_wts[9, 10] = -8.94559126275719e-003;

            __statist_i_h_wts[9, 11] = -5.78054012098083e-003;

            __statist_i_h_wts[9, 12] = 3.05541432791524e-002;

            __statist_i_h_wts[9, 13] = 3.23072188672791e-003;

            __statist_i_h_wts[9, 14] = -1.05982151214416e-002;

            __statist_i_h_wts[9, 15] = -2.69555270753057e-002;

            __statist_i_h_wts[9, 16] = 1.68957368485709e-002;

            __statist_i_h_wts[9, 17] = -1.09862408335695e-003;

            __statist_i_h_wts[9, 18] = 1.52302699103066e-002;

            __statist_i_h_wts[9, 19] = -1.94286419373958e-002;

            __statist_i_h_wts[9, 20] = 1.66223643824627e-002;

            __statist_i_h_wts[9, 21] = -1.30263581309107e-002;

            __statist_i_h_wts[9, 22] = -6.18429520497494e-003;

            __statist_i_h_wts[9, 23] = 8.47599937811900e-003;

            __statist_i_h_wts[9, 24] = 1.12366987720030e-003;

            __statist_i_h_wts[9, 25] = 1.56510769229939e-002;

            __statist_i_h_wts[9, 26] = -1.06140836063862e-002;

            __statist_i_h_wts[9, 27] = 8.82596378336437e-003;

            __statist_i_h_wts[9, 28] = 4.44184140756005e-003;

            __statist_i_h_wts[9, 29] = -2.82810052056806e-002;

            __statist_i_h_wts[9, 30] = 1.47744529739312e-002;

            __statist_i_h_wts[9, 31] = 1.36759428255436e-002;

            __statist_i_h_wts[9, 32] = -2.86252686354984e-003;

            __statist_i_h_wts[9, 33] = 1.10220456265772e-002;

            __statist_i_h_wts[9, 34] = 5.73648156672138e-003;

            __statist_i_h_wts[9, 35] = 2.26352121240314e-002;

            __statist_i_h_wts[9, 36] = -5.20666320293104e-004;

            __statist_i_h_wts[9, 37] = -1.44573886844156e-002;

            __statist_i_h_wts[9, 38] = 3.67255426306074e-002;

            __statist_i_h_wts[9, 39] = 1.21778900558376e-002;

            __statist_i_h_wts[9, 40] = -1.23256079795537e-002;

            __statist_i_h_wts[9, 41] = -1.19020042177929e-002;

            __statist_i_h_wts[9, 42] = -7.88019604729505e-003;

            __statist_i_h_wts[9, 43] = -2.03785502671095e-002;

            __statist_i_h_wts[9, 44] = -3.48637565888278e-002;

            __statist_i_h_wts[9, 45] = -1.03822736883812e-001;

            __statist_i_h_wts[9, 46] = 5.08543579980540e-002;

            __statist_i_h_wts[9, 47] = -2.69574358601656e-002;

            __statist_i_h_wts[9, 48] = 3.56562939483996e-001;

            __statist_i_h_wts[9, 49] = -1.84313441860241e-001;

            __statist_i_h_wts[9, 50] = -2.35361009018869e-001;

            __statist_i_h_wts[9, 51] = -1.64968122455505e-001;

            __statist_i_h_wts[9, 52] = 1.07348536215246e-001;

            __statist_i_h_wts[9, 53] = -7.54571686644876e-003;

            __statist_i_h_wts[9, 54] = -3.19370631153157e-002;

            __statist_i_h_wts[9, 55] = -2.22035694913069e-002;

            __statist_i_h_wts[9, 56] = -3.66784465450070e-002;

            __statist_i_h_wts[9, 57] = 3.56030661012339e-002;

            __statist_i_h_wts[9, 58] = -1.07794750988078e-001;

            __statist_i_h_wts[9, 59] = 1.41795882155668e-002;

            __statist_i_h_wts[9, 60] = -4.30673652732664e-002;

            __statist_i_h_wts[9, 61] = 3.68636610583507e-002;

            __statist_i_h_wts[9, 62] = -5.82969098216333e-002;

            __statist_i_h_wts[9, 63] = 6.09990113231957e-001;

            __statist_i_h_wts[9, 64] = -2.90802066557651e-001;

            __statist_i_h_wts[9, 65] = -3.69885240674698e-001;

            __statist_i_h_wts[9, 66] = -1.26022852797855e-001;

            __statist_i_h_wts[9, 67] = 6.00966953317987e-002;

            __statist_i_h_wts[9, 68] = -1.63053043962299e-002;

            __statist_i_h_wts[9, 69] = -4.91893350645339e-002;

            __statist_i_h_wts[9, 70] = -5.35454317097011e-002;

            __statist_i_h_wts[9, 71] = 4.01734855082693e-003;

            __statist_i_h_wts[9, 72] = -2.79534229815314e-001;

            __statist_i_h_wts[9, 73] = 1.57093473457579e-001;

            __statist_i_h_wts[9, 74] = 5.30602021964700e-002;

            __statist_i_h_wts[9, 75] = -4.54538047007384e-001;

            __statist_i_h_wts[9, 76] = 2.33369791291686e-001;

            __statist_i_h_wts[9, 77] = 1.43820399501133e-001;

            __statist_i_h_wts[9, 78] = -4.74530501990831e-001;

            __statist_i_h_wts[9, 79] = 2.88206987822193e-001;

            __statist_i_h_wts[9, 80] = 8.35744998036665e-002;

            __statist_i_h_wts[9, 81] = -2.70394339335716e-001;

            __statist_i_h_wts[9, 82] = 1.63866578378053e-001;

            __statist_i_h_wts[9, 83] = 5.39812478910004e-002;

            __statist_i_h_wts[9, 84] = -2.41231155077072e-002;

            __statist_i_h_wts[9, 85] = -5.40235960348277e-002;

            __statist_i_h_wts[9, 86] = 1.46346482911172e-002;

            __statist_i_h_wts[9, 87] = -1.30616809009896e-001;

            __statist_i_h_wts[9, 88] = 7.55890489808743e-003;

            __statist_i_h_wts[9, 89] = 5.17529081536253e-002;

            __statist_i_h_wts[9, 90] = 2.51325755021070e-001;

            __statist_i_h_wts[9, 91] = -4.43619882731533e-001;

            __statist_i_h_wts[9, 92] = 1.22603810395202e-001;

            __statist_i_h_wts[9, 93] = -1.05713175631141e-001;

            __statist_i_h_wts[9, 94] = -2.41168859765423e-002;

            __statist_i_h_wts[9, 95] = 5.92023497087470e-002;

            __statist_i_h_wts[9, 96] = -2.31488768247835e-002;

            __statist_i_h_wts[9, 97] = -9.44334918497301e-002;

            __statist_i_h_wts[9, 98] = 3.32814116173275e-002;

            __statist_i_h_wts[9, 99] = -6.48055826897885e-002;

            __statist_i_h_wts[9, 100] = -4.80272560457842e-002;

            __statist_i_h_wts[9, 101] = 1.77189041999123e-002;

            __statist_i_h_wts[9, 102] = -1.35081692520497e-001;

            __statist_i_h_wts[9, 103] = 1.83798564103984e-002;

            __statist_i_h_wts[9, 104] = 5.46440813600140e-002;

            __statist_i_h_wts[9, 105] = 1.64850506769760e-001;

            __statist_i_h_wts[9, 106] = -3.35197863065239e-001;

            __statist_i_h_wts[9, 107] = 1.23679824152600e-001;

            __statist_i_h_wts[9, 108] = -1.64490764168588e-001;

            __statist_i_h_wts[9, 109] = 6.88961505704400e-002;

            __statist_i_h_wts[9, 110] = 2.39066578374495e-002;

            __statist_i_h_wts[9, 111] = -7.49462214719540e-002;

            __statist_i_h_wts[9, 112] = -1.62470854129187e-002;

            __statist_i_h_wts[9, 113] = 4.07278241050401e-002;



            __statist_i_h_wts[10, 0] = 8.82009141880671e-002;

            __statist_i_h_wts[10, 1] = 8.31414329407371e-003;

            __statist_i_h_wts[10, 2] = 9.74636666685441e-002;

            __statist_i_h_wts[10, 3] = 2.65822381332251e-002;

            __statist_i_h_wts[10, 4] = -2.02026852360010e-001;

            __statist_i_h_wts[10, 5] = 5.36530595885593e-003;

            __statist_i_h_wts[10, 6] = -1.46558976780617e-002;

            __statist_i_h_wts[10, 7] = -5.49284214350124e-002;

            __statist_i_h_wts[10, 8] = -1.13297544585631e-002;

            __statist_i_h_wts[10, 9] = -1.57958294374785e-002;

            __statist_i_h_wts[10, 10] = -2.48361107758711e-002;

            __statist_i_h_wts[10, 11] = 2.10621507296299e-002;

            __statist_i_h_wts[10, 12] = 6.28558860856196e-003;

            __statist_i_h_wts[10, 13] = 2.37300312196222e-002;

            __statist_i_h_wts[10, 14] = -1.36523562220163e-002;

            __statist_i_h_wts[10, 15] = -1.11173161890146e-001;

            __statist_i_h_wts[10, 16] = 3.90038563488311e-002;

            __statist_i_h_wts[10, 17] = -8.36710520998634e-002;

            __statist_i_h_wts[10, 18] = -1.16539444304353e-002;

            __statist_i_h_wts[10, 19] = -1.89156608350000e-002;

            __statist_i_h_wts[10, 20] = 1.35759663648470e-002;

            __statist_i_h_wts[10, 21] = -4.61966110942155e-003;

            __statist_i_h_wts[10, 22] = -1.35920092695670e-002;

            __statist_i_h_wts[10, 23] = -4.90183451884714e-002;

            __statist_i_h_wts[10, 24] = 8.22763088694582e-003;

            __statist_i_h_wts[10, 25] = 9.75559475155461e-002;

            __statist_i_h_wts[10, 26] = -9.48605854431589e-003;

            __statist_i_h_wts[10, 27] = 6.34576299655054e-002;

            __statist_i_h_wts[10, 28] = 4.19273210234962e-003;

            __statist_i_h_wts[10, 29] = -9.40639042653844e-002;

            __statist_i_h_wts[10, 30] = -4.31775270028210e-003;

            __statist_i_h_wts[10, 31] = 7.45950718888489e-002;

            __statist_i_h_wts[10, 32] = -4.64791191273424e-003;

            __statist_i_h_wts[10, 33] = -4.75845943712000e-002;

            __statist_i_h_wts[10, 34] = -5.61379016882683e-003;

            __statist_i_h_wts[10, 35] = 6.95763835335955e-003;

            __statist_i_h_wts[10, 36] = -1.34722433580785e-004;

            __statist_i_h_wts[10, 37] = -6.21798704811686e-002;

            __statist_i_h_wts[10, 38] = 6.92268235751472e-002;

            __statist_i_h_wts[10, 39] = 3.85491966712780e-002;

            __statist_i_h_wts[10, 40] = -1.89268973596586e-002;

            __statist_i_h_wts[10, 41] = 5.42150848756102e-002;

            __statist_i_h_wts[10, 42] = -1.40499394733101e-001;

            __statist_i_h_wts[10, 43] = 1.28320479716686e-001;

            __statist_i_h_wts[10, 44] = -6.93737414660320e-002;

            __statist_i_h_wts[10, 45] = -1.31459886703810e-001;

            __statist_i_h_wts[10, 46] = 9.34197474950417e-002;

            __statist_i_h_wts[10, 47] = -4.32758178754861e-002;

            __statist_i_h_wts[10, 48] = 9.54378406584641e-001;

            __statist_i_h_wts[10, 49] = -3.79906159918083e-001;

            __statist_i_h_wts[10, 50] = -6.67629507137256e-001;

            __statist_i_h_wts[10, 51] = -3.05960019672534e-001;

            __statist_i_h_wts[10, 52] = 2.12573928366950e-001;

            __statist_i_h_wts[10, 53] = -2.64882537876084e-003;

            __statist_i_h_wts[10, 54] = -3.17818056446279e-002;

            __statist_i_h_wts[10, 55] = 2.72885298223101e-002;

            __statist_i_h_wts[10, 56] = -8.30652915714788e-002;

            __statist_i_h_wts[10, 57] = -2.96942353642695e-001;

            __statist_i_h_wts[10, 58] = 1.70025423279922e-001;

            __statist_i_h_wts[10, 59] = 2.54004945474432e-002;

            __statist_i_h_wts[10, 60] = -1.54707430376364e-001;

            __statist_i_h_wts[10, 61] = 2.64102495111406e-001;

            __statist_i_h_wts[10, 62] = -1.96915382937723e-001;

            __statist_i_h_wts[10, 63] = 1.70421570471035e+000;

            __statist_i_h_wts[10, 64] = -5.20360557041343e-001;

            __statist_i_h_wts[10, 65] = -1.28949255386098e+000;

            __statist_i_h_wts[10, 66] = -3.01646708456594e-001;

            __statist_i_h_wts[10, 67] = 2.83022835678681e-001;

            __statist_i_h_wts[10, 68] = -5.08129734186995e-002;

            __statist_i_h_wts[10, 69] = -2.90016645341352e-001;

            __statist_i_h_wts[10, 70] = 2.08665462011482e-001;

            __statist_i_h_wts[10, 71] = 1.71950948578102e-002;

            __statist_i_h_wts[10, 72] = -6.18558341129279e-001;

            __statist_i_h_wts[10, 73] = 3.66081846516510e-001;

            __statist_i_h_wts[10, 74] = 1.71441028945991e-001;

            __statist_i_h_wts[10, 75] = -9.61389313419902e-001;

            __statist_i_h_wts[10, 76] = 4.91233956523568e-001;

            __statist_i_h_wts[10, 77] = 3.82719886632322e-001;

            __statist_i_h_wts[10, 78] = -1.02627772306212e+000;

            __statist_i_h_wts[10, 79] = 7.11955403723628e-001;

            __statist_i_h_wts[10, 80] = 2.13420823335761e-001;

            __statist_i_h_wts[10, 81] = -5.93901183629362e-001;

            __statist_i_h_wts[10, 82] = 4.37863435195230e-001;

            __statist_i_h_wts[10, 83] = 9.39803474426495e-002;

            __statist_i_h_wts[10, 84] = -2.71070970325410e-001;

            __statist_i_h_wts[10, 85] = 9.16412465056892e-002;

            __statist_i_h_wts[10, 86] = 5.79647433570403e-002;

            __statist_i_h_wts[10, 87] = -1.87674232667288e-001;

            __statist_i_h_wts[10, 88] = -3.78969998303829e-002;

            __statist_i_h_wts[10, 89] = 1.34914198595064e-001;

            __statist_i_h_wts[10, 90] = 5.33478883136675e-001;

            __statist_i_h_wts[10, 91] = -9.28631832755876e-001;

            __statist_i_h_wts[10, 92] = 2.91485838789826e-001;

            __statist_i_h_wts[10, 93] = -4.58222960940299e-002;

            __statist_i_h_wts[10, 94] = -1.67394544129553e-001;

            __statist_i_h_wts[10, 95] = 1.54941896092818e-001;

            __statist_i_h_wts[10, 96] = -5.94600264744482e-002;

            __statist_i_h_wts[10, 97] = -1.08425954843091e-001;

            __statist_i_h_wts[10, 98] = 8.98810440232034e-002;

            __statist_i_h_wts[10, 99] = -1.93640134251857e-001;

            __statist_i_h_wts[10, 100] = 3.69063740902035e-002;

            __statist_i_h_wts[10, 101] = 8.89074848326634e-002;

            __statist_i_h_wts[10, 102] = -6.84860810908634e-002;

            __statist_i_h_wts[10, 103] = -1.57349028561725e-001;

            __statist_i_h_wts[10, 104] = 1.07478818760328e-001;

            __statist_i_h_wts[10, 105] = 4.82667416604666e-001;

            __statist_i_h_wts[10, 106] = -8.06169630691581e-001;

            __statist_i_h_wts[10, 107] = 2.56940819790570e-001;

            __statist_i_h_wts[10, 108] = -9.12428898111551e-002;

            __statist_i_h_wts[10, 109] = -8.73462919648912e-003;

            __statist_i_h_wts[10, 110] = 4.95633564292694e-002;

            __statist_i_h_wts[10, 111] = -1.60493290252655e-001;

            __statist_i_h_wts[10, 112] = 2.89818465396714e-002;

            __statist_i_h_wts[10, 113] = 7.94820392863596e-002;



            __statist_i_h_wts[11, 0] = -2.94054200624072e-001;

            __statist_i_h_wts[11, 1] = -8.90626990698066e-002;

            __statist_i_h_wts[11, 2] = -4.15363314440732e-002;

            __statist_i_h_wts[11, 3] = -1.40851177218203e-001;

            __statist_i_h_wts[11, 4] = 1.47213668279083e-001;

            __statist_i_h_wts[11, 5] = -3.52686245813411e-001;

            __statist_i_h_wts[11, 6] = -5.54291869216480e-002;

            __statist_i_h_wts[11, 7] = -2.30793931312284e-002;

            __statist_i_h_wts[11, 8] = -7.56038286023145e-002;

            __statist_i_h_wts[11, 9] = -1.67387432404039e-001;

            __statist_i_h_wts[11, 10] = -2.54213807713414e-001;

            __statist_i_h_wts[11, 11] = 1.85714996060179e-001;

            __statist_i_h_wts[11, 12] = 1.74813395349149e-001;

            __statist_i_h_wts[11, 13] = 1.28065986935154e-001;

            __statist_i_h_wts[11, 14] = 4.16908684204546e-002;

            __statist_i_h_wts[11, 15] = -1.32329083250894e-002;

            __statist_i_h_wts[11, 16] = -1.01796722645841e-001;

            __statist_i_h_wts[11, 17] = -1.56175793121021e-001;

            __statist_i_h_wts[11, 18] = -1.07489557543376e-002;

            __statist_i_h_wts[11, 19] = 4.65086222755600e-002;

            __statist_i_h_wts[11, 20] = -1.31858621971141e-002;

            __statist_i_h_wts[11, 21] = -6.73853557448485e-003;

            __statist_i_h_wts[11, 22] = 4.00295259489168e-002;

            __statist_i_h_wts[11, 23] = 1.61058737114568e-001;

            __statist_i_h_wts[11, 24] = 1.04861599751442e-003;

            __statist_i_h_wts[11, 25] = -6.12903080812105e-002;

            __statist_i_h_wts[11, 26] = -1.14633154548227e-001;

            __statist_i_h_wts[11, 27] = -1.80985655668986e-001;

            __statist_i_h_wts[11, 28] = -9.87682209406783e-002;

            __statist_i_h_wts[11, 29] = -6.13584145637568e-003;

            __statist_i_h_wts[11, 30] = -1.09654503909169e-002;

            __statist_i_h_wts[11, 31] = 1.10734221955345e-001;

            __statist_i_h_wts[11, 32] = -1.89417220975814e-001;

            __statist_i_h_wts[11, 33] = 8.14874328899634e-002;

            __statist_i_h_wts[11, 34] = -4.64145585034729e-002;

            __statist_i_h_wts[11, 35] = 1.62451396235530e-001;

            __statist_i_h_wts[11, 36] = 3.10929487476455e-003;

            __statist_i_h_wts[11, 37] = 9.08253158332187e-002;

            __statist_i_h_wts[11, 38] = 8.07423360206103e-002;

            __statist_i_h_wts[11, 39] = 3.21661321431649e-001;

            __statist_i_h_wts[11, 40] = 1.14352900775027e-001;

            __statist_i_h_wts[11, 41] = 1.18746485904632e-001;

            __statist_i_h_wts[11, 42] = -7.34834812294009e-002;

            __statist_i_h_wts[11, 43] = -2.18746383579477e-001;

            __statist_i_h_wts[11, 44] = -2.17594924504077e-001;

            __statist_i_h_wts[11, 45] = -5.04965994746197e-001;

            __statist_i_h_wts[11, 46] = -1.43930924578782e-001;

            __statist_i_h_wts[11, 47] = 1.37040134909746e-001;

            __statist_i_h_wts[11, 48] = -3.45379821039606e-001;

            __statist_i_h_wts[11, 49] = -5.98320447775687e-001;

            __statist_i_h_wts[11, 50] = 4.46400113593242e-001;

            __statist_i_h_wts[11, 51] = -4.94809984461340e-001;

            __statist_i_h_wts[11, 52] = -1.91093235348439e-001;

            __statist_i_h_wts[11, 53] = 1.89452563217405e-001;

            __statist_i_h_wts[11, 54] = 8.61859487176459e-003;

            __statist_i_h_wts[11, 55] = -4.40651728859354e-001;

            __statist_i_h_wts[11, 56] = -6.92157960853534e-002;

            __statist_i_h_wts[11, 57] = -2.19994090164013e-001;

            __statist_i_h_wts[11, 58] = -1.56966843314885e-001;

            __statist_i_h_wts[11, 59] = -1.19019316765404e-001;

            __statist_i_h_wts[11, 60] = -3.07551845631453e-001;

            __statist_i_h_wts[11, 61] = -3.64464685873820e-001;

            __statist_i_h_wts[11, 62] = 1.77063984520913e-001;

            __statist_i_h_wts[11, 63] = -1.38991812937453e+000;

            __statist_i_h_wts[11, 64] = -5.75494610076751e-001;

            __statist_i_h_wts[11, 65] = 1.45636840252389e+000;

            __statist_i_h_wts[11, 66] = -1.51109819207552e-001;

            __statist_i_h_wts[11, 67] = -1.25768565277384e-001;

            __statist_i_h_wts[11, 68] = -2.26730038239250e-001;

            __statist_i_h_wts[11, 69] = -2.22549402502115e-001;

            __statist_i_h_wts[11, 70] = -1.22861459970042e-001;

            __statist_i_h_wts[11, 71] = -1.71085591664111e-001;

            __statist_i_h_wts[11, 72] = 1.28292343575493e-001;

            __statist_i_h_wts[11, 73] = 2.63956263889024e-001;

            __statist_i_h_wts[11, 74] = -9.01746012823572e-001;

            __statist_i_h_wts[11, 75] = 8.96748538510367e-001;

            __statist_i_h_wts[11, 76] = 5.25851957499845e-001;

            __statist_i_h_wts[11, 77] = -1.89994120062406e+000;

            __statist_i_h_wts[11, 78] = 8.84796907352832e-001;

            __statist_i_h_wts[11, 79] = 1.27429752043890e-001;

            __statist_i_h_wts[11, 80] = -1.53555274343803e+000;

            __statist_i_h_wts[11, 81] = -1.20254926091880e-001;

            __statist_i_h_wts[11, 82] = -1.84041441431762e-001;

            __statist_i_h_wts[11, 83] = -2.07674792085462e-001;

            __statist_i_h_wts[11, 84] = 1.91973095467643e-001;

            __statist_i_h_wts[11, 85] = -3.02202977963195e-001;

            __statist_i_h_wts[11, 86] = -4.10566858330142e-001;

            __statist_i_h_wts[11, 87] = 1.44891211688694e-001;

            __statist_i_h_wts[11, 88] = 1.74676900972947e-001;

            __statist_i_h_wts[11, 89] = -8.06234268394116e-001;

            __statist_i_h_wts[11, 90] = 7.90368371067814e-001;

            __statist_i_h_wts[11, 91] = 4.00645980535762e-001;

            __statist_i_h_wts[11, 92] = -1.69850342037448e+000;

            __statist_i_h_wts[11, 93] = 1.87057067095204e-001;

            __statist_i_h_wts[11, 94] = 3.53541395223054e-001;

            __statist_i_h_wts[11, 95] = -1.01100423121609e+000;

            __statist_i_h_wts[11, 96] = -1.96789965048428e-001;

            __statist_i_h_wts[11, 97] = 3.29738914095175e-001;

            __statist_i_h_wts[11, 98] = -6.33333506392204e-001;

            __statist_i_h_wts[11, 99] = -5.91308478105776e-002;

            __statist_i_h_wts[11, 100] = -3.70207035634463e-002;

            __statist_i_h_wts[11, 101] = -4.38518827653260e-001;

            __statist_i_h_wts[11, 102] = 3.82748552488842e-002;

            __statist_i_h_wts[11, 103] = 1.78195106830859e-001;

            __statist_i_h_wts[11, 104] = -7.07329779772487e-001;

            __statist_i_h_wts[11, 105] = 2.44705395731889e-001;

            __statist_i_h_wts[11, 106] = 4.99227807547685e-001;

            __statist_i_h_wts[11, 107] = -1.24705480160005e+000;

            __statist_i_h_wts[11, 108] = 5.56881833242459e-003;

            __statist_i_h_wts[11, 109] = -7.58937294363178e-002;

            __statist_i_h_wts[11, 110] = -4.06994456319346e-001;

            __statist_i_h_wts[11, 111] = 8.37298619667652e-002;

            __statist_i_h_wts[11, 112] = -8.84873835742024e-002;

            __statist_i_h_wts[11, 113] = -4.86007645337400e-001;



            __statist_i_h_wts[12, 0] = -4.02973651738129e-002;

            __statist_i_h_wts[12, 1] = -1.35138666598474e-002;

            __statist_i_h_wts[12, 2] = -3.13003580489038e-002;

            __statist_i_h_wts[12, 3] = -1.80496263517338e-002;

            __statist_i_h_wts[12, 4] = 1.60501517789079e-002;

            __statist_i_h_wts[12, 5] = -1.27708967486692e-002;

            __statist_i_h_wts[12, 6] = -8.89229124736857e-003;

            __statist_i_h_wts[12, 7] = 1.77791871451497e-002;

            __statist_i_h_wts[12, 8] = 6.05800576468293e-003;

            __statist_i_h_wts[12, 9] = -2.47600515953185e-002;

            __statist_i_h_wts[12, 10] = 4.21863079819546e-003;

            __statist_i_h_wts[12, 11] = -2.47831619664985e-003;

            __statist_i_h_wts[12, 12] = 1.21261933561359e-002;

            __statist_i_h_wts[12, 13] = -4.24349370975016e-003;

            __statist_i_h_wts[12, 14] = -1.31520684567209e-002;

            __statist_i_h_wts[12, 15] = 3.60234565407589e-003;

            __statist_i_h_wts[12, 16] = -2.82735808163220e-002;

            __statist_i_h_wts[12, 17] = 1.48122085877989e-002;

            __statist_i_h_wts[12, 18] = -9.82173548631052e-003;

            __statist_i_h_wts[12, 19] = 1.30722007146861e-002;

            __statist_i_h_wts[12, 20] = -2.67512849487821e-002;

            __statist_i_h_wts[12, 21] = -4.72555962087147e-003;

            __statist_i_h_wts[12, 22] = -2.30470211473031e-002;

            __statist_i_h_wts[12, 23] = 6.37542640031239e-003;

            __statist_i_h_wts[12, 24] = 8.58212590925243e-003;

            __statist_i_h_wts[12, 25] = -1.29917293284723e-002;

            __statist_i_h_wts[12, 26] = 1.16757088185277e-002;

            __statist_i_h_wts[12, 27] = -5.82014756835491e-003;

            __statist_i_h_wts[12, 28] = -1.29847668885250e-004;

            __statist_i_h_wts[12, 29] = 2.74720959684734e-002;

            __statist_i_h_wts[12, 30] = -1.59223052674706e-002;

            __statist_i_h_wts[12, 31] = -3.42591590776646e-002;

            __statist_i_h_wts[12, 32] = -2.10061461926398e-003;

            __statist_i_h_wts[12, 33] = -1.42186628547461e-002;

            __statist_i_h_wts[12, 34] = -1.78372503062767e-002;

            __statist_i_h_wts[12, 35] = -4.56812487208712e-002;

            __statist_i_h_wts[12, 36] = -6.65297295977828e-003;

            __statist_i_h_wts[12, 37] = 5.21369321655455e-003;

            __statist_i_h_wts[12, 38] = -3.16423311224170e-002;

            __statist_i_h_wts[12, 39] = -1.58397556053060e-002;

            __statist_i_h_wts[12, 40] = 1.79567297790432e-002;

            __statist_i_h_wts[12, 41] = -4.79906143160187e-003;

            __statist_i_h_wts[12, 42] = -1.14574350007555e-001;

            __statist_i_h_wts[12, 43] = -1.19012085762477e-001;

            __statist_i_h_wts[12, 44] = -1.41774707992962e-002;

            __statist_i_h_wts[12, 45] = -1.26669265459878e-001;

            __statist_i_h_wts[12, 46] = -9.57425290137799e-002;

            __statist_i_h_wts[12, 47] = -1.87200915530539e-002;

            __statist_i_h_wts[12, 48] = 1.92363499143775e-001;

            __statist_i_h_wts[12, 49] = -6.03925243746840e-001;

            __statist_i_h_wts[12, 50] = 1.60265947918667e-001;

            __statist_i_h_wts[12, 51] = -8.69358172246688e-002;

            __statist_i_h_wts[12, 52] = -1.63725902414169e-001;

            __statist_i_h_wts[12, 53] = 1.42046146967047e-003;

            __statist_i_h_wts[12, 54] = -1.48255678716142e-001;

            __statist_i_h_wts[12, 55] = -1.40574599335914e-001;

            __statist_i_h_wts[12, 56] = 2.13536166970375e-002;

            __statist_i_h_wts[12, 57] = -6.34841304413140e-002;

            __statist_i_h_wts[12, 58] = -1.71312634918126e-001;

            __statist_i_h_wts[12, 59] = -3.20351732803158e-002;

            __statist_i_h_wts[12, 60] = -1.16144848439970e-001;

            __statist_i_h_wts[12, 61] = -1.82783968453983e-001;

            __statist_i_h_wts[12, 62] = 5.08319611866562e-002;

            __statist_i_h_wts[12, 63] = 8.86792821585319e-002;

            __statist_i_h_wts[12, 64] = -7.72783070425441e-001;

            __statist_i_h_wts[12, 65] = 4.18006181428976e-001;

            __statist_i_h_wts[12, 66] = -9.04974637111845e-002;

            __statist_i_h_wts[12, 67] = -1.74212737775898e-001;

            __statist_i_h_wts[12, 68] = 1.54354302283324e-002;

            __statist_i_h_wts[12, 69] = -1.26394983494907e-002;

            __statist_i_h_wts[12, 70] = -2.09405096878839e-001;

            __statist_i_h_wts[12, 71] = -2.17814503037410e-002;

            __statist_i_h_wts[12, 72] = -6.61383566507038e-001;

            __statist_i_h_wts[12, 73] = 4.28250644590310e-001;

            __statist_i_h_wts[12, 74] = -3.42585421029333e-002;

            __statist_i_h_wts[12, 75] = -6.72122897849929e-001;

            __statist_i_h_wts[12, 76] = 5.05185782562920e-001;

            __statist_i_h_wts[12, 77] = -8.15491740254814e-002;

            __statist_i_h_wts[12, 78] = -7.26208082496825e-001;

            __statist_i_h_wts[12, 79] = 5.31378351382741e-001;

            __statist_i_h_wts[12, 80] = -7.18059951400308e-002;

            __statist_i_h_wts[12, 81] = -6.65274126172912e-001;

            __statist_i_h_wts[12, 82] = 4.24924680560091e-001;

            __statist_i_h_wts[12, 83] = -1.37717183868875e-002;

            __statist_i_h_wts[12, 84] = -1.03916171466247e-002;

            __statist_i_h_wts[12, 85] = -2.21011858482670e-001;

            __statist_i_h_wts[12, 86] = -1.18762416048818e-002;

            __statist_i_h_wts[12, 87] = -5.45320190435356e-002;

            __statist_i_h_wts[12, 88] = -1.56517995258453e-001;

            __statist_i_h_wts[12, 89] = -3.77091257709291e-002;

            __statist_i_h_wts[12, 90] = 7.01550522472642e-001;

            __statist_i_h_wts[12, 91] = -8.57941003418535e-001;

            __statist_i_h_wts[12, 92] = -1.00474810008105e-001;

            __statist_i_h_wts[12, 93] = -1.23740858387611e-001;

            __statist_i_h_wts[12, 94] = -8.95724865582692e-002;

            __statist_i_h_wts[12, 95] = -2.75216771845593e-002;

            __statist_i_h_wts[12, 96] = -6.58843383655788e-002;

            __statist_i_h_wts[12, 97] = -1.57299338553602e-001;

            __statist_i_h_wts[12, 98] = -2.77284428443874e-002;

            __statist_i_h_wts[12, 99] = -7.40291926412510e-002;

            __statist_i_h_wts[12, 100] = -1.67096940249341e-001;

            __statist_i_h_wts[12, 101] = -1.72360865046502e-002;

            __statist_i_h_wts[12, 102] = -1.21316723876945e-001;

            __statist_i_h_wts[12, 103] = -1.24875325440260e-001;

            __statist_i_h_wts[12, 104] = 2.68467053188180e-004;

            __statist_i_h_wts[12, 105] = 6.00177457128741e-001;

            __statist_i_h_wts[12, 106] = -7.74923227526854e-001;

            __statist_i_h_wts[12, 107] = -1.12843012320459e-001;

            __statist_i_h_wts[12, 108] = -1.84280938489765e-001;

            __statist_i_h_wts[12, 109] = -8.22335470939786e-002;

            __statist_i_h_wts[12, 110] = -1.76040725572642e-002;

            __statist_i_h_wts[12, 111] = -9.42447357738428e-002;

            __statist_i_h_wts[12, 112] = -1.51933066124635e-001;

            __statist_i_h_wts[12, 113] = -1.95361511080900e-002;



            __statist_i_h_wts[13, 0] = -1.35051808829723e-001;

            __statist_i_h_wts[13, 1] = -7.60370914268989e-002;

            __statist_i_h_wts[13, 2] = 3.57504416825406e-002;

            __statist_i_h_wts[13, 3] = 1.07585860790574e-001;

            __statist_i_h_wts[13, 4] = -6.88682107504530e-002;

            __statist_i_h_wts[13, 5] = 1.48687152529997e-002;

            __statist_i_h_wts[13, 6] = 1.81770560418849e-001;

            __statist_i_h_wts[13, 7] = -7.73275897167902e-002;

            __statist_i_h_wts[13, 8] = -7.01243520934120e-003;

            __statist_i_h_wts[13, 9] = -1.22194735541777e-001;

            __statist_i_h_wts[13, 10] = 4.28900996440682e-002;

            __statist_i_h_wts[13, 11] = -2.71702588863051e-002;

            __statist_i_h_wts[13, 12] = 5.57946999179682e-003;

            __statist_i_h_wts[13, 13] = 4.78545795005126e-002;

            __statist_i_h_wts[13, 14] = 4.71582796387192e-002;

            __statist_i_h_wts[13, 15] = -8.59059893145833e-002;

            __statist_i_h_wts[13, 16] = 7.72784535453251e-002;

            __statist_i_h_wts[13, 17] = 7.11901311283236e-002;

            __statist_i_h_wts[13, 18] = 1.23044242155584e-002;

            __statist_i_h_wts[13, 19] = -7.21351952942402e-002;

            __statist_i_h_wts[13, 20] = -2.57120510473571e-002;

            __statist_i_h_wts[13, 21] = -1.89254611533712e-002;

            __statist_i_h_wts[13, 22] = 9.45137824767056e-002;

            __statist_i_h_wts[13, 23] = 4.12694757779470e-002;

            __statist_i_h_wts[13, 24] = 1.25477023826561e-001;

            __statist_i_h_wts[13, 25] = 2.46720097631202e-002;

            __statist_i_h_wts[13, 26] = -7.19116774765872e-002;

            __statist_i_h_wts[13, 27] = -5.79802238627707e-002;

            __statist_i_h_wts[13, 28] = -2.38736043798044e-002;

            __statist_i_h_wts[13, 29] = -2.13864972677160e-003;

            __statist_i_h_wts[13, 30] = 1.09443845122439e-001;

            __statist_i_h_wts[13, 31] = -1.26945086254906e-002;

            __statist_i_h_wts[13, 32] = -1.04552202592118e-001;

            __statist_i_h_wts[13, 33] = 6.36777496825824e-002;

            __statist_i_h_wts[13, 34] = -1.00858739689759e-001;

            __statist_i_h_wts[13, 35] = -3.65076994719020e-002;

            __statist_i_h_wts[13, 36] = 1.67032714683898e-002;

            __statist_i_h_wts[13, 37] = -9.97204482187490e-002;

            __statist_i_h_wts[13, 38] = 9.87261578849987e-002;

            __statist_i_h_wts[13, 39] = -6.46189260214956e-002;

            __statist_i_h_wts[13, 40] = 3.28937644378597e-003;

            __statist_i_h_wts[13, 41] = 1.50373853630752e-001;

            __statist_i_h_wts[13, 42] = 1.11455165859040e-001;

            __statist_i_h_wts[13, 43] = 2.24163878184381e-001;

            __statist_i_h_wts[13, 44] = -2.94240949822789e-001;

            __statist_i_h_wts[13, 45] = -1.69342032817830e-002;

            __statist_i_h_wts[13, 46] = 4.32898206226561e-001;

            __statist_i_h_wts[13, 47] = -3.85656438189743e-001;

            __statist_i_h_wts[13, 48] = 4.22714364805951e-001;

            __statist_i_h_wts[13, 49] = 4.87111509461544e-001;

            __statist_i_h_wts[13, 50] = -8.62782073339570e-001;

            __statist_i_h_wts[13, 51] = 2.77013437806498e-001;

            __statist_i_h_wts[13, 52] = 1.37074733623408e-001;

            __statist_i_h_wts[13, 53] = -3.70625479879986e-001;

            __statist_i_h_wts[13, 54] = 1.80597833107518e-001;

            __statist_i_h_wts[13, 55] = 7.46466202206331e-002;

            __statist_i_h_wts[13, 56] = -2.13845544213935e-001;

            __statist_i_h_wts[13, 57] = 2.28107118469933e-001;

            __statist_i_h_wts[13, 58] = -3.39720248067058e-002;

            __statist_i_h_wts[13, 59] = -1.23491057173734e-001;

            __statist_i_h_wts[13, 60] = 3.18558283588517e-001;

            __statist_i_h_wts[13, 61] = 2.79237198894479e-004;

            __statist_i_h_wts[13, 62] = -2.64168297510874e-001;

            __statist_i_h_wts[13, 63] = 1.38035666169158e+000;

            __statist_i_h_wts[13, 64] = 3.90398943698544e-001;

            __statist_i_h_wts[13, 65] = -1.72690287401228e+000;

            __statist_i_h_wts[13, 66] = 3.28106047874793e-001;

            __statist_i_h_wts[13, 67] = 1.22352848473603e-001;

            __statist_i_h_wts[13, 68] = -4.14829272756346e-001;

            __statist_i_h_wts[13, 69] = 7.03843362204957e-002;

            __statist_i_h_wts[13, 70] = 1.83685985230884e-001;

            __statist_i_h_wts[13, 71] = -2.10541729293942e-001;

            __statist_i_h_wts[13, 72] = -2.57226214652251e-002;

            __statist_i_h_wts[13, 73] = -7.62430745938754e-002;

            __statist_i_h_wts[13, 74] = 1.55371038033023e-001;

            __statist_i_h_wts[13, 75] = -1.33896697948147e-001;

            __statist_i_h_wts[13, 76] = -6.60146251159018e-001;

            __statist_i_h_wts[13, 77] = 8.61885894541012e-001;

            __statist_i_h_wts[13, 78] = -4.92994342628114e-002;

            __statist_i_h_wts[13, 79] = -5.07830802803415e-001;

            __statist_i_h_wts[13, 80] = 5.83096522119109e-001;

            __statist_i_h_wts[13, 81] = 3.23844151743786e-002;

            __statist_i_h_wts[13, 82] = -1.91104758311716e-001;

            __statist_i_h_wts[13, 83] = 2.06441309380276e-001;

            __statist_i_h_wts[13, 84] = 3.33131173339216e-002;

            __statist_i_h_wts[13, 85] = -2.01479188675335e-001;

            __statist_i_h_wts[13, 86] = 2.54847352446689e-001;

            __statist_i_h_wts[13, 87] = -3.26347311481185e-001;

            __statist_i_h_wts[13, 88] = -2.53902579360379e-001;

            __statist_i_h_wts[13, 89] = 6.30743597705257e-001;

            __statist_i_h_wts[13, 90] = -5.12095248027193e-001;

            __statist_i_h_wts[13, 91] = -3.97625963918126e-001;

            __statist_i_h_wts[13, 92] = 9.71163064752271e-001;

            __statist_i_h_wts[13, 93] = -3.96026329681538e-001;

            __statist_i_h_wts[13, 94] = -2.81488043429885e-002;

            __statist_i_h_wts[13, 95] = 4.76269551907724e-001;

            __statist_i_h_wts[13, 96] = -3.34813207757548e-001;

            __statist_i_h_wts[13, 97] = 1.49380059853960e-001;

            __statist_i_h_wts[13, 98] = 2.07400674599582e-001;

            __statist_i_h_wts[13, 99] = -1.30717642604223e-001;

            __statist_i_h_wts[13, 100] = -1.62372723032485e-001;

            __statist_i_h_wts[13, 101] = 3.28313612809386e-001;

            __statist_i_h_wts[13, 102] = -4.24259012571549e-001;

            __statist_i_h_wts[13, 103] = -3.32273099921439e-002;

            __statist_i_h_wts[13, 104] = 4.66676376213026e-001;

            __statist_i_h_wts[13, 105] = -5.27598896890232e-001;

            __statist_i_h_wts[13, 106] = -2.33541824564642e-001;

            __statist_i_h_wts[13, 107] = 7.87673993501913e-001;

            __statist_i_h_wts[13, 108] = -2.93648771222376e-001;

            __statist_i_h_wts[13, 109] = -1.35840195835207e-001;

            __statist_i_h_wts[13, 110] = 4.71046182482750e-001;

            __statist_i_h_wts[13, 111] = -1.83471195442238e-001;

            __statist_i_h_wts[13, 112] = -9.93249600615751e-002;

            __statist_i_h_wts[13, 113] = 3.55007907136439e-001;



            double[,] __statist_h_o_wts = new double[2, 14];



            __statist_h_o_wts[0, 0] = 4.26575743673538e-001;

            __statist_h_o_wts[0, 1] = 1.24733968379355e-002;

            __statist_h_o_wts[0, 2] = 2.36555977076386e-001;

            __statist_h_o_wts[0, 3] = 7.80741664663230e-001;

            __statist_h_o_wts[0, 4] = 3.02517805297249e-001;

            __statist_h_o_wts[0, 5] = 2.59310128848250e-001;

            __statist_h_o_wts[0, 6] = -1.22501139065575e-001;

            __statist_h_o_wts[0, 7] = 8.15300665052286e-002;

            __statist_h_o_wts[0, 8] = 3.28390020361401e-001;

            __statist_h_o_wts[0, 9] = 2.90908141741065e-001;

            __statist_h_o_wts[0, 10] = 7.71196483113683e-002;

            __statist_h_o_wts[0, 11] = -1.18476893590305e+000;

            __statist_h_o_wts[0, 12] = -1.40395865824242e-001;

            __statist_h_o_wts[0, 13] = 6.68932941972934e-001;



            __statist_h_o_wts[1, 0] = -4.22878738347578e-001;

            __statist_h_o_wts[1, 1] = 5.76027115085352e-002;

            __statist_h_o_wts[1, 2] = -2.13046239316836e-001;

            __statist_h_o_wts[1, 3] = -7.44482618203106e-001;

            __statist_h_o_wts[1, 4] = -3.25727078564278e-001;

            __statist_h_o_wts[1, 5] = -1.96846278054636e-001;

            __statist_h_o_wts[1, 6] = 1.24485026057110e-001;

            __statist_h_o_wts[1, 7] = -9.33823660473101e-002;

            __statist_h_o_wts[1, 8] = -3.55033894365946e-001;

            __statist_h_o_wts[1, 9] = -3.01289271103302e-001;

            __statist_h_o_wts[1, 10] = -4.07105986433960e-002;

            __statist_h_o_wts[1, 11] = 1.17895380892088e+000;

            __statist_h_o_wts[1, 12] = 2.05298056385012e-001;

            __statist_h_o_wts[1, 13] = -6.83735811786383e-001;



            double[] __statist_hidden_bias = new double[14];

            __statist_hidden_bias[0] = -1.95474376550970e-002;

            __statist_hidden_bias[1] = -1.61761682635697e-002;

            __statist_hidden_bias[2] = 6.48310609833478e-002;

            __statist_hidden_bias[3] = 2.62583188411560e-002;

            __statist_hidden_bias[4] = 1.52012632402567e-002;

            __statist_hidden_bias[5] = 4.84819905964142e-002;

            __statist_hidden_bias[6] = -1.15510348135648e-001;

            __statist_hidden_bias[7] = -5.01274660068397e-002;

            __statist_hidden_bias[8] = -1.00728498901541e-002;

            __statist_hidden_bias[9] = -6.46704079700090e-002;

            __statist_hidden_bias[10] = -9.58015688561350e-002;

            __statist_hidden_bias[11] = -5.20850289268913e-001;

            __statist_hidden_bias[12] = -2.53925919243948e-001;

            __statist_hidden_bias[13] = 4.88718893405634e-002;



            double[] __statist_output_bias = new double[2];

            __statist_output_bias[0] = -7.22694937821191e-001;

            __statist_output_bias[1] = 7.58565441602532e-001;



            double[] __statist_inputs = new double[114];



            double[] __statist_hidden = new double[14];



            double[] __statist_outputs = new double[2];

            __statist_outputs[0] = -1.0e+307;

            __statist_outputs[1] = -1.0e+307;





            if (Var4 == "0")
            {

                __statist_inputs[0] = 1;

            }

            else
            {

                __statist_inputs[0] = 0;

            }



            if (Var4 == "1")
            {

                __statist_inputs[1] = 1;

            }

            else
            {

                __statist_inputs[1] = 0;

            }



            if (Var4 == "10")
            {

                __statist_inputs[2] = 1;

            }

            else
            {

                __statist_inputs[2] = 0;

            }



            if (Var4 == "11")
            {

                __statist_inputs[3] = 1;

            }

            else
            {

                __statist_inputs[3] = 0;

            }



            if (Var4 == "12")
            {

                __statist_inputs[4] = 1;

            }

            else
            {

                __statist_inputs[4] = 0;

            }



            if (Var4 == "13")
            {

                __statist_inputs[5] = 1;

            }

            else
            {

                __statist_inputs[5] = 0;

            }



            if (Var4 == "14")
            {

                __statist_inputs[6] = 1;

            }

            else
            {

                __statist_inputs[6] = 0;

            }



            if (Var4 == "15")
            {

                __statist_inputs[7] = 1;

            }

            else
            {

                __statist_inputs[7] = 0;

            }



            if (Var4 == "16")
            {

                __statist_inputs[8] = 1;

            }

            else
            {

                __statist_inputs[8] = 0;

            }



            if (Var4 == "17")
            {

                __statist_inputs[9] = 1;

            }

            else
            {

                __statist_inputs[9] = 0;

            }



            if (Var4 == "18")
            {

                __statist_inputs[10] = 1;

            }

            else
            {

                __statist_inputs[10] = 0;

            }



            if (Var4 == "19")
            {

                __statist_inputs[11] = 1;

            }

            else
            {

                __statist_inputs[11] = 0;

            }



            if (Var4 == "2")
            {

                __statist_inputs[12] = 1;

            }

            else
            {

                __statist_inputs[12] = 0;

            }



            if (Var4 == "20")
            {

                __statist_inputs[13] = 1;

            }

            else
            {

                __statist_inputs[13] = 0;

            }



            if (Var4 == "21")
            {

                __statist_inputs[14] = 1;

            }

            else
            {

                __statist_inputs[14] = 0;

            }



            if (Var4 == "22")
            {

                __statist_inputs[15] = 1;

            }

            else
            {

                __statist_inputs[15] = 0;

            }



            if (Var4 == "23")
            {

                __statist_inputs[16] = 1;

            }

            else
            {

                __statist_inputs[16] = 0;

            }



            if (Var4 == "24")
            {

                __statist_inputs[17] = 1;

            }

            else
            {

                __statist_inputs[17] = 0;

            }



            if (Var4 == "25")
            {

                __statist_inputs[18] = 1;

            }

            else
            {

                __statist_inputs[18] = 0;

            }



            if (Var4 == "26")
            {

                __statist_inputs[19] = 1;

            }

            else
            {

                __statist_inputs[19] = 0;

            }



            if (Var4 == "27")
            {

                __statist_inputs[20] = 1;

            }

            else
            {

                __statist_inputs[20] = 0;

            }



            if (Var4 == "28")
            {

                __statist_inputs[21] = 1;

            }

            else
            {

                __statist_inputs[21] = 0;

            }



            if (Var4 == "29")
            {

                __statist_inputs[22] = 1;

            }

            else
            {

                __statist_inputs[22] = 0;

            }



            if (Var4 == "3")
            {

                __statist_inputs[23] = 1;

            }

            else
            {

                __statist_inputs[23] = 0;

            }



            if (Var4 == "30")
            {

                __statist_inputs[24] = 1;

            }

            else
            {

                __statist_inputs[24] = 0;

            }



            if (Var4 == "31")
            {

                __statist_inputs[25] = 1;

            }

            else
            {

                __statist_inputs[25] = 0;

            }



            if (Var4 == "32")
            {

                __statist_inputs[26] = 1;

            }

            else
            {

                __statist_inputs[26] = 0;

            }



            if (Var4 == "33")
            {

                __statist_inputs[27] = 1;

            }

            else
            {

                __statist_inputs[27] = 0;

            }



            if (Var4 == "34")
            {

                __statist_inputs[28] = 1;

            }

            else
            {

                __statist_inputs[28] = 0;

            }



            if (Var4 == "35")
            {

                __statist_inputs[29] = 1;

            }

            else
            {

                __statist_inputs[29] = 0;

            }



            if (Var4 == "36")
            {

                __statist_inputs[30] = 1;

            }

            else
            {

                __statist_inputs[30] = 0;

            }



            if (Var4 == "37")
            {

                __statist_inputs[31] = 1;

            }

            else
            {

                __statist_inputs[31] = 0;

            }



            if (Var4 == "38")
            {

                __statist_inputs[32] = 1;

            }

            else
            {

                __statist_inputs[32] = 0;

            }



            if (Var4 == "39")
            {

                __statist_inputs[33] = 1;

            }

            else
            {

                __statist_inputs[33] = 0;

            }



            if (Var4 == "4")
            {

                __statist_inputs[34] = 1;

            }

            else
            {

                __statist_inputs[34] = 0;

            }



            if (Var4 == "40")
            {

                __statist_inputs[35] = 1;

            }

            else
            {

                __statist_inputs[35] = 0;

            }



            if (Var4 == "41")
            {

                __statist_inputs[36] = 1;

            }

            else
            {

                __statist_inputs[36] = 0;

            }



            if (Var4 == "5")
            {

                __statist_inputs[37] = 1;

            }

            else
            {

                __statist_inputs[37] = 0;

            }



            if (Var4 == "6")
            {

                __statist_inputs[38] = 1;

            }

            else
            {

                __statist_inputs[38] = 0;

            }



            if (Var4 == "7")
            {

                __statist_inputs[39] = 1;

            }

            else
            {

                __statist_inputs[39] = 0;

            }



            if (Var4 == "8")
            {

                __statist_inputs[40] = 1;

            }

            else
            {

                __statist_inputs[40] = 0;

            }



            if (Var4 == "9")
            {

                __statist_inputs[41] = 1;

            }

            else
            {

                __statist_inputs[41] = 0;

            }



            if (Var6 == "0")
            {

                __statist_inputs[42] = 1;

            }

            else
            {

                __statist_inputs[42] = 0;

            }



            if (Var6 == "1")
            {

                __statist_inputs[43] = 1;

            }

            else
            {

                __statist_inputs[43] = 0;

            }



            if (Var6 == "2")
            {

                __statist_inputs[44] = 1;

            }

            else
            {

                __statist_inputs[44] = 0;

            }



            if (Var7 == "0")
            {

                __statist_inputs[45] = 1;

            }

            else
            {

                __statist_inputs[45] = 0;

            }



            if (Var7 == "1")
            {

                __statist_inputs[46] = 1;

            }

            else
            {

                __statist_inputs[46] = 0;

            }



            if (Var7 == "2")
            {

                __statist_inputs[47] = 1;

            }

            else
            {

                __statist_inputs[47] = 0;

            }



            if (Var8 == "0")
            {

                __statist_inputs[48] = 1;

            }

            else
            {

                __statist_inputs[48] = 0;

            }



            if (Var8 == "1")
            {

                __statist_inputs[49] = 1;

            }

            else
            {

                __statist_inputs[49] = 0;

            }



            if (Var8 == "2")
            {

                __statist_inputs[50] = 1;

            }

            else
            {

                __statist_inputs[50] = 0;

            }



            if (Var9 == "0")
            {

                __statist_inputs[51] = 1;

            }

            else
            {

                __statist_inputs[51] = 0;

            }



            if (Var9 == "1")
            {

                __statist_inputs[52] = 1;

            }

            else
            {

                __statist_inputs[52] = 0;

            }



            if (Var9 == "2")
            {

                __statist_inputs[53] = 1;

            }

            else
            {

                __statist_inputs[53] = 0;

            }



            if (Var10 == "0")
            {

                __statist_inputs[54] = 1;

            }

            else
            {

                __statist_inputs[54] = 0;

            }



            if (Var10 == "1")
            {

                __statist_inputs[55] = 1;

            }

            else
            {

                __statist_inputs[55] = 0;

            }



            if (Var10 == "2")
            {

                __statist_inputs[56] = 1;

            }

            else
            {

                __statist_inputs[56] = 0;

            }



            if (Var11 == "0")
            {

                __statist_inputs[57] = 1;

            }

            else
            {

                __statist_inputs[57] = 0;

            }



            if (Var11 == "1")
            {

                __statist_inputs[58] = 1;

            }

            else
            {

                __statist_inputs[58] = 0;

            }



            if (Var11 == "2")
            {

                __statist_inputs[59] = 1;

            }

            else
            {

                __statist_inputs[59] = 0;

            }



            if (Var12 == "0")
            {

                __statist_inputs[60] = 1;

            }

            else
            {

                __statist_inputs[60] = 0;

            }



            if (Var12 == "1")
            {

                __statist_inputs[61] = 1;

            }

            else
            {

                __statist_inputs[61] = 0;

            }



            if (Var12 == "2")
            {

                __statist_inputs[62] = 1;

            }

            else
            {

                __statist_inputs[62] = 0;

            }



            if (Var13 == "0")
            {

                __statist_inputs[63] = 1;

            }

            else
            {

                __statist_inputs[63] = 0;

            }



            if (Var13 == "1")
            {

                __statist_inputs[64] = 1;

            }

            else
            {

                __statist_inputs[64] = 0;

            }



            if (Var13 == "2")
            {

                __statist_inputs[65] = 1;

            }

            else
            {

                __statist_inputs[65] = 0;

            }



            if (Var14 == "0")
            {

                __statist_inputs[66] = 1;

            }

            else
            {

                __statist_inputs[66] = 0;

            }



            if (Var14 == "1")
            {

                __statist_inputs[67] = 1;

            }

            else
            {

                __statist_inputs[67] = 0;

            }



            if (Var14 == "2")
            {

                __statist_inputs[68] = 1;

            }

            else
            {

                __statist_inputs[68] = 0;

            }



            if (Var15 == "0")
            {

                __statist_inputs[69] = 1;

            }

            else
            {

                __statist_inputs[69] = 0;

            }



            if (Var15 == "1")
            {

                __statist_inputs[70] = 1;

            }

            else
            {

                __statist_inputs[70] = 0;

            }



            if (Var15 == "2")
            {

                __statist_inputs[71] = 1;

            }

            else
            {

                __statist_inputs[71] = 0;

            }



            if (Var16 == "0")
            {

                __statist_inputs[72] = 1;

            }

            else
            {

                __statist_inputs[72] = 0;

            }



            if (Var16 == "1")
            {

                __statist_inputs[73] = 1;

            }

            else
            {

                __statist_inputs[73] = 0;

            }



            if (Var16 == "2")
            {

                __statist_inputs[74] = 1;

            }

            else
            {

                __statist_inputs[74] = 0;

            }



            if (Var17 == "0")
            {

                __statist_inputs[75] = 1;

            }

            else
            {

                __statist_inputs[75] = 0;

            }



            if (Var17 == "1")
            {

                __statist_inputs[76] = 1;

            }

            else
            {

                __statist_inputs[76] = 0;

            }



            if (Var17 == "2")
            {

                __statist_inputs[77] = 1;

            }

            else
            {

                __statist_inputs[77] = 0;

            }



            if (Var19 == "0")
            {

                __statist_inputs[78] = 1;

            }

            else
            {

                __statist_inputs[78] = 0;

            }



            if (Var19 == "1")
            {

                __statist_inputs[79] = 1;

            }

            else
            {

                __statist_inputs[79] = 0;

            }



            if (Var19 == "2")
            {

                __statist_inputs[80] = 1;

            }

            else
            {

                __statist_inputs[80] = 0;

            }



            if (Var20 == "0")
            {

                __statist_inputs[81] = 1;

            }

            else
            {

                __statist_inputs[81] = 0;

            }



            if (Var20 == "1")
            {

                __statist_inputs[82] = 1;

            }

            else
            {

                __statist_inputs[82] = 0;

            }



            if (Var20 == "2")
            {

                __statist_inputs[83] = 1;

            }

            else
            {

                __statist_inputs[83] = 0;

            }



            if (Var21 == "0")
            {

                __statist_inputs[84] = 1;

            }

            else
            {

                __statist_inputs[84] = 0;

            }



            if (Var21 == "1")
            {

                __statist_inputs[85] = 1;

            }

            else
            {

                __statist_inputs[85] = 0;

            }



            if (Var21 == "2")
            {

                __statist_inputs[86] = 1;

            }

            else
            {

                __statist_inputs[86] = 0;

            }



            if (Var22 == "0")
            {

                __statist_inputs[87] = 1;

            }

            else
            {

                __statist_inputs[87] = 0;

            }



            if (Var22 == "1")
            {

                __statist_inputs[88] = 1;

            }

            else
            {

                __statist_inputs[88] = 0;

            }



            if (Var22 == "2")
            {

                __statist_inputs[89] = 1;

            }

            else
            {

                __statist_inputs[89] = 0;

            }



            if (Var23 == "0")
            {

                __statist_inputs[90] = 1;

            }

            else
            {

                __statist_inputs[90] = 0;

            }



            if (Var23 == "1")
            {

                __statist_inputs[91] = 1;

            }

            else
            {

                __statist_inputs[91] = 0;

            }



            if (Var23 == "2")
            {

                __statist_inputs[92] = 1;

            }

            else
            {

                __statist_inputs[92] = 0;

            }



            if (Var24 == "0")
            {

                __statist_inputs[93] = 1;

            }

            else
            {

                __statist_inputs[93] = 0;

            }



            if (Var24 == "1")
            {

                __statist_inputs[94] = 1;

            }

            else
            {

                __statist_inputs[94] = 0;

            }



            if (Var24 == "2")
            {

                __statist_inputs[95] = 1;

            }

            else
            {

                __statist_inputs[95] = 0;

            }



            if (Var25 == "0")
            {

                __statist_inputs[96] = 1;

            }

            else
            {

                __statist_inputs[96] = 0;

            }



            if (Var25 == "1")
            {

                __statist_inputs[97] = 1;

            }

            else
            {

                __statist_inputs[97] = 0;

            }



            if (Var25 == "2")
            {

                __statist_inputs[98] = 1;

            }

            else
            {

                __statist_inputs[98] = 0;

            }



            if (Var26 == "0")
            {

                __statist_inputs[99] = 1;

            }

            else
            {

                __statist_inputs[99] = 0;

            }



            if (Var26 == "1")
            {

                __statist_inputs[100] = 1;

            }

            else
            {

                __statist_inputs[100] = 0;

            }



            if (Var26 == "2")
            {

                __statist_inputs[101] = 1;

            }

            else
            {

                __statist_inputs[101] = 0;

            }



            if (Var27 == "0")
            {

                __statist_inputs[102] = 1;

            }

            else
            {

                __statist_inputs[102] = 0;

            }



            if (Var27 == "1")
            {

                __statist_inputs[103] = 1;

            }

            else
            {

                __statist_inputs[103] = 0;

            }



            if (Var27 == "2")
            {

                __statist_inputs[104] = 1;

            }

            else
            {

                __statist_inputs[104] = 0;

            }



            if (Var28 == "0")
            {

                __statist_inputs[105] = 1;

            }

            else
            {

                __statist_inputs[105] = 0;

            }



            if (Var28 == "1")
            {

                __statist_inputs[106] = 1;

            }

            else
            {

                __statist_inputs[106] = 0;

            }



            if (Var28 == "2")
            {

                __statist_inputs[107] = 1;

            }

            else
            {

                __statist_inputs[107] = 0;

            }



            if (Var29 == "0")
            {

                __statist_inputs[108] = 1;

            }

            else
            {

                __statist_inputs[108] = 0;

            }



            if (Var29 == "1")
            {

                __statist_inputs[109] = 1;

            }

            else
            {

                __statist_inputs[109] = 0;

            }



            if (Var29 == "2")
            {

                __statist_inputs[110] = 1;

            }

            else
            {

                __statist_inputs[110] = 0;

            }



            if (Var30 == "0")
            {

                __statist_inputs[111] = 1;

            }

            else
            {

                __statist_inputs[111] = 0;

            }



            if (Var30 == "1")
            {

                __statist_inputs[112] = 1;

            }

            else
            {

                __statist_inputs[112] = 0;

            }



            if (Var30 == "2")
            {

                __statist_inputs[113] = 1;

            }

            else
            {

                __statist_inputs[113] = 0;

            }



            double __statist_delta = 0;

            double __statist_maximum = 1;

            double __statist_minimum = 0;

            int __statist_ninputs = 114;

            int __statist_nhidden = 14;



            /*Compute feed forward signals from Input layer to hidden layer*/

            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                __statist_hidden[__statist_row] = 0.0;

                for (int __statist_col = 0; __statist_col < __statist_ninputs; __statist_col++)
                {

                    __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + (__statist_i_h_wts[__statist_row, __statist_col] * __statist_inputs[__statist_col]);

                }

                __statist_hidden[__statist_row] = __statist_hidden[__statist_row] + __statist_hidden_bias[__statist_row];

            }



            for (int __statist_row = 0; __statist_row < __statist_nhidden; __statist_row++)
            {

                if (__statist_hidden[__statist_row] > 100.0)
                {

                    __statist_hidden[__statist_row] = 1.0;

                }

                else
                {

                    __statist_hidden[__statist_row] = Math.Exp(__statist_hidden[__statist_row]);

                }

            }



            int __statist_noutputs = 2;



            /*Compute feed forward signals from hidden layer to output layer*/

            for (int __statist_row2 = 0; __statist_row2 < __statist_noutputs; __statist_row2++)
            {

                __statist_outputs[__statist_row2] = 0.0;

                for (int __statist_col2 = 0; __statist_col2 < __statist_nhidden; __statist_col2++)
                {

                    __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + (__statist_h_o_wts[__statist_row2, __statist_col2] * __statist_hidden[__statist_col2]);

                }

                __statist_outputs[__statist_row2] = __statist_outputs[__statist_row2] + __statist_output_bias[__statist_row2];

            }





            double __statist_sum = 0.0;

            double __statist_maxIndex = 0;

            for (int __statist_jj = 0; __statist_jj < __statist_noutputs; __statist_jj++)
            {

                if (__statist_outputs[__statist_jj] > 200)
                {

                    double __statist_max = __statist_outputs[1];

                    __statist_maxIndex = 0;

                    for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
                    {

                        if (__statist_outputs[__statist_ii] > __statist_max)
                        {

                            __statist_max = __statist_outputs[__statist_ii];

                            __statist_maxIndex = __statist_ii;

                        }

                    }



                    for (int __statist_kk = 0; __statist_kk < __statist_noutputs; __statist_kk++)
                    {

                        if (__statist_kk == __statist_maxIndex)
                        {

                            __statist_outputs[__statist_jj] = 1.0;

                        }

                        else
                        {

                            __statist_outputs[__statist_kk] = 0.0;

                        }

                    }

                }

                else
                {

                    __statist_outputs[__statist_jj] = Math.Exp(__statist_outputs[__statist_jj]);

                    __statist_sum = __statist_sum + __statist_outputs[__statist_jj];

                }

            }

            for (int __statist_ll = 0; __statist_ll < __statist_noutputs; __statist_ll++)
            {

                if (__statist_sum != 0)
                {

                    __statist_outputs[__statist_ll] = __statist_outputs[__statist_ll] / __statist_sum;

                }

            }



            int __statist_PredIndex = 1;

            for (int __statist_ii = 0; __statist_ii < __statist_noutputs; __statist_ii++)
            {

                if (__statist_ConfLevel < __statist_outputs[__statist_ii])
                {

                    __statist_ConfLevel = __statist_outputs[__statist_ii];

                    __statist_PredIndex = __statist_ii;

                }

            }



            __statist_PredCat = __statist_DCats[__statist_PredIndex];


            string[] prediction = new string[2] { __statist_PredCat, __statist_ConfLevel.ToString() };
            
            return prediction;
        }

        public static string[] Main(string[] args)
        {

            int argID = 0;

            string[] CatInputs = new string[26];

            int catID = 0;



            if (args.Length >= 25)
            {

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

                CatInputs[catID++] = args[argID++];

            }

            else
            {
                string Comment = "";

                string Comment1 = "**************************************************************************\n";

                Comment += Comment1;

                string Comment2 = "Please enter at least NaN command line parameters in the following order for \nthe program to Predict.\n";

                Comment += Comment2;

                Comment += Comment1;

                string Comment3 = "Var4  Type - String (categories are { \"0\"  \"1\"  \"10\"  \"11\"  \"12\"  \"13\"  \"14\"  \"15\"  \"16\"  \"17\"  \"18\"  \"19\"  \"2\"  \"20\"  \"21\"  \"22\"  \"23\"  \"24\"  \"25\"  \"26\"  \"27\"  \"28\"  \"29\"  \"3\"  \"30\"  \"31\"  \"32\"  \"33\"  \"34\"  \"35\"  \"36\"  \"37\"  \"38\"  \"39\"  \"4\"  \"40\"  \"41\"  \"5\"  \"6\"  \"7\"  \"8\"  \"9\" } )\n";

                Comment += Comment3;

                string Comment4 = "Var6  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment4;

                string Comment5 = "Var7  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment5;

                string Comment6 = "Var8  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment6;

                string Comment7 = "Var9  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment7;

                string Comment8 = "Var10  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment8;

                string Comment9 = "Var11  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment9;

                string Comment10 = "Var12  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment10;

                string Comment11 = "Var13  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment11;

                string Comment12 = "Var14  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment12;

                string Comment13 = "Var15  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment13;

                string Comment14 = "Var16  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment14;

                string Comment15 = "Var17  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment15;

                string Comment16 = "Var19  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment16;

                string Comment17 = "Var20  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment17;

                string Comment18 = "Var21  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment18;

                string Comment19 = "Var22  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment19;

                string Comment20 = "Var23  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment20;

                string Comment21 = "Var24  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment21;

                string Comment22 = "Var25  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment22;

                string Comment23 = "Var26  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment23;

                string Comment24 = "Var27  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment24;

                string Comment25 = "Var28  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment25;

                string Comment26 = "Var29  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment26;

                string Comment27 = "Var30  Type - String (categories are { \"0\"  \"1\"  \"2\" } )\n";

                Comment += Comment27;

                Comment += Comment1;

                return new string[] { Comment };

            }

            return MLP_114_14_2(CatInputs);
        }
    }
}
